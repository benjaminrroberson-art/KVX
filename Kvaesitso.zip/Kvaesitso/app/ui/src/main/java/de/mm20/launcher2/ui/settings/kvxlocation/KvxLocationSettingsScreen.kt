package de.mm20.launcher2.ui.settings.kvxlocation

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation3.runtime.NavKey
import de.mm20.launcher2.devicepose.KvxLocation
import de.mm20.launcher2.preferences.weather.WeatherSettings
import de.mm20.launcher2.ui.component.preferences.Preference
import de.mm20.launcher2.ui.component.preferences.PreferenceCategory
import de.mm20.launcher2.ui.component.preferences.PreferenceScreen
import de.mm20.launcher2.ui.component.preferences.SwitchPreference
import de.mm20.launcher2.ui.launcher.widgets.facesclock.WeatherPlacePicker
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializable
import org.koin.compose.koinInject

@Serializable
data object KvxLocationRoute : NavKey

@Composable
fun KvxLocationSettingsScreen() {
    val ctx = LocalContext.current
    var rev by remember { mutableIntStateOf(0) }
    @Suppress("UNUSED_EXPRESSION") rev
    val place = KvxLocation.place(ctx)
    val on = KvxLocation.isOn(ctx)
    val weatherSettings: WeatherSettings = koinInject()
    val scope = rememberCoroutineScope()
    var coords by remember { mutableStateOf(false) }

    fun changed() {
        rev++
        // Any weather settings change makes the weather refresh; zero the last update so it isn't skipped.
        scope.launch { weatherSettings.setLastUpdate(0L) }
    }

    PreferenceScreen(title = "Location") {
        item {
            PreferenceCategory("Fixed place") {
                @Suppress("UNUSED_EXPRESSION") rev
                SwitchPreference(
                    title = "Use a fixed place instead of GPS",
                    summary = if (place == null) "Pick a place below first"
                    else if (on) "Everything below uses " + place.name.ifBlank { "your place" } + " and nothing asks the phone for location"
                    else "Off. Features use the phone's location when they need it.",
                    value = on && place != null,
                    enabled = place != null,
                    onValueChanged = { KvxLocation.setOn(ctx, it); changed() },
                )
                WeatherPlacePicker(
                    name = place?.name ?: "",
                    detail = "",
                    onPick = { n, _, la, lo -> if (n.isNotBlank()) { KvxLocation.setPlace(ctx, n, la, lo); if (!KvxLocation.isOn(ctx)) KvxLocation.setOn(ctx, true); changed() } },
                    title = "Search for a place",
                    unset = "Not set",
                )
                Preference(
                    title = "Enter coordinates",
                    summary = if (place == null) "Type a latitude and longitude. Works fully offline." else "%.4f, %.4f".format(place.lat, place.lon),
                    onClick = { coords = true },
                )
            }
        }
        item {
            Text(
                "With the fixed place on, these use it: weather (the launcher provider and weather widgets), clock face weather, sunrise and sunset, nearby places, and the distance and compass on place results. A place picked inside a single widget still wins for that widget.\\n\\nSearching for a place sends the name you type to the Open-Meteo geocoding service. Entering coordinates sends nothing.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
            )
        }
    }

    if (coords) {
        var name by remember { mutableStateOf(place?.name ?: "") }
        var lat by remember { mutableStateOf(place?.lat?.toString() ?: "") }
        var lon by remember { mutableStateOf(place?.lon?.toString() ?: "") }
        val la = lat.trim().toDoubleOrNull()
        val lo = lon.trim().toDoubleOrNull()
        val valid = la != null && lo != null && la in -90.0..90.0 && lo in -180.0..180.0
        AlertDialog(
            onDismissRequest = { coords = false },
            title = { Text("Enter coordinates") },
            text = {
                Column {
                    OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true, label = { Text("Name (optional)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = lat, onValueChange = { lat = it }, singleLine = true, label = { Text("Latitude, for example 36.16") }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
                    OutlinedTextField(value = lon, onValueChange = { lon = it }, singleLine = true, label = { Text("Longitude, for example -86.78") }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
                }
            },
            confirmButton = {
                TextButton(
                    enabled = valid,
                    onClick = {
                        KvxLocation.setPlace(ctx, name.trim().ifBlank { "My place" }, la!!, lo!!)
                        KvxLocation.setOn(ctx, true)
                        coords = false
                        changed()
                    },
                ) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { coords = false }) { Text("Cancel") } },
        )
    }
}
