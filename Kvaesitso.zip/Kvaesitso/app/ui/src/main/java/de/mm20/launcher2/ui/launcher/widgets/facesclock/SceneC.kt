package de.mm20.launcher2.ui.launcher.widgets.facesclock

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

// ---------------------------------------------------------------- Zen sand garden

internal class SandScene(c: Context) : Scene(c) {
    override val grabs = true
    private var gw = 0
    private var gh = 0
    private var hm = FloatArray(0)
    private var grain = ByteArray(0)
    private var pix = IntArray(0)
    private var bmp: Bitmap? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var lastX = -1f
    private var lastY = -1f
    private var rocksFor = -1
    private val rf = RectF()
    private val rx = floatArrayOf(0.22f, 0.62f, 0.82f, 0.4f, 0.1f, 0.7f, 0.5f, 0.9f, 0.3f, 0.55f)
    private val ry = floatArrayOf(0.5f, 0.3f, 0.7f, 0.78f, 0.2f, 0.82f, 0.15f, 0.25f, 0.2f, 0.55f)
    private val rs = floatArrayOf(0.1f, 0.07f, 0.09f, 0.06f, 0.05f, 0.05f, 0.04f, 0.05f, 0.045f, 0.04f)

    private fun setup(e: SceneEnv) {
        gw = max(60, (e.w / (3f * e.dp)).toInt())
        gh = max(30, (e.h / (3f * e.dp)).toInt())
        hm = FloatArray(gw * gh)
        pix = IntArray(gw * gh)
        val r = java.util.Random(9)
        grain = ByteArray(gw * gh) { (r.nextInt(7) - 3).toByte() }
        bmp = Bitmap.createBitmap(gw, gh, Bitmap.Config.ARGB_8888)
        rocksFor = -1
    }

    private fun rings(e: SceneEnv) {
        for (i in 0 until hm.size) hm[i] = 0f
        // gentle parallel lines
        for (y in 0 until gh) if (y % 4 == 0) for (x in 0 until gw) hm[y * gw + x] = -0.8f
        val cnt = min(e.amount.coerceIn(1, 10), 10)
        for (k in 0 until cnt) {
            val cx = rx[k] * gw
            val cy = ry[k] * gh
            val rr = rs[k] * gh * 2.2f
            for (y in 0 until gh) for (x in 0 until gw) {
                val d = hypot(x - cx, (y - cy) * 1.0f)
                if (d < rr + 14f) {
                    val ring = ((d - rr) / 3.2f)
                    hm[y * gw + x] = if (d < rr) 0f else if (abs(ring - Math.round(ring)) < 0.28f) -0.8f else 0f
                }
            }
        }
        rocksFor = e.amount
    }

    private fun groove(cx: Float, cy: Float, dx: Float, dy: Float) {
        val l = max(0.001f, hypot(dx, dy))
        val nx = -dy / l
        val ny = dx / l
        for (k in -2..2) {
            val x = cx + nx * k * 3.2f
            val y = cy + ny * k * 3.2f
            val ix = x.toInt()
            val iy = y.toInt()
            if (ix in 1 until gw - 1 && iy in 1 until gh - 1) {
                hm[iy * gw + ix] = -1f
                val ax = (x + nx * 1.6f).toInt(); val ay = (y + ny * 1.6f).toInt()
                val bx = (x - nx * 1.6f).toInt(); val by = (y - ny * 1.6f).toInt()
                if (ax in 0 until gw && ay in 0 until gh) hm[ay * gw + ax] = max(hm[ay * gw + ax], 0.7f)
                if (bx in 0 until gw && by in 0 until gh) hm[by * gw + bx] = max(hm[by * gw + bx], 0.7f)
            }
        }
    }

    private fun rake(x0: Float, y0: Float, x1: Float, y1: Float, e: SceneEnv) {
        if (gw == 0) return
        val ax = x0 / e.w * gw
        val ay = y0 / e.h * gh
        val bx = x1 / e.w * gw
        val by = y1 / e.h * gh
        val d = hypot(bx - ax, by - ay)
        val n = max(1, (d * 1.6f).toInt())
        for (i in 0..n) {
            val f = i / n.toFloat()
            groove(lerpF(ax, bx, f), lerpF(ay, by, f), bx - ax, by - ay)
        }
    }

    override fun down(x: Float, y: Float, e: SceneEnv) { lastX = x; lastY = y }
    override fun move(x: Float, y: Float, e: SceneEnv) {
        if (lastX >= 0f && hypot(x - lastX, y - lastY) > 1f) rake(lastX, lastY, x, y, e)
        lastX = x; lastY = y
    }
    override fun up(x: Float, y: Float, e: SceneEnv, tap: Boolean) { lastX = -1f }

    override fun draw(c: Canvas, e: SceneEnv) {
        if (bmp == null || abs(gw - max(60, (e.w / (3f * e.dp)).toInt())) > 1) setup(e)
        if (rocksFor != e.amount) rings(e)
        val dim = 0.62f + 0.38f * e.day
        val sand = if (e.useColor) e.custom else 0xFFE6D3A8.toInt()
        val sr = Color.red(sand)
        val sg = Color.green(sand)
        val sb = Color.blue(sand)
        for (y in 0 until gh) for (x in 0 until gw) {
            val i = y * gw + x
            val l = if (x > 0) hm[i - 1] else hm[i]
            val r = if (x < gw - 1) hm[i + 1] else hm[i]
            val shade = (0.92f + (l - r) * 0.18f + hm[i] * 0.06f + grain[i] * 0.012f) * dim
            val rr = (sr * shade).toInt().coerceIn(0, 255)
            val gg = (sg * shade).toInt().coerceIn(0, 255)
            val bb = (sb * shade).toInt().coerceIn(0, 255)
            pix[i] = (0xFF shl 24) or (rr shl 16) or (gg shl 8) or bb
            hm[i] *= 1f - e.dt * 0.012f
        }
        val b = bmp ?: return
        b.setPixels(pix, 0, gw, 0, 0, gw, gh)
        p.isFilterBitmap = true
        rf.set(0f, 0f, e.w, e.h)
        c.drawBitmap(b, null, rf, p)
        // rocks
        val cnt = min(e.amount.coerceIn(1, 10), 10)
        for (k in 0 until cnt) {
            val cx = rx[k] * e.w
            val cy = ry[k] * e.h
            val r = rs[k] * e.h * 2.2f
            p.color = alC(Color.BLACK, 0.3f * dim)
            c.drawOval(cx - r * 0.95f + r * 0.2f, cy - r * 0.6f + r * 0.3f, cx + r * 0.95f + r * 0.2f, cy + r * 0.6f + r * 0.35f, p)
            p.shader = RadialGradient(cx - r * 0.3f, cy - r * 0.3f, r * 1.3f, mixC(0xFF8B8B90.toInt(), Color.BLACK, 1f - dim), mixC(0xFF3A3A40.toInt(), Color.BLACK, 1f - dim), Shader.TileMode.CLAMP)
            c.drawOval(cx - r, cy - r * 0.65f, cx + r, cy + r * 0.65f, p)
            p.shader = null
        }
        if (e.t < 4f) {
            p.color = alC(Color.BLACK, 0.45f * (1f - e.t / 4f))
            p.textSize = 11f * e.dp
            c.drawText("Drag to rake the sand", 10f * e.dp, e.h - 10f * e.dp, p)
        }
    }
}

// ---------------------------------------------------------------- Snow globe

internal class GlobeScene(c: Context) : Scene(c) {
    override val needsTilt = true
    override val grabs = true
    private var f = FloatArray(0)
    private var cnt = -1
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private var px = -1f
    private var py = -1f
    private var pvx = 0f
    private var pvy = 0f
    private var lastShake = 0f

    private fun build(e: SceneEnv) {
        cnt = e.amount
        val n = 50 + e.amount * 22
        f = FloatArray(n * 5)
        for (i in 0 until n) {
            f[i * 5] = e.rr(-1f, 1f); f[i * 5 + 1] = e.rr(-1f, 0.6f)
            f[i * 5 + 2] = 0f; f[i * 5 + 3] = 0f; f[i * 5 + 4] = e.rr(0.8f, 2.2f)
        }
    }

    private fun stir(power: Float, e: SceneEnv) {
        for (i in 0 until f.size / 5) {
            f[i * 5 + 2] += e.rr(-1f, 1f) * power
            f[i * 5 + 3] += e.rr(-1.2f, 0.4f) * power
        }
    }

    override fun down(x: Float, y: Float, e: SceneEnv) { px = x; py = y; pvx = 0f; pvy = 0f }
    override fun move(x: Float, y: Float, e: SceneEnv) { pvx = x - px; pvy = y - py; px = x; py = y }
    override fun up(x: Float, y: Float, e: SceneEnv, tap: Boolean) { px = -1f; if (tap) stir(1.4f, e) }

    override fun draw(c: Canvas, e: SceneEnv) {
        if (cnt != e.amount) build(e)
        val w = e.w
        val h = e.h
        val dp = e.dp
        val R = min(w * 0.46f, h * 0.4f)
        val cx = w / 2f
        val cy = h * 0.46f
        p.color = mixC(0xFF0B0F1C.toInt(), 0xFF1A2236.toInt(), 0.5f + 0.5f * e.day)
        c.drawRect(0f, 0f, w, h, p)
        // inside
        c.save()
        path.reset(); path.addCircle(cx, cy, R, Path.Direction.CW)
        c.clipPath(path)
        val skyTop = if (e.useColor) mixC(e.custom, Color.BLACK, 0.6f) else mixC(0xFF0E1A3D.toInt(), 0xFF5D91C9.toInt(), e.day)
        val skyBot = if (e.useColor) mixC(e.custom, Color.BLACK, 0.3f) else mixC(0xFF2A3A6B.toInt(), 0xFFBFD9F2.toInt(), e.day)
        p.shader = LinearGradient(0f, cy - R, 0f, cy + R, skyTop, skyBot, Shader.TileMode.CLAMP)
        c.drawRect(cx - R, cy - R, cx + R, cy + R, p)
        p.shader = null
        // ground
        p.color = 0xFFEFF3F8.toInt()
        c.drawOval(cx - R * 1.3f, cy + R * 0.55f, cx + R * 1.3f, cy + R * 1.6f, p)
        // house
        val hx = cx - R * 0.15f
        val hy = cy + R * 0.58f
        p.color = 0xFF8A4B2A.toInt()
        c.drawRect(hx - R * 0.2f, hy - R * 0.2f, hx + R * 0.2f, hy, p)
        p.color = 0xFF5A2E1A.toInt()
        path.reset(); path.moveTo(hx - R * 0.26f, hy - R * 0.2f); path.lineTo(hx, hy - R * 0.42f); path.lineTo(hx + R * 0.26f, hy - R * 0.2f); path.close()
        c.drawPath(path, p)
        p.color = alC(0xFFFFD27A.toInt(), 0.7f + 0.3f * sin(e.t * 7f))
        c.drawRect(hx - R * 0.05f, hy - R * 0.14f, hx + R * 0.07f, hy - R * 0.04f, p)
        // pines
        for (t in 0 until 3) {
            val tx = cx + R * (0.28f + t * 0.13f)
            val ty = hy + (t % 2) * R * 0.04f
            p.color = 0xFF14472C.toInt()
            for (l in 0 until 3) {
                path.reset()
                path.moveTo(tx - R * (0.12f - l * 0.02f), ty - l * R * 0.1f)
                path.lineTo(tx, ty - R * 0.2f - l * R * 0.1f)
                path.lineTo(tx + R * (0.12f - l * 0.02f), ty - l * R * 0.1f)
                path.close()
                c.drawPath(path, p)
            }
            p.color = alC(Color.WHITE, 0.85f)
            c.drawCircle(tx, ty - R * 0.46f, R * 0.02f, p)
        }
        // flakes
        if (e.shake > 0.25f && e.shake > lastShake) stir(e.shake * 2.2f, e)
        lastShake = e.shake
        val n = f.size / 5
        val gx = e.tx * 1.1f
        val col = if (e.useColor) mixC(e.custom, Color.WHITE, 0.7f) else Color.WHITE
        p.color = col
        for (i in 0 until n) {
            val o = i * 5
            var x = f[o]
            var y = f[o + 1]
            var vx = f[o + 2]
            var vy = f[o + 3]
            vy += (0.22f + e.rr(-0.02f, 0.02f)) * e.dt * 1.0f
            vx += gx * 0.25f * e.dt + sin(e.t * 1.3f + i) * 0.03f * e.dt
            vx *= 1f - 1.8f * e.dt
            vy *= 1f - 1.4f * e.dt
            if (px >= 0f) {
                val fx = (px - cx) / R
                val fy = (py - cy) / R
                val d = hypot(x - fx, y - fy)
                if (d < 0.35f) { vx += pvx / R * 0.8f * (1f - d / 0.35f); vy += pvy / R * 0.8f * (1f - d / 0.35f) }
            }
            x += vx * e.dt * 2f
            y += vy * e.dt * 2f
            val floor = 0.72f - 0.25f * (x * x)
            if (y > floor) { y = floor; vy = 0f; vx *= 0.7f }
            val d = hypot(x, y)
            if (d > 0.97f) { x *= 0.97f / d; y *= 0.97f / d; vx *= 0.5f; vy *= 0.5f }
            f[o] = x; f[o + 1] = y; f[o + 2] = vx; f[o + 3] = vy
            c.drawCircle(cx + x * R, cy + y * R, f[o + 4] * dp, p)
        }
        c.restore()
        // glass
        p.shader = RadialGradient(cx - R * 0.4f, cy - R * 0.45f, R * 1.2f, alC(Color.WHITE, 0.22f), 0x00FFFFFF, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, R, p)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2f * dp
        p.color = alC(Color.WHITE, 0.45f)
        c.drawCircle(cx, cy, R, p)
        p.style = Paint.Style.FILL
        // base
        path.reset()
        path.moveTo(cx - R * 0.6f, cy + R * 0.9f); path.lineTo(cx + R * 0.6f, cy + R * 0.9f)
        path.lineTo(cx + R * 0.85f, cy + R * 1.18f); path.lineTo(cx - R * 0.85f, cy + R * 1.18f); path.close()
        p.color = 0xFF5B3A22.toInt()
        c.drawPath(path, p)
        p.color = 0xFFC9A24A.toInt()
        c.drawRect(cx - R * 0.5f, cy + R * 1.02f, cx + R * 0.5f, cy + R * 1.06f, p)
    }
}

// ---------------------------------------------------------------- Campfire

internal class FireScene(c: Context) : Scene(c) {
    override val needsAudio = true
    override val needsTilt = true
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val add = Paint(Paint.ANTI_ALIAS_FLAG).apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.ADD) }
    private val path = Path()
    // x, y, vx, vy, life, max, size, kind(0 flame,1 spark,2 smoke)
    private val parts = ArrayList<FloatArray>()
    private val srnd = java.util.Random(4)
    private val sx = FloatArray(60) { srnd.nextFloat() }
    private val sy = FloatArray(60) { srnd.nextFloat() * 0.55f }
    private var acc = 0f
    private var stirT = 0f

    override fun up(x: Float, y: Float, e: SceneEnv, tap: Boolean) { if (tap) stirT = 1.2f }

    override fun draw(c: Canvas, e: SceneEnv) {
        val w = e.w
        val h = e.h
        val dp = e.dp
        val size = 0.6f + e.amount * 0.12f
        p.shader = LinearGradient(0f, 0f, 0f, h, 0xFF05060E.toInt(), mixC(0xFF140C10.toInt(), 0xFF2A140E.toInt(), 0.5f), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, p)
        p.shader = null
        for (i in sx.indices) {
            p.color = alC(Color.WHITE, 0.3f + 0.3f * sin(e.t * 1.5f + i))
            c.drawCircle(sx[i] * w, sy[i] * h, 1f * dp, p)
        }
        // hills
        p.color = 0xFF0A0B10.toInt()
        path.reset(); path.moveTo(0f, h); path.lineTo(0f, h * 0.78f)
        path.quadTo(w * 0.25f, h * 0.7f, w * 0.5f, h * 0.82f)
        path.quadTo(w * 0.8f, h * 0.7f, w, h * 0.78f); path.lineTo(w, h); path.close()
        c.drawPath(path, p)
        val bx = w / 2f
        val by = h * 0.86f
        val flick = 0.85f + 0.15f * sin(e.t * 13f) * sin(e.t * 7.3f)
        val fireCol = if (e.useColor) e.custom else 0xFFFF8A2A.toInt()
        val glowR = (90f + 90f * size) * dp * (flick + e.level * 0.4f)
        p.shader = RadialGradient(bx, by - 20f * dp, glowR, alC(fireCol, 0.38f), 0x00000000, Shader.TileMode.CLAMP)
        c.drawCircle(bx, by - 20f * dp, glowR, p)
        p.shader = null
        // logs
        c.save()
        c.translate(bx, by)
        p.color = 0xFF3A2416.toInt()
        c.rotate(-12f); c.drawRoundRect(-48f * dp, -4f * dp, 48f * dp, 7f * dp, 4f * dp, 4f * dp, p)
        c.rotate(24f); c.drawRoundRect(-48f * dp, -4f * dp, 48f * dp, 7f * dp, 4f * dp, 4f * dp, p)
        c.restore()
        p.shader = RadialGradient(bx, by, 40f * dp, alC(0xFFFF5A1A.toInt(), 0.7f), 0x00000000, Shader.TileMode.CLAMP)
        c.drawCircle(bx, by, 40f * dp, p)
        p.shader = null
        // spawn
        stirT = max(0f, stirT - e.dt)
        val energy = 1f + (if (e.dance) e.level * 1.8f + e.beat * 1.2f else 0f) + stirT * 1.5f
        acc += e.dt * 90f * size * energy
        while (acc >= 1f && parts.size < 420) {
            acc -= 1f
            val k = e.rf()
            if (k < 0.07f) parts.add(floatArrayOf(bx + e.rr(-26f, 26f) * dp * size, by - 4f * dp, e.rr(-30f, 30f) * dp, -e.rr(60f, 150f) * dp * energy, 0f, e.rr(0.8f, 1.8f), e.rr(1f, 2f) * dp, 1f))
            else if (k < 0.1f) parts.add(floatArrayOf(bx + e.rr(-10f, 10f) * dp, by - 60f * dp * size, 0f, -e.rr(15f, 30f) * dp, 0f, e.rr(1.5f, 3f), e.rr(12f, 22f) * dp, 2f))
            else parts.add(floatArrayOf(bx + e.rr(-24f, 24f) * dp * size, by - 2f * dp, e.rr(-8f, 8f) * dp, -e.rr(55f, 105f) * dp * energy, 0f, e.rr(0.5f, 1.0f), e.rr(9f, 17f) * dp * size, 0f))
        }
        acc = min(acc, 3f)
        val it = parts.iterator()
        while (it.hasNext()) {
            val q = it.next()
            q[4] += e.dt
            if (q[4] >= q[5]) { it.remove(); continue }
            val f = q[4] / q[5]
            q[2] += (e.tx * 40f * dp + sin(e.t * 3f + q[0] * 0.05f) * 14f * dp) * e.dt
            q[0] += q[2] * e.dt
            q[1] += q[3] * e.dt
            if (q[7] == 0f) {
                val r = q[6] * (1f - f * 0.85f)
                val col = mixC(mixC(0xFFFFF4B0.toInt(), fireCol, f * 1.6f), 0xFFC0200A.toInt(), max(0f, f - 0.5f) * 1.6f)
                add.color = alC(col, (1f - f) * 0.55f)
                c.drawCircle(q[0], q[1], r, add)
            } else if (q[7] == 1f) {
                add.color = alC(0xFFFFC24A.toInt(), 1f - f)
                c.drawCircle(q[0], q[1], q[6], add)
            } else {
                p.color = alC(0xFF8A8A94.toInt(), (1f - f) * 0.06f)
                c.drawCircle(q[0], q[1], q[6] * (1f + f * 2f), p)
            }
        }
    }
}

// ---------------------------------------------------------------- Newton's cradle

internal class CradleScene(c: Context) : Scene(c) {
    override val needsTilt = true
    override val grabs = true
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var n = -1
    private var th = FloatArray(0)
    private var om = FloatArray(0)
    private var held = -1
    private var restT = 0f
    private var L = 1f
    private var gap = 1f
    private var x0 = 0f
    private var topY = 0f
    private var ballR = 1f

    private fun build(e: SceneEnv) {
        n = e.amount.coerceIn(3, 10)
        th = FloatArray(n)
        om = FloatArray(n)
        th[0] = -0.7f
    }

    private fun ballX(i: Int) = x0 + i * gap + L * sin(th[i])
    private fun ballY(i: Int) = topY + L * cos(th[i])

    override fun down(x: Float, y: Float, e: SceneEnv) {
        if (n <= 0) return
        var best = -1
        var bd = 1e9f
        for (i in 0 until n) {
            val d = hypot(ballX(i) - x, ballY(i) - y)
            if (d < bd) { bd = d; best = i }
        }
        if (bd < ballR * 3f) held = best
    }

    override fun move(x: Float, y: Float, e: SceneEnv) {
        if (held < 0) return
        val a = kotlin.math.atan2(x - (x0 + held * gap), max(10f, y - topY))
        th[held] = a.coerceIn(-1.2f, 1.2f)
        om[held] = 0f
    }

    override fun up(x: Float, y: Float, e: SceneEnv, tap: Boolean) { held = -1; restT = 0f }

    override fun draw(c: Canvas, e: SceneEnv) {
        if (n != e.amount.coerceIn(3, 10)) build(e)
        val w = e.w
        val h = e.h
        val dp = e.dp
        ballR = min(w / (n * 2.3f), h * 0.09f)
        gap = ballR * 2f
        L = h * 0.5f
        x0 = (w - gap * (n - 1)) / 2f
        topY = h * 0.14f
        val g = 9f / (L / dp) * 40f * (L / dp) / 40f
        val grav = 28f * dp / L * 3f
        val tilt = e.tx * 0.5f
        val steps = 6
        val dt = min(0.033f, e.dt) / steps
        for (s in 0 until steps) {
            for (i in 0 until n) {
                if (i == held) continue
                om[i] += -grav * sin(th[i] - tilt) * dt - om[i] * 0.08f * dt
                th[i] += om[i] * dt
            }
            for (i in 0 until n - 1) {
                val dx = ballX(i + 1) - ballX(i)
                if (dx < gap) {
                    val tmp = om[i]
                    if (i != held && i + 1 != held) { om[i] = om[i + 1]; om[i + 1] = tmp }
                    else if (i == held) { om[i + 1] = max(om[i + 1], 0.5f) }
                    // push apart
                    val push = (gap - dx) / L * 0.5f
                    if (i != held) th[i] -= push
                    if (i + 1 != held) th[i + 1] += push
                }
            }
        }
        // restart when still
        var mv = 0f
        for (i in 0 until n) mv += abs(om[i]) + abs(th[i] - tilt)
        if (held < 0 && mv < 0.15f) { restT += e.dt; if (restT > 2f) { th[0] = -0.7f; restT = 0f } } else restT = 0f
        // draw
        p.shader = LinearGradient(0f, 0f, 0f, h, mixC(0xFF11141C.toInt(), 0xFF2C3446.toInt(), 0.5f + 0.5f * e.day), mixC(0xFF080A10.toInt(), 0xFF181D29.toInt(), 0.5f + 0.5f * e.day), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, p)
        p.shader = null
        // table
        p.color = 0xFF3B2A1C.toInt()
        c.drawRect(0f, topY + L + ballR * 2.2f, w, h, p)
        // frame
        p.color = 0xFFB8BCC6.toInt()
        c.drawRoundRect(x0 - gap, topY - 6f * dp, x0 + gap * n, topY, 3f * dp, 3f * dp, p)
        p.strokeWidth = 5f * dp
        c.drawLine(x0 - gap * 0.7f, topY - 3f * dp, x0 - gap * 0.7f, topY + L + ballR * 2.2f, p)
        c.drawLine(x0 + gap * (n - 0.3f), topY - 3f * dp, x0 + gap * (n - 0.3f), topY + L + ballR * 2.2f, p)
        p.strokeWidth = 1.2f * dp
        for (i in 0 until n) {
            val bx = ballX(i)
            val by = ballY(i)
            p.color = alC(Color.WHITE, 0.55f)
            c.drawLine(x0 + i * gap, topY, bx, by, p)
            p.color = alC(Color.BLACK, 0.25f)
            c.drawOval(bx - ballR, topY + L + ballR * 1.8f, bx + ballR, topY + L + ballR * 2.2f, p)
            val base = if (e.useColor) e.custom else 0xFFC9CFDA.toInt()
            p.shader = RadialGradient(bx - ballR * 0.35f, by - ballR * 0.35f, ballR * 1.5f, Color.WHITE, mixC(base, Color.BLACK, 0.55f), Shader.TileMode.CLAMP)
            c.drawCircle(bx, by, ballR, p)
            p.shader = null
        }
    }
}

// ---------------------------------------------------------------- Firefly jar

internal class JarScene(c: Context) : Scene(c) {
    override val needsTilt = true
    override val grabs = false
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val add = Paint(Paint.ANTI_ALIAS_FLAG).apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.ADD) }
    private val path = Path()
    // x, y (jar-local -1..1), vx, vy, phase, period
    private var f = FloatArray(0)
    private var cnt = -1
    private var flash = 0f
    private var lastShake = 0f
    private val rf = RectF()

    private fun build(e: SceneEnv) {
        cnt = e.amount
        val n = 4 + e.amount * 2
        f = FloatArray(n * 6)
        for (i in 0 until n) {
            f[i * 6] = e.rr(-0.7f, 0.7f); f[i * 6 + 1] = e.rr(-0.7f, 0.7f)
            f[i * 6 + 4] = e.rr(0f, 6f); f[i * 6 + 5] = e.rr(2f, 5f)
        }
    }

    override fun up(x: Float, y: Float, e: SceneEnv, tap: Boolean) {
        if (tap) { flash = 1f; for (i in 0 until f.size / 6) { f[i * 6 + 2] += e.rr(-1f, 1f) * 0.5f; f[i * 6 + 3] += e.rr(-1f, 1f) * 0.5f } }
    }

    override fun draw(c: Canvas, e: SceneEnv) {
        if (cnt != e.amount) build(e)
        val w = e.w
        val h = e.h
        val dp = e.dp
        val night = 1f - e.day * 0.7f
        p.shader = LinearGradient(0f, 0f, 0f, h, mixC(0xFF0A1220.toInt(), 0xFF040608.toInt(), night), mixC(0xFF11200F.toInt(), 0xFF070B06.toInt(), night), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, p)
        p.shader = null
        val jh = h * 0.86f
        val jw = min(w * 0.8f, jh * 0.7f)
        val cx = w / 2f
        val top = h * 0.07f
        val jt = top + jh * 0.14f
        val jb = top + jh
        val col = if (e.useColor) e.custom else 0xFFC8FF3A.toInt()
        // outer soft glow from the flies
        var glowSum = 0f
        for (i in 0 until f.size / 6) glowSum += max(0f, sin(f[i * 6 + 4] * 6.28f / f[i * 6 + 5]))
        val glow = (glowSum / (f.size / 6)).coerceIn(0f, 1f) + flash * 0.6f
        p.shader = RadialGradient(cx, (jt + jb) / 2f, max(w, h) * 0.8f, alC(col, 0.1f + glow * 0.18f), 0x00000000, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, p)
        p.shader = null
        // jar body
        rf.set(cx - jw / 2f, jt, cx + jw / 2f, jb)
        p.color = alC(0xFF9FB4C8.toInt(), 0.1f)
        c.drawRoundRect(rf, jw * 0.18f, jw * 0.18f, p)
        // grass at the bottom
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.6f * dp
        p.color = alC(0xFF3F7A2E.toInt(), 0.7f)
        for (i in 0 until 14) {
            val gx = cx - jw * 0.4f + jw * 0.8f * i / 13f
            c.drawLine(gx, jb - 3f * dp, gx + sin(i * 2f) * 6f * dp, jb - 18f * dp - (i % 3) * 5f * dp, p)
        }
        p.style = Paint.Style.FILL
        // flies
        if (e.shake > 0.25f && e.shake > lastShake) { flash = 1f; for (i in 0 until f.size / 6) { f[i * 6 + 2] += e.rr(-1f, 1f) * e.shake; f[i * 6 + 3] += e.rr(-1f, 1f) * e.shake } }
        lastShake = e.shake
        flash = max(0f, flash - e.dt * 1.2f)
        val n = f.size / 6
        for (i in 0 until n) {
            val o = i * 6
            f[o + 2] += (e.rr(-1f, 1f) * 0.9f + e.tx * 0.2f) * e.dt
            f[o + 3] += (e.rr(-1f, 1f) * 0.9f - 0.05f) * e.dt
            f[o + 2] *= 1f - 0.9f * e.dt
            f[o + 3] *= 1f - 0.9f * e.dt
            f[o] += f[o + 2] * e.dt * 0.6f
            f[o + 1] += f[o + 3] * e.dt * 0.6f
            f[o] = f[o].coerceIn(-0.85f, 0.85f)
            f[o + 1] = f[o + 1].coerceIn(-0.85f, 0.8f)
            f[o + 4] += e.dt
            val b = max(0f, sin(f[o + 4] * 6.28f / f[o + 5]))
            val a = min(1f, b * b + flash * 0.8f)
            val fx = cx + f[o] * jw * 0.46f
            val fy = (jt + jb) / 2f + f[o + 1] * (jb - jt) * 0.46f
            if (a > 0.02f) {
                add.shader = RadialGradient(fx, fy, 18f * dp, alC(col, a * 0.8f), 0x00000000, Shader.TileMode.CLAMP)
                c.drawCircle(fx, fy, 18f * dp, add)
                add.shader = null
            }
            p.color = alC(mixC(col, Color.WHITE, 0.6f), 0.25f + a * 0.75f)
            c.drawCircle(fx, fy, 1.5f * dp, p)
        }
        // jar rim, lid, highlights
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2f * dp
        p.color = alC(Color.WHITE, 0.4f)
        c.drawRoundRect(rf, jw * 0.18f, jw * 0.18f, p)
        p.style = Paint.Style.FILL
        p.color = alC(Color.WHITE, 0.1f)
        c.drawRoundRect(cx - jw * 0.38f, jt + jh * 0.08f, cx - jw * 0.3f, jb - jh * 0.12f, 4f * dp, 4f * dp, p)
        p.color = 0xFF6B7078.toInt()
        c.drawRoundRect(cx - jw * 0.36f, top, cx + jw * 0.36f, jt + 2f * dp, 5f * dp, 5f * dp, p)
        p.color = 0xFF8A8F98.toInt()
        c.drawRect(cx - jw * 0.36f, top + 4f * dp, cx + jw * 0.36f, top + 7f * dp, p)
    }
}
