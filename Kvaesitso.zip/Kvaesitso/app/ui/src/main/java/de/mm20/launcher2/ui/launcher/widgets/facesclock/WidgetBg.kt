package de.mm20.launcher2.ui.launcher.widgets.facesclock

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.foundation.layout.Column
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import de.mm20.launcher2.ui.component.preferences.SliderPreference
import de.mm20.launcher2.ui.component.preferences.SwitchPreference
import java.util.UUID

/** Per-widget card background opacity. -1 means "use the launcher's default". */
object KvxWidgetBg {
    private fun sp(c: Context) = c.applicationContext.getSharedPreferences("kvx_widget_bg", Context.MODE_PRIVATE)
    fun get(c: Context, id: UUID): Int = sp(c).getInt(id.toString(), -1)
    fun set(c: Context, id: UUID, v: Int) { sp(c).edit().putInt(id.toString(), v).apply() }
    internal fun prefs(c: Context): SharedPreferences = sp(c)
}

/** Live value: follows changes made in settings or the widget sheet. */
@Composable
fun rememberWidgetBg(id: UUID): Int {
    val ctx = LocalContext.current
    var v by remember(id) { mutableIntStateOf(KvxWidgetBg.get(ctx, id)) }
    DisposableEffect(id) {
        val sp = KvxWidgetBg.prefs(ctx)
        val l = SharedPreferences.OnSharedPreferenceChangeListener { _, key -> if (key == id.toString()) v = KvxWidgetBg.get(ctx, id) }
        sp.registerOnSharedPreferenceChangeListener(l)
        v = KvxWidgetBg.get(ctx, id)
        onDispose { sp.unregisterOnSharedPreferenceChangeListener(l) }
    }
    return v
}

/** Background opacity controls, shown for every widget. */
@Composable
fun WidgetBgControl(id: UUID) {
    val ctx = LocalContext.current
    val cur = rememberWidgetBg(id)
    OutlinedCard(Modifier.then(androidx.compose.ui.Modifier)) {
        Column {
            SwitchPreference(
                title = "Custom background",
                summary = "Off: uses the launcher's default card background",
                value = cur >= 0,
                onValueChanged = { on -> KvxWidgetBg.set(ctx, id, if (on) 60 else -1) },
            )
            if (cur >= 0) SliderPreference(
                title = "Background opacity", value = cur, min = 0, max = 100,
                onValueChanged = { KvxWidgetBg.set(ctx, id, it) }, label = { Text("$it%") },
            )
        }
    }
}
