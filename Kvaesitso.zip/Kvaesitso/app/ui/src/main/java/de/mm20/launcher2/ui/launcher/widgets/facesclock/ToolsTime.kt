package de.mm20.launcher2.ui.launcher.widgets.facesclock

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.SystemClock
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.Column
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.time.ZoneId

/** Timers fire through the system alarm clock, so they ring even when the launcher is not running. */
class TimerReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        try { fire(ctx, intent) } catch (e: Throwable) { android.util.Log.e("KvxTimer", "timer alert failed", e) }
    }

    private fun fire(ctx: Context, intent: Intent) {
        if (intent.action == "kvx.timer.show") return
        val id = intent.getIntExtra("id", -1)
        val label = intent.getStringExtra("label") ?: "Timer"
        val arr = TimerStore.load(ctx)
        val rest = JSONArray()
        for (i in 0 until arr.length()) if (arr.getJSONObject(i).getInt("id") != id) rest.put(arr.getJSONObject(i))
        TimerStore.save(ctx, rest)
        TimerStore.hideTimer(ctx, id)
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("kvx_timer", "Timers", NotificationManager.IMPORTANCE_HIGH).apply {
            enableVibration(true); vibrationPattern = longArrayOf(0, 500, 300, 500, 300, 800)
        })
        val n = Notification.Builder(ctx, "kvx_timer")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Time is up")
            .setContentText(label)
            .setAutoCancel(true)
            .setCategory(Notification.CATEGORY_ALARM)
            .build()
        nm.notify(5000 + id, n)
    }
}

internal object TimerStore {
    fun load(c: Context): JSONArray = try { JSONArray(ToolStore.get(c, "timers", "[]")) } catch (e: Exception) { JSONArray() }
    fun save(c: Context, a: JSONArray) = ToolStore.put(c, "timers", a.toString())

    fun pi(c: Context, id: Int, label: String): PendingIntent =
        PendingIntent.getBroadcast(c, id, Intent(c, TimerReceiver::class.java).putExtra("id", id).putExtra("label", label), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    fun arm(c: Context, id: Int, label: String, endWall: Long) {
        // a harmless broadcast: launching the home activity from here can bring up Android's "choose a launcher" prompt
        val show = PendingIntent.getBroadcast(c, 1, Intent(c, TimerReceiver::class.java).setAction("kvx.timer.show"), PendingIntent.FLAG_IMMUTABLE)
        val am = c.getSystemService(AlarmManager::class.java)
        try { am.setAlarmClock(AlarmManager.AlarmClockInfo(endWall, show), pi(c, id, label)) }
        catch (e: Throwable) {
            // fall back to an inexact alarm rather than failing the timer
            try { am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, endWall, pi(c, id, label)) } catch (e2: Throwable) { android.util.Log.e("KvxTimer", "arm failed", e2) }
        }
        showTimer(c, id, label, endWall)
    }

    fun disarm(c: Context, id: Int, label: String) {
        try { c.getSystemService(AlarmManager::class.java).cancel(pi(c, id, label)) } catch (e: Throwable) {}
        hideTimer(c, id)
    }

    // ---- ongoing notifications while a timer or the stopwatch runs. The system draws the ticking clock
    // itself (a chronometer), so nothing has to keep running in the background for it.
    private fun live(c: Context): Notification.Builder {
        c.getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("kvx_timer_live", "Running timers", NotificationManager.IMPORTANCE_LOW))
        return Notification.Builder(c, "kvx_timer_live")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(true)
    }

    private fun post(c: Context, id: Int, n: Notification) {
        try { c.getSystemService(NotificationManager::class.java).notify(id, n) } catch (e: Throwable) {}
    }

    fun showTimer(c: Context, id: Int, label: String, endWall: Long) {
        post(c, 6000 + id, live(c).setContentTitle(label).setContentText("Timer running")
            .setWhen(endWall).setUsesChronometer(true).setChronometerCountDown(true).build())
    }

    fun hideTimer(c: Context, id: Int) {
        try { c.getSystemService(NotificationManager::class.java).cancel(6000 + id) } catch (e: Throwable) {}
    }

    /** Shows the stopwatch while it runs or is paused with time on it, and removes it after a reset. */
    fun stopwatch(c: Context, running: Boolean, elapsedMs: Long) {
        if (!running && elapsedMs <= 0) {
            try { c.getSystemService(NotificationManager::class.java).cancel(7000) } catch (e: Throwable) {}
            return
        }
        val b = live(c).setContentTitle("Stopwatch")
        if (running) b.setContentText("Running").setWhen(System.currentTimeMillis() - elapsedMs).setUsesChronometer(true)
        else b.setContentText("Stopped at " + fmt(elapsedMs, true)).setWhen(System.currentTimeMillis()).setUsesChronometer(false)
        post(c, 7000, b.build())
    }
}

private fun fmt(ms: Long, tenths: Boolean = false): String {
    val t = ms.coerceAtLeast(0)
    val h = t / 3_600_000
    val m = (t / 60_000) % 60
    val s = (t / 1000) % 60
    val base = if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
    return if (tenths) base + "." + ((t / 100) % 10) else base
}

@Composable
fun TimersTool() {
    val ctx = LocalContext.current
    var tab by remember { mutableStateOf(0) }
    ToolCard {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for ((i, n) in listOf("Timer", "Stopwatch", "Countdown").withIndex()) {
                FilterChip(selected = tab == i, onClick = { tab = i }, label = { Text(n) })
            }
        }
        when (tab) {
            0 -> TimerTab(ctx)
            1 -> StopwatchTab(ctx)
            else -> CountdownTab(ctx)
        }
    }
}

@Composable
private fun TimerTab(ctx: Context) {
    var rev by remember { mutableStateOf(0) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { now = System.currentTimeMillis(); kotlinx.coroutines.delay(250) } }
    var custom by remember { mutableStateOf(false) }
    var minText by remember { mutableStateOf("") }
    var labelText by remember { mutableStateOf("") }
    val askPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { rev++ }
    val needPerm = Build.VERSION.SDK_INT >= 33 && ctx.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
    @Suppress("UNUSED_EXPRESSION") rev
    val arr = TimerStore.load(ctx)

    fun add(min: Int, label: String) {
        val id = (System.currentTimeMillis() % 100000).toInt()
        val dur = min * 60_000L
        val end = System.currentTimeMillis() + dur
        val name = label.ifBlank { "$min min timer" }
        arr.put(JSONObject().put("id", id).put("label", name).put("dur", dur).put("end", end).put("left", dur))
        TimerStore.save(ctx, arr)
        TimerStore.arm(ctx, id, name, end)
        rev++
    }

    Column(Modifier.padding(top = 8.dp)) {
        var any = false
        for (i in 0 until arr.length()) {
            val t = arr.getJSONObject(i)
            val id = t.getInt("id")
            val label = t.getString("label")
            val dur = t.getLong("dur")
            val running = t.getLong("end") > 0
            val left = if (running) t.getLong("end") - now else t.getLong("left")
            if (running && left <= 0) continue
            any = true
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(fmt(left), style = MaterialTheme.typography.headlineSmall)
                    LinearProgressIndicator(progress = { (1f - left.toFloat() / dur).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth().padding(top = 4.dp))
                }
                TextButton(onClick = {
                    if (running) {
                        t.put("left", left); t.put("end", 0L); TimerStore.disarm(ctx, id, label)
                    } else {
                        val end = System.currentTimeMillis() + t.getLong("left"); t.put("end", end); TimerStore.arm(ctx, id, label, end)
                    }
                    TimerStore.save(ctx, arr); rev++
                }) { Text(if (running) "Pause" else "Resume") }
                TextButton(onClick = {
                    TimerStore.disarm(ctx, id, label)
                    val rest = JSONArray()
                    for (j in 0 until arr.length()) if (arr.getJSONObject(j).getInt("id") != id) rest.put(arr.getJSONObject(j))
                    TimerStore.save(ctx, rest); rev++
                }) { Text("Cancel") }
            }
        }
        if (!any) Text("No timers running", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 4.dp).horizontalScroll(rememberScrollState())) {
            for (m in listOf(1, 2, 3, 5, 10, 15, 20, 30, 45, 60, 90, 120)) FilterChip(selected = false, onClick = { add(m, "") }, label = { Text(if (m >= 60 && m % 60 == 0) "${m / 60}h" else "${m}m") })
            FilterChip(selected = false, onClick = { custom = true }, label = { Text("Custom") })
        }
        if (needPerm) TextButton(onClick = { askPerm.launch(android.Manifest.permission.POST_NOTIFICATIONS) }) { Text("Allow notifications so timers can alert you") }
    }
    if (custom) AlertDialog(
        onDismissRequest = { custom = false },
        title = { Text("New timer") },
        text = {
            Column {
                OutlinedTextField(value = minText, onValueChange = { minText = it.filter { c -> c.isDigit() }.take(4) }, label = { Text("Minutes") }, singleLine = true)
                OutlinedTextField(value = labelText, onValueChange = { labelText = it }, label = { Text("Name (optional)") }, singleLine = true, modifier = Modifier.padding(top = 8.dp))
            }
        },
        confirmButton = { TextButton(onClick = { val m = minText.toIntOrNull() ?: 0; if (m > 0) add(m, labelText); custom = false; minText = ""; labelText = "" }) { Text("Start") } },
        dismissButton = { TextButton(onClick = { custom = false }) { Text("Cancel") } },
    )
}

@Composable
private fun StopwatchTab(ctx: Context) {
    // state is kept as: base (accumulated ms), startedAt (elapsedRealtime when running, 0 when stopped), laps
    var base by remember { mutableLongStateOf(ToolStore.getLong(ctx, "sw_base")) }
    var startedAt by remember { mutableLongStateOf(ToolStore.getLong(ctx, "sw_start")) }
    var laps by remember { mutableStateOf(ToolStore.get(ctx, "sw_laps")) }
    var tick by remember { mutableLongStateOf(SystemClock.elapsedRealtime()) }
    LaunchedEffect(startedAt) { while (true) { tick = SystemClock.elapsedRealtime(); kotlinx.coroutines.delay(50) } }
    fun elapsed() = base + (if (startedAt > 0) tick - startedAt else 0L)
    fun persist() {
        ToolStore.putLong(ctx, "sw_base", base); ToolStore.putLong(ctx, "sw_start", startedAt); ToolStore.put(ctx, "sw_laps", laps)
        TimerStore.stopwatch(ctx, startedAt > 0, elapsed())
    }
    Column(Modifier.padding(top = 8.dp)) {
        Text(fmt(elapsed(), true), style = MaterialTheme.typography.displaySmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 8.dp)) {
            Button(onClick = {
                if (startedAt > 0) { base = elapsed(); startedAt = 0 } else startedAt = SystemClock.elapsedRealtime()
                persist()
            }) { Text(if (startedAt > 0) "Stop" else if (base > 0) "Resume" else "Start") }
            TextButton(onClick = { if (startedAt > 0) { laps = (fmt(elapsed(), true) + "\n" + laps).trim(); persist() } }, enabled = startedAt > 0) { Text("Lap") }
            TextButton(onClick = { base = 0; startedAt = 0; laps = ""; persist() }) { Text("Reset") }
        }
        val lines = laps.lines().filter { it.isNotBlank() }.take(4)
        lines.forEachIndexed { i, l -> Text("Lap ${laps.lines().filter { it.isNotBlank() }.size - i}   $l", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}

@Composable
private fun CountdownTab(ctx: Context) {
    var target by remember { mutableLongStateOf(ToolStore.getLong(ctx, "cd_target")) }
    var label by remember { mutableStateOf(ToolStore.get(ctx, "cd_label")) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { now = System.currentTimeMillis(); kotlinx.coroutines.delay(1000) } }
    var ask by remember { mutableStateOf(false) }
    var nameText by remember { mutableStateOf(label) }
    Column(Modifier.padding(top = 8.dp)) {
        if (target > now) {
            val left = target - now
            val d = left / 86_400_000
            val h = (left / 3_600_000) % 24
            val m = (left / 60_000) % 60
            Text(label.ifBlank { "Countdown" }, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("${d}d ${h}h ${m}m", style = MaterialTheme.typography.displaySmall)
        } else {
            Text(if (target > 0) "${label.ifBlank { "Countdown" }} has arrived" else "No countdown set", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(vertical = 8.dp))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TextButton(onClick = { ask = true }) { Text(if (target > 0) "Change" else "Set a date") }
            if (target > 0) TextButton(onClick = { target = 0; label = ""; ToolStore.putLong(ctx, "cd_target", 0); ToolStore.put(ctx, "cd_label", "") }) { Text("Clear") }
        }
    }
    if (ask) AlertDialog(
        onDismissRequest = { ask = false },
        title = { Text("Countdown to") },
        text = { OutlinedTextField(value = nameText, onValueChange = { nameText = it }, label = { Text("What is it?") }, singleLine = true) },
        confirmButton = {
            TextButton(onClick = {
                ask = false
                val c = java.util.Calendar.getInstance()
                android.app.DatePickerDialog(ctx, { _, y, mo, d ->
                    android.app.TimePickerDialog(ctx, { _, hh, mm ->
                        val cal = java.util.Calendar.getInstance().apply { set(y, mo, d, hh, mm, 0) }
                        target = cal.timeInMillis; label = nameText
                        ToolStore.putLong(ctx, "cd_target", target); ToolStore.put(ctx, "cd_label", label)
                    }, 9, 0, false).show()
                }, c.get(java.util.Calendar.YEAR), c.get(java.util.Calendar.MONTH), c.get(java.util.Calendar.DAY_OF_MONTH)).show()
            }) { Text("Pick date") }
        },
        dismissButton = { TextButton(onClick = { ask = false }) { Text("Cancel") } },
    )
}
