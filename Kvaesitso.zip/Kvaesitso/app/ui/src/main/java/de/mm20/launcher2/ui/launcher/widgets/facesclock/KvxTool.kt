package de.mm20.launcher2.ui.launcher.widgets.facesclock

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import de.mm20.launcher2.ui.component.preferences.ListPreference
import de.mm20.launcher2.ui.component.preferences.Preference
import de.mm20.launcher2.ui.component.preferences.SliderPreference
import de.mm20.launcher2.widgets.KvxToolWidget
import de.mm20.launcher2.widgets.KvxToolWidgetConfig

/** Small key-value store shared by the tools (timers, to-dos, contacts, headlines cache). */
internal object ToolStore {
    private fun sp(c: Context) = c.applicationContext.getSharedPreferences("kvx_tools", Context.MODE_PRIVATE)
    fun get(c: Context, k: String, d: String = ""): String = sp(c).getString(k, d) ?: d
    fun put(c: Context, k: String, v: String) = sp(c).edit().putString(k, v).apply()
    fun getLong(c: Context, k: String, d: Long = 0L): Long = sp(c).getLong(k, d)
    fun putLong(c: Context, k: String, v: Long) = sp(c).edit().putLong(k, v).apply()
}

internal val toolNames = listOf(
    "Timers, stopwatch, countdown" to 0, "To-do list" to 1, "Quick toggles" to 2, "Favorite contacts" to 3,
    "Headlines (RSS)" to 4, "Meters (loudness, EQ, more)" to 5, "Metronome and tap tempo" to 6, "Ride conditions" to 7, "Tuner" to 8,
)

@Composable
internal fun ToolCard(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(MaterialTheme.shapes.large)
            .background(MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.88f))
            .padding(12.dp),
        content = content,
    )
}

@Composable
fun KvxToolView(widget: KvxToolWidget) = KvxToolBody(widget.config)

@Composable
fun KvxToolBody(cfg: KvxToolWidgetConfig) {
    Column(Modifier.fillMaxWidth().padding(start = 12.dp + cfg.padStart.dp, top = 12.dp + cfg.padTop.dp, end = 12.dp + cfg.padEnd.dp, bottom = 12.dp + cfg.padBottom.dp)) {
        when (cfg.tool) {
            1 -> TodoTool()
            2 -> TogglesTool(cfg)
            3 -> ContactsTool(cfg)
            4 -> HeadlinesTool(cfg)
            5 -> MeterTool(cfg)
            6 -> MetronomeTool()
            7 -> RideTool()
            8 -> TunerTool(cfg)
            else -> TimersTool()
        }
    }
}

private val toggleNames = listOf("Flashlight", "Wi-Fi", "Bluetooth", "Internet", "Airplane mode", "Do not disturb", "Auto-rotate", "Location", "Battery saver", "Hotspot", "Volume", "Battery share")

@Composable
fun ConfigureKvxToolWidget(widget: KvxToolWidget, onWidgetUpdated: (KvxToolWidget) -> Unit) {
    val c = widget.config
    fun upd(n: KvxToolWidgetConfig) = onWidgetUpdated(widget.copy(config = n))
    OutlinedCard {
        Column {
            ListPreference(title = "Tool", items = toolNames, value = c.tool, onValueChanged = { v -> upd(c.copy(tool = v)) })
            when (c.tool) {
                2 -> for ((i, n) in toggleNames.withIndex()) {
                    de.mm20.launcher2.ui.component.preferences.SwitchPreference(
                        title = n, value = (c.mask shr i) and 1 == 1,
                        onValueChanged = { on -> upd(c.copy(mask = if (on) c.mask or (1 shl i) else c.mask and (1 shl i).inv())) },
                    )
                }
                3 -> ListPreference(title = "Tapping a contact", items = listOf("Opens the dialer" to 0, "Starts a text" to 1, "Opens the contact" to 2), value = c.mode, onValueChanged = { v -> upd(c.copy(mode = v)) })
                4 -> {
                    SliderPreference(title = "Headlines shown", value = c.count, min = 3, max = 15, onValueChanged = { v -> upd(c.copy(count = v)) }, label = { Text("$it") })
                    FeedsEditor(c.feeds) { v -> upd(c.copy(feeds = v)) }
                }
                5 -> {
                    ListPreference(title = "Listen to", items = listOf("Live sound (microphone, for concerts)" to 0, "Music playing on this phone" to 1), value = c.mode, onValueChanged = { v -> upd(c.copy(mode = v)) })
                    if (c.mode == 0) {
                        Text("Live mode shows the loudness meter and EQ, and always waits for a tap.", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
                        SliderPreference(title = "Microphone calibration", value = c.calib, min = 60, max = 140, onValueChanged = { v -> upd(c.copy(calib = v)) }, label = { Text("+$it dB") })
                        Text("Phone mics are not calibrated. Compare against a real meter or an SPL app and nudge this until they match.", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(16.dp))
                        SliderPreference(title = "Spectrum height", value = c.height, min = 190, max = 360, onValueChanged = { v -> upd(c.copy(height = v)) }, label = { Text("$it dp") })
                    } else {
                        de.mm20.launcher2.ui.component.preferences.SwitchPreference(title = "Tap to listen", summary = "Off: meters run on their own while you're on the page and music plays", value = c.tap, onValueChanged = { v -> upd(c.copy(tap = v)) })
                        for ((i, n) in meterNames.withIndex()) {
                            de.mm20.launcher2.ui.component.preferences.SwitchPreference(
                                title = n, value = (c.mmask shr i) and 1 == 1,
                                onValueChanged = { on -> upd(c.copy(mmask = if (on) c.mmask or (1 shl i) else c.mmask and (1 shl i).inv())) },
                            )
                        }
                    }
                }
                8 -> SliderPreference(title = "Concert pitch (A4)", value = c.a4, min = 415, max = 466, onValueChanged = { v -> upd(c.copy(a4 = v)) }, label = { Text("$it Hz") })
            }
            PaddingControls(c.padTop, c.padBottom, c.padStart, c.padEnd) { t, b, s, e -> upd(c.copy(padTop = t, padBottom = b, padStart = s, padEnd = e)) }
        }
    }
}
