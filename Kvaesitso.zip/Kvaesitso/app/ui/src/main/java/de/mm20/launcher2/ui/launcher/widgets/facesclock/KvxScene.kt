package de.mm20.launcher2.ui.launcher.widgets.facesclock

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Path
import android.graphics.RectF
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.graphics.ColorUtils
import de.mm20.launcher2.ui.component.preferences.ListPreference
import de.mm20.launcher2.ui.component.preferences.SliderPreference
import de.mm20.launcher2.ui.component.preferences.SwitchPreference
import de.mm20.launcher2.ui.launcher.widgets.facesclock.np.MediaState
import de.mm20.launcher2.widgets.KvxSceneWidget
import de.mm20.launcher2.widgets.KvxSceneWidgetConfig
import java.time.ZonedDateTime
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.tan

/** Everything a scene can react to: audio, time of day, weather, tilt, colours. */
internal class SceneEnv {
    var w = 0f
    var h = 0f
    var dp = 1f
    var t = 0f
    var dt = 0.016f
    var level = 0f
    var beat = 0f
    var bass = 0f
    var day = 1f
    var wx = 0
    var wxReal = false
    var humidity = 60
    var tx = 0f
    var ty = 1f
    var shake = 0f
    var accent = 0xFF4FC3F7.toInt()
    var accent2 = 0xFFFF4081.toInt()
    var useColor = false
    var custom = 0xFF4FC3F7.toInt()
    var amount = 5
    var dance = true
    var tilt = true
    var speed = 1f
    val rnd = java.util.Random()
    fun rf() = rnd.nextFloat()
    fun rr(a: Float, b: Float) = a + rnd.nextFloat() * (b - a)
    fun pick(def: Int) = if (useColor) custom else def
}

internal abstract class Scene(val ctx: Context) {
    open val grabs = false
    open val needsAudio = false
    open val needsTilt = false
    abstract fun draw(c: Canvas, e: SceneEnv)
    open fun down(x: Float, y: Float, e: SceneEnv) {}
    open fun move(x: Float, y: Float, e: SceneEnv) {}
    open fun up(x: Float, y: Float, e: SceneEnv, tap: Boolean) {}
    open fun detach() {}
}

internal fun mixC(a: Int, b: Int, f: Float): Int = ColorUtils.blendARGB(a, b, f.coerceIn(0f, 1f))
internal fun alC(c: Int, a: Float): Int = (c and 0xFFFFFF) or ((a.coerceIn(0f, 1f) * 255f).toInt() shl 24)
internal fun lerpF(a: Float, b: Float, f: Float) = a + (b - a) * f
internal fun smooth(a: Float, b: Float, x: Float): Float {
    val t = ((x - a) / (b - a)).coerceIn(0f, 1f)
    return t * t * (3f - 2f * t)
}

/** Daylight 0 (night) .. 1 (day) from sunrise and sunset at the weather location. */
internal object SceneSun {
    fun times(): Pair<Int, Int> {
        val lat = if (ClockEnv.lat.isNaN()) 36.16 else ClockEnv.lat
        val lon = if (ClockEnv.lon.isNaN()) -86.78 else ClockEnv.lon
        val now = ZonedDateTime.now()
        val r = calc(lat, lon, true, now) ?: 390
        val s = calc(lat, lon, false, now) ?: 1050
        return Pair(r, s)
    }

    fun daylight(): Float {
        val (r, s) = times()
        val now = ZonedDateTime.now()
        val m = now.hour * 60f + now.minute
        val up = smooth(r - 35f, r + 35f, m)
        val down = 1f - smooth(s - 35f, s + 35f, m)
        return if (m < 720f) up else down
    }

    private fun calc(lat: Double, lon: Double, rising: Boolean, now: ZonedDateTime): Int? {
        try {
            val rad = PI / 180.0
            val n = now.dayOfYear
            val lngHour = lon / 15.0
            val t = n + ((if (rising) 6 else 18) - lngHour) / 24.0
            val m = 0.9856 * t - 3.289
            var l = m + 1.916 * sin(m * rad) + 0.020 * sin(2 * m * rad) + 282.634
            l = ((l % 360) + 360) % 360
            var ra = atan(0.91764 * tan(l * rad)) / rad
            ra = ((ra % 360) + 360) % 360
            ra += (floor(l / 90) * 90) - (floor(ra / 90) * 90)
            ra /= 15.0
            val sinDec = 0.39782 * sin(l * rad)
            val cosDec = cos(asin(sinDec))
            val cosH = (cos(90.833 * rad) - sinDec * sin(lat * rad)) / (cosDec * cos(lat * rad))
            if (cosH > 1 || cosH < -1) return null
            val h = (if (rising) 360 - acos(cosH) / rad else acos(cosH) / rad) / 15.0
            val tt = h + ra - 0.06571 * t - 6.622
            var ut = (tt - lngHour) % 24
            if (ut < 0) ut += 24
            val local = (ut + now.offset.totalSeconds / 3600.0 + 24) % 24
            return (local * 60).roundToInt()
        } catch (e: Exception) {
            return null
        }
    }
}

internal val sceneNames = listOf(
    "Fish tank" to 0, "Ant farm" to 1, "Window on the weather" to 2, "Lava lamp" to 3,
    "Planetarium" to 4, "Koi pond" to 5, "Zen sand garden" to 6, "Snow globe" to 7,
    "Campfire" to 8, "Newton's cradle" to 9, "Firefly jar" to 10,
)

private val amountLabel = mapOf(
    0 to "Fish", 1 to "Ants", 3 to "Blobs", 4 to "Time lapse (1 = real time)", 5 to "Koi", 6 to "Rocks",
    7 to "Snowfall", 8 to "Fire size", 9 to "Balls", 10 to "Fireflies",
)

internal fun makeScene(i: Int, c: Context): Scene = when (i) {
    1 -> AntScene(c)
    2 -> WindowScene(c)
    3 -> LavaScene(c)
    4 -> PlanetScene(c)
    5 -> KoiScene(c)
    6 -> SandScene(c)
    7 -> GlobeScene(c)
    8 -> FireScene(c)
    9 -> CradleScene(c)
    10 -> JarScene(c)
    else -> FishScene(c)
}

internal class SceneView(context: Context) : View(context), SensorEventListener {
    val env = SceneEnv()
    private var scene: Scene? = null
    private var cfg = KvxSceneWidgetConfig()
    private var last = 0L
    private var sunAt = 0L
    private val clip = Path()
    private val rect = RectF()
    private var audioHeld = false
    private var sensing = false
    private var downX = 0f
    private var downY = 0f
    private var downT = 0L
    private var moved = false
    private val slop = ViewConfiguration.get(context).scaledTouchSlop
    private var ax = 0f
    private var ay = 0f
    private var az = 0f
    private var lastMag = 9.8f

    fun setConfig(c: KvxSceneWidgetConfig) {
        val old = cfg
        cfg = c
        if (scene == null || old.scene != c.scene) {
            holdAudio(false)
            scene?.detach()
            scene = makeScene(c.scene, context)
        }
        env.amount = c.amount
        env.dance = c.dance
        env.tilt = c.tilt
        env.useColor = c.colorMode == 1
        env.custom = c.color
        env.speed = c.speed / 100f
        if (isAttachedToWindow) sync()
        invalidate()
    }

    private fun sync() {
        val vis = windowVisibility == VISIBLE
        holdAudio(vis && scene?.needsAudio == true && cfg.dance)
        sense(vis && scene?.needsTilt == true && cfg.tilt)
    }

    private fun holdAudio(on: Boolean) {
        if (on && !audioHeld) { audioHeld = true; VizAudio.start(context) }
        else if (!on && audioHeld) { audioHeld = false; VizAudio.stop() }
    }

    private fun sense(on: Boolean) {
        val sm = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager ?: return
        if (on && !sensing) {
            val s = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) ?: return
            sm.registerListener(this, s, SensorManager.SENSOR_DELAY_GAME)
            sensing = true
        } else if (!on && sensing) {
            sm.unregisterListener(this)
            sensing = false
        }
    }

    override fun onSensorChanged(ev: SensorEvent) {
        val x = ev.values[0]
        val y = ev.values[1]
        val z = ev.values[2]
        env.tx += ((-x / 9.8f).coerceIn(-1f, 1f) - env.tx) * 0.12f
        env.ty += ((y / 9.8f).coerceIn(-1f, 1f) - env.ty) * 0.12f
        val mag = kotlin.math.sqrt(x * x + y * y + z * z)
        val jolt = abs(mag - lastMag)
        lastMag = mag
        env.shake = max(env.shake, (jolt / 12f).coerceIn(0f, 1f))
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        de.mm20.launcher2.ui.launcher.widgets.facesclock.np.MediaState.ensureStarted(context)
        last = SystemClock.uptimeMillis()
        sync()
        invalidate()
    }

    override fun onDetachedFromWindow() {
        holdAudio(false)
        sense(false)
        scene?.detach()
        super.onDetachedFromWindow()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (isAttachedToWindow) sync()
        if (visibility == VISIBLE) { last = SystemClock.uptimeMillis(); invalidate() }
    }

    override fun onDraw(canvas: Canvas) {
        val s = scene ?: return
        val now = SystemClock.uptimeMillis()
        val rdt = ((now - last) / 1000f).coerceIn(0.001f, 0.05f)
        last = now
        val e = env
        e.w = width.toFloat()
        e.h = height.toFloat()
        e.dp = resources.displayMetrics.density
        e.dt = rdt * e.speed
        e.t += e.dt
        e.shake *= 0.94f
        if (s.needsAudio && cfg.dance) {
            VizAudio.playing = MediaState.playing
            VizAudio.gain = 1f
            VizAudio.fall = 1f
            VizAudio.update(false)
            e.level = (VizAudio.level * 3f).coerceIn(0f, 1.4f)
            e.beat = VizAudio.beatEnv
            var b = 0f
            for (i in 0 until 6) b += VizAudio.disp[i]
            e.bass = (b / 6f * 2f).coerceIn(0f, 1.4f)
        } else {
            e.level = 0f; e.beat = 0f; e.bass = 0f
        }
        if (MediaState.playing && cfg.dance) {
            e.accent = MediaState.accent
            e.accent2 = MediaState.accent2
        } else {
            e.accent = 0xFF4FC3F7.toInt()
            e.accent2 = 0xFFFF4081.toInt()
        }
        if (!cfg.tilt) { e.tx = 0f; e.ty = 1f }
        if (now - sunAt > 20_000L) {
            sunAt = now
            e.day = SceneSun.daylight()
            val wx = ClockEnv.weather
            if (wx != null) {
                e.wx = wx.now.code; e.wxReal = true; e.humidity = wx.now.humidity
            } else {
                e.wx = 61; e.wxReal = false; e.humidity = 85
            }
        }
        val r = cfg.corner * e.dp
        clip.reset()
        rect.set(0f, 0f, e.w, e.h)
        clip.addRoundRect(rect, r, r, Path.Direction.CW)
        canvas.save()
        canvas.clipPath(clip)
        s.draw(canvas, e)
        canvas.restore()
        if (windowVisibility == VISIBLE) postInvalidateOnAnimation()
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        val s = scene ?: return false
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = ev.x; downY = ev.y; downT = SystemClock.uptimeMillis(); moved = false
                if (s.grabs) parent?.requestDisallowInterceptTouchEvent(true)
                s.down(ev.x, ev.y, env)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (abs(ev.x - downX) > slop || abs(ev.y - downY) > slop) moved = true
                s.move(ev.x, ev.y, env)
                return true
            }
            MotionEvent.ACTION_UP -> {
                s.up(ev.x, ev.y, env, !moved && SystemClock.uptimeMillis() - downT < 450)
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                s.up(ev.x, ev.y, env, false)
                return true
            }
        }
        return super.onTouchEvent(ev)
    }
}

@Composable
fun KvxSceneView(widget: KvxSceneWidget) = KvxSceneBody(widget.config)

@Composable
fun KvxSceneBody(cfg: KvxSceneWidgetConfig) {
    FeedClockEnv()
    Column(Modifier.fillMaxWidth().padding(start = 12.dp + cfg.padStart.dp, top = 12.dp + cfg.padTop.dp, end = 12.dp + cfg.padEnd.dp, bottom = 12.dp + cfg.padBottom.dp)) {
        AndroidView(
            factory = { SceneView(it) },
            update = { it.setConfig(cfg) },
            modifier = Modifier.fillMaxWidth().height(cfg.height.dp),
        )
    }
}

@Composable
fun ConfigureKvxSceneWidget(widget: KvxSceneWidget, onWidgetUpdated: (KvxSceneWidget) -> Unit) {
    val c = widget.config
    fun upd(n: KvxSceneWidgetConfig) = onWidgetUpdated(widget.copy(config = n))
    OutlinedCard {
        Column {
            ListPreference(title = "Scene", items = sceneNames, value = c.scene, onValueChanged = { v -> upd(c.copy(scene = v)) })
            amountLabel[c.scene]?.let { l ->
                SliderPreference(title = l, value = c.amount, min = 1, max = 10, onValueChanged = { v -> upd(c.copy(amount = v)) }, label = { Text("$it") })
            }
            if (c.scene == 2 || c.scene == 4 || c.scene == 0 || c.scene == 1) Text("Sun times, weather and the sky use the place you typed in Settings > Widgets, so no location permission is needed.", style = androidx.compose.material3.MaterialTheme.typography.bodySmall, modifier = Modifier.padding(16.dp))
            SliderPreference(title = "Height", value = c.height, min = 100, max = 420, onValueChanged = { v -> upd(c.copy(height = v)) }, label = { Text("$it dp") })
            SliderPreference(title = "Speed", value = c.speed, min = 25, max = 300, onValueChanged = { v -> upd(c.copy(speed = v)) }, label = { Text("$it%") })
            SliderPreference(title = "Corner radius", value = c.corner, min = 0, max = 48, onValueChanged = { v -> upd(c.copy(corner = v)) }, label = { Text("$it dp") })
            ListPreference(title = "Colours", items = listOf("Scene's own" to 0, "My colour" to 1), value = c.colorMode, onValueChanged = { v -> upd(c.copy(colorMode = v)) })
            if (c.colorMode == 1) ColorPreference("Colour", c.color) { v -> upd(c.copy(color = v)) }
            val (granted, ask) = rememberAudioPermission()
            if (!granted) de.mm20.launcher2.ui.component.preferences.Preference(title = "Allow audio access", summary = "Needed for scenes to dance to the music", onClick = ask)
            SwitchPreference(title = "Dance to music", summary = "Fish, lava, koi and fire move with what's playing", value = c.dance, onValueChanged = { v -> upd(c.copy(dance = v)) })
            SwitchPreference(title = "Tilt and shake", summary = "Snow globe, jar, cradle and lava react to the phone moving", value = c.tilt, onValueChanged = { v -> upd(c.copy(tilt = v)) })
            PaddingControls(c.padTop, c.padBottom, c.padStart, c.padEnd) { t, b, s, e -> upd(c.copy(padTop = t, padBottom = b, padStart = s, padEnd = e)) }
        }
    }
}
