package de.mm20.launcher2.ui.settings.homescreen

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import de.mm20.launcher2.ui.component.ChargingStyleCanvas
import de.mm20.launcher2.ui.component.chargingStyleNames
import de.mm20.launcher2.ui.component.preferences.ListPreference
import de.mm20.launcher2.ui.launcher.widgets.facesclock.KvxSettings

@Composable
fun ChargingStylePreference() {
    val context = LocalContext.current
    val style = KvxSettings.chargingStyle(context)
    Box(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp).height(120.dp)
            .clip(RoundedCornerShape(16.dp)).background(Color(0xFF14171C)),
        contentAlignment = Alignment.Center,
    ) {
        if (style == 0) {
            Text("Stock bubbles rise from the bottom while charging.", color = Color.White.copy(alpha = 0.7f), style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(16.dp))
        } else {
            ChargingStyleCanvas(style, 8, Modifier.fillMaxSize())
        }
    }
    ListPreference(
        title = "Charging animation style",
        items = chargingStyleNames.mapIndexed { i, n -> n to i },
        value = style,
        onValueChanged = { KvxSettings.setChargingStyle(context, it) },
    )
    val cmode = KvxSettings.chargingColorMode(context)
    ListPreference(
        title = "Charging animation color",
        items = listOf("White" to 0, "Custom" to 1, "Theme accent" to 2, "Rainbow" to 3),
        value = cmode,
        onValueChanged = { KvxSettings.setChargingColorMode(context, it) },
    )
    if (cmode == 1) de.mm20.launcher2.ui.launcher.widgets.facesclock.ColorPreference("Color", KvxSettings.chargingColor(context)) { KvxSettings.setChargingColor(context, it) }
}
