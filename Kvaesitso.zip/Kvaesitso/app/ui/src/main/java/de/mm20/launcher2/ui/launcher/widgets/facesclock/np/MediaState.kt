package de.mm20.launcher2.ui.launcher.widgets.facesclock.np

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import de.mm20.launcher2.music.MusicService
import de.mm20.launcher2.music.PlaybackState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.koin.core.context.GlobalContext
import kotlin.math.max
import kotlin.math.min

/** What is playing, as the card and the EQ see it. Fed from the launcher's own music service. */
object MediaState {
    var title = ""
    var artist = ""
    var album = ""
    var art: Bitmap? = null
    @Volatile var playing = false
    var hasSession = false
    var durationMs = 0L
    var pkg = ""
    @Volatile var status = "Not started"

    var accent = 0xFF00E5FF.toInt()
    var accent2 = 0xFFFF4081.toInt()
    var dark = 0xFF14161A.toInt()
    var light = 0xFFFFFFFF.toInt()
    var palette = intArrayOf(0xFF00E5FF.toInt(), 0xFFFF4081.toInt(), 0xFFFFD740.toInt(), 0xFF69F0AE.toInt())
    var paletteSig = 0

    private var posBase = 0L
    private var posTime = 0L
    private val main = Handler(Looper.getMainLooper())
    private val listeners = ArrayList<() -> Unit>()
    private var started = false
    private var music: MusicService? = null

    fun addListener(l: () -> Unit) { if (l !in listeners) listeners.add(l) }
    fun removeListener(l: () -> Unit) { listeners.remove(l) }
    private fun changed() { for (l in ArrayList(listeners)) l() }

    fun ensureStarted(ctx: Context) {
        if (started) return
        started = true
        val m = try { GlobalContext.get().get<MusicService>() } catch (e: Exception) { status = "Music service unavailable"; return }
        music = m
        val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
        scope.launch { m.title.collect { title = it ?: ""; changed() } }
        scope.launch { m.artist.collect { artist = it ?: ""; changed() } }
        scope.launch { m.album.collect { album = it ?: ""; changed() } }
        scope.launch { m.albumArt.collect { art = it; computeColors(it); changed() } }
        scope.launch { m.duration.collect { durationMs = it ?: 0L; changed() } }
        scope.launch { m.position.collect { posBase = it ?: 0L; posTime = SystemClock.elapsedRealtime(); changed() } }
        scope.launch {
            m.playbackState.collect {
                posBase = positionMs(); posTime = SystemClock.elapsedRealtime()
                playing = it == PlaybackState.Playing
                hasSession = it != PlaybackState.Stopped
                pkg = m.lastPlayerPackage ?: pkg
                status = if (hasSession) "Connected" else "Waiting for music"
                changed()
            }
        }
    }

    fun positionMs(): Long {
        if (!playing) return posBase
        return posBase + (SystemClock.elapsedRealtime() - posTime)
    }

    fun playPause() { music?.togglePause() }
    fun next() { music?.next() }
    fun prev() { music?.previous() }
    fun seekTo(ms: Long) { music?.seekTo(ms); posBase = ms; posTime = SystemClock.elapsedRealtime() }

    fun launchIntent(ctx: Context) = if (pkg.isEmpty()) null else ctx.packageManager.getLaunchIntentForPackage(pkg)

    // ---- colors from the artwork (same method as the Now Playing Card app)

    private fun computeColors(b: Bitmap?) {
        if (b == null) {
            accent = 0xFF00E5FF.toInt(); accent2 = 0xFFFF4081.toInt()
            dark = 0xFF14161A.toInt(); light = 0xFFFFFFFF.toInt()
            palette = intArrayOf(0xFF00E5FF.toInt(), 0xFFFF4081.toInt(), 0xFFFFD740.toInt(), 0xFF69F0AE.toInt())
            paletteSig = palette.contentHashCode()
            return
        }
        val s = Bitmap.createScaledBitmap(b, 24, 24, true)
        val hsv = FloatArray(3)
        var bestScore = -1f
        var best = 0
        var avgR = 0f; var avgG = 0f; var avgB = 0f
        val px = IntArray(24 * 24)
        s.getPixels(px, 0, 24, 0, 0, 24, 24)
        for (p in px) {
            avgR += Color.red(p); avgG += Color.green(p); avgB += Color.blue(p)
            Color.colorToHSV(p, hsv)
            val score = hsv[1] * hsv[2] * (if (hsv[2] < 0.25f) 0.2f else 1f)
            if (score > bestScore) { bestScore = score; best = p }
        }
        val n = px.size
        Color.colorToHSV(best, hsv)
        hsv[1] = max(hsv[1], 0.55f); hsv[2] = max(hsv[2], 0.85f)
        accent = Color.HSVToColor(hsv)
        buildPalette(px, accent)
        accent2 = if (palette.size > 1) palette[1] else Color.HSVToColor(floatArrayOf((hsv[0] + 40f) % 360f, hsv[1], hsv[2]))
        val avg = Color.rgb((avgR / n).toInt(), (avgG / n).toInt(), (avgB / n).toInt())
        val dh = FloatArray(3)
        Color.colorToHSV(avg, dh)
        dh[1] = min(dh[1], 0.6f); dh[2] = 0.16f
        dark = Color.HSVToColor(dh)
        light = Color.HSVToColor(floatArrayOf(hsv[0], 0.12f, 1f))
    }

    /** Groups the artwork's colorful pixels by hue and keeps the strongest groups as the palette. */
    private fun buildPalette(px: IntArray, first: Int) {
        val bins = 12
        val wt = FloatArray(bins)
        val sx = FloatArray(bins)
        val sy = FloatArray(bins)
        val ss = FloatArray(bins)
        val sv = FloatArray(bins)
        val hsv = FloatArray(3)
        for (p in px) {
            Color.colorToHSV(p, hsv)
            if (hsv[1] < 0.22f || hsv[2] < 0.22f) continue
            val w = hsv[1] * hsv[2]
            val bi = ((hsv[0] / 360f) * bins).toInt().coerceIn(0, bins - 1)
            val rad = Math.toRadians(hsv[0].toDouble())
            wt[bi] += w
            sx[bi] += (Math.cos(rad) * w).toFloat()
            sy[bi] += (Math.sin(rad) * w).toFloat()
            ss[bi] += hsv[1] * w
            sv[bi] += hsv[2] * w
        }
        val order = (0 until bins).filter { wt[it] > 0f }.sortedByDescending { wt[it] }
        val out = ArrayList<FloatArray>()
        if (order.isNotEmpty()) {
            val top = wt[order[0]]
            for (bi in order) {
                if (out.size >= 6) break
                if (wt[bi] < top * 0.06f) break
                var hue = Math.toDegrees(Math.atan2(sy[bi].toDouble(), sx[bi].toDouble())).toFloat()
                if (hue < 0f) hue += 360f
                // skip a hue that is almost the same as one already kept
                if (out.any { val dd = Math.abs(it[0] - hue); Math.min(dd, 360f - dd) < 24f }) continue
                out.add(floatArrayOf(hue, max(ss[bi] / wt[bi], 0.55f), max(sv[bi] / wt[bi], 0.85f)))
            }
        }
        if (out.isEmpty()) {
            Color.colorToHSV(first, hsv)
            out.add(floatArrayOf(hsv[0], hsv[1], hsv[2]))
        }
        // too few real colors (plain or black-and-white art): add tints and neighbouring hues
        var k = 0
        while (out.size < 4 && k < 8) {
            val b = out[k % out.size]
            val v = k / out.size
            out.add(
                when (v) {
                    0 -> floatArrayOf((b[0] + 28f) % 360f, max(b[1] * 0.85f, 0.45f), 1f)
                    else -> floatArrayOf((b[0] + 332f) % 360f, max(b[1] * 0.6f, 0.35f), 1f)
                }
            )
            k++
        }
        // order around the color wheel, starting at the main accent, so neighbours blend smoothly
        val h0 = out[0][0]
        out.sortBy { (it[0] - h0 + 360f) % 360f }
        palette = IntArray(out.size) { Color.HSVToColor(out[it]) }
        paletteSig = palette.contentHashCode()
    }
}
