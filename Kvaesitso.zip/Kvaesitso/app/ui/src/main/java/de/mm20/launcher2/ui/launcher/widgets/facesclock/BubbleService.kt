package de.mm20.launcher2.ui.launcher.widgets.facesclock

import android.animation.ValueAnimator
import android.app.AppOpsManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import de.mm20.launcher2.music.MusicService
import de.mm20.launcher2.music.PlaybackState
import de.mm20.launcher2.ui.R
import de.mm20.launcher2.ui.launcher.widgets.facesclock.np.CardView
import de.mm20.launcher2.ui.launcher.widgets.facesclock.np.MediaState
import de.mm20.launcher2.ui.launcher.widgets.facesclock.np.Prefs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject

/** The floating bubble: art with the visualizer, over every app while music plays. */
class BubbleService : Service(), KoinComponent {

    companion object {
        @Volatile var running = false
        @Volatile var instance: BubbleService? = null
        @Volatile var status = "Bubble: off"
        @Volatile private var cardOnlyNext = false

        /**
         * Opens or closes the Now Playing card even when the bubble is switched off. Returns false if the
         * card can't be shown (no overlay permission), so the caller can fall back to the music app.
         */
        fun toggleCard(ctx: Context): Boolean {
            val b = instance
            if (b != null) { b.toggleCardExternal(); return true }
            if (!Settings.canDrawOverlays(ctx)) return false
            cardOnlyNext = true
            return try {
                ctx.startForegroundService(Intent(ctx, BubbleService::class.java).setAction("kvx.CARD"))
                true
            } catch (e: Exception) { cardOnlyNext = false; false }
        }

        fun hasUsageAccess(ctx: Context): Boolean = try {
            val ops = ctx.getSystemService(AppOpsManager::class.java)
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), ctx.packageName) == AppOpsManager.MODE_ALLOWED
        } catch (e: Exception) { false }

        /** Starts or restarts the service if the bubble is on, stops it if not. Call after any settings change. */
        fun refresh(ctx: Context) {
            if (BubbleSettings.on(ctx) && Settings.canDrawOverlays(ctx)) {
                try { ctx.startForegroundService(Intent(ctx, BubbleService::class.java)) } catch (e: Exception) {}
            } else if (running) {
                ctx.stopService(Intent(ctx, BubbleService::class.java))
            }
        }
    }

    private val music: MusicService by inject()
    private val npPrefs by lazy { Prefs(this) }
    private var scrim: View? = null
    private var popup: CardView? = null
    private val popupClose = Runnable { closePopup(false) }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private val d get() = resources.displayMetrics.density

    private var bubble: VizBubbleView? = null
    private var bubbleLp: WindowManager.LayoutParams? = null
    private var screenOn = true
    /** Started only to show the card (bubble off): no bubble, and the service ends when the card closes. */
    private var cardOnly = false
    private var pausedExpired = false
    private var pausedArmed = false
    private var state = PlaybackState.Stopped
    private var art: Bitmap? = null
    private val collectors = ArrayList<Job>()

    private val savePos = Runnable {
        if (miniState == 1) return@Runnable
        bubbleLp?.let { BubbleSettings.setInt(this, "x", it.x); BubbleSettings.setInt(this, "y", it.y) }
    }
    private val pausedHide = Runnable { pausedArmed = false; pausedExpired = true; sync() }

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            screenOn = intent.action != Intent.ACTION_SCREEN_OFF
            if (!screenOn) closePopup(true)
            sync()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        cardOnly = cardOnlyNext
        cardOnlyNext = false
        wm = getSystemService(WindowManager::class.java)
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("kvx_bubble", "Floating bubble", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 1, Intent(this, BubbleService::class.java).setAction("kvx.BUBBLE_STOP"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, "kvx_bubble")
            .setSmallIcon(R.drawable.music_note_24px)
            .setContentTitle("Music bubble is on")
            .setOngoing(true)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, R.drawable.music_note_24px), "Turn off", stop).build())
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(1, n)
        val f = IntentFilter().apply { addAction(Intent.ACTION_SCREEN_ON); addAction(Intent.ACTION_SCREEN_OFF) }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(screenReceiver, f, Context.RECEIVER_NOT_EXPORTED) else registerReceiver(screenReceiver, f)
        collectors += scope.launch { music.playbackState.collect { state = it; sync() } }
        collectors += scope.launch { music.albumArt.collect { art = it; bubble?.art = it } }
        MediaState.ensureStarted(this)
        running = true
        instance = this
        handler.postDelayed(fgPoll, 1000)
        handler.postDelayed(vizPoll, 600)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "kvx.BUBBLE_STOP") {
            BubbleSettings.setOn(this, false)
            status = "Bubble: off"
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent?.action == "kvx.CARD") {
            cardOnly = true
            handler.post { togglePopup() }
            return START_NOT_STICKY
        }
        cardOnly = false
        closePopup(true)
        removeBubble(true)
        pausedExpired = false
        sync()
        return START_STICKY
    }

    /** Opens or closes the card from outside (the edge-light gear). */
    fun toggleCardExternal() { handler.post { togglePopup() } }

    override fun onDestroy() {
        running = false
        if (instance === this) instance = null
        status = "Bubble: off"
        scope.cancel()
        try { unregisterReceiver(screenReceiver) } catch (e: Exception) {}
        handler.removeCallbacksAndMessages(null)
        closePopup(true)
        removeBubble(true)
        super.onDestroy()
    }

    // ---- hide while the music app itself is on screen (needs Usage access)
    private var fgPkg = ""
    private var fgLast = 0L
    private var inMusicApp = false

    private var onVizPage = false
    private val vizPoll = object : Runnable {
        override fun run() {
            val now = BubbleSettings.hideOnViz(this@BubbleService) && VizWidgetRegistry.anyVisible()
            if (now != onVizPage) { onVizPage = now; sync() }
            handler.postDelayed(this, 500)
        }
    }

    private val fgPoll = object : Runnable {
        override fun run() {
            val was = inMusicApp
            inMusicApp = false
            if (BubbleSettings.hideInApp(this@BubbleService) && hasUsageAccess(this@BubbleService)) {
                try {
                    val usm = getSystemService(UsageStatsManager::class.java)
                    val now = System.currentTimeMillis()
                    val from = if (fgLast == 0L) now - 600_000L else fgLast
                    val ev = usm.queryEvents(from, now)
                    val e = UsageEvents.Event()
                    while (ev.hasNextEvent()) {
                        ev.getNextEvent(e)
                        if (e.eventType == UsageEvents.Event.ACTIVITY_RESUMED) fgPkg = e.packageName ?: ""
                        else if (e.eventType == UsageEvents.Event.ACTIVITY_PAUSED && e.packageName == fgPkg) fgPkg = ""
                    }
                    fgLast = now - 1500L
                } catch (x: Exception) {}
                inMusicApp = fgPkg.isNotEmpty() && fgPkg == music.lastPlayerPackage
            }
            if (was != inMusicApp) sync()
            handler.postDelayed(this, 1000)
        }
    }

    private fun sync() {
        if (!Settings.canDrawOverlays(this)) {
            status = "Bubble: needs \"Display over other apps\""
            removeBubble(true)
            return
        }
        if (cardOnly) { if (bubble != null) removeBubble(true); return }
        val playing = state == PlaybackState.Playing
        val hasSession = state != PlaybackState.Stopped
        val keep = BubbleSettings.keepPaused(this) && hasSession
        val hideMin = BubbleSettings.hideMin(this)
        if (playing) {
            pausedExpired = false; pausedArmed = false
            handler.removeCallbacks(pausedHide)
        } else if (keep && hideMin > 0 && !pausedArmed && !pausedExpired) {
            pausedArmed = true
            handler.postDelayed(pausedHide, hideMin * 60_000L)
        } else if (!keep) {
            pausedArmed = false
            handler.removeCallbacks(pausedHide)
        }
        val want = (playing || (keep && !pausedExpired)) && !inMusicApp && !onVizPage && screenOn
        if (want && bubble == null) addBubble()
        else if (!want && bubble != null) { closePopup(false); removeBubble(false) }
        bubble?.playing = playing
        status = when {
            inMusicApp -> "Bubble: hidden (you are in the music app)"
            onVizPage -> "Bubble: hidden (a visualizer widget is on screen)"
            bubble != null -> if (playing) "Bubble: showing (playing)" else "Bubble: showing (paused)"
            !hasSession -> "Bubble: waiting for music"
            else -> "Bubble: hidden (paused)"
        }
    }

    private fun screenW(): Int = wm.currentWindowMetrics.bounds.width()
    private fun screenH(): Int = wm.currentWindowMetrics.bounds.height()

    private fun addBubble() {
        miniState = 0
        val v = VizBubbleView(this)
        v.artDp = BubbleSettings.size(this).toFloat()
        v.cfg = BubbleSettings.viz(this)
        v.art = art
        v.playing = state == PlaybackState.Playing
        v.haptic = BubbleSettings.haptic(this)
        v.enableGestures()
        val total = v.totalPx
        val inset = v.inset.toInt()
        val m = (4 * d).toInt()
        val lp = WindowManager.LayoutParams(
            total, total, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        val sx = BubbleSettings.int(this, "x", -99999)
        val sy = BubbleSettings.int(this, "y", -99999)
        lp.x = if (sx == -99999) screenW() - total + inset - m else sx
        lp.y = if (sy == -99999) (screenH() * 0.35f).toInt() else sy
        lp.x = lp.x.coerceIn(-inset, screenW() - total + inset)
        lp.y = lp.y.coerceIn(-inset, screenH() - total + inset)

        v.onFling = fl@{ vx, vy ->
            val t = 900f * d
            if (miniState != 0 || inZone) return@fl false
            if (BubbleSettings.tuck(this) && Math.abs(vx) > t && Math.abs(vx) > Math.abs(vy) * 1.2f) { hideZone(); tuck(vx > 0); true } else false
        }
        v.onTap = tap@{
            if (miniState != 0) { restoreBubble(); return@tap }
            if (npPrefs.bubbleTapPlay) {
                if (state != PlaybackState.Stopped) {
                    val willPlay = state != PlaybackState.Playing
                    music.togglePause()
                    v.flashAction(willPlay)
                }
            } else togglePopup()
        }
        v.onLong = lg@{
            if (miniState != 0) { restoreBubble(); return@lg }
            if (npPrefs.bubbleTapPlay) togglePopup()
            else try { music.openPlayer()?.send() } catch (e: Exception) {}
        }
        v.onDrag = { dx, dy ->
            if (popup != null) closePopup(true)
            if (miniState == 1) miniState = 0
            lp.x = (lp.x + dx).toInt().coerceIn(-inset, screenW() - total + inset)
            lp.y = (lp.y + dy).toInt().coerceIn(-inset, screenH() - total + inset)
            try { wm.updateViewLayout(v, lp) } catch (e: Exception) {}
            if (miniState == 0) { showZone(); updateZone() }
        }
        v.onRelease = { if (inZone) dropInZone() else snap(); hideZone() }
        v.alpha = 0f
        try { wm.addView(v, lp) } catch (e: Exception) { status = "Bubble: couldn't be shown"; return }
        bubble = v
        bubbleLp = lp
        v.animate().alpha(BubbleSettings.opacity(this) / 100f).setDuration(220).start()
    }

    private fun removeBubble(immediate: Boolean) {
        hideZone()
        val v = bubble ?: return
        handler.removeCallbacks(savePos)
        savePos.run()
        bubble = null
        bubbleLp = null
        if (immediate) { try { wm.removeView(v) } catch (e: Exception) {}; return }
        v.animate().alpha(0f).setDuration(220).withEndAction { try { wm.removeView(v) } catch (e: Exception) {} }.start()
    }

    // 0 normal, 1 tucked into the edge, 2 shrunk to a dot
    private var miniState = 0
    private var preTuckX = 0

    private fun slideTo(tx: Int, ms: Long = 200) {
        val v = bubble ?: return
        val lp = bubbleLp ?: return
        ValueAnimator.ofInt(lp.x, tx).apply {
            duration = ms
            addUpdateListener { lp.x = it.animatedValue as Int; try { wm.updateViewLayout(v, lp) } catch (e: Exception) {} }
            start()
        }
    }

    private fun tuck(right: Boolean) {
        val v = bubble ?: return
        val lp = bubbleLp ?: return
        closePopup(true)
        preTuckX = lp.x
        val vis = (14 * d).toInt()
        val tx = if (right) screenW() - v.inset.toInt() - vis else vis + v.inset.toInt() - v.totalPx
        miniState = 1
        slideTo(tx)
    }

    private var zoneView: View? = null
    private var zoneCx = 0
    private var zoneCy = 0
    private var inZone = false

    private fun showZone() {
        if (!BubbleSettings.dot(this) || zoneView != null) return
        val size = (64 * d).toInt()
        val z = object : View(this) {
            override fun onDraw(c: android.graphics.Canvas) {
                val pt = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
                pt.color = android.graphics.Color.argb(if (inZone) 200 else 110, 20, 20, 24)
                c.drawCircle(width / 2f, height / 2f, width / 2f * (if (inZone) 1f else 0.82f), pt)
                pt.style = android.graphics.Paint.Style.STROKE
                pt.strokeWidth = 2.2f * d
                pt.strokeCap = android.graphics.Paint.Cap.ROUND
                pt.color = android.graphics.Color.WHITE
                c.drawLine(width / 2f - 9f * d, height / 2f, width / 2f + 9f * d, height / 2f, pt)
            }
        }
        val lp = WindowManager.LayoutParams(
            size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = (screenW() - size) / 2
        lp.y = screenH() - size - (110 * d).toInt()
        zoneCx = lp.x + size / 2
        zoneCy = lp.y + size / 2
        z.alpha = 0f
        try { wm.addView(z, lp) } catch (e: Exception) { return }
        zoneView = z
        z.animate().alpha(1f).setDuration(150).start()
    }

    private fun updateZone() {
        val v = bubble ?: return
        val lp = bubbleLp ?: return
        val now = Math.hypot((lp.x + v.totalPx / 2 - zoneCx).toDouble(), (lp.y + v.totalPx / 2 - zoneCy).toDouble()) < 60 * d
        if (now != inZone) { inZone = now; zoneView?.invalidate() }
    }

    private fun hideZone() {
        val z = zoneView ?: return
        zoneView = null
        inZone = false
        try { wm.removeView(z) } catch (e: Exception) {}
    }

    private fun dropInZone() {
        val v = bubble ?: return
        val lp = bubbleLp ?: return
        lp.x = zoneCx - v.totalPx / 2
        lp.y = zoneCy - v.totalPx / 2
        try { wm.updateViewLayout(v, lp) } catch (e: Exception) {}
        closePopup(true)
        miniState = 2
        v.animate().scaleX(0.4f).scaleY(0.4f).alpha(BubbleSettings.opacity(this) / 100f * 0.8f).setDuration(200).start()
        handler.removeCallbacks(savePos)
        handler.postDelayed(savePos, 400)
    }

    private fun restoreBubble() {
        val v = bubble ?: return
        if (miniState == 1) slideTo(preTuckX)
        if (miniState == 2) v.animate().scaleX(1f).scaleY(1f).alpha(BubbleSettings.opacity(this) / 100f).setDuration(200).start()
        miniState = 0
        handler.removeCallbacks(savePos)
        handler.postDelayed(savePos, 500)
    }

    private fun snap() {
        val v = bubble ?: return
        val lp = bubbleLp ?: return
        if (!BubbleSettings.snap(this)) { handler.removeCallbacks(savePos); handler.postDelayed(savePos, 300); return }
        val total = v.totalPx
        val inset = v.inset.toInt()
        val m = (4 * d).toInt()
        val tx = if (lp.x + total / 2 < screenW() / 2) m - inset else screenW() - total + inset - m
        slideTo(tx, 180)
        handler.removeCallbacks(savePos)
        handler.postDelayed(savePos, 400)
    }

    // ------------------------------------------------------------------ pop-up card

    private fun togglePopup() { if (popup != null) closePopup(false) else openPopup() }

    private fun armClose() {
        handler.removeCallbacks(popupClose)
        if (npPrefs.popupClose > 0) handler.postDelayed(popupClose, npPrefs.popupClose * 1000L)
    }

    private fun openPopup() {
        try { openPopupInner() } catch (e: Throwable) {
            status = "Bubble: panel failed (" + e.javaClass.simpleName + ")"
            closePopup(true)
        }
    }

    private fun openPopupInner() {
        val b = bubble
        val lp = bubbleLp
        val sw = screenW()
        val sh = screenH()
        val margin = (8 * d).toInt()
        val pw = minOf((npPrefs.popupWidth * d).toInt(), sw - 2 * margin)
        val card = CardView(this, npPrefs)
        card.renderer.showMinChip = npPrefs.bubbleDot
        card.onMinimize = { dropShrink() }
        card.measure(View.MeasureSpec.makeMeasureSpec(pw, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(sh, View.MeasureSpec.AT_MOST))
        val ph = card.measuredHeight
        // With no bubble (card-only mode) the card opens centred, a little below the top.
        val total = b?.totalPx ?: 0
        val inset = b?.inset?.toInt() ?: 0
        val lpX = lp?.x ?: (sw / 2)
        val lpY = lp?.y ?: (sh * 0.25f).toInt()
        val bx = lpX + total / 2
        val x = (bx - pw / 2).coerceIn(margin, sw - pw - margin)
        val below = lpY + total - inset + margin
        val fitsBelow = below + ph <= sh - margin
        val y = if (fitsBelow) below else (lpY + inset - margin - ph).coerceAtLeast(margin)
        val sc = View(this)
        sc.setOnClickListener { closePopup(false) }
        val scLp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        val cLp = WindowManager.LayoutParams(
            pw, ph, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        cLp.gravity = Gravity.TOP or Gravity.START
        cLp.x = x
        cLp.y = y
        card.onInteract = { armClose() }
        card.onTap = {
            val i = MediaState.launchIntent(this)
            if (i != null) {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try { startActivity(i) } catch (e: Exception) {}
            }
            closePopup(false)
        }
        card.alpha = 0f
        card.pivotX = (bx - x).toFloat().coerceIn(0f, pw.toFloat())
        card.pivotY = if (fitsBelow) 0f else ph.toFloat()
        card.scaleX = 0.88f
        card.scaleY = 0.88f
        try {
            wm.addView(sc, scLp)
            wm.addView(card, cLp)
        } catch (e: Exception) {
            try { wm.removeView(sc) } catch (e2: Exception) {}
            status = "Bubble: panel couldn't be shown"
            return
        }
        scrim = sc
        popup = card
        card.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(180).start()
        armClose()
    }

    private fun dropShrink() {
        val v = bubble ?: return
        closePopup(true)
        miniState = 2
        v.animate().scaleX(0.4f).scaleY(0.4f).alpha(BubbleSettings.opacity(this) / 100f * 0.8f).setDuration(200).start()
    }

    private fun closePopup(immediate: Boolean) {
        handler.removeCallbacks(popupClose)
        val card = popup
        val sc = scrim
        popup = null
        scrim = null
        if (sc != null) { try { wm.removeView(sc) } catch (e: Exception) {} }
        if (cardOnly) handler.postDelayed({ if (cardOnly && popup == null) stopSelf() }, 500)
        if (card == null) return
        if (immediate) { try { wm.removeView(card) } catch (e: Exception) {}; return }
        card.animate().alpha(0f).scaleX(0.9f).scaleY(0.9f).setDuration(150).withEndAction { try { wm.removeView(card) } catch (e: Exception) {} }.start()
    }
}
