package de.mm20.launcher2.ui.launcher.widgets.facesclock

import android.graphics.Rect
import android.os.PowerManager
import android.view.View

/**
 * Tells a view whether it can really be seen right now (on screen, window shown, screen on), and calls
 * [onTick] about once a second so audio capture, sensors and animation loops can be released when it can't.
 */
class ViewGate(private val v: View, private val onTick: (Boolean) -> Unit) {
    private val r = Rect()
    private var running = false
    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            onTick(visible(v, r))
            v.postDelayed(this, 1000L)
        }
    }

    fun start() {
        if (running) return
        running = true
        v.post(tick)
    }

    fun stop() {
        running = false
        v.removeCallbacks(tick)
    }

    /** Re-check right away (after a media change, say). */
    fun poke() { if (running) onTick(visible(v, r)) }

    companion object {
        fun visible(v: View, r: Rect = Rect()): Boolean {
            if (!v.isAttachedToWindow || v.windowVisibility != View.VISIBLE || !v.isShown) return false
            val pm = v.context.getSystemService(PowerManager::class.java)
            if (pm != null && !pm.isInteractive) return false
            return v.getGlobalVisibleRect(r) && r.width() > 8 && r.height() > 8
        }
    }
}
