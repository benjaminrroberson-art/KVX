package de.mm20.launcher2.ui.launcher.widgets.facesclock

import android.Manifest
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.SystemClock
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import de.mm20.launcher2.widgets.KvxToolWidgetConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sqrt

private val noteNames = arrayOf("C", "C♯", "D", "D♯", "E", "F", "F♯", "G", "G♯", "A", "A♯", "B")
private const val TW = 2048
private const val TMAX = 1000

/** YIN pitch detection. Returns frequency in Hz or -1. */
private fun yin(x: FloatArray, rate: Int): Float {
    val d = FloatArray(TMAX)
    for (tau in 1 until TMAX) {
        var sum = 0f
        for (j in 0 until TW) { val diff = x[j] - x[j + tau]; sum += diff * diff }
        d[tau] = sum
    }
    var running = 0f
    d[0] = 1f
    for (tau in 1 until TMAX) { running += d[tau]; d[tau] = if (running > 0f) d[tau] * tau / running else 1f }
    var tau = 2
    var found = -1
    while (tau < TMAX - 1) {
        if (d[tau] < 0.13f) {
            while (tau + 1 < TMAX - 1 && d[tau + 1] < d[tau]) tau++
            found = tau; break
        }
        tau++
    }
    if (found < 0) return -1f
    val a = d[found - 1]; val b = d[found]; val c = d[found + 1]
    val den = a + c - 2 * b
    val shift = if (abs(den) > 1e-9f) (a - c) / (2 * den) else 0f
    return rate / (found + shift)
}

@Composable
fun TunerTool(cfg: KvxToolWidgetConfig) {
    val ctx = LocalContext.current
    val (visible, posMod) = rememberOnScreen()
    var on by remember { mutableStateOf(false) }
    val running = on && visible
    var denied by remember { mutableStateOf(false) }
    val ask = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) on = true else denied = true }
    LaunchedEffect(visible) { if (!visible) on = false }

    var freq by remember { mutableFloatStateOf(0f) }
    var seen by remember { mutableStateOf(0L) }
    var tick by remember { mutableIntStateOf(0) }

    LaunchedEffect(running) {
        if (!running) return@LaunchedEffect
        withContext(Dispatchers.Default) {
            val rate = 44100
            val minBuf = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val rec = try {
                AudioRecord(MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, max(minBuf, 16384))
                    .also { if (it.state != AudioRecord.STATE_INITIALIZED) { it.release(); throw IllegalStateException() } }
            } catch (e: Exception) { null } ?: return@withContext
            try {
                rec.startRecording()
                val buf = FloatArray(TW + TMAX + 8)
                val chunk = ShortArray(1024)
                val recent = ArrayList<Float>()
                while (isActive) {
                    val r = rec.read(chunk, 0, chunk.size)
                    if (r <= 0) break
                    System.arraycopy(buf, r, buf, 0, buf.size - r)
                    for (i in 0 until r) buf[buf.size - r + i] = chunk[i] / 32768f
                    var e = 0f
                    for (i in buf.size - TW until buf.size) e += buf[i] * buf[i]
                    val rms = sqrt(e / TW)
                    if (rms < 0.006f) { continue }
                    val f = yin(buf, rate)
                    if (f in 40f..1800f) {
                        recent.add(f); if (recent.size > 5) recent.removeAt(0)
                        freq = recent.sorted()[recent.size / 2]
                        seen = SystemClock.elapsedRealtime()
                        tick++
                    }
                }
            } finally { try { rec.stop() } catch (_: Exception) {}; rec.release() }
        }
    }
    // let the reading fade after a moment of silence
    LaunchedEffect(running) { while (running) { kotlinx.coroutines.delay(300); tick++ } }
    @Suppress("UNUSED_EXPRESSION") tick

    val fresh = running && freq > 0f && SystemClock.elapsedRealtime() - seen < 1500
    val midiF = if (freq > 0f) 69.0 + 12.0 * ln(freq / cfg.a4.toDouble()) / ln(2.0) else 0.0
    val midi = midiF.roundToInt()
    val cents = if (freq > 0f) ((midiF - midi) * 100).toFloat() else 0f
    val inTune = fresh && abs(cents) <= 5f
    val good = Color(0xFF4CAF50)
    val track = MaterialTheme.colorScheme.surfaceVariant

    ToolCard {
        Column(Modifier.fillMaxWidth().then(posMod), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    if (fresh) noteNames[((midi % 12) + 12) % 12] else "--",
                    style = MaterialTheme.typography.displayLarge,
                    color = if (inTune) good else MaterialTheme.colorScheme.onSurface,
                )
                if (fresh) Text("${midi / 12 - 1}", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(start = 2.dp, bottom = 10.dp))
            }
            Text(
                if (fresh) "%.1f Hz   %+.0f cents".format(freq, cents) else if (running) "Play a note" else "Tap to listen",
                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Canvas(Modifier.fillMaxWidth().height(44.dp).padding(vertical = 8.dp)) {
                val mid = size.width / 2f
                drawRoundRect(track, Offset.Zero, size, CornerRadius(8.dp.toPx()))
                drawRect(good.copy(alpha = 0.35f), Offset(mid - size.width * 0.05f, 0f), Size(size.width * 0.1f, size.height))
                for (k in -5..5) drawRect(Color.White.copy(alpha = 0.35f), Offset(mid + size.width * k / 10.4f - 1f, size.height * (if (k % 5 == 0) 0.1f else 0.3f)), Size(2f, size.height * (if (k % 5 == 0) 0.8f else 0.4f)))
                if (fresh) {
                    val x = mid + size.width * (cents.coerceIn(-50f, 50f) / 100f)
                    drawRoundRect(if (inTune) good else Color(0xFFFFB300), Offset(x - 4.dp.toPx(), 0f), Size(8.dp.toPx(), size.height), CornerRadius(4.dp.toPx()))
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("flat", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("sharp", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = {
                    if (on) on = false
                    else if (ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) ask.launch(Manifest.permission.RECORD_AUDIO)
                    else { on = true; freq = 0f }
                }) { Text(if (running) "Stop" else "Tap to listen") }
                if (denied && !running) Text("  Microphone permission is needed", style = MaterialTheme.typography.bodySmall)
                else Text("  A4 = ${cfg.a4} Hz", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
