package de.mm20.launcher2.ui.settings.homescreen

import androidx.appcompat.app.AppCompatActivity
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ButtonGroupDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.ToggleButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation3.runtime.NavKey
import de.mm20.launcher2.preferences.SearchBarColors
import de.mm20.launcher2.preferences.SearchBarStyle
import de.mm20.launcher2.preferences.SystemBarColors
import de.mm20.launcher2.ui.R
import de.mm20.launcher2.ui.component.DismissableBottomSheet
import de.mm20.launcher2.ui.component.SearchBar
import de.mm20.launcher2.ui.component.SearchBarLevel
import de.mm20.launcher2.ui.component.preferences.ListPreference
import de.mm20.launcher2.ui.component.preferences.Preference
import de.mm20.launcher2.ui.component.preferences.PreferenceCategory
import de.mm20.launcher2.ui.component.preferences.PreferenceScreen
import de.mm20.launcher2.ui.component.preferences.SliderPreference
import de.mm20.launcher2.ui.component.preferences.SwitchPreference
import de.mm20.launcher2.ui.launcher.widgets.clock.ConfigureClockWidgetSheet
import de.mm20.launcher2.ui.locals.LocalDarkTheme
import de.mm20.launcher2.ui.locals.LocalPreferDarkContentOverWallpaper
import kotlinx.serialization.Serializable

@Serializable
data object HomescreenSettingsRoute : NavKey

@Serializable
data class HomescreenPageRoute(val page: String) : NavKey

@Composable
fun HomescreenSettingsScreen() {
    val back = de.mm20.launcher2.ui.locals.LocalBackStack.current
    PreferenceScreen(title = stringResource(id = R.string.preference_screen_homescreen)) {
        item {
            PreferenceCategory {
                Preference(icon = R.drawable.widgets_24px, title = "Layout and widgets", summary = "Rotation, clock, dock, widgets on the home screen, edit button", onClick = { back.add(HomescreenPageRoute("layout")) })
                Preference(icon = R.drawable.search_24px, title = "Search bar", summary = "Style, colors, position, fixed or scrolling", onClick = { back.add(HomescreenPageRoute("search")) })
                Preference(icon = R.drawable.palette_24px, title = "Wallpaper", summary = "Choose, dim and blur", onClick = { back.add(HomescreenPageRoute("wallpaper")) })
                Preference(icon = R.drawable.bolt_24px, title = "Animations and system bars", summary = "Charging animation, status and navigation bar", onClick = { back.add(HomescreenPageRoute("system")) })
            }
        }
    }
}

@Composable
fun HomescreenPageScreen(page: String) {
    val viewModel: HomescreenSettingsScreenVM =
        viewModel(factory = HomescreenSettingsScreenVM.Factory)

    val context = LocalContext.current

    val dock by viewModel.dock.collectAsStateWithLifecycle(null)
    val dockRows by viewModel.dockRows.collectAsStateWithLifecycle(1)
    val fixedRotation by viewModel.fixedRotation.collectAsStateWithLifecycle(null)
    val widgetsOnHomeScreen by viewModel.widgetsOnHomeScreen.collectAsStateWithLifecycle(null)
    val editButton by viewModel.widgetEditButton.collectAsStateWithLifecycle(null)
    val searchBarStyle by viewModel.searchBarStyle.collectAsStateWithLifecycle(null)
    val searchBarColor by viewModel.searchBarColor.collectAsStateWithLifecycle(null)
    val bottomSearchBar by viewModel.bottomSearchBar.collectAsStateWithLifecycle(null)
    val fixedSearchBar by viewModel.fixedSearchBar.collectAsStateWithLifecycle(null)
    val lightStatusBar by viewModel.statusBarIcons.collectAsStateWithLifecycle(null)
    val dimWallpaper by viewModel.dimWallpaper.collectAsStateWithLifecycle()
    val blurWallpaper by viewModel.blurWallpaper.collectAsStateWithLifecycle()
    val blurWallpaperRadius by viewModel.blurWallpaperRadius.collectAsStateWithLifecycle()
    val lightNavBar by viewModel.navBarIcons.collectAsStateWithLifecycle(null)
    val hideStatusBar by viewModel.hideStatusBar.collectAsStateWithLifecycle(null)
    val hideNavBar by viewModel.hideNavBar.collectAsStateWithLifecycle(null)
    val chargingAnimation by viewModel.chargingAnimation.collectAsStateWithLifecycle(null)

    PreferenceScreen(title = when (page) { "layout" -> "Layout and widgets"; "search" -> "Search bar"; "wallpaper" -> "Wallpaper"; else -> "Animations and system bars" }) {
        if (page == "layout") item {
            PreferenceCategory {
                SwitchPreference(
                    title = stringResource(R.string.preference_layout_fixed_rotation),
                    summary = stringResource(R.string.preference_layout_fixed_rotation_summary),
                    value = fixedRotation == true,
                    onValueChanged = {
                        viewModel.setFixedRotation(it)
                    },
                )
            }
        }
        if (page == "layout") item {
            PreferenceCategory(
                title = stringResource(id = R.string.preference_category_widgets)
            ) {
                val widgetBack = de.mm20.launcher2.ui.locals.LocalBackStack.current
                Preference(
                    title = "Customize widgets",
                    summary = "Every widget with a live preview: clock, weather, battery, scenes and more",
                    onClick = { widgetBack.add(de.mm20.launcher2.ui.settings.widgets.WidgetsSettingsRoute) }
                )
                Preference(
                    title = stringResource(R.string.preference_screen_clockwidget),
                    summary = stringResource(R.string.preference_screen_clockwidget_summary),
                    onClick = {
                        viewModel.showClockWidgetSheet = true
                    }
                )
                SwitchPreference(
                    title = stringResource(R.string.preference_clockwidget_favorites_part),
                    summary = stringResource(R.string.preference_clockwidget_favorites_part_summary),
                    value = dock == true,
                    onValueChanged = {
                        viewModel.setDock(it)
                    },
                )
                AnimatedVisibility(dock == true) {
                    SliderPreference(
                        title = stringResource(R.string.preference_clockwidget_dock_rows),
                        value = dockRows,
                        min = 1,
                        max = 4,
                        onValueChanged = {
                            viewModel.setDockRows(it)
                        }
                    )
                }
                SwitchPreference(
                    title = stringResource(R.string.preference_widgets_on_home_screen),
                    summary = stringResource(R.string.preference_widgets_on_home_screen_summary),
                    value = widgetsOnHomeScreen == true,
                    onValueChanged = {
                        viewModel.setWidgetsOnHomeScreen(it)
                    })
                SwitchPreference(
                    title = stringResource(id = R.string.preference_edit_button),
                    summary = stringResource(id = R.string.preference_widgets_edit_button_summary),
                    value = editButton == true,
                    onValueChanged = {
                        viewModel.setWidgetEditButton(it)
                    })
            }

        }
        if (page == "search") item { KvxSearchBarCategory() }
        if (page == "search") item {
            PreferenceCategory(stringResource(R.string.preference_category_searchbar)) {
                SearchBarStylePreference(
                    title = stringResource(R.string.preference_search_bar_style),
                    summary = stringResource(R.string.preference_search_bar_style_summary),
                    value = searchBarStyle,
                    colors = searchBarColor,
                    onStyleChanged = {
                        viewModel.setSearchBarStyle(it)
                    },
                    onColorsChanged = {
                        viewModel.setSearchBarColor(it)
                    }
                )

                ListPreference(
                    title = stringResource(R.string.preference_layout_search_bar_position),
                    items = listOf(
                        stringResource(R.string.search_bar_position_top) to false,
                        stringResource(R.string.search_bar_position_bottom) to true,
                    ),
                    value = bottomSearchBar,
                    onValueChanged = {
                        if (it != null) viewModel.setBottomSearchBar(it)
                    },
                )
                SwitchPreference(
                    title = stringResource(R.string.preference_layout_fixed_search_bar),
                    summary = stringResource(R.string.preference_layout_fixed_search_bar_summary),
                    value = fixedSearchBar == true,
                    onValueChanged = {
                        viewModel.setFixedSearchBar(it)
                    },
                )
            }
        }
        if (page == "wallpaper") item {
            PreferenceCategory(stringResource(id = R.string.preference_category_wallpaper)) {
                Preference(
                    title = stringResource(R.string.wallpaper),
                    summary = stringResource(R.string.preference_wallpaper_summary),
                    onClick = {
                        viewModel.openWallpaperChooser(context as AppCompatActivity)
                    }
                )
                SwitchPreference(
                    title = stringResource(R.string.preference_dim_wallpaper),
                    summary = stringResource(R.string.preference_dim_wallpaper_summary),
                    value = dimWallpaper,
                    onValueChanged = {
                        viewModel.setDimWallpaper(it)
                    }
                )
                val isBlurSupported = remember { viewModel.isBlurAvailable(context) }
                SwitchPreference(
                    title = stringResource(R.string.preference_blur_wallpaper),
                    summary = stringResource(
                        if (isBlurSupported) R.string.preference_blur_wallpaper_summary
                        else R.string.preference_blur_wallpaper_unsupported
                    ),
                    value = blurWallpaper && isBlurSupported,
                    onValueChanged = {
                        viewModel.setBlurWallpaper(it)
                    },
                    enabled = isBlurSupported
                )
                AnimatedVisibility(blurWallpaper && isBlurSupported) {
                    SliderPreference(
                        title = stringResource(R.string.preference_blur_wallpaper_radius),
                        value = blurWallpaperRadius,
                        onValueChanged = {
                            viewModel.setBlurWallpaperRadius(it)
                        },
                        min = 4,
                        max = 64,
                        step = 4,
                    )
                }
            }
        }
        if (page == "system") item {
            PreferenceCategory(stringResource(R.string.preference_category_animations)) {
                val actx = LocalContext.current
                var launchMode by remember { mutableStateOf(de.mm20.launcher2.ui.theme.KvxLaunchAnim.mode(actx)) }
                ListPreference(
                    title = "App open and close animation",
                    summary = "How the launcher moves when an app opens, and when you come back",
                    items = de.mm20.launcher2.ui.theme.KvxLaunchAnim.names.mapIndexed { i, n -> n to i },
                    value = launchMode,
                    onValueChanged = { launchMode = it; de.mm20.launcher2.ui.theme.KvxLaunchAnim.setMode(actx, it) },
                )
                var lockMode by remember { mutableStateOf(de.mm20.launcher2.ui.theme.KvxLockAnim.mode(actx)) }
                ListPreference(
                    title = "Screen lock animation",
                    summary = "Plays when the launcher locks the screen (lock gesture or Screen off action). The power button\u2019s effect is controlled by Android.",
                    items = de.mm20.launcher2.ui.theme.KvxLockAnim.names.mapIndexed { i, n -> n to i },
                    value = lockMode,
                    onValueChanged = { lockMode = it; de.mm20.launcher2.ui.theme.KvxLockAnim.setMode(actx, it) },
                )
                SwitchPreference(
                    title = stringResource(R.string.preference_charging_animation),
                    summary = stringResource(R.string.preference_charging_animation_summary),
                    value = chargingAnimation == true,
                    onValueChanged = {
                        viewModel.setChargingAnimation(it)
                    }
                )
                if (chargingAnimation == true) ChargingStylePreference()
            }
        }
        if (page == "system") item {

            PreferenceCategory(stringResource(R.string.preference_category_system_bars)) {
                ListPreference(
                    title = stringResource(R.string.preference_status_bar_icons),
                    value = lightStatusBar,
                    items = listOf(
                        stringResource(R.string.preference_system_bar_icons_auto) to SystemBarColors.Auto,
                        stringResource(R.string.preference_system_bar_icons_light) to SystemBarColors.Light,
                        stringResource(R.string.preference_system_bar_icons_dark) to SystemBarColors.Dark,
                    ),
                    onValueChanged = {
                        if (it != null) viewModel.setLightStatusBar(it)
                    }
                )
                ListPreference(
                    title = stringResource(R.string.preference_nav_bar_icons),
                    value = lightNavBar,
                    items = listOf(
                        stringResource(R.string.preference_system_bar_icons_auto) to SystemBarColors.Auto,
                        stringResource(R.string.preference_system_bar_icons_light) to SystemBarColors.Light,
                        stringResource(R.string.preference_system_bar_icons_dark) to SystemBarColors.Dark,
                    ),
                    onValueChanged = {
                        if (it != null) viewModel.setLightNavBar(it)
                    }
                )
                SwitchPreference(
                    title = stringResource(R.string.preference_hide_status_bar),
                    value = hideStatusBar == true,
                    onValueChanged = {
                        viewModel.setHideStatusBar(it)
                    }
                )
                SwitchPreference(
                    title = stringResource(R.string.preference_hide_nav_bar),
                    value = hideNavBar == true,
                    onValueChanged = {
                        viewModel.setHideNavBar(it)
                    }
                )
            }
        }
    }

    ConfigureClockWidgetSheet(
        expanded = viewModel.showClockWidgetSheet,
        onDismiss = { viewModel.showClockWidgetSheet = false }
    )
}

@Composable
fun SearchBarStylePreference(
    title: String,
    summary: String? = null,
    value: SearchBarStyle?,
    colors: SearchBarColors?,
    onStyleChanged: (SearchBarStyle) -> Unit,
    onColorsChanged: (SearchBarColors) -> Unit
) {
    var showDialog by remember { mutableStateOf(false) }
    Preference(title = title, summary = summary, onClick = { showDialog = true })

    DismissableBottomSheet(
        expanded = showDialog,
        onDismissRequest = {
            showDialog = false
        }
    ) {
        val styles = SearchBarStyle.entries

        val darkColors =
            LocalPreferDarkContentOverWallpaper.current && colors == SearchBarColors.Auto || colors == SearchBarColors.Dark

        Box(
            modifier = Modifier
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
                .navigationBarsPadding(),
        ) {
            Column(
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                for (style in styles) {
                    Column {
                        Row(
                            modifier = Modifier
                                .padding(top = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                text = stringResource(
                                    when (style) {
                                        SearchBarStyle.Transparent -> R.string.preference_search_bar_style_transparent
                                        SearchBarStyle.Solid -> R.string.preference_search_bar_style_solid
                                        SearchBarStyle.Hidden -> R.string.preference_search_bar_style_hidden
                                    }
                                ),
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.weight(1f),
                            )
                            IconButton(
                                onClick = {
                                    onStyleChanged(style)
                                }
                            ) {
                                Icon(
                                    painterResource(
                                        if (style == value) R.drawable.check_circle_24px_filled
                                        else R.drawable.circle_24px
                                    ),
                                    contentDescription = null,
                                    tint = if (style == value) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                                )
                            }
                        }
                        Box(
                            modifier = Modifier
                                .border(
                                    if (style == value) 4.dp else 2.dp,
                                    if (style == value) MaterialTheme.colorScheme.primary else Color.Transparent,
                                    MaterialTheme.shapes.medium,
                                )
                                .clip(MaterialTheme.shapes.medium)
                                .background(
                                    when {
                                        style != SearchBarStyle.Transparent -> MaterialTheme.colorScheme.inverseSurface
                                        LocalDarkTheme.current != darkColors -> MaterialTheme.colorScheme.surfaceContainer
                                        else -> MaterialTheme.colorScheme.inverseSurface
                                    }
                                )
                                .height(IntrinsicSize.Min)
                        ) {
                            SearchBar(
                                modifier = Modifier
                                    .padding(16.dp),
                                level = SearchBarLevel.Resting,
                                style = style,
                                value = "",
                                onValueChange = {},
                                readOnly = true,
                                darkColors = darkColors,
                            )
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clickable {
                                        onStyleChanged(style)
                                    }
                            )
                        }
                        if (style == SearchBarStyle.Transparent) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 16.dp),
                                horizontalArrangement = Arrangement.spacedBy(ButtonGroupDefaults.ConnectedSpaceBetween)
                            ) {
                                ToggleButton(
                                    modifier = Modifier.weight(1f),
                                    checked = colors == SearchBarColors.Auto,
                                    onCheckedChange = {
                                        onColorsChanged(SearchBarColors.Auto)
                                    },
                                    shapes = ButtonGroupDefaults.connectedLeadingButtonShapes(),
                                ) {
                                    Icon(
                                        painterResource(R.drawable.auto_awesome_20dp),
                                        contentDescription = null,
                                    )
                                }
                                ToggleButton(
                                    modifier = Modifier.weight(1f),
                                    checked = colors == SearchBarColors.Light,
                                    onCheckedChange = {
                                        onColorsChanged(SearchBarColors.Light)
                                    },
                                    shapes = ButtonGroupDefaults.connectedMiddleButtonShapes(),
                                ) {
                                    Icon(
                                        painterResource(R.drawable.light_mode_24px),
                                        contentDescription = null,
                                    )
                                }
                                ToggleButton(
                                    modifier = Modifier.weight(1f),
                                    checked = colors == SearchBarColors.Dark,
                                    onCheckedChange = {
                                        onColorsChanged(SearchBarColors.Dark)
                                    },
                                    shapes = ButtonGroupDefaults.connectedTrailingButtonShapes(),
                                ) {
                                    Icon(
                                        painterResource(R.drawable.dark_mode_24px),
                                        contentDescription = null,
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}


@Composable
private fun KvxSearchBarCategory() {
    val ctx = LocalContext.current
    val sp = remember { de.mm20.launcher2.ui.component.KvxSearchBarStyle.sp(ctx) }
    var rev by remember { mutableStateOf(0) }
    fun putI(k: String, v: Int) { sp.edit().putInt(k, v).apply(); rev++ }
    fun putB(k: String, v: Boolean) { sp.edit().putBoolean(k, v).apply(); rev++ }
    PreferenceCategory("Search bar style") {
        @Suppress("UNUSED_EXPRESSION") rev
        KvxSearchBarPreview()
        ListPreference(
            title = "Shape",
            items = de.mm20.launcher2.ui.component.KvxSearchBarStyle.shapeNames.mapIndexed { i, n -> n to i },
            value = sp.getInt("shape", 0),
            onValueChanged = { putI("shape", it) },
        )
        de.mm20.launcher2.ui.component.preferences.SliderPreference(
            title = "Height",
            value = sp.getInt("height", 48),
            min = 36,
            max = 80,
            onValueChanged = { putI("height", it) },
            label = { Text("$it dp") },
        )
        de.mm20.launcher2.ui.component.preferences.SliderPreference(
            title = "Text size",
            value = sp.getInt("textScale", 100),
            min = 80,
            max = 140,
            onValueChanged = { putI("textScale", it) },
            label = { Text("$it%") },
        )
        de.mm20.launcher2.ui.component.preferences.SliderPreference(
            title = "Background opacity",
            value = sp.getInt("bgAlpha", -1),
            min = -1,
            max = 100,
            onValueChanged = { putI("bgAlpha", it) },
            label = { Text(if (it < 0) "Theme default" else "$it%") },
        )
        de.mm20.launcher2.ui.component.preferences.SliderPreference(
            title = "Border",
            value = sp.getInt("border", 0),
            min = 0,
            max = 4,
            onValueChanged = { putI("border", it) },
            label = { Text(if (it == 0) "None" else "$it dp") },
        )
        if (sp.getInt("border", 0) > 0) SwitchPreference(
            title = "Accent color border",
            summary = "Off uses the neutral outline color",
            value = sp.getBoolean("borderAccent", true),
            onValueChanged = { putB("borderAccent", it) },
        )
        SwitchPreference(
            title = "Show search icon",
            value = sp.getBoolean("icon", true),
            onValueChanged = { putB("icon", it) },
        )
        var text by remember { mutableStateOf(sp.getString("placeholder", "") ?: "") }
        androidx.compose.material3.OutlinedTextField(
            value = text,
            onValueChange = { text = it; sp.edit().putString("placeholder", it).apply() },
            singleLine = true,
            label = { Text("Placeholder text (blank for default)") },
            modifier = androidx.compose.ui.Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        )
    }
}


/** Live sample of the search bar with the current style, shown above the options. */
@Composable
private fun KvxSearchBarPreview() {
    val kx = de.mm20.launcher2.ui.component.KvxSearchBarStyle.current()
    val cs = androidx.compose.material3.MaterialTheme.colorScheme
    val shape = kx.shapeOr(androidx.compose.foundation.shape.RoundedCornerShape(12.dp))
    val a = if (kx.bgAlphaPct < 0) 1f else kx.bgAlphaPct / 100f
    val ts = androidx.compose.material3.MaterialTheme.typography.bodyLarge
    androidx.compose.foundation.layout.Box(
        Modifier
            .fillMaxWidth()
            .background(cs.surfaceVariant.copy(alpha = 0.5f))
            .padding(horizontal = 16.dp, vertical = 14.dp)
    ) {
        androidx.compose.foundation.layout.Row(
            Modifier
                .fillMaxWidth()
                .height(kx.heightDp.dp)
                .clip(shape)
                .background(cs.surfaceContainerHigh.copy(alpha = a))
                .then(if (kx.borderDp > 0) Modifier.border(kx.borderDp.dp, if (kx.borderAccent) cs.primary else cs.outline, shape) else Modifier)
                .padding(horizontal = 16.dp),
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
        ) {
            if (kx.showIcon) {
                androidx.compose.material3.Icon(
                    androidx.compose.ui.res.painterResource(de.mm20.launcher2.ui.R.drawable.search_24px), null,
                    tint = cs.onSurfaceVariant, modifier = Modifier.padding(end = 12.dp),
                )
            }
            Text(
                kx.placeholder.ifBlank { "Search" },
                color = cs.onSurfaceVariant,
                style = ts.copy(fontSize = ts.fontSize * kx.textScalePct / 100f),
            )
        }
    }
}
