package de.mm20.launcher2.ui.launcher.widgets.facesclock

import android.content.Context
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import de.mm20.launcher2.ui.launcher.widgets.facesclock.np.MediaState

/**
 * Holds the shared audio analysis for one view. Turning it on is immediate; turning it off waits a few
 * seconds, so a track change, a short pause or scrolling past the widget doesn't tear the analyser down
 * and rebuild it (which is slow and can fail), while a widget that stays hidden still lets go.
 */
class AudioHold(private val ctx: Context, private val graceMs: Long = 5000L) {
    private var held = false
    private val h = Handler(Looper.getMainLooper())
    private val drop = Runnable { if (held) { held = false; VizAudio.stop() } }

    val isHeld: Boolean get() = held

    fun set(on: Boolean) {
        if (on) {
            h.removeCallbacks(drop)
            if (!held) { held = true; VizAudio.start(ctx) }
        } else if (held) {
            h.removeCallbacks(drop)
            h.postDelayed(drop, graceMs)
        }
    }

    fun release() {
        h.removeCallbacks(drop)
        if (held) { held = false; VizAudio.stop() }
    }

    companion object {
        /** Anything is playing: a media session says so, or Android reports music audio. */
        fun musicOn(ctx: Context): Boolean =
            MediaState.playing || (ctx.getSystemService(AudioManager::class.java)?.isMusicActive == true)
    }
}
