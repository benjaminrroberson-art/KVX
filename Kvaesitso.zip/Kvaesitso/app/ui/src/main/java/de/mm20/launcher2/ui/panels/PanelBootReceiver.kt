package de.mm20.launcher2.ui.panels

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Brings the edge panel back after an app update or a reboot, without opening the settings. */
class PanelBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        PanelService.refresh(context.applicationContext)
    }
}
