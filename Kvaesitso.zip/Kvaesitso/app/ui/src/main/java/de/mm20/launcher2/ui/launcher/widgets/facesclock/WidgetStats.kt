package de.mm20.launcher2.ui.launcher.widgets.facesclock

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.Process
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

/**
 * Rough per-widget battery accounting. Android doesn't report usage per widget, so we measure what each
 * widget actually does while it is shown (on-screen time, drawing work, microphone, audio capture,
 * sensors, network requests) and convert that to an estimate with typical phone power figures.
 */
object WidgetStats {
    class Acc {
        @Volatile var visMs = 0.0
        @Volatile var cpuMs = 0.0
        @Volatile var micS = 0.0
        @Volatile var audioS = 0.0
        @Volatile var sensorS = 0.0
        @Volatile var net = 0.0
        @Volatile var frames = 0.0

        /** Estimated charge in mAh. Display power is not included; the screen is on for other reasons. */
        fun mah(): Double =
            cpuMs / 1000.0 * 0.05 * 3.0 +      // drawing CPU, x3 for the render thread and GPU work we can't time
                micS * 0.0075 + audioS * 0.004 + sensorS * 0.00006 + net * 0.3
    }

    private val map = ConcurrentHashMap<String, Acc>()
    private var loaded = false
    private var since = System.currentTimeMillis()
    private var cpuStart = Process.getElapsedCpuTime()
    private var ctx: Context? = null
    private val handler = Handler(Looper.getMainLooper())
    private var scheduled = false

    private fun acc(key: String): Acc {
        return map.getOrPut(key) { Acc() }
    }

    fun init(c: Context) {
        if (loaded) return
        loaded = true
        ctx = c.applicationContext
        try {
            val sp = c.applicationContext.getSharedPreferences("kvx_wstats", Context.MODE_PRIVATE)
            since = sp.getLong("since", since)
            cpuStart = Process.getElapsedCpuTime() - sp.getLong("cpuBase", 0L)
            val j = JSONObject(sp.getString("data", "{}") ?: "{}")
            for (k in j.keys()) {
                val a = j.getJSONArray(k)
                val x = acc(k)
                x.visMs = a.optDouble(0); x.cpuMs = a.optDouble(1); x.micS = a.optDouble(2); x.audioS = a.optDouble(3)
                x.sensorS = a.optDouble(4); x.net = a.optDouble(5); x.frames = a.optDouble(6)
            }
        } catch (_: Exception) {}
        schedule()
    }

    private fun schedule() {
        if (scheduled) return
        scheduled = true
        handler.postDelayed({ scheduled = false; flush(); schedule() }, 60_000L)
    }

    fun flush() {
        val c = ctx ?: return
        try {
            val j = JSONObject()
            for ((k, x) in map) j.put(k, org.json.JSONArray(listOf(x.visMs, x.cpuMs, x.micS, x.audioS, x.sensorS, x.net, x.frames)))
            c.getSharedPreferences("kvx_wstats", Context.MODE_PRIVATE).edit()
                .putString("data", j.toString()).putLong("since", since).putLong("cpuBase", Process.getElapsedCpuTime() - cpuStart).apply()
        } catch (_: Exception) {}
    }

    fun reset() {
        map.clear()
        since = System.currentTimeMillis()
        cpuStart = Process.getElapsedCpuTime()
        flush()
    }

    fun vis(key: String, ms: Double) { acc(key).visMs += ms }
    fun cpu(key: String, ns: Long) { val a = acc(key); a.cpuMs += ns / 1e6; a.frames += 1 }
    fun res(key: String, mic: Double = 0.0, audio: Double = 0.0, sensor: Double = 0.0, net: Double = 0.0) {
        val a = acc(key)
        a.micS += mic; a.audioS += audio; a.sensorS += sensor; a.net += net
    }

    fun snapshot(): List<Pair<String, Acc>> = map.entries.map { it.key to it.value }.sortedByDescending { it.second.mah() }
    fun sinceMs() = since
    /** Rough full-charge capacity in mAh, worked out from the battery's own counters. */
    fun capacityMah(ctx: Context): Double {
        try {
            val bm = ctx.getSystemService(android.os.BatteryManager::class.java)
            val counter = bm.getLongProperty(android.os.BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER) // microamp-hours
            val pct = bm.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY)
            if (counter > 0 && pct in 5..100) return counter / 1000.0 / (pct / 100.0)
        } catch (e: Exception) {}
        return 4500.0
    }

    fun processCpuMs() = Process.getElapsedCpuTime() - cpuStart
}

/** Name a widget goes by in the battery report. */
internal fun statKey(w: de.mm20.launcher2.widgets.Widget): String = when (w) {
    is de.mm20.launcher2.widgets.KvxSceneWidget -> sceneTitle(w.config.scene)
    is de.mm20.launcher2.widgets.KvxToolWidget -> toolTitle(w.config.tool)
    is de.mm20.launcher2.widgets.KvxVizWidget -> "Visualizer"
    is de.mm20.launcher2.widgets.NowPlayingWidget -> "Now playing"
    is de.mm20.launcher2.widgets.FacesClockWidget -> "Face clock"
    is de.mm20.launcher2.widgets.RingerWidget -> "Ringer mode"
    is de.mm20.launcher2.widgets.KvxCalendarWidget -> "Agenda calendar"
    is de.mm20.launcher2.widgets.KvxWeatherWidget -> "Weather card"
    is de.mm20.launcher2.widgets.KvxBatteryWidget -> "Battery"
    else -> w.javaClass.simpleName.removeSuffix("Widget")
}
