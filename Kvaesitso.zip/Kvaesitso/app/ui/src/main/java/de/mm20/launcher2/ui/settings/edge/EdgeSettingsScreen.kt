package de.mm20.launcher2.ui.settings.edge

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.navigation3.runtime.NavKey
import de.mm20.launcher2.ui.R
import de.mm20.launcher2.ui.component.preferences.ListPreference
import de.mm20.launcher2.ui.component.preferences.Preference
import de.mm20.launcher2.ui.component.preferences.PreferenceCategory
import de.mm20.launcher2.ui.component.preferences.PreferenceScreen
import de.mm20.launcher2.ui.component.preferences.SliderPreference
import de.mm20.launcher2.ui.component.preferences.SwitchPreference
import de.mm20.launcher2.ui.edge.Prefs
import de.mm20.launcher2.ui.edge.VolumeService
import de.mm20.launcher2.ui.launcher.widgets.facesclock.ColorPreference
import de.mm20.launcher2.ui.locals.LocalBackStack
import kotlinx.serialization.Serializable

@Serializable
data object EdgeSettingsRoute : NavKey

@Serializable
data class EdgePageRoute(val page: String) : NavKey

private class Preset(
    val name: String, val shape: Int, val mode: Int, val c1: Int, val c2: Int,
    val glow: Int, val thick: Int, val effect: Int, val fill: Int, val enter: Int,
    val opacity: Int = 100, val pattern: Int = 0,
)

private val presets = listOf(
    Preset("Cyan", 0, 0, 0xFF00E5FF.toInt(), 0xFFFF4081.toInt(), 24, 4, 0, 1, 0),
    Preset("Sunset", 0, 2, 0xFFFF9100.toInt(), 0xFFFF4081.toInt(), 32, 5, 1, 1, 0),
    Preset("Aurora", 0, 2, 0xFF00E676.toInt(), 0xFF7C4DFF.toInt(), 36, 5, 2, 1, 1),
    Preset("Meter", 1, 4, 0xFF76FF03.toInt(), 0xFFFF1744.toInt(), 16, 5, 0, 0, 0),
    Preset("Neon dot", 2, 0, 0xFFFF4081.toInt(), 0xFF7C4DFF.toInt(), 30, 4, 3, 2, 0),
    Preset("Ambient", 3, 0, 0xFFFFFFFF.toInt(), 0xFFFFFFFF.toInt(), 44, 3, 1, 1, 0, 70),
    Preset("Mirror", 0, 2, 0xFFFF9100.toInt(), 0xFFFF4081.toInt(), 30, 5, 0, 1, 0, 100, 1),
    Preset("Wrap", 0, 2, 0xFF00E5FF.toInt(), 0xFF7C4DFF.toInt(), 30, 4, 2, 1, 0, 100, 2),
    Preset("Orbit", 0, 3, 0xFF00E5FF.toInt(), 0xFFFF4081.toInt(), 20, 4, 0, 1, 0, 100, 3),
    Preset("Swell", 0, 4, 0xFF76FF03.toInt(), 0xFFFF1744.toInt(), 40, 4, 0, 1, 0, 100, 4),
)

private val handler = Handler(Looper.getMainLooper())
private val previewRun = Runnable { VolumeService.instance?.preview() }
private val connectRun = Runnable { VolumeService.instance?.previewConnect(true) }

/** Apply changes live and show a demo shortly after the user stops fiddling. */
private fun changed(connect: Boolean = false) {
    if (connect) {
        handler.removeCallbacks(connectRun)
        handler.postDelayed(connectRun, 400)
        return
    }
    VolumeService.instance?.onPrefsChanged()
    handler.removeCallbacks(previewRun)
    handler.postDelayed(previewRun, 400)
}

private class Ed(ctx: Context) {
    val p = Prefs(ctx)
    var rev by mutableIntStateOf(0)
    fun bump() { rev++ }
}

@Composable
private fun rememberEd(): Ed {
    val ctx = LocalContext.current
    val e = remember { Ed(ctx.applicationContext) }
    @Suppress("UNUSED_EXPRESSION") e.rev
    return e
}

private fun toast(ctx: Context, m: String) = Toast.makeText(ctx, m, Toast.LENGTH_SHORT).show()

private val EDGE_PAGES = listOf(
    Triple("presets", "Presets", "Ready-made and saved looks"),
    Triple("keys", "Volume keys", "Hold delay and repeat speed"),
    Triple("gear", "Gear button", "Icon, size, position, visibility"),
    Triple("menu", "Gear menu", "Which controls it offers"),
    Triple("look", "Edge light", "Pattern, shape, colors, glow"),
    Triple("anim", "Animation", "Motion, effects, appear and disappear"),
    Triple("audio", "Audio output animation", "Headphone connect and disconnect"),
    Triple("extras", "Extras", "Color from music, step size, boost memory, safe volume, games, gear shortcuts"),
)

@Composable
private fun SwitchRow(e: Ed, title: String, summary: String? = null, get: () -> Boolean, connect: Boolean = false, set: (Boolean) -> Unit) {
    SwitchPreference(title = title, summary = summary, value = get(), onValueChanged = { set(it); e.bump(); changed(connect) })
}

@Composable
private fun Choice(e: Ed, title: String, opts: List<String>, get: () -> Int, connect: Boolean = false, set: (Int) -> Unit) {
    ListPreference(
        title = title,
        items = opts.mapIndexed { i, s -> s to i },
        value = get(),
        onValueChanged = { set(it); e.bump(); changed(connect) },
    )
}

@Composable
private fun Slide(e: Ed, title: String, unit: String, min: Int, max: Int, get: () -> Int, connect: Boolean = false, set: (Int) -> Unit) {
    SliderPreference(
        title = title,
        value = get(),
        min = min,
        max = max,
        onValueChanged = { set(it); e.bump(); changed(connect) },
        label = { Text(if (unit.isEmpty()) "$it" else "$it $unit") },
    )
}

@Composable
private fun Note(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
    )
}

@Composable
private fun PermRow(title: String, desc: String, granted: Boolean, intent: () -> Intent) {
    val ctx = LocalContext.current
    Preference(
        title = (if (granted) "✓  " else "") + title,
        summary = if (granted) "On" else desc,
        onClick = {
            if (!granted) {
                try { ctx.startActivity(intent().addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (x: Exception) { toast(ctx, "Could not open that settings page") }
            }
        },
    )
}

@Composable
fun EdgeSettingsScreen() {
    val back = LocalBackStack.current
    PreferenceScreen(title = "Edge volume light") {
        item { EdgeSetup() }
        item {
            PreferenceCategory(title = "Customize") {
                for ((id, t, s) in EDGE_PAGES) {
                    Preference(title = t, summary = s, onClick = { back.add(EdgePageRoute(id)) })
                }
            }
        }
    }
}

@Composable
private fun EdgeSetup() {
    val e = rememberEd()
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val o = LifecycleEventObserver { _, ev -> if (ev == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(o)
        onDispose { owner.lifecycle.removeObserver(o) }
    }
    @Suppress("UNUSED_EXPRESSION") tick
    Column(verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(12.dp)) {
        PreferenceCategory(title = "Setup") {
            PermRow(
                "Accessibility service (required)",
                "Turn on “Kvaesitso X edge light”. If it is greyed out: App info, then the ⋮ menu, then Allow restricted settings.",
                VolumeService.instance != null,
            ) { Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS) }
            PermRow(
                "Modify system settings (brightness)",
                "Needed only if you want to control brightness.",
                Settings.System.canWrite(ctx),
            ) { Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${ctx.packageName}")) }
            PermRow(
                "Do Not Disturb access (silent mode)",
                "Needed only to switch to Silent. Ring and Vibrate work without it.",
                ctx.getSystemService(NotificationManager::class.java).isNotificationPolicyAccessGranted,
            ) { Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS) }
        }
        PreferenceCategory(title = "Main switches") {
            SwitchRow(e, "Replace system volume panel", "The volume keys drive the edge light and the gear menu instead", { e.p.replacePanel }) { e.p.replacePanel = it }
            SwitchRow(e, "Animate on output change", "A quick edge animation when headphones or speakers connect", { e.p.connectOn }) { e.p.connectOn = it }
            Preference(title = "Test", summary = "Show the edge light now", onClick = {
                val s = VolumeService.instance
                if (s == null) toast(ctx, "Turn on the accessibility service first") else s.preview()
            })
        }
    }
}

@Composable
fun EdgePageScreen(page: String) {
    val title = EDGE_PAGES.firstOrNull { it.first == page }?.second ?: "Edge volume light"
    PreferenceScreen(title = title) {
        item {
          Column(verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(12.dp)) {
            when (page) {
                "presets" -> PresetsPage()
                "keys" -> KeysPage()
                "gear" -> GearPage()
                "menu" -> MenuPage()
                "look" -> LookPage()
                "anim" -> AnimPage()
                "audio" -> AudioPage()
                "extras" -> ExtrasPage()
                else -> PresetsPage()
            }
          }
        }
    }
}

@Composable
private fun PresetsPage() {
    val e = rememberEd()
    val ctx = LocalContext.current
    var saving by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    Column(verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(12.dp)) {
        PreferenceCategory(title = "Ready-made") {
            for (pr in presets) {
                Preference(title = pr.name, summary = "Tap to apply", onClick = {
                    val p = e.p
                    p.shape = pr.shape; p.colorMode = pr.mode; p.color = pr.c1; p.color2 = pr.c2
                    p.glow = pr.glow; p.thickness = pr.thick; p.effect = pr.effect; p.fillAnim = pr.fill
                    p.enterAnim = pr.enter; p.opacity = pr.opacity; p.pattern = pr.pattern
                    e.bump(); changed()
                })
            }
        }
        PreferenceCategory(title = "Yours") {
            Preference(title = "Save current look as preset", summary = "Edge light, animation and gear button", onClick = { name = ""; saving = true })
            for (nm in e.p.savedPresetNames()) {
                Preference(
                    title = "★ $nm",
                    summary = "Tap to load",
                    onClick = { e.p.loadPreset(nm); e.bump(); changed() },
                    controls = { TextButton(onClick = { e.p.deletePreset(nm); e.bump() }) { Text("Delete") } },
                )
            }
        }
    }
    if (saving) {
        AlertDialog(
            onDismissRequest = { saving = false },
            title = { Text("Save current look") },
            text = { OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true, label = { Text("Preset name") }) },
            confirmButton = {
                TextButton(onClick = {
                    val n = name.trim()
                    if (n.isEmpty()) toast(ctx, "Give it a name") else { e.p.savePreset(n); saving = false; e.bump() }
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { saving = false }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun KeysPage() {
    val e = rememberEd()
    val p = e.p
    PreferenceCategory(title = "Volume keys") {
        Slide(e, "Hold delay before repeating", "ms", 150, 800, { p.holdDelay }) { p.holdDelay = it }
        Slide(e, "Repeat interval (lower is faster)", "ms", 30, 300, { p.holdInterval }) { p.holdInterval = it }
        SwitchRow(e, "Speed up the longer you hold", null, { p.holdAccel }) { p.holdAccel = it }
    }
}

@Composable
private fun GearPage() {
    val e = rememberEd()
    val p = e.p
    PreferenceCategory(title = "Look") {
        Choice(e, "Icon", listOf("Gear", "Dots", "Sliders", "Bars", "Ring", "Chevron"), { p.gearIcon }) { p.gearIcon = it }
        Choice(e, "Background", listOf("Dark disc", "None (icon only)", "Filled with color", "Outline only"), { p.gearBgStyle }) { p.gearBgStyle = it }
        Choice(e, "Shape", listOf("Circle", "Rounded square"), { p.gearShape }) { p.gearShape = it }
        ColorPreference("Disc and menu background", p.gearBgColor) { p.gearBgColor = it; e.bump(); changed() }
        Choice(e, "Icon color", listOf("Same as edge light", "Custom"), { p.gearColorMode }) { p.gearColorMode = it }
        if (p.gearColorMode == 1) ColorPreference("Custom icon color", p.gearColor) { p.gearColor = it; e.bump(); changed() }
    }
    PreferenceCategory(title = "Size and position") {
        Slide(e, "Size", "dp", 28, 72, { p.gearSize }) { p.gearSize = it }
        Slide(e, "Opacity", "%", 20, 100, { p.gearOpacity }) { p.gearOpacity = it }
        Slide(e, "Distance from screen edge", "dp", 0, 48, { p.gearInset }) { p.gearInset = it }
        Slide(e, "Height on screen", "%", 0, 80, { p.panelY }) { p.panelY = it }
    }
    PreferenceCategory(title = "Visibility") {
        Slide(e, "Gear stays visible for", "ms", 1000, 8000, { p.panelDuration }) { p.panelDuration = it }
        SwitchRow(e, "Keep a dim gear visible all the time", null, { p.panelIdle }) { p.panelIdle = it }
        if (p.panelIdle) Slide(e, "Dim opacity when parked", "%", 10, 80, { p.gearIdle }) { p.gearIdle = it }
    }
}

@Composable
private fun MenuPage() {
    val e = rememberEd()
    val p = e.p
    PreferenceCategory(title = "Controls it offers") {
        VolumeService.NAMES.forEachIndexed { i, n ->
            SwitchRow(e, n, null, { ((p.targetMask shr i) and 1) == 1 }) {
                p.targetMask = if (it) p.targetMask or (1 shl i) else p.targetMask and (1 shl i).inv()
            }
        }
        Note("The volume keys control one of these at a time.")
    }
    PreferenceCategory(title = "Behavior") {
        SwitchRow(e, "Tap outside the menu to close it", null, { p.closeOutside }) { p.closeOutside = it }
        SwitchRow(e, "Keep menu open until I close it", null, { p.panelOpenForever }) { p.panelOpenForever = it }
        if (!p.panelOpenForever) Slide(e, "Menu stays open for", "ms", 3000, 30000, { p.panelOpenDuration }) { p.panelOpenDuration = it }
    }
}

@Composable
private fun LookPage() {
    val e = rememberEd()
    val p = e.p
    PreferenceCategory(title = "Pattern") {
        Choice(
            e, "Pattern",
            listOf("Bottom to top", "Center outward (up and down)", "Center outward, wrapping around the phone", "Clockwise loop around the phone", "Swell (thicker and brighter)"),
            { p.pattern },
        ) { p.pattern = it }
        Choice(e, "Shape (first two patterns)", listOf("Bar", "Segments", "Dot", "Full edge"), { p.shape }) { p.shape = it }
        Choice(e, "Side (not used by the loop)", listOf("Left", "Right", "Both"), { p.side }) { p.side = it }
    }
    PreferenceCategory(title = "Color") {
        Choice(e, "Color mode", listOf("Solid", "Per control (media, ring...)", "Gradient", "Rainbow", "Green to red"), { p.colorMode }) { p.colorMode = it }
        ColorPreference("Main color (solid or gradient start)", p.color) { p.color = it; e.bump(); changed() }
        ColorPreference("Gradient end color", p.color2) { p.color2 = it; e.bump(); changed() }
        if (p.colorMode == 1) VolumeService.NAMES.forEachIndexed { i, n ->
            ColorPreference("Color for $n", p.targetColor(i)) { p.setTargetColor(i, it); e.bump(); changed() }
        }
    }
    PreferenceCategory(title = "Size") {
        Slide(e, "Thickness", "dp", 2, 16, { p.thickness }) { p.thickness = it }
        Slide(e, "Glow", "dp", 0, 64, { p.glow }) { p.glow = it }
        Slide(e, "Opacity", "%", 10, 100, { p.opacity }) { p.opacity = it }
        Slide(e, "Screen corner radius (wrap and loop)", "dp", 0, 70, { p.corner }) { p.corner = it }
        Slide(e, "Visible for", "ms", 500, 4000, { p.duration }) { p.duration = it }
    }
    PreferenceCategory(title = "Length and position") {
        Slide(e, "Length", "% of screen height", 20, 100, { p.lenPct }) { p.lenPct = it }
        Slide(e, "Move up or down", "%", -40, 40, { p.offY }) { p.offY = it }
        Note("Applies to the bar patterns, not the wrapping pattern or the loop.")
    }
}

@Composable
private fun AnimPage() {
    val e = rememberEd()
    val p = e.p
    PreferenceCategory(title = "Motion") {
        Choice(e, "Motion of the level", listOf("Instant", "Smooth glide", "Springy"), { p.fillAnim }) { p.fillAnim = it }
        if (p.fillAnim != 0) Slide(e, "Glide time (longer is smoother)", "ms", 60, 1000, { p.smoothMs }) { p.smoothMs = it }
        Choice(e, "Appear and disappear", listOf("Fade", "Slide in from edge", "None", "Grow from zero (retracts on exit)"), { p.enterAnim }) { p.enterAnim = it }
    }
    PreferenceCategory(title = "Effect") {
        Choice(
            e, "Effect",
            listOf("None", "Pulse glow", "Shimmer", "Flash on change", "Breathe (glow size)", "Comet", "Wave", "Color cycle", "Music pulse (needs audio)"),
            { p.effect },
        ) { p.effect = it }
        Slide(e, "Effect intensity", "%", 5, 100, { p.effectIntensity }) { p.effectIntensity = it }
        Slide(e, "Effect speed", "%", 25, 300, { p.effectSpeed }) { p.effectSpeed = it }
        Note("Shimmer, Comet and Wave need the Bar shape. Color cycle needs a colored (not white) light.")
    }
}

@Composable
private fun AudioPage() {
    val e = rememberEd()
    val p = e.p
    val ctx = LocalContext.current
    PreferenceCategory(title = "When") {
        SwitchRow(e, "Bluetooth devices", null, { p.connectBt }) { p.connectBt = it }
        SwitchRow(e, "Wired and USB headphones", null, { p.connectWired }) { p.connectWired = it }
        SwitchRow(e, "Also animate when disconnected", null, { p.connectDisc }) { p.connectDisc = it }
        Note("Uses the same edge (left, right or both) as the edge light. Turn the whole thing on with Animate on output change on the main page.")
    }
    PreferenceCategory(title = "Look") {
        Choice(e, "Animation style", listOf("Sweep along the edge", "Soft pulse", "Quick flash", "Comet"), { p.connectStyle }, connect = true) { p.connectStyle = it }
        Choice(e, "Colors", listOf("Match edge light colors", "Custom colors"), { p.connectColorMode }, connect = true) { p.connectColorMode = it }
        if (p.connectColorMode == 1) {
            ColorPreference("Connected color", p.connectColor) { p.connectColor = it; e.bump(); changed(true) }
            ColorPreference("Disconnected color", p.connectColorOff) { p.connectColorOff = it; e.bump(); changed(true) }
        }
        Slide(e, "Duration", "ms", 400, 3000, { p.connectDuration }, true) { p.connectDuration = it }
        Slide(e, "Thickness", "dp", 2, 24, { p.connectThick }, true) { p.connectThick = it }
        Slide(e, "Glow", "dp", 10, 120, { p.connectGlow }, true) { p.connectGlow = it }
        Slide(e, "Brightness", "%", 20, 100, { p.connectBright }, true) { p.connectBright = it }
    }
    PreferenceCategory(title = "Try it") {
        Preference(title = "Test connect animation", onClick = {
            val s = VolumeService.instance
            if (s == null) toast(ctx, "Turn on the accessibility service first") else s.previewConnect(true)
        })
        Preference(title = "Test disconnect animation", onClick = {
            val s = VolumeService.instance
            if (s == null) toast(ctx, "Turn on the accessibility service first") else s.previewConnect(false)
        })
    }
}

@Composable
private fun ExtrasPage() {
    val e = rememberEd()
    val p = e.p
    Column(verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(12.dp)) {
        Note("Everything here is off until you switch it on.")
        PreferenceCategory(title = "Color") {
            Choice(e, "Edge light color from the music", listOf("Off", "Album art color", "Color of the music app’s icon"), { p.xColorSrc }) { p.xColorSrc = it }
            Note("Works with the Solid and Per control color modes, on the media volume.")
        }
        PreferenceCategory(title = "Volume steps") {
            SwitchRow(e, "Different volume step per output", null, { p.xStepOn }) { p.xStepOn = it }
            if (p.xStepOn) {
                Slide(e, "Bluetooth: steps per key press", "", 1, 4, { p.xStepBt }) { p.xStepBt = it }
                Slide(e, "Wired and USB: steps per key press", "", 1, 4, { p.xStepWired }) { p.xStepWired = it }
                Slide(e, "Phone speaker: steps per key press", "", 1, 4, { p.xStepSpeaker }) { p.xStepSpeaker = it }
            }
        }
        PreferenceCategory(title = "Boost") {
            Choice(e, "Remember the +6 dB boost", listOf("Off", "Per output (each headphones or speaker)", "Per music app"), { p.xBoostMem }) { p.xBoostMem = it }
        }
        PreferenceCategory(title = "Safe volume") {
            SwitchRow(e, "Warning on headphones", "The edge light turns red at a high level", { p.xSafeOn }) { p.xSafeOn = it }
            if (p.xSafeOn) Slide(e, "Warn at or above", "%", 40, 100, { p.xSafeLevel }) { p.xSafeLevel = it }
        }
        PreferenceCategory(title = "Volume keys") {
            SwitchRow(e, "Swap up and down", "Volume up lowers, volume down raises", { p.xInvert }) { p.xInvert = it }
            SwitchRow(e, "Tick on every step", "A small vibration for each volume step", { p.xHaptic }) { p.xHaptic = it }
            Slide(e, "Maximum media volume", "%", 20, 100, { p.xMaxVol }) { p.xMaxVol = it }
            Note("The maximum stops the media volume from going above this level with the keys. Set to 100% for no limit.")
        }
        PreferenceCategory(title = "Games and shortcuts") {
            SwitchRow(e, "Keep the edge light and gear out of games", "Volume keys still work. Detects apps Android marks as games.", { p.xHideGames }) { p.xHideGames = it }
            Choice(e, "Long-press the gear", listOf("Nothing", "Open the EQ menu", "Open the Now Playing card"), { p.xGearHold }) { p.xGearHold = it }
            Note("The EQ menu needs the overlay permission. The card needs the music bubble turned on, otherwise it opens the music app.")
        }
    }
}
