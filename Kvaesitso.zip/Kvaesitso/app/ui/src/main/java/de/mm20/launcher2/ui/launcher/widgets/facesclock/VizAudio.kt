package de.mm20.launcher2.ui.launcher.widgets.facesclock

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.audiofx.Visualizer
import android.os.SystemClock
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Live audio analysis shared by every card on screen. The audio is only analysed (FFT +
 * waveform), never recorded or stored. Smoothing runs in [update], which each view calls once
 * per frame.
 */
object VizAudio {
    const val N = 64
    const val W = 96

    /** Smoothed band levels 0..1.2, bass first (log-spaced). */
    val disp = FloatArray(N)

    /** Smoothed waveform -1..1. */
    val wave = FloatArray(W)

    var level = 0f
    var beatEnv = 0f

    @Volatile
    var beatCount = 0

    @Volatile
    var gain = 1f

    /** Set by the views that show the visualizer. */
    @Volatile
    var playing = false

    @Volatile
    var status = "Audio: not started"

    private val target = FloatArray(N)
    private val waveT = FloatArray(W)
    private val raw = FloatArray(N)
    private var viz: Visualizer? = null
    private var users = 0
    private var retryAt = 0L
    private var since = 0L
    private var heard = 0L
    private var lastNs = 0L
    private var peak = 6f
    private var wavePeak = 0.1f
    private var bassSlow = 0f
    private var lastBeat = 0L
    private var demoBeat = 0L

    /** True while CaptureService feeds us (any output, including Bluetooth). */
    @Volatile
    var external = false

    fun setExternal(ctx: Context, on: Boolean) {
        external = on
        if (on) {
            release()
            since = SystemClock.uptimeMillis()
            heard = since
            peak = 6f
            status = "Audio: playback capture"
        } else if (users > 0) {
            retryAt = 0L
            tryStart(ctx)
        } else {
            status = "Audio: stopped"
        }
    }

    // ---- stereo image (only available while CaptureService is feeding real L/R samples)
    const val G = 256
    val gonioL = FloatArray(G)
    val gonioR = FloatArray(G)
    @Volatile var corr = 0f
    @Volatile var lRms = 0f
    @Volatile var rRms = 0f
    @Volatile var width = 0f
    @Volatile var stereoAt = 0L

    fun stereoLive() = SystemClock.uptimeMillis() - stereoAt < 1200L

    /** Interleaved L/R 16-bit frames from the playback capture. */
    fun feedStereo(buf: ShortArray, frames: Int) {
        val n = minOf(frames, 1024)
        if (n < 8) return
        val o = (frames - n) * 2
        var ll = 0.0; var rr = 0.0; var lr = 0.0; var mm = 0.0; var ss = 0.0
        for (i in 0 until n) {
            val l = buf[o + i * 2] / 32768.0
            val r = buf[o + i * 2 + 1] / 32768.0
            ll += l * l; rr += r * r; lr += l * r
            val m = (l + r) * 0.5; val sd = (l - r) * 0.5
            mm += m * m; ss += sd * sd
        }
        val c = if (ll > 1e-9 && rr > 1e-9) (lr / Math.sqrt(ll * rr)).toFloat() else 0f
        corr += (c - corr) * 0.25f
        lRms += ((Math.sqrt(ll / n)).toFloat() - lRms) * 0.35f
        rRms += ((Math.sqrt(rr / n)).toFloat() - rRms) * 0.35f
        val wd = if (mm + ss > 1e-9) (ss / (mm + ss)).toFloat() else 0f
        width += (wd - width) * 0.2f
        val step = n.toFloat() / G
        for (i in 0 until G) {
            val k = o + (i * step).toInt().coerceAtMost(n - 1) * 2
            gonioL[i] = buf[k] / 32768f
            gonioR[i] = buf[k + 1] / 32768f
        }
        stereoAt = SystemClock.uptimeMillis()
    }

    fun feedFft(f: ByteArray) = onFft(f)

    fun feedWave(w: ByteArray) = onWave(w)

    fun start(ctx: Context) {
        users++
        if (viz == null && !external) tryStart(ctx)
    }

    fun stop() {
        if (users > 0) users--
        if (users == 0) release()
    }

    /** Retry capture (after granting the permission, say). */
    fun retry(ctx: Context) {
        if (users > 0 && viz == null && !external) {
            retryAt = 0L
            tryStart(ctx)
        }
    }

    private fun tryStart(ctx: Context) {
        if (external) return
        val now = SystemClock.uptimeMillis()
        if (now < retryAt) return
        if (ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            status = "Audio: needs the audio permission"
            retryAt = now + 3000
            return
        }
        try {
            val v = Visualizer(0)
            v.setEnabled(false)
            v.setCaptureSize(Visualizer.getCaptureSizeRange()[1])
            v.setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                override fun onWaveFormDataCapture(vis: Visualizer?, w: ByteArray?, sr: Int) {
                    if (w != null) onWave(w)
                }

                override fun onFftDataCapture(vis: Visualizer?, f: ByteArray?, sr: Int) {
                    if (f != null) onFft(f)
                }
            }, min(Visualizer.getMaxCaptureRate(), 30000), true, true)
            v.setEnabled(true)
            viz = v
            since = now
            heard = now
            peak = 6f
            status = "Audio: analysing"
        } catch (e: Throwable) {
            viz = null
            retryAt = now + 20000
            status = "Audio: couldn't start capture (" + e.javaClass.simpleName + ")"
        }
    }

    private fun release() {
        val v = viz ?: return
        viz = null
        try { v.setEnabled(false) } catch (e: Exception) {}
        try { v.release() } catch (e: Exception) {}
        status = "Audio: stopped"
    }

    private fun onWave(w: ByteArray) {
        val per = max(1, w.size / W)
        var mx = 0f
        for (j in 0 until W) {
            var s = 0f
            var c = 0
            val a = j * per
            for (k in a until min(a + per, w.size)) {
                s += ((w[k].toInt() and 0xFF) - 128) / 128f
                c++
            }
            val v = if (c > 0) s / c else 0f
            waveT[j] = v
            if (abs(v) > mx) mx = abs(v)
        }
        wavePeak = max(max(mx, wavePeak * 0.995f), 0.06f)
        for (j in 0 until W) waveT[j] = (waveT[j] / wavePeak).coerceIn(-1f, 1f)
    }

    private fun onFft(fft: ByteArray) {
        val bins = fft.size / 2
        if (bins < 32) return
        // Visualizer covers about 20 Hz to 16 kHz (log spaced). Bins span 0..nyquist.
        val binHz = 24000f / bins
        fun mag(k: Int): Float {
            val kk = k.coerceIn(0, bins - 1)
            val re = fft[2 * kk].toFloat()
            val im = fft[2 * kk + 1].toFloat()
            return sqrt(re * re + im * im)
        }
        val lo = 20f
        val hiF = 16000f
        val ratio = hiF / lo
        var maxv = 0f
        for (i in 0 until N) {
            val fa = lo * ratio.pow(i.toFloat() / N)
            val fb = lo * ratio.pow((i + 1f) / N)
            val fc = sqrt(fa * fb)
            val ka = fa / binHz
            val kb = fb / binHz
            val avg: Float
            if (kb - ka < 1.2f) {
                val kc = fc / binHz
                val k0 = kc.toInt()
                val fr = kc - k0
                avg = mag(k0) * (1f - fr) + mag(k0 + 1) * fr
            } else {
                var sum = 0f
                var cnt = 0
                for (k in max(1, ka.toInt())..min(kb.toInt(), bins - 1)) { sum += mag(k); cnt++ }
                avg = if (cnt > 0) sum / cnt else 0f
            }
            var tilt = (fc / 150f).pow(0.4f).coerceIn(0.5f, 7f)
            // extra lift above 3 kHz, rising smoothly to about +15% at 16 kHz
            if (fc > 3000f) tilt *= 1f + 0.15f * (kotlin.math.ln(fc / 3000f) / kotlin.math.ln(16000f / 3000f)).coerceAtMost(1f)
            raw[i] = avg * tilt
            if (raw[i] > maxv) maxv = raw[i]
        }
        val now = SystemClock.uptimeMillis()
        if (maxv > 1f) heard = now
        peak = max(max(maxv, peak * 0.992f), 6f)
        val g = gain
        for (i in 0 until N) target[i] = ((raw[i] / peak).pow(0.85f) * g).coerceIn(0f, 1.2f)
        var bass = 0f
        for (i in 8 until 20) bass += target[i]
        bass /= 12f
        if (bass > bassSlow * 1.35f + 0.08f && now - lastBeat > 180) {
            lastBeat = now
            beatCount++
            beatEnv = 1f
        }
        bassSlow = bassSlow * 0.9f + bass * 0.1f
        val tag = if (external) "playback capture" else "analysing"
        status = if (now - since > 4000 && now - heard > 4000) {
            "Audio: connected but silent (" + (if (external) "that app may block capture" else "capture may be blocked on this phone") + ")"
        } else {
            "Audio: $tag"
        }
    }

    private fun synth(t: Float, scale: Float) {
        val env = 0.55f + 0.45f * sin(t * 1.9f)
        for (i in 0 until N) {
            val base = 0.5f + 0.5f * sin(t * (1.3f + i * 0.11f) + i * 0.7f)
            val shape = 1f - i / 95f
            target[i] = ((base * env * shape * 0.9f + 0.05f) * scale).coerceIn(0f, 1.2f)
        }
        for (j in 0 until W) {
            waveT[j] = (0.6f * sin(t * 6f + j * 0.25f) + 0.3f * sin(t * 13f + j * 0.6f)) * env * scale
        }
    }

    /** Fall speed multiplier (1 = default, higher = bars drop faster). Set by each view before update(). */
    @JvmField var fall = 1f

    /** Call once per frame from every animated view. Cheap if called twice in a frame. */
    fun update(idleBreath: Boolean) {
        val now = System.nanoTime()
        if (now - lastNs < 6_000_000L) return
        val dt = ((now - lastNs) / 1_000_000_000f).coerceIn(0.001f, 0.05f)
        lastNs = now
        val t = SystemClock.uptimeMillis() / 1000f
        if (false) {
            synth(t, gain)
            val ms = SystemClock.uptimeMillis()
            if (ms - demoBeat > 480) {
                demoBeat = ms
                beatCount++
                beatEnv = 1f
            }
        } else if (!playing) {
            if (idleBreath) synth(t * 0.35f, 0.12f)
            else {
                for (i in 0 until N) target[i] = 0f
                for (j in 0 until W) waveT[j] = 0f
            }
        }
        val up = 1f - exp(-dt / 0.04f)
        val down = 1f - exp(-dt / 0.05f)
        var sum = 0f
        for (i in 0 until N) {
            val tv = target[i]
            disp[i] += (tv - disp[i]) * (if (tv > disp[i]) up else down)
            sum += disp[i]
        }
        level += (sum / N - level) * 0.3f
        val wk = 1f - exp(-dt / 0.03f)
        for (j in 0 until W) wave[j] += (waveT[j] - wave[j]) * wk
        beatEnv = max(0f, beatEnv - dt * 3.2f)
    }

    /** Back to silence (used when the widget stops animating, so it shows a resting pose). */
    fun reset() {
        for (i in 0 until N) { target[i] = 0f; disp[i] = 0f }
        for (j in 0 until W) { waveT[j] = 0f; wave[j] = 0f }
        level = 0f
        beatEnv = 0f
    }

    /** Level for bar i of n (groups of the 64 bands, averaged). */
    fun band(i: Int, n: Int): Float {
        val a = i * N / n
        val b = max(a + 1, (i + 1) * N / n)
        var s = 0f
        for (k in a until min(b, N)) s += disp[k]
        return s / (min(b, N) - a)
    }

    /** True when something is moving (keeps animation loops going, then lets them sleep). */
    fun active(): Boolean = level > 0.004f || beatEnv > 0f

    /**
     * True while music is playing but no sound data has reached us for a while (for example on
     * Bluetooth when the audio can't be read). The visualizer graphics are hidden then.
     */
    fun noSignal(): Boolean {
        if (users <= 0 || !playing) return false
        val now = SystemClock.uptimeMillis()
        return now - since > 5000 && now - heard > 5000
    }
}
