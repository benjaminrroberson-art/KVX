package de.mm20.launcher2.ui.settings.common

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp

/** A small stand-in for the launcher, drawn with the current colors, type, shapes. Pinned at the top of Appearance. */
@Composable
fun ThemePreview() {
    val cs = MaterialTheme.colorScheme
    Column(
        Modifier.fillMaxWidth().background(cs.surfaceContainer).padding(horizontal = 16.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("12:45", style = MaterialTheme.typography.displaySmall, color = cs.onSurface)
            Column {
                Text("Monday, November 16", style = MaterialTheme.typography.titleSmall, color = cs.onSurface)
                Text("Partly cloudy, 58°", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            }
        }
        Box(
            Modifier.fillMaxWidth().clip(MaterialTheme.shapes.extraLarge).background(cs.surfaceContainerHigh).padding(horizontal = 16.dp, vertical = 12.dp),
        ) { Text("Search", style = MaterialTheme.typography.bodyLarge, color = cs.onSurfaceVariant) }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            for ((i, sh) in listOf(MaterialTheme.shapes.small, MaterialTheme.shapes.medium, MaterialTheme.shapes.large, MaterialTheme.shapes.extraLarge).withIndex()) {
                Box(
                    Modifier.size(44.dp).clip(sh).background(if (i % 2 == 0) cs.primaryContainer else cs.tertiaryContainer),
                    contentAlignment = Alignment.Center,
                ) { Text("Aa", style = MaterialTheme.typography.labelLarge, color = if (i % 2 == 0) cs.onPrimaryContainer else cs.onTertiaryContainer) }
            }
            Box(Modifier.size(44.dp).clip(CircleShape).background(cs.secondaryContainer))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = {}) { Text("Button") }
            FilledTonalButton(onClick = {}) { Text("Tonal") }
            AssistChip(onClick = {}, label = { Text("Chip") })
        }
        Text("Updates when you change colors, type, shapes or transparency.", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
    }
}
