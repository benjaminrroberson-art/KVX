package de.mm20.launcher2.ui.theme

import android.animation.ValueAnimator
import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.View
import android.view.ViewGroup
import android.view.animation.AccelerateInterpolator
import java.lang.ref.WeakReference

/**
 * Plays an animation over the launcher right before it locks the screen (lock gesture, Screen off action).
 * Android doesn't allow apps to change the system's own screen-off effect (power button), so this only
 * runs when the launcher itself does the locking.
 */
object KvxLockAnim {
    val names = listOf("None", "TV switch-off", "Fade to black", "Iris close", "Wipe down")

    private fun sp(ctx: Context) = ctx.applicationContext.getSharedPreferences("kvx_lock_anim", Context.MODE_PRIVATE)
    fun mode(ctx: Context): Int = sp(ctx).getInt("mode", 0)
    fun setMode(ctx: Context, v: Int) { sp(ctx).edit().putInt("mode", v).apply() }

    private var host = WeakReference<Activity>(null)
    private var overlay: View? = null

    fun register(a: Activity) { host = WeakReference(a) }

    /** Plays the animation (if one is chosen) and then runs [lock]. */
    fun lock(lock: () -> Unit) {
        val a = host.get()
        val m = a?.let { mode(it) } ?: 0
        if (a == null || m == 0) { lock(); return }
        val root = a.window?.decorView as? ViewGroup
        if (root == null) { lock(); return }
        clear()
        val v = AnimView(a, m)
        overlay = v
        root.addView(v, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = if (m == 2) 320L else 430L
            interpolator = AccelerateInterpolator(1.3f)
            addUpdateListener { v.p = it.animatedValue as Float }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: android.animation.Animator) {
                    lock()
                }
            })
            start()
        }
    }

    /** Takes the overlay away (when the launcher is back on screen after unlocking). */
    fun clear() {
        val v = overlay ?: return
        overlay = null
        (v.parent as? ViewGroup)?.removeView(v)
    }

    private class AnimView(ctx: Context, private val mode: Int) : View(ctx) {
        var p = 0f
            set(value) { field = value; invalidate() }
        private val black = Paint().apply { color = Color.BLACK; isAntiAlias = true }
        private val white = Paint().apply { color = Color.WHITE; isAntiAlias = true }
        private val path = Path()

        override fun onDraw(c: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            when (mode) {
                1 -> {
                    // two black halves close on the middle, then the last line shrinks to a dot
                    val squash = (p / 0.7f).coerceIn(0f, 1f)
                    val half = h / 2f * (1f - squash)
                    if (squash < 1f) {
                        c.drawRect(0f, 0f, w, h / 2f - half, black)
                        c.drawRect(0f, h / 2f + half, w, h, black)
                        white.alpha = (255 * squash).toInt()
                        c.drawRect(0f, h / 2f - half, w, h / 2f + half, white.apply { alpha = (90 * squash).toInt() })
                    } else {
                        c.drawColor(Color.BLACK)
                        val t = ((p - 0.7f) / 0.3f).coerceIn(0f, 1f)
                        white.alpha = (255 * (1f - t)).toInt()
                        val lw = w * (1f - t * 0.97f) / 2f
                        c.drawRect(w / 2f - lw, h / 2f - 3f, w / 2f + lw, h / 2f + 3f, white)
                    }
                }
                2 -> c.drawColor(Color.argb((255 * p).toInt(), 0, 0, 0))
                3 -> {
                    val r = Math.hypot(w.toDouble(), h.toDouble()).toFloat() / 2f * (1f - p)
                    path.reset()
                    path.fillType = Path.FillType.EVEN_ODD
                    path.addRect(0f, 0f, w, h, Path.Direction.CW)
                    path.addCircle(w / 2f, h / 2f, r.coerceAtLeast(0f), Path.Direction.CW)
                    c.drawPath(path, black)
                }
                4 -> {
                    val y = h * p
                    c.drawRect(0f, 0f, w, y, black)
                    white.alpha = (120 * (1f - p)).toInt()
                    c.drawRect(0f, y, w, y + 3f, white)
                }
            }
        }
    }
}
