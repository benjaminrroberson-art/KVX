package de.mm20.launcher2.ui.launcher.widgets.facesclock

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.TextButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import de.mm20.launcher2.widgets.FacesClockWidget
import de.mm20.launcher2.widgets.FacesClockWidgetConfig
import java.util.UUID

/** Live preview on top, every setting for the faces clock underneath. Used by the home clock and the widget picker. */
@Composable
fun FacesClockEditor(
    clockJson: String,
    onChange: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val widget = FacesClockWidget(UUID(0L, 0L), FacesClockWidgetConfig(clockJson))
    Column(modifier = modifier) {
        Surface(
            color = MaterialTheme.colorScheme.surfaceContainer,
            shape = MaterialTheme.shapes.large,
            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(16.dp).fillMaxWidth(),
            ) {
                FacesClockBody(clockJson, Modifier.fillMaxWidth(0.8f))
            }
        }
        ConfigureFacesClockWidget(widget) { onChange(it.config.clock) }
    }
}

@Composable
fun FacesClockStyleDialog(
    clockJson: String,
    onChange: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            shape = MaterialTheme.shapes.extraLarge,
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth(0.94f).heightIn(max = 700.dp),
        ) {
            Column {
                Column(
                    modifier = Modifier
                        .weight(1f, fill = false)
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp),
                ) {
                    FacesClockEditor(clockJson, onChange)
                }
                TextButton(onClick = onDismiss, modifier = Modifier.align(Alignment.End).padding(8.dp)) { Text("Done") }
            }
        }
    }
}

@Composable
fun FacesClockAddDialog(
    clockJson: String,
    onChange: (String) -> Unit,
    onAdd: () -> Unit,
    onDismiss: () -> Unit,
) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            shape = MaterialTheme.shapes.extraLarge,
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth(0.94f).heightIn(max = 700.dp),
        ) {
            Column {
                Column(
                    modifier = Modifier
                        .weight(1f, fill = false)
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp),
                ) {
                    FacesClockEditor(clockJson, onChange)
                }
                androidx.compose.foundation.layout.Row(
                    modifier = Modifier.align(Alignment.End).padding(8.dp),
                ) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    TextButton(onClick = onAdd) { Text("Add to home") }
                }
            }
        }
    }
}

/** A live sample of one of our widgets with its default look. */
@Composable
fun WidgetPreview(type: String) {
    when (type) {
        FacesClockWidget.Type -> FacesClockBody("", Modifier.fillMaxWidth(0.6f))
        de.mm20.launcher2.widgets.RingerWidget.Type -> RingerBody(de.mm20.launcher2.widgets.RingerWidgetConfig())
        de.mm20.launcher2.widgets.NowPlayingWidget.Type -> NowPlayingBody(de.mm20.launcher2.widgets.NowPlayingWidgetConfig())
        de.mm20.launcher2.widgets.KvxCalendarWidget.Type -> KvxCalendarBody(de.mm20.launcher2.widgets.KvxCalendarWidgetConfig())
        de.mm20.launcher2.widgets.KvxWeatherWidget.Type -> KvxWeatherBody(de.mm20.launcher2.widgets.KvxWeatherWidgetConfig())
        de.mm20.launcher2.widgets.KvxBatteryWidget.Type -> KvxBatteryBody(de.mm20.launcher2.widgets.KvxBatteryWidgetConfig())
        de.mm20.launcher2.widgets.KvxVizWidget.Type -> KvxVizBody(de.mm20.launcher2.widgets.KvxVizWidgetConfig())
    }
}

/** Preview, every setting, and an Add button, for any of our widgets. */
@Composable
fun WidgetAddDialog(
    widget: de.mm20.launcher2.widgets.Widget,
    onChange: (de.mm20.launcher2.widgets.Widget) -> Unit,
    onAdd: () -> Unit,
    onDismiss: () -> Unit,
) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            shape = MaterialTheme.shapes.extraLarge,
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth(0.94f).heightIn(max = 700.dp),
        ) {
            Column {
                Column(
                    modifier = Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState()).padding(16.dp),
                ) {
                    when (widget) {
                        is FacesClockWidget -> FacesClockEditor(widget.config.clock, onChange = { onChange(widget.copy(config = FacesClockWidgetConfig(it))) })
                        is de.mm20.launcher2.widgets.RingerWidget -> {
                            Surface(color = MaterialTheme.colorScheme.surfaceContainer, shape = MaterialTheme.shapes.large, modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)) { RingerBody(widget.config) }
                            ConfigureRingerWidget(widget) { onChange(it) }
                        }
                        is de.mm20.launcher2.widgets.NowPlayingWidget -> {
                            Surface(color = MaterialTheme.colorScheme.surfaceContainer, shape = MaterialTheme.shapes.large, modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)) { NowPlayingBody(widget.config) }
                            ConfigureNowPlayingWidget(widget) { onChange(it) }
                        }
                        is de.mm20.launcher2.widgets.KvxCalendarWidget -> {
                            Surface(color = MaterialTheme.colorScheme.surfaceContainer, shape = MaterialTheme.shapes.large, modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)) { KvxCalendarBody(widget.config) }
                            ConfigureKvxCalendarWidget(widget) { onChange(it) }
                        }
                        is de.mm20.launcher2.widgets.KvxWeatherWidget -> {
                            Surface(color = MaterialTheme.colorScheme.surfaceContainer, shape = MaterialTheme.shapes.large, modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)) { KvxWeatherBody(widget.config) }
                            ConfigureKvxWeatherWidget(widget) { onChange(it) }
                        }
                        is de.mm20.launcher2.widgets.KvxBatteryWidget -> {
                            Surface(color = MaterialTheme.colorScheme.surfaceContainer, shape = MaterialTheme.shapes.large, modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)) { KvxBatteryBody(widget.config) }
                            ConfigureKvxBatteryWidget(widget) { onChange(it) }
                        }
                        is de.mm20.launcher2.widgets.KvxVizWidget -> {
                            Surface(color = MaterialTheme.colorScheme.surfaceContainer, shape = MaterialTheme.shapes.large, modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)) { KvxVizBody(widget.config) }
                            ConfigureKvxVizWidget(widget) { onChange(it) }
                        }
                        else -> {}
                    }
                }
                androidx.compose.foundation.layout.Row(modifier = Modifier.align(Alignment.End).padding(8.dp)) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    TextButton(onClick = onAdd) { Text("Add") }
                }
            }
        }
    }
}
