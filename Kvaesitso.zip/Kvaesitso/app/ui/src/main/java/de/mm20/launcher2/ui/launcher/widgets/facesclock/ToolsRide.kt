package de.mm20.launcher2.ui.launcher.widgets.facesclock

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import kotlin.math.abs
import kotlin.math.max

/** 0..100 for riding at this hour. Temps are Celsius, wind km/h. */
private fun rideScore(tempC: Double, code: Int, pop: Int, windKmh: Double, day: Boolean): Int {
    var s = 100.0
    s -= when { tempC in 15.0..25.0 -> 0.0; tempC < 15.0 -> (15 - tempC) * 3.5; else -> (tempC - 25) * 5.0 }
    s -= pop * 0.5
    s -= max(0.0, windKmh - 12) * 1.6
    if (code >= 95) s -= 40 else if (code >= 71 && code <= 86) s -= 35 else if (code >= 51) s -= 15 else if (code in 45..48) s -= 12
    if (!day) s -= 12
    return s.toInt().coerceIn(0, 100)
}

private fun verdict(s: Int) = when { s >= 80 -> "Great day to ride"; s >= 60 -> "Good enough"; s >= 40 -> "Rideable if you dress for it"; else -> "Not today" }

@Composable
fun RideTool() {
    FeedClockEnv()
    val wx = ClockEnv.weather
    ToolCard {
        if (wx == null) {
            Text("Waiting for weather. Set a place in Weather settings if location is off.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            return@ToolCard
        }
        val metric = ClockEnv.metric
        fun t(c: Double) = if (metric) "%.0f°".format(c) else "%.0f°".format(c * 9 / 5 + 32)
        val now = wx.now
        val hours = wx.hours.take(12)
        val scores = hours.map { rideScore(it.temp, it.code, it.pop, now.wind, it.day) }
        val nowScore = rideScore(now.temp, now.code, hours.firstOrNull()?.pop ?: 0, now.wind, now.day)
        val ring = when { nowScore >= 70 -> Color(0xFF4CAF50); nowScore >= 45 -> Color(0xFFFFB300); else -> Color(0xFFE53935) }
        val track = MaterialTheme.colorScheme.surfaceVariant
        Row(verticalAlignment = Alignment.CenterVertically) {
            Canvas(Modifier.size(72.dp)) {
                val st = Stroke(10.dp.toPx(), cap = StrokeCap.Round)
                drawArc(track, 135f, 270f, false, style = st)
                drawArc(ring, 135f, 270f * nowScore / 100f, false, style = st)
            }
            Column(Modifier.padding(start = 16.dp)) {
                Text("$nowScore", style = MaterialTheme.typography.headlineMedium)
                Text(verdict(nowScore), style = MaterialTheme.typography.titleSmall)
                val w = if (metric) "%.0f km/h".format(now.wind) else "%.0f mph".format(now.wind * 0.621)
                Text("${t(now.temp)} (feels ${t(now.feels)})  ·  wind $w", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        if (hours.isNotEmpty()) {
            Canvas(Modifier.fillMaxWidth().height(40.dp).padding(top = 10.dp)) {
                val w = size.width / hours.size
                scores.forEachIndexed { i, sc ->
                    val c = when { sc >= 70 -> Color(0xFF4CAF50); sc >= 45 -> Color(0xFFFFB300); else -> Color(0xFFE53935) }
                    val h = size.height * (0.25f + 0.75f * sc / 100f)
                    drawRect(c, Offset(i * w + 2f, size.height - h), Size(w - 4f, h))
                }
            }
            // best 2-hour window
            var bi = 0; var bs = -1
            for (i in 0 until scores.size - 1) { val s = scores[i] + scores[i + 1]; if (s > bs) { bs = s; bi = i } }
            if (scores.size >= 2) {
                val h = hours[bi].time.hour
                fun lab(x: Int) = if (x == 0) "12am" else if (x < 12) "${x}am" else if (x == 12) "12pm" else "${x - 12}pm"
                Text("Best window: ${lab(h)} to ${lab((h + 2) % 24)}", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 6.dp))
            }
        }
        val c = now.temp
        val rainy = (hours.take(4).maxOfOrNull { it.pop } ?: 0) >= 40
        val wear = buildString {
            append(when { c < 2 -> "Heavy layers, winter gloves, ear cover"; c < 10 -> "Jacket, long gloves, tights or warm pants"; c < 16 -> "Light jacket or arm warmers"; c < 27 -> "Short sleeves"; else -> "Light, breathable, bring water" })
            if (rainy) append(". Rain likely, wear a shell and fenders")
            if (now.wind > 25) append(". Strong wind, plan the return leg into it first")
        }
        Text(wear, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp))
    }
}
