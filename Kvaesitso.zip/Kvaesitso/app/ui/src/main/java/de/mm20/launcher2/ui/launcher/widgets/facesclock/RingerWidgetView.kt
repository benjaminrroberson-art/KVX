package de.mm20.launcher2.ui.launcher.widgets.facesclock

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioManager
import android.provider.Settings
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import de.mm20.launcher2.ui.R
import de.mm20.launcher2.ui.component.preferences.ListPreference
import de.mm20.launcher2.ui.component.preferences.SliderPreference
import de.mm20.launcher2.ui.component.preferences.SwitchPreference
import de.mm20.launcher2.widgets.RingerWidget
import de.mm20.launcher2.widgets.RingerWidgetConfig

private val ringerIcons = intArrayOf(R.drawable.kvx_ic_mute, R.drawable.kvx_ic_vibrate, R.drawable.kvx_ic_ring)
private val ringerNames = arrayOf("Silent", "Vibrate", "Ring")

private fun currentMode(c: Context): Int = when (c.getSystemService(AudioManager::class.java).ringerMode) {
    AudioManager.RINGER_MODE_SILENT -> 0
    AudioManager.RINGER_MODE_VIBRATE -> 1
    else -> 2
}

@Composable
fun RingerWidgetView(widget: RingerWidget) = RingerBody(widget.config)

@Composable
fun RingerBody(cfg: RingerWidgetConfig) {
    val context = LocalContext.current
    val haptics = LocalHapticFeedback.current
    var mode by remember { mutableIntStateOf(currentMode(context)) }
    DisposableEffect(Unit) {
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                mode = currentMode(c)
            }
        }
        context.registerReceiver(r, IntentFilter(AudioManager.RINGER_MODE_CHANGED_ACTION))
        mode = currentMode(context)
        onDispose { context.unregisterReceiver(r) }
    }

    fun pick(i: Int) {
        if (i == 0 && !context.getSystemService(NotificationManager::class.java).isNotificationPolicyAccessGranted) {
            context.startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return
        }
        try {
            context.getSystemService(AudioManager::class.java).ringerMode = when (i) {
                0 -> AudioManager.RINGER_MODE_SILENT
                1 -> AudioManager.RINGER_MODE_VIBRATE
                else -> AudioManager.RINGER_MODE_NORMAL
            }
            mode = i
        } catch (e: SecurityException) {
        }
        if (cfg.haptic) haptics.performHapticFeedback(HapticFeedbackType.LongPress)
    }

    val accent = MaterialTheme.colorScheme.primary
    val idle = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.75f)
    val spread = cfg.spacing.coerceIn(40, 100) / 100f
    val heightDp = if (cfg.labels) 84.dp else 72.dp

    BoxWithConstraints(Modifier.fillMaxWidth().height(heightDp), contentAlignment = Alignment.Center) {
        val groupW = maxWidth * spread
        Row(Modifier.width(groupW).height(heightDp)) {
            for (i in 0..2) {
                val on by animateFloatAsState(if (mode == i) 1f else 0f, spring(dampingRatio = 0.6f, stiffness = 380f), label = "ringer$i")
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(heightDp)
                        .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { pick(i) }
                        .drawBehind {
                            if (on < 0.01f) return@drawBehind
                            val cy = size.height / 2f - (if (cfg.labels) 6.dp.toPx() else 0f)
                            val cx = size.width / 2f
                            if (cfg.highlight == 0 || cfg.highlight == 2) {
                                val rad = minOf(size.height / 2f, size.width * 0.65f) * on.coerceAtLeast(0.2f)
                                val g = cfg.glow / 100f
                                drawCircle(
                                    brush = Brush.radialGradient(
                                        0f to accent.copy(alpha = (g * 0.9f * on).coerceIn(0f, 1f)),
                                        0.45f to accent.copy(alpha = (g * 0.4f * on).coerceIn(0f, 1f)),
                                        1f to Color.Transparent,
                                        center = Offset(cx, cy), radius = rad.coerceAtLeast(1f),
                                    ),
                                    radius = rad, center = Offset(cx, cy),
                                )
                            }
                            if (cfg.highlight == 1 || cfg.highlight == 2) {
                                val ph = 44.dp.toPx() * cfg.iconSize / 100f * on
                                val pw = 64.dp.toPx() * cfg.iconSize / 100f * on
                                drawRoundRect(
                                    accent.copy(alpha = 0.22f * on),
                                    topLeft = Offset(cx - pw / 2, cy - ph / 2),
                                    size = Size(pw, ph),
                                    cornerRadius = CornerRadius(ph / 2, ph / 2),
                                )
                            }
                        },
                    contentAlignment = Alignment.Center,
                ) {
                    val col = lerp(idle, accent, on)
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            painterResource(ringerIcons[i]), ringerNames[i],
                            tint = col,
                            modifier = Modifier.size((28.dp * cfg.iconSize / 100f) * (1f + 0.14f * on)),
                        )
                        if (cfg.labels) Text(ringerNames[i], color = col, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun ConfigureRingerWidget(widget: RingerWidget, onWidgetUpdated: (RingerWidget) -> Unit) {
    val c = widget.config
    fun upd(n: RingerWidgetConfig) = onWidgetUpdated(widget.copy(config = n))
    OutlinedCard {
        Column {
            ListPreference(
                title = "Highlight",
                items = listOf("Glow" to 0, "Pill" to 1, "Glow and pill" to 2),
                value = c.highlight,
                onValueChanged = { v -> upd(c.copy(highlight = v)) },
            )
            SliderPreference(title = "Glow strength", value = c.glow, min = 10, max = 100, onValueChanged = { v -> upd(c.copy(glow = v)) }, label = { Text("$it%") })
            SliderPreference(title = "Icon size", value = c.iconSize, min = 60, max = 160, onValueChanged = { v -> upd(c.copy(iconSize = v)) }, label = { Text("$it%") })
            SliderPreference(title = "Spacing", value = c.spacing, min = 40, max = 100, onValueChanged = { v -> upd(c.copy(spacing = v)) }, label = { Text("$it%") })
            SwitchPreference(title = "Show labels", value = c.labels, onValueChanged = { v -> upd(c.copy(labels = v)) })
            SwitchPreference(title = "Haptic tap", value = c.haptic, onValueChanged = { v -> upd(c.copy(haptic = v)) })
        }
    }
}
