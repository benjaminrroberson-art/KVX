package de.mm20.launcher2.ui.launcher.widgets.external

import android.appwidget.AppWidgetProviderInfo
import android.os.Build
import android.os.Bundle
import android.util.SizeF
import android.util.SparseIntArray
import android.view.View
import android.view.ViewGroup
import android.widget.ListView
import android.widget.ScrollView
import androidx.annotation.RequiresApi
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.key
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.iterator
import androidx.core.view.setPadding
import de.mm20.launcher2.ktx.isAtLeastApiLevel
import de.mm20.launcher2.ui.base.LocalAppWidgetHost
import de.mm20.launcher2.ui.ktx.toPixels
import palettes.TonalPalette
import kotlin.math.roundToInt

@Composable
fun AppWidgetHost(
    widgetInfo: AppWidgetProviderInfo,
    widgetId: Int,
    modifier: Modifier = Modifier,
    borderless: Boolean = false,
    useThemeColors: Boolean = false,
    onLightBackground: Boolean = false,
    style: de.mm20.launcher2.widgets.AppWidgetConfig? = null,
) {
    val padding = (if (style != null && style.padDp >= 0) style.padDp.dp else if (borderless) 0.dp else 8.dp).toPixels().roundToInt()

    val colorScheme = MaterialTheme.colorScheme
    val appWidgetHost = LocalAppWidgetHost.current

    BoxWithConstraints(
        modifier = modifier,
    ) {
        val maxWidth = maxWidth
        val maxHeight = maxHeight
        key(widgetId) {
            AndroidView(
                modifier = modifier
                    .fillMaxSize(),
                factory = {
                    val view = appWidgetHost.createView(it.applicationContext, widgetId, widgetInfo)
                    enableNestedScroll(view)
                    return@AndroidView view
                },
                update = {
                    if (isAtLeastApiLevel(29)) {
                        it.setOnLightBackground(onLightBackground)
                    }
                    if (isAtLeastApiLevel(31)) {
                        val fade = style?.bgFadePct ?: 0
                        if (useThemeColors || fade > 0) {
                            val colorMapping = getColorMapping(colorScheme)
                            if (fade > 0) fadeBackgroundColors(colorMapping, fade, !onLightBackground)
                            it.setColorResources(colorMapping)
                        } else {
                            it.resetColorResources()
                        }
                        it.updateAppWidgetSize(
                            Bundle(),
                            arrayListOf(SizeF(maxWidth.value, maxHeight.value))
                        )
                    } else {
                        it.updateAppWidgetSize(
                            null,
                            maxWidth.value.roundToInt(),
                            maxHeight.value.roundToInt(),
                            maxWidth.value.roundToInt(),
                            maxHeight.value.roundToInt(),
                        )
                        // Workaround to force update of the widget view
                        it.updateAppWidgetOptions(Bundle())
                    }
                    it.setPadding(padding)
                    applyKvxStyle(it, style, colorScheme)
                }
            )
        }
    }
}

/** Tier A restyling: whatever the widget draws, the launcher can wrap, clip, filter and fade it. */
private fun applyKvxStyle(v: View, s: de.mm20.launcher2.widgets.AppWidgetConfig?, cs: ColorScheme) {
    val d = v.resources.displayMetrics.density
    if (s == null) return
    v.alpha = (s.alphaPct / 100f).coerceIn(0.05f, 1f)

    // color filter over the whole widget
    val paint = when (s.filter) {
        1 -> android.graphics.Paint().apply {
            colorFilter = android.graphics.ColorMatrixColorFilter(floatArrayOf(
                -1f, 0f, 0f, 0f, 255f,
                0f, -1f, 0f, 0f, 255f,
                0f, 0f, -1f, 0f, 255f,
                0f, 0f, 0f, 1f, 0f,
            ))
        }
        2 -> android.graphics.Paint().apply {
            colorFilter = android.graphics.ColorMatrixColorFilter(android.graphics.ColorMatrix().apply { setSaturation(0f) })
        }
        3 -> {
            val c = cs.primary.toArgb()
            val r = android.graphics.Color.red(c) / 255f
            val g = android.graphics.Color.green(c) / 255f
            val b = android.graphics.Color.blue(c) / 255f
            android.graphics.Paint().apply {
                // luminance of the widget drives the brightness of the theme color
                colorFilter = android.graphics.ColorMatrixColorFilter(floatArrayOf(
                    0.3f * r, 0.59f * r, 0.11f * r, 0f, 0f,
                    0.3f * g, 0.59f * g, 0.11f * g, 0f, 0f,
                    0.3f * b, 0.59f * b, 0.11f * b, 0f, 0f,
                    0f, 0f, 0f, 1f, 0f,
                ))
            }
        }
        4 -> android.graphics.Paint().apply {
            colorFilter = android.graphics.ColorMatrixColorFilter(floatArrayOf(
                0.6f, 0f, 0f, 0f, 0f,
                0f, 0.6f, 0f, 0f, 0f,
                0f, 0f, 0.6f, 0f, 0f,
                0f, 0f, 0f, 1f, 0f,
            ))
        }
        else -> null
    }
    v.setLayerType(if (paint != null) View.LAYER_TYPE_HARDWARE else View.LAYER_TYPE_NONE, paint)

    // background fill, border and rounded corners
    val fillColor = when (s.fill) {
        1 -> cs.surfaceContainer.toArgb()
        2 -> cs.surfaceContainerHighest.toArgb()
        3 -> cs.primaryContainer.toArgb()
        4 -> android.graphics.Color.BLACK
        5 -> android.graphics.Color.WHITE
        else -> null
    }
    val radius = if (s.cornerDp >= 0) s.cornerDp * d else 0f
    if (fillColor != null || s.strokeDp > 0) {
        v.background = android.graphics.drawable.GradientDrawable().apply {
            shape = android.graphics.drawable.GradientDrawable.RECTANGLE
            cornerRadius = radius
            setColor(
                if (fillColor == null) android.graphics.Color.TRANSPARENT
                else (fillColor and 0xFFFFFF) or ((s.fillAlphaPct.coerceIn(0, 100) * 255 / 100) shl 24)
            )
            if (s.strokeDp > 0) setStroke((s.strokeDp * d).toInt().coerceAtLeast(1), cs.outline.toArgb())
        }
    } else {
        v.background = null
    }
    if (s.cornerDp >= 0) {
        v.outlineProvider = object : android.view.ViewOutlineProvider() {
            override fun getOutline(view: View, outline: android.graphics.Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, radius)
            }
        }
        v.clipToOutline = true
    } else {
        v.outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
        v.clipToOutline = false
    }
}

private fun enableNestedScroll(view: View) {
    if (view is ViewGroup) {
        for (child in view.iterator()) {
            enableNestedScroll(child)
        }
    }
    if (view is ListView || view is ScrollView) view.isNestedScrollingEnabled = true
}

/**
 * Widgets that follow Android's system colors draw their background with a neutral tone. Making those tones
 * translucent makes the widget's own background see-through without touching text and icon colors.
 */
@RequiresApi(Build.VERSION_CODES.S)
private fun fadeBackgroundColors(m: SparseIntArray, fadePct: Int, dark: Boolean) {
    val a = ((100 - fadePct.coerceIn(0, 100)) * 255 / 100)
    val ids = if (dark) intArrayOf(
        android.R.color.system_neutral1_700, android.R.color.system_neutral1_800, android.R.color.system_neutral1_900,
        android.R.color.system_neutral1_1000,
        android.R.color.system_neutral2_700, android.R.color.system_neutral2_800, android.R.color.system_neutral2_900,
        android.R.color.system_neutral2_1000,
    ) else intArrayOf(
        android.R.color.system_neutral1_0, android.R.color.system_neutral1_10, android.R.color.system_neutral1_50,
        android.R.color.system_neutral1_100,
        android.R.color.system_neutral2_0, android.R.color.system_neutral2_10, android.R.color.system_neutral2_50,
        android.R.color.system_neutral2_100,
    )
    for (id in ids) {
        val c = m.get(id, 0)
        if (c != 0) m.put(id, (c and 0xFFFFFF) or (a shl 24))
    }
}

@RequiresApi(Build.VERSION_CODES.S)
private fun getColorMapping(colorScheme: ColorScheme): SparseIntArray {
    val p = TonalPalette.fromInt(colorScheme.primary.toArgb())
    val s = TonalPalette.fromInt(colorScheme.secondary.toArgb())
    val t = TonalPalette.fromInt(colorScheme.tertiary.toArgb())
    val n = TonalPalette.fromInt(colorScheme.outline.toArgb())
    val nv = TonalPalette.fromInt(colorScheme.outlineVariant.toArgb())

    val colorResources = SparseIntArray()
    colorResources.append(android.R.color.system_accent1_0, p.tone(100))
    colorResources.append(android.R.color.system_accent1_10, p.tone(99))
    colorResources.append(android.R.color.system_accent1_50, p.tone(95))
    colorResources.append(android.R.color.system_accent1_100, p.tone(90))
    colorResources.append(android.R.color.system_accent1_200, p.tone(80))
    colorResources.append(android.R.color.system_accent1_300, p.tone(70))
    colorResources.append(android.R.color.system_accent1_400, p.tone(60))
    colorResources.append(android.R.color.system_accent1_500, p.tone(50))
    colorResources.append(android.R.color.system_accent1_600, p.tone(40))
    colorResources.append(android.R.color.system_accent1_700, p.tone(30))
    colorResources.append(android.R.color.system_accent1_800, p.tone(20))
    colorResources.append(android.R.color.system_accent1_900, p.tone(10))
    colorResources.append(android.R.color.system_accent1_1000, s.tone(0))
    colorResources.append(android.R.color.system_accent2_0, s.tone(100))
    colorResources.append(android.R.color.system_accent2_10, s.tone(99))
    colorResources.append(android.R.color.system_accent2_50, s.tone(95))
    colorResources.append(android.R.color.system_accent2_100, s.tone(90))
    colorResources.append(android.R.color.system_accent2_200, s.tone(80))
    colorResources.append(android.R.color.system_accent2_300, s.tone(70))
    colorResources.append(android.R.color.system_accent2_400, s.tone(60))
    colorResources.append(android.R.color.system_accent2_500, s.tone(50))
    colorResources.append(android.R.color.system_accent2_600, s.tone(40))
    colorResources.append(android.R.color.system_accent2_700, s.tone(30))
    colorResources.append(android.R.color.system_accent2_800, s.tone(20))
    colorResources.append(android.R.color.system_accent2_900, s.tone(10))
    colorResources.append(android.R.color.system_accent2_1000, t.tone(0))
    colorResources.append(android.R.color.system_accent3_0, t.tone(100))
    colorResources.append(android.R.color.system_accent3_10, t.tone(99))
    colorResources.append(android.R.color.system_accent3_50, t.tone(95))
    colorResources.append(android.R.color.system_accent3_100, t.tone(90))
    colorResources.append(android.R.color.system_accent3_200, t.tone(80))
    colorResources.append(android.R.color.system_accent3_300, t.tone(70))
    colorResources.append(android.R.color.system_accent3_400, t.tone(60))
    colorResources.append(android.R.color.system_accent3_500, t.tone(50))
    colorResources.append(android.R.color.system_accent3_600, t.tone(40))
    colorResources.append(android.R.color.system_accent3_700, t.tone(30))
    colorResources.append(android.R.color.system_accent3_800, t.tone(20))
    colorResources.append(android.R.color.system_accent3_900, t.tone(10))
    colorResources.append(android.R.color.system_accent3_1000, t.tone(0))
    colorResources.append(android.R.color.system_neutral1_0, n.tone(100))
    colorResources.append(android.R.color.system_neutral1_10, n.tone(99))
    colorResources.append(android.R.color.system_neutral1_50, n.tone(95))
    colorResources.append(android.R.color.system_neutral1_100, n.tone(90))
    colorResources.append(android.R.color.system_neutral1_200, n.tone(80))
    colorResources.append(android.R.color.system_neutral1_300, n.tone(70))
    colorResources.append(android.R.color.system_neutral1_400, n.tone(60))
    colorResources.append(android.R.color.system_neutral1_500, n.tone(50))
    colorResources.append(android.R.color.system_neutral1_600, n.tone(40))
    colorResources.append(android.R.color.system_neutral1_700, n.tone(30))
    colorResources.append(android.R.color.system_neutral1_800, n.tone(20))
    colorResources.append(android.R.color.system_neutral1_900, n.tone(10))
    colorResources.append(android.R.color.system_neutral1_1000, nv.tone(0))
    colorResources.append(android.R.color.system_neutral2_0, nv.tone(100))
    colorResources.append(android.R.color.system_neutral2_10, nv.tone(99))
    colorResources.append(android.R.color.system_neutral2_50, nv.tone(95))
    colorResources.append(android.R.color.system_neutral2_100, nv.tone(90))
    colorResources.append(android.R.color.system_neutral2_200, nv.tone(80))
    colorResources.append(android.R.color.system_neutral2_300, nv.tone(70))
    colorResources.append(android.R.color.system_neutral2_400, nv.tone(60))
    colorResources.append(android.R.color.system_neutral2_500, nv.tone(50))
    colorResources.append(android.R.color.system_neutral2_600, nv.tone(40))
    colorResources.append(android.R.color.system_neutral2_700, nv.tone(30))
    colorResources.append(android.R.color.system_neutral2_800, nv.tone(20))
    colorResources.append(android.R.color.system_neutral2_900, nv.tone(10))
    colorResources.append(android.R.color.system_neutral2_1000, nv.tone(0))

    return colorResources
}