package de.mm20.launcher2.ui.launcher.search

import android.content.Context
import de.mm20.launcher2.search.SearchFilters

/**
 * Plain-language search, done on the phone with simple rules (no AI, nothing leaves the device).
 * "call mom" searches contacts for "mom", "open the camera" searches apps for "camera",
 * "documents about taxes" searches files for "taxes".
 */
object KvxNl {
    class Result(val query: String, val filters: SearchFilters, val note: String? = null)

    private fun sp(ctx: Context) = ctx.applicationContext.getSharedPreferences("kvx_nl_search", Context.MODE_PRIVATE)
    fun enabled(ctx: Context) = sp(ctx).getBoolean("on", true)
    fun setEnabled(ctx: Context, v: Boolean) { sp(ctx).edit().putBoolean("on", v).apply() }

    private enum class Cat { Apps, Contacts, Files, Events, Places, Articles }

    private val openVerbs = listOf("open", "launch", "start", "run", "fire up", "switch to", "go to")
    private val contactVerbs = listOf("call", "phone", "ring", "dial", "text", "message", "sms", "email", "e-mail", "mail", "whatsapp", "contact")
    private val placeVerbs = listOf("directions to", "navigate to", "route to", "take me to", "how do i get to", "nearest", "closest", "find nearby", "nearby")
    private val wikiVerbs = listOf("what is", "what are", "what's", "who is", "who was", "who's", "tell me about", "define", "wiki", "explain")
    private val findVerbs = listOf("show me", "show", "find me", "find", "search for", "search", "look for", "look up", "get me", "where is", "where's", "i need", "i want")

    private val catWords = mapOf(
        Cat.Apps to listOf("apps", "app", "applications", "application", "program", "programs"),
        Cat.Contacts to listOf("contacts", "contact", "people", "person", "number", "numbers"),
        Cat.Files to listOf("files", "file", "documents", "document", "docs", "doc", "pdfs", "pdf", "photos", "photo", "pictures", "picture", "images", "image", "videos", "video", "downloads", "songs", "music files", "spreadsheets", "presentations"),
        Cat.Events to listOf("events", "event", "meetings", "meeting", "appointments", "appointment", "calendar", "schedule"),
        Cat.Places to listOf("places", "place", "restaurants", "restaurant", "cafes", "cafe", "coffee shops", "bars", "shops", "stores", "gas stations", "pharmacies", "hotels", "near me", "nearby"),
    )
    private val timeWords = listOf("today", "tomorrow", "yesterday", "tonight", "this week", "next week", "last week", "this month", "next month", "last month", "this weekend", "this morning", "this afternoon")
    private val leadFillers = listOf("the", "my", "a", "an", "some", "any", "all", "all my", "all the", "for", "me", "up", "about", "of", "to", "that", "i", "please")

    private fun SearchFilters.only(vararg c: Cat): SearchFilters {
        val s = c.toSet()
        return copy(
            apps = Cat.Apps in s, contacts = Cat.Contacts in s, files = Cat.Files in s,
            events = Cat.Events in s, places = Cat.Places in s, articles = Cat.Articles in s,
            websites = false, shortcuts = Cat.Apps in s, tools = false,
        )
    }

    private fun stripLead(q: String, words: List<String>): String? {
        for (w in words.sortedByDescending { it.length }) {
            if (q == w) return ""
            if (q.startsWith("$w ")) return q.substring(w.length + 1).trim()
        }
        return null
    }

    private fun stripFillers(q0: String): String {
        var q = q0.trim()
        var again = true
        while (again) {
            again = false
            for (f in leadFillers.sortedByDescending { it.length }) {
                if (q.startsWith("$f ")) { q = q.substring(f.length + 1).trim(); again = true; break }
            }
        }
        return q
    }

    fun parse(ctx: Context, raw: String, filters: SearchFilters): Result {
        val same = Result(raw, filters)
        if (!enabled(ctx)) return same
        // only act when the person hasn't narrowed the categories themselves
        if (!filters.allCategoriesEnabled) return same
        var q = raw.trim().lowercase().replace(Regex("[?!.,]+$"), "").replace(Regex("\\s+"), " ")
        if (q.length < 4 || ' ' !in q) return same
        // maths and conversions stay untouched
        if (Regex("\\d").containsMatchIn(q) && Regex("[+\\-*/=^]|\\b(in|to|into)\\b").containsMatchIn(q)) return same

        var cat: Cat? = null

        // 1. leading verb, repeatedly ("can you please open ...")
        q = q.removePrefix("can you ").removePrefix("could you ").removePrefix("please ").trim()
        stripLead(q, contactVerbs)?.let { r -> if (r.isNotEmpty()) { q = r; cat = Cat.Contacts } }
        if (cat == null) stripLead(q, placeVerbs)?.let { r -> if (r.isNotEmpty()) { q = r; cat = Cat.Places } }
        if (cat == null) stripLead(q, wikiVerbs)?.let { r -> if (r.isNotEmpty() && !Regex("\\d").containsMatchIn(r)) { q = r; cat = Cat.Articles } }
        if (cat == null) stripLead(q, openVerbs)?.let { r -> if (r.isNotEmpty()) { q = r; cat = Cat.Apps } }
        if (cat == null) stripLead(q, findVerbs)?.let { r -> if (r.isNotEmpty()) q = r }
        q = stripFillers(q)

        // 2. category noun at the start or the end ("photos from vacation", "spotify app", "meetings with sam")
        if (cat == null || cat == Cat.Apps) {
            loop@ for ((c, words) in catWords) {
                for (w in words.sortedByDescending { it.length }) {
                    when {
                        q == w -> continue@loop
                        q.endsWith(" $w") -> { q = q.removeSuffix(" $w").trim(); cat = c; break@loop }
                        q.startsWith("$w ") -> { q = q.substring(w.length + 1).trim(); cat = c; break@loop }
                    }
                }
            }
            q = stripFillers(q).removeSuffix(" in").removeSuffix(" on").removeSuffix(" with").removeSuffix(" from").removeSuffix(" for").trim()
        }
        // "meetings with sam" style joiners after a category noun
        for (j in listOf("with ", "from ", "about ", "named ", "called ", "for ", "of ", "on ", "in ")) {
            if (cat != null && q.startsWith(j)) { q = q.substring(j.length).trim(); break }
        }

        // 3. time words don't narrow anything yet, so drop them from calendar searches rather than finding nothing
        if (cat == Cat.Events) for (t in timeWords) q = q.replace(t, "").trim()
        q = q.replace(Regex("\\s+"), " ").trim()

        if (q.isEmpty() || (cat == null && q == raw.trim().lowercase())) return same
        val f = when (cat) {
            Cat.Apps -> filters.only(Cat.Apps)
            Cat.Contacts -> filters.only(Cat.Contacts)
            Cat.Files -> filters.only(Cat.Files)
            Cat.Events -> filters.only(Cat.Events)
            Cat.Places -> filters.only(Cat.Places)
            Cat.Articles -> filters.only(Cat.Articles).copy(websites = true)
            null -> filters
        }
        return Result(q, f)
    }
}
