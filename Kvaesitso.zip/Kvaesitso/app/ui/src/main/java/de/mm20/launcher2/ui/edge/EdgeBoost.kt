package de.mm20.launcher2.ui.edge

import android.content.Context
import de.mm20.launcher2.ui.launcher.widgets.facesclock.np.EqDevices
import de.mm20.launcher2.ui.launcher.widgets.facesclock.np.EqEngine
import de.mm20.launcher2.ui.launcher.widgets.facesclock.np.EqService
import de.mm20.launcher2.ui.launcher.widgets.facesclock.np.MediaState

/** Optional: remembers the +6 dB boost per output device or per music app. */
object EdgeBoost {
    private fun store(ctx: Context) = ctx.applicationContext.getSharedPreferences("kvx_edge_boost", Context.MODE_PRIVATE)

    private fun key(ctx: Context): String? = when (Prefs(ctx).xBoostMem) {
        1 -> EqDevices.current(ctx)?.let { "o:$it" }
        2 -> MediaState.pkg.takeIf { it.isNotEmpty() }?.let { "a:$it" }
        else -> null
    }

    fun save(ctx: Context, on: Boolean) {
        val k = key(ctx) ?: return
        store(ctx).edit().putBoolean(k, on).apply()
    }

    /** Called when the output or the playing app changes. */
    fun restore(ctx: Context) {
        val k = key(ctx) ?: return
        val on = store(ctx).getBoolean(k, false)
        val np = de.mm20.launcher2.ui.launcher.widgets.facesclock.np.Prefs(ctx)
        if (np.eqBoost == on) return
        np.eqBoost = on
        EqEngine.ctx = ctx.applicationContext
        EqService.sync(ctx)
        EqEngine.apply(np)
    }
}
