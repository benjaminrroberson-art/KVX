package de.mm20.launcher2.ui.launcher.widgets.facesclock

import android.graphics.Typeface
import android.os.Build
import android.view.View
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.ui.unit.dp
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameMillis
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.IntSize
import de.mm20.launcher2.widgets.FacesClockWidget
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.time.Instant
import java.time.ZoneId
import java.time.ZonedDateTime

internal fun parseClockCfg(json: String): ClockCfg =
    try {
        if (json.isBlank()) ClockCfg() else ClockCfg.fromJson(JSONObject(json))
    } catch (e: Exception) {
        ClockCfg()
    }

/** The pieces of one clock, drawn once and then moved around every frame. */
private class FaceLayers(
    val dial: ImageBitmap,
    val hour: ImageBitmap?,
    val minute: ImageBitmap?,
    val second: ImageBitmap?,
    val ring: ImageBitmap?,
    val comet: ImageBitmap?,
    val badgeLeft: Float,
    val badgeTop: Float,
    val badgePx: Int,
    val badgeScale: Float,
)

private fun buildLayers(
    context: android.content.Context,
    st: Style,
    cfg: ClockCfg,
    w: Int,
    h: Int,
    now: ZonedDateTime,
): FaceLayers {
    fun face(layer: Int) = ClockRenderer.render(context, st, cfg, w, h, false, now, layer).asImageBitmap()
    if (!cfg.sec) return FaceLayers(face(0), null, null, null, null, null, 0f, 0f, 0, 1f)
    val kind = ClockStyles.secEff(cfg)
    val spec = ClockStyles.at(cfg.style)
    if (kind == 7) {
        val slotW = ClockStyles.slotW(cfg)
        val slotH = ClockStyles.slotH(cfg)
        val totalW = spec.w + slotW
        val totalH = spec.h + slotH
        val sc = minOf(w / totalW, h / totalH)
        val bc = ClockStyles.badgeCenter(spec, slotW, slotH)
        val bpx = (ClockStyles.BADGE * sc).toInt().coerceAtLeast(8)
        val left = (w - totalW * sc) / 2f + bc.first * sc - bpx / 2f
        val top = (h - totalH * sc) / 2f + bc.second * sc - bpx / 2f
        return FaceLayers(
            face(5), null, null, null,
            ClockRenderer.renderBadge(context, st, cfg, bpx, 1).asImageBitmap(),
            ClockRenderer.renderBadge(context, st, cfg, bpx, 2).asImageBitmap(),
            left, top, bpx, sc,
        )
    }
    return if (spec.name in ClockStyles.sweepFaces) {
        FaceLayers(face(1), face(2), face(3), face(4), null, null, 0f, 0f, 0, 1f)
    } else {
        FaceLayers(face(5), null, null, face(4), null, null, 0f, 0f, 0, 1f)
    }
}

/**
 * A clock face. The static art is drawn once a minute by the same code the old widgets app used.
 * The hands and the seconds marker are separate pictures that are turned every frame, so the seconds glide.
 */
@Composable
fun FacesClockWidget(widget: FacesClockWidget) = FacesClockBody(widget.config.clock, Modifier.fillMaxWidth())

@Composable
fun FacesClockBody(clockJson: String, modifier: Modifier = Modifier) {
    FeedClockEnv()
    val env = envTick.intValue
    val context = LocalContext.current
    val view = LocalView.current
    val cfg = remember(clockJson) { parseClockCfg(clockJson) }
    val zone = remember { ZoneId.systemDefault() }
    val live = cfg.sec
    val fps = KvxSettings.fps(context)

    var nowMs by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(live, cfg.smooth, fps) {
        if (live && cfg.smooth) {
            var last = 0L
            while (true) {
                withFrameMillis { t ->
                    if (fps == 0 || t - last >= 1000L / fps - 2L) {
                        last = t
                        nowMs = System.currentTimeMillis()
                    }
                }
            }
        } else {
            val step = if (live) 1000L else 60_000L
            while (true) {
                val t = System.currentTimeMillis()
                nowMs = t
                delay(step - t % step + 5L)
            }
        }
    }
    DisposableEffect(live, cfg.smooth, fps) {
        if (Build.VERSION.SDK_INT >= 35 && live && cfg.smooth) {
            view.setRequestedFrameRate(if (fps == 0) View.REQUESTED_FRAME_RATE_CATEGORY_HIGH else fps.toFloat())
        }
        onDispose {
            if (Build.VERSION.SDK_INT >= 35) view.setRequestedFrameRate(View.REQUESTED_FRAME_RATE_CATEGORY_DEFAULT)
        }
    }

    val colors = MaterialTheme.colorScheme
    val st = remember(colors.onSurface, colors.primary, colors.surface) {
        Style().apply {
            colorMode = 1
            text = colors.onSurface.toArgb()
            accent = colors.primary.toArgb()
            bg = colors.surface.toArgb()
        }
    }
    val dims = remember(cfg) { ClockStyles.dp(cfg.style, cfg) }
    var px by remember { mutableStateOf(IntSize.Zero) }
    val minuteKey = nowMs / 60_000L
    val layers by produceState<FaceLayers?>(null, cfg, st, px, minuteKey, env) {
        if (px.width > 0 && px.height > 0) {
            value = withContext(Dispatchers.Default) {
                buildLayers(context, st, cfg, px.width, px.height, Instant.ofEpochMilli(System.currentTimeMillis()).atZone(zone))
            }
        }
    }

    val t = Instant.ofEpochMilli(nowMs).atZone(zone)
    val secF = if (live) (if (cfg.smooth) t.second + (nowMs % 1000L) / 1000f else t.second.toFloat()) else 0f
    val minF = t.minute + secF / 60f
    val hourF = (t.hour % 12) + minF / 60f
    val bold = ClockStyles.boldSec(ClockStyles.at(cfg.style).name)
    val digitPaint = remember(bold) {
        android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            textAlign = android.graphics.Paint.Align.CENTER
            typeface = if (bold) Typeface.create("sans-serif-condensed", Typeface.BOLD) else Typeface.create("sans-serif-light", Typeface.NORMAL)
        }
    }

    Canvas(
        modifier = modifier
            .padding(start = cfg.padL.dp, top = cfg.padT.dp, end = cfg.padR.dp, bottom = cfg.padB.dp)
            .aspectRatio(dims.first.toFloat() / dims.second.toFloat())
            .onSizeChanged { px = it }
    ) {
        val l = layers ?: return@Canvas
        val dc = ClockStyles.dialCenter(cfg, size.width, size.height)
        val c = Offset(dc.first, dc.second)
        drawImage(l.dial)
        if (!live) return@Canvas
        l.hour?.let { img -> rotate(hourF * 30f, c) { drawImage(img) } }
        l.minute?.let { img -> rotate(minF * 6f, c) { drawImage(img) } }
        l.second?.let { img -> rotate(secF * 6f, c) { drawImage(img) } }
        l.ring?.let { ring ->
            translate(l.badgeLeft, l.badgeTop) {
                drawImage(ring)
                l.comet?.let { img -> rotate(secF * 6f, Offset(l.badgePx / 2f, l.badgePx / 2f)) { drawImage(img) } }
                if (cfg.secDigits) {
                    digitPaint.color = st.text
                    digitPaint.textSize = ClockStyles.BADGE * 0.37f * l.badgeScale
                    val fm = digitPaint.fontMetrics
                    drawContext.canvas.nativeCanvas.drawText(
                        "%02d".format(t.second), l.badgePx / 2f, l.badgePx / 2f - (fm.ascent + fm.descent) / 2f, digitPaint
                    )
                }
            }
        }
    }
}
