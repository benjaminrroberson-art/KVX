package de.mm20.launcher2.ui.launcher.widgets.facesclock

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameMillis
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.dp
import de.mm20.launcher2.widgets.FacesClockWidget
import kotlinx.coroutines.delay
import java.time.Instant
import java.time.ZoneId

object FaceClockFaces {
    val names = listOf("Classic", "Numerals", "Minimal", "Ring")
    val colorNames = listOf("Red", "Orange", "Yellow", "Green", "Blue", "Purple", "White")
    val colors = listOf(
        0xFFFF4D4D.toInt(), 0xFFFF9500.toInt(), 0xFFFFD60A.toInt(), 0xFF34C759.toInt(),
        0xFF4D9BFF.toInt(), 0xFFBF5AF2.toInt(), 0xFFFFFFFF.toInt(),
    )
}

/**
 * A clock face drawn directly on the canvas. Because it is a real view and not a picture handed to the launcher,
 * the second hand can be redrawn every frame and glide.
 */
@Composable
fun FacesClockWidget(widget: FacesClockWidget) {
    val cfg = widget.config
    val zone = remember { ZoneId.systemDefault() }
    var nowMs by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(cfg.seconds, cfg.smooth) {
        if (cfg.seconds && cfg.smooth) {
            while (true) {
                withFrameMillis { nowMs = System.currentTimeMillis() }
            }
        } else {
            val step = if (cfg.seconds) 1000L else 60_000L
            while (true) {
                val t = System.currentTimeMillis()
                nowMs = t
                delay(step - t % step + 5L)
            }
        }
    }

    val t = Instant.ofEpochMilli(nowMs).atZone(zone)
    val secF = if (cfg.seconds) (if (cfg.smooth) t.second + (nowMs % 1000L) / 1000f else t.second.toFloat()) else 0f
    val minF = t.minute + secF / 60f
    val hourF = (t.hour % 12) + minF / 60f

    val ink = MaterialTheme.colorScheme.onSurface
    val accent = MaterialTheme.colorScheme.primary
    val soft = MaterialTheme.colorScheme.outlineVariant
    val secColor = Color(cfg.secondsColor)
    val face = cfg.face.coerceIn(0, FaceClockFaces.names.size - 1)

    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(1f)
            .padding(12.dp)
    ) {
        val r = size.minDimension / 2f
        when (face) {
            0 -> classic(r, ink, accent, soft, hourF, minF)
            1 -> numerals(r, ink, accent, soft, hourF, minF)
            2 -> minimal(r, ink, accent, soft, hourF, minF)
            else -> ringFace(r, ink, accent, soft, hourF, minF, secF, secColor, cfg.seconds)
        }
        if (cfg.seconds) {
            if (face == 3) {
                // the ring face shows its seconds as a filling arc, so the hand is drawn only as a small head
                val head = secF * 6f
                rotate(head, center) { drawCircle(secColor, r * 0.035f, Offset(center.x, center.y - r * 0.9f)) }
            } else {
                drawSeconds(cfg.secondsStyle, r, secF, secColor)
            }
        }
        drawCircle(ink, r * 0.045f, center)
        drawCircle(if (cfg.seconds) secColor else accent, r * 0.02f, center)
    }
}

private fun DrawScope.hand(angle: Float, tail: Float, length: Float, width: Float, color: Color) {
    rotate(angle, center) {
        drawLine(color, Offset(center.x, center.y + tail), Offset(center.x, center.y - length), width, StrokeCap.Round)
    }
}

private fun DrawScope.ticks(r: Float, ink: Color, soft: Color, major: Float, minor: Float, minorToo: Boolean) {
    for (i in 0 until 60) {
        val big = i % 5 == 0
        if (!big && !minorToo) continue
        rotate(i * 6f, center) {
            drawLine(
                if (big) ink else soft,
                Offset(center.x, center.y - r * 0.95f),
                Offset(center.x, center.y - r * (if (big) 0.95f - major else 0.95f - minor)),
                r * (if (big) 0.03f else 0.012f),
                StrokeCap.Round,
            )
        }
    }
}

private fun DrawScope.classic(r: Float, ink: Color, accent: Color, soft: Color, hourF: Float, minF: Float) {
    drawCircle(soft, r * 0.99f, center, style = Stroke(r * 0.02f))
    ticks(r, ink, soft, 0.11f, 0.06f, true)
    hand(hourF * 30f, r * 0.08f, r * 0.5f, r * 0.06f, ink)
    hand(minF * 6f, r * 0.1f, r * 0.76f, r * 0.04f, accent)
}

private fun DrawScope.numerals(r: Float, ink: Color, accent: Color, soft: Color, hourF: Float, minF: Float) {
    drawCircle(soft, r * 0.99f, center, style = Stroke(r * 0.02f))
    val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = ink.toArgb()
        textAlign = android.graphics.Paint.Align.CENTER
        textSize = r * 0.2f
        isFakeBoldText = true
    }
    val fm = paint.fontMetrics
    for (n in 1..12) {
        val a = Math.toRadians(n * 30.0 - 90.0)
        val px = center.x + (r * 0.78f * Math.cos(a)).toFloat()
        val py = center.y + (r * 0.78f * Math.sin(a)).toFloat()
        drawContext.canvas.nativeCanvas.drawText(n.toString(), px, py - (fm.ascent + fm.descent) / 2f, paint)
    }
    for (i in 0 until 60) {
        rotate(i * 6f, center) {
            drawLine(soft, Offset(center.x, center.y - r * 0.98f), Offset(center.x, center.y - r * 0.94f), r * 0.01f, StrokeCap.Round)
        }
    }
    hand(hourF * 30f, r * 0.08f, r * 0.45f, r * 0.06f, ink)
    hand(minF * 6f, r * 0.1f, r * 0.62f, r * 0.04f, accent)
}

private fun DrawScope.minimal(r: Float, ink: Color, accent: Color, soft: Color, hourF: Float, minF: Float) {
    for (i in 0 until 12) {
        rotate(i * 30f, center) {
            drawCircle(if (i % 3 == 0) ink else soft, r * (if (i % 3 == 0) 0.035f else 0.025f), Offset(center.x, center.y - r * 0.9f))
        }
    }
    hand(hourF * 30f, 0f, r * 0.5f, r * 0.03f, ink)
    hand(minF * 6f, 0f, r * 0.78f, r * 0.02f, accent)
}

private fun DrawScope.ringFace(r: Float, ink: Color, accent: Color, soft: Color, hourF: Float, minF: Float, secF: Float, secColor: Color, showSeconds: Boolean) {
    val stroke = r * 0.07f
    val inset = stroke / 2f + r * 0.02f
    val topLeft = Offset(center.x - r + inset, center.y - r + inset)
    val sz = Size((r - inset) * 2f, (r - inset) * 2f)
    drawArc(soft, 0f, 360f, false, topLeft, sz, style = Stroke(stroke))
    if (showSeconds) {
        drawArc(secColor, -90f, secF * 6f, false, topLeft, sz, style = Stroke(stroke, cap = StrokeCap.Round))
    }
    hand(hourF * 30f, 0f, r * 0.45f, r * 0.07f, ink)
    hand(minF * 6f, 0f, r * 0.68f, r * 0.045f, accent)
}

private fun DrawScope.drawSeconds(style: Int, r: Float, secF: Float, color: Color) {
    val angle = secF * 6f
    when (style) {
        1 -> rotate(angle, center) { drawCircle(color, r * 0.04f, Offset(center.x, center.y - r * 0.93f)) }
        2 -> {
            val stroke = r * 0.035f
            val topLeft = Offset(center.x - r * 0.93f, center.y - r * 0.93f)
            val sz = Size(r * 1.86f, r * 1.86f)
            for (j in 0 until 16) {
                drawArc(
                    color.copy(alpha = (j + 1) / 16f * 0.8f),
                    angle - 90f - (16 - j) * 3.2f,
                    3.4f,
                    false,
                    topLeft,
                    sz,
                    style = Stroke(stroke),
                )
            }
            rotate(angle, center) { drawCircle(color, r * 0.045f, Offset(center.x, center.y - r * 0.93f)) }
        }
        else -> {
            hand(angle, r * 0.18f, r * 0.9f, r * 0.018f, color)
        }
    }
}


