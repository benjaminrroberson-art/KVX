package de.mm20.launcher2.ui.launcher.widgets.facesclock

import android.content.Context
import de.mm20.launcher2.widgets.VizConfig
import org.json.JSONObject

/** Settings for the floating bubble. Plain SharedPreferences so the overlay service can read them directly. */
object BubbleSettings {
    private fun sp(c: Context) = c.applicationContext.getSharedPreferences("kvx_bubble", Context.MODE_PRIVATE)

    fun on(c: Context) = sp(c).getBoolean("on", false)
    fun setOn(c: Context, v: Boolean) = sp(c).edit().putBoolean("on", v).apply()

    fun int(c: Context, k: String, d: Int) = sp(c).getInt(k, d)
    fun bool(c: Context, k: String, d: Boolean) = sp(c).getBoolean(k, d)
    fun setInt(c: Context, k: String, v: Int) = sp(c).edit().putInt(k, v).apply()
    fun setBool(c: Context, k: String, v: Boolean) = sp(c).edit().putBoolean(k, v).apply()

    // keys: size, opacity, snap, keepPaused, hideInApp, tuck, dot, haptic, hideMin, x, y
    fun size(c: Context) = int(c, "size", 56)
    fun opacity(c: Context) = int(c, "opacity", 100)
    fun snap(c: Context) = bool(c, "snap", true)
    fun keepPaused(c: Context) = bool(c, "keepPaused", false)
    fun hideInApp(c: Context) = bool(c, "hideInApp", true)
    fun hideOnViz(c: Context) = bool(c, "hideOnViz", true)
    fun tuck(c: Context) = bool(c, "tuck", true)
    fun dot(c: Context) = bool(c, "dot", true)
    fun haptic(c: Context) = bool(c, "haptic", true)
    fun hideMin(c: Context) = int(c, "hideMin", 0)

    fun viz(c: Context): VizConfig {
        val s = sp(c).getString("viz", null) ?: return VizConfig()
        return try {
            val o = JSONObject(s)
            val d = VizConfig()
            VizConfig(
                style = o.optInt("style", d.style), shape = o.optInt("shape", d.shape), colorMode = o.optInt("colorMode", d.colorMode),
                color = o.optInt("color", d.color), color2 = o.optInt("color2", d.color2), bars = o.optInt("bars", d.bars),
                sens = o.optInt("sens", d.sens), reach = o.optInt("reach", d.reach), fall = o.optInt("fall", d.fall),
                vert = o.optInt("vert", d.vert), low = o.optInt("low", d.low), spin = o.optBoolean("spin", d.spin),
                glow = o.optBoolean("glow", d.glow), vizOp = o.optInt("vizOp", d.vizOp), artOp = o.optInt("artOp", d.artOp),
                borderOp = o.optInt("borderOp", d.borderOp), vizHeight = o.optInt("vizHeight", d.vizHeight),
            )
        } catch (e: Exception) { VizConfig() }
    }

    fun setViz(c: Context, v: VizConfig) {
        val o = JSONObject()
        o.put("style", v.style); o.put("shape", v.shape); o.put("colorMode", v.colorMode); o.put("color", v.color); o.put("color2", v.color2)
        o.put("bars", v.bars); o.put("sens", v.sens); o.put("reach", v.reach); o.put("fall", v.fall); o.put("vert", v.vert); o.put("low", v.low)
        o.put("spin", v.spin); o.put("glow", v.glow); o.put("vizOp", v.vizOp); o.put("artOp", v.artOp); o.put("borderOp", v.borderOp); o.put("vizHeight", v.vizHeight)
        sp(c).edit().putString("viz", o.toString()).apply()
    }
}
