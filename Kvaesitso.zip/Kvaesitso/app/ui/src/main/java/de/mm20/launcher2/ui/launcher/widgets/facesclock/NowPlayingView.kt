package de.mm20.launcher2.ui.launcher.widgets.facesclock

import android.graphics.Bitmap
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.draw.scale
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.lifecycle.viewmodel.compose.viewModel
import de.mm20.launcher2.music.PlaybackState
import de.mm20.launcher2.ui.R
import de.mm20.launcher2.ui.component.preferences.SliderPreference
import de.mm20.launcher2.ui.component.preferences.SwitchPreference
import de.mm20.launcher2.ui.launcher.widgets.music.MusicWidgetVM
import de.mm20.launcher2.widgets.NowPlayingWidget
import de.mm20.launcher2.widgets.NowPlayingWidgetConfig
import kotlin.math.PI
import kotlin.math.sin

private fun artAccentOf(b: Bitmap?, fallback: Color): Color {
    if (b == null) return fallback
    return try {
        val s = Bitmap.createScaledBitmap(b, 16, 16, true)
        var best = 0f
        var bc = 0
        for (x in 0 until 16) for (y in 0 until 16) {
            val p = s.getPixel(x, y)
            val r = android.graphics.Color.red(p); val g = android.graphics.Color.green(p); val bl = android.graphics.Color.blue(p)
            val mx = maxOf(r, g, bl); val mn = minOf(r, g, bl)
            val sat = if (mx == 0) 0f else (mx - mn) / mx.toFloat()
            val score = sat * (mx / 255f)
            if (score > best) { best = score; bc = p }
        }
        if (best < 0.15f) fallback else Color(bc)
    } catch (e: Exception) { fallback }
}

private fun keyed(a: android.media.session.PlaybackState.CustomAction, vararg keys: String): Boolean {
    val n = (a.name?.toString() ?: "").lowercase() + " " + (a.action ?: "").lowercase()
    return keys.any { n.contains(it) } && !n.contains("dislike") && !n.contains("thumbs_down")
}

@Composable
fun NowPlayingView(widget: NowPlayingWidget) = NowPlayingBody(widget.config)

@Composable
fun NowPlayingBody(cfg: NowPlayingWidgetConfig) {
    val vm: MusicWidgetVM = viewModel()
    val context = LocalContext.current
    val haptics = LocalHapticFeedback.current
    val title by vm.title.collectAsState(null)
    val artist by vm.artist.collectAsState(null)
    val art by vm.albumArt.collectAsState(null)
    val state by vm.playbackState.collectAsState(PlaybackState.Stopped)
    val dur by vm.duration.collectAsState(null)
    val pos by vm.position.collectAsState(null)
    val actions by vm.supportedActions.collectAsState(null)

    val primary = MaterialTheme.colorScheme.primary
    val accent = if (cfg.artAccent) remember(art) { artAccentOf(art, primary) } else primary
    val fg = MaterialTheme.colorScheme.onSurface
    val playing = state == PlaybackState.Playing

    fun tap() { if (cfg.haptic) haptics.performHapticFeedback(HapticFeedbackType.LongPress) }

    if (title == null && state == PlaybackState.Stopped) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(painterResource(R.drawable.music_note_24px), null, tint = accent)
            Text("  Nothing playing", color = fg.copy(alpha = 0.7f))
        }
        return
    }

    Column(Modifier.fillMaxWidth().padding(start = 12.dp + cfg.padStart.dp, top = 12.dp + cfg.padTop.dp, end = 12.dp + cfg.padEnd.dp, bottom = 12.dp + cfg.padBottom.dp)) {
        val artDp = 84f * cfg.artSize / 100f
        val vi = if (cfg.showViz) artDp * 0.34f else 0f
        Row(Modifier.padding(start = (vi * 0.8f).dp, top = (vi * 0.6f).dp, bottom = (vi * 0.5f).dp), verticalAlignment = Alignment.CenterVertically) {
            if (cfg.showViz) {
                VizBubble(artDp, if (cfg.vizFollowBubble) BubbleSettings.viz(androidx.compose.ui.platform.LocalContext.current) else cfg.viz, art, playing, false)
            } else Surface(shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.surfaceContainerHigh, modifier = Modifier.size(artDp.dp)) {
                val a = art
                if (a != null) Image(a.asImageBitmap(), null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxWidth().height(84.dp))
                else Box(contentAlignment = Alignment.Center) { Icon(painterResource(R.drawable.music_note_24px), null, tint = accent) }
            }
            Column(Modifier.padding(start = 14.dp + (vi * 0.7f).dp).weight(1f)) {
                Text(title ?: "", style = MaterialTheme.typography.titleMedium, color = fg, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(artist ?: "", style = MaterialTheme.typography.bodyMedium, color = fg.copy(alpha = 0.7f), maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }

        if (cfg.progress && dur != null && dur!! > 0L) {
            val phase by rememberInfiniteTransition(label = "wave").animateFloat(
                0f, (2 * PI).toFloat(),
                infiniteRepeatable(tween(1800, easing = LinearEasing), RepeatMode.Restart), label = "phase",
            )
            var smooth by remember { mutableFloatStateOf(0f) }
            LaunchedEffect(pos, playing, dur) {
                val base = (pos ?: 0L).toFloat()
                smooth = base
                if (playing) {
                    val t0 = withFrameNanos { it }
                    while (true) {
                        withFrameNanos { now -> smooth = (base + (now - t0) / 1_000_000f).coerceAtMost(dur!!.toFloat()) }
                    }
                }
            }
            val frac = (smooth / dur!!.toFloat()).coerceIn(0f, 1f)
            val track = fg.copy(alpha = 0.18f)
            val wavy = cfg.wavy
            var dragging by remember { mutableStateOf(false) }
            var dragFrac by remember { mutableFloatStateOf(0f) }
            val shown = if (dragging) dragFrac else frac
            Canvas(
                Modifier.fillMaxWidth().height(28.dp).padding(top = 6.dp)
                    .pointerInput(dur) {
                        detectTapGestures { o -> vm.seekTo((o.x / size.width * dur!!).toLong()); tap() }
                    }
                    .pointerInput(dur) {
                        detectHorizontalDragGestures(
                            onDragStart = { o -> dragging = true; dragFrac = (o.x / size.width).coerceIn(0f, 1f) },
                            onDragEnd = { vm.seekTo((dragFrac * dur!!).toLong()); dragging = false },
                            onDragCancel = { dragging = false },
                        ) { change, _ -> dragFrac = (change.position.x / size.width).coerceIn(0f, 1f) }
                    }
            ) {
                val w = size.width; val cy = size.height / 2f
                val x1 = w * shown
                drawLine(track, Offset(x1, cy), Offset(w, cy), 4.dp.toPx(), StrokeCap.Round)
                val path = Path()
                val amp = if (wavy) (if (playing) 4.dp.toPx() else 2.dp.toPx()) else 0f
                val wl = 22.dp.toPx()
                var x = 0f
                path.moveTo(0f, cy)
                while (x <= x1) {
                    path.lineTo(x, cy + amp * sin((x / wl) * 2 * PI.toFloat() - (if (playing) phase else 0f)))
                    x += 2f
                }
                drawPath(path, accent, style = Stroke(4.dp.toPx(), cap = StrokeCap.Round))
                drawCircle(accent, 7.dp.toPx(), Offset(x1, cy))
            }
        }

        Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            val ca = actions?.customActions ?: emptyList()
            if (cfg.extras) ca.firstOrNull { keyed(it, "shuffle") }?.let { a ->
                PressIcon(R.drawable.kvx_shuffle_24, "Shuffle", fg.copy(alpha = 0.8f)) { vm.performCustomAction(a); tap() }
            }
            PressIcon(R.drawable.skip_previous_24px, "Previous", fg, 28.dp) { vm.skipPrevious(); tap() }
            PlayPauseButton(playing, accent, MaterialTheme.colorScheme.onPrimary) { vm.togglePause(); tap() }
            PressIcon(R.drawable.skip_next_24px, "Next", fg, 28.dp) { vm.skipNext(); tap() }
            if (cfg.extras) ca.firstOrNull { keyed(it, "repeat") }?.let { a ->
                PressIcon(R.drawable.kvx_repeat_24, "Repeat", fg.copy(alpha = 0.8f)) { vm.performCustomAction(a); tap() }
            }
            if (cfg.extras) ca.firstOrNull { keyed(it, "like", "thumbs_up", "favorite", "heart") }?.let { a ->
                PressIcon(R.drawable.favorite_24px, "Like", fg.copy(alpha = 0.8f)) { vm.performCustomAction(a); tap() }
            }
        }
    }
}

@Composable
private fun PressIcon(res: Int, desc: String, tint: Color, size: Dp = 24.dp, onClick: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    val down by src.collectIsPressedAsState()
    val sc by animateFloatAsState(if (down) 0.78f else 1f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium), label = "press")
    Box(
        Modifier.size(44.dp).scale(sc).clip(RoundedCornerShape(22.dp)).clickable(src, null, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Icon(painterResource(res), desc, tint = tint, modifier = Modifier.size(size)) }
}

@Composable
private fun PlayPauseButton(playing: Boolean, bg: Color, fgc: Color, onClick: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    val down by src.collectIsPressedAsState()
    val sc by animateFloatAsState(if (down) 0.88f else 1f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium), label = "pp_press")
    val t by animateFloatAsState(if (playing) 0f else 1f, spring(Spring.DampingRatioNoBouncy, Spring.StiffnessMediumLow), label = "pp_morph")
    val corner by animateDpAsState(if (playing) 18.dp else 28.dp, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessLow), label = "pp_corner")
    Box(
        Modifier.size(56.dp).scale(sc).clip(RoundedCornerShape(corner)).background(bg).clickable(src, null, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.size(28.dp)) {
            val u = size.width / 24f
            fun lerp(a: Float, b: Float) = a + (b - a) * t
            fun quad(p: List<Float>, q: List<Float>) {
                val path = Path()
                for (i in 0 until 4) {
                    val x = lerp(p[i * 2], q[i * 2]) * u; val y = lerp(p[i * 2 + 1], q[i * 2 + 1]) * u
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                path.close()
                drawPath(path, fgc)
            }
            // t=0 pause, t=1 play
            quad(listOf(7f, 5f, 10.5f, 5f, 10.5f, 19f, 7f, 19f), listOf(8f, 5f, 13f, 8.2f, 13f, 15.8f, 8f, 19f))
            quad(listOf(13.5f, 5f, 17f, 5f, 17f, 19f, 13.5f, 19f), listOf(13f, 8.2f, 18.5f, 12f, 18.5f, 12f, 13f, 15.8f))
        }
    }
}

@Composable
fun ConfigureNowPlayingWidget(widget: NowPlayingWidget, onWidgetUpdated: (NowPlayingWidget) -> Unit) {
    val c = widget.config
    fun upd(n: NowPlayingWidgetConfig) = onWidgetUpdated(widget.copy(config = n))
    OutlinedCard {
        Column {
            SwitchPreference(title = "Progress bar", value = c.progress, onValueChanged = { v -> upd(c.copy(progress = v)) })
            SwitchPreference(title = "Wavy progress", summary = "The played part ripples while music plays", value = c.wavy, onValueChanged = { v -> upd(c.copy(wavy = v)) })
            SwitchPreference(title = "Shuffle, repeat and like buttons", summary = "Shown when the player offers them", value = c.extras, onValueChanged = { v -> upd(c.copy(extras = v)) })
            SwitchPreference(title = "Visualizer", summary = "Music-reactive graphics around the artwork", value = c.showViz, onValueChanged = { v -> upd(c.copy(showViz = v)) })
            if (c.showViz) SwitchPreference(title = "Match the bubble's look", summary = "Uses your bubble and imported visualizer settings", value = c.vizFollowBubble, onValueChanged = { v -> upd(c.copy(vizFollowBubble = v)) })
            if (c.showViz && !c.vizFollowBubble) VizControls(c.viz, true) { v -> upd(c.copy(viz = v)) }
            SwitchPreference(title = "Colors from album art", value = c.artAccent, onValueChanged = { v -> upd(c.copy(artAccent = v)) })
            SwitchPreference(title = "Haptic taps", value = c.haptic, onValueChanged = { v -> upd(c.copy(haptic = v)) })
            PaddingControls(c.padTop, c.padBottom, c.padStart, c.padEnd) { t, b, s, e -> upd(c.copy(padTop = t, padBottom = b, padStart = s, padEnd = e)) }
            SliderPreference(title = "Artwork size", value = c.artSize, min = 50, max = 130, onValueChanged = { v -> upd(c.copy(artSize = v)) }, label = { Text("$it%") })
        }
    }
}
