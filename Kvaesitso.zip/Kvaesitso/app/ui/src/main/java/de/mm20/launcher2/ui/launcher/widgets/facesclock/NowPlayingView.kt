package de.mm20.launcher2.ui.launcher.widgets.facesclock

import android.graphics.Bitmap
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.lifecycle.viewmodel.compose.viewModel
import de.mm20.launcher2.music.PlaybackState
import de.mm20.launcher2.ui.R
import de.mm20.launcher2.ui.component.preferences.SliderPreference
import de.mm20.launcher2.ui.component.preferences.SwitchPreference
import de.mm20.launcher2.ui.launcher.widgets.music.MusicWidgetVM
import de.mm20.launcher2.widgets.NowPlayingWidget
import de.mm20.launcher2.widgets.NowPlayingWidgetConfig
import kotlin.math.PI
import kotlin.math.sin

private fun artAccentOf(b: Bitmap?, fallback: Color): Color {
    if (b == null) return fallback
    return try {
        val s = Bitmap.createScaledBitmap(b, 16, 16, true)
        var best = 0f
        var bc = 0
        for (x in 0 until 16) for (y in 0 until 16) {
            val p = s.getPixel(x, y)
            val r = android.graphics.Color.red(p); val g = android.graphics.Color.green(p); val bl = android.graphics.Color.blue(p)
            val mx = maxOf(r, g, bl); val mn = minOf(r, g, bl)
            val sat = if (mx == 0) 0f else (mx - mn) / mx.toFloat()
            val score = sat * (mx / 255f)
            if (score > best) { best = score; bc = p }
        }
        if (best < 0.15f) fallback else Color(bc)
    } catch (e: Exception) { fallback }
}

private fun keyed(a: android.media.session.PlaybackState.CustomAction, vararg keys: String): Boolean {
    val n = (a.name?.toString() ?: "").lowercase() + " " + (a.action ?: "").lowercase()
    return keys.any { n.contains(it) } && !n.contains("dislike") && !n.contains("thumbs_down")
}

@Composable
fun NowPlayingView(widget: NowPlayingWidget) = NowPlayingBody(widget.config)

@Composable
fun NowPlayingBody(cfg: NowPlayingWidgetConfig) {
    val vm: MusicWidgetVM = viewModel()
    val context = LocalContext.current
    val haptics = LocalHapticFeedback.current
    val title by vm.title.collectAsState(null)
    val artist by vm.artist.collectAsState(null)
    val art by vm.albumArt.collectAsState(null)
    val state by vm.playbackState.collectAsState(PlaybackState.Stopped)
    val dur by vm.duration.collectAsState(null)
    val pos by vm.position.collectAsState(null)
    val actions by vm.supportedActions.collectAsState(null)

    val primary = MaterialTheme.colorScheme.primary
    val accent = if (cfg.artAccent) remember(art) { artAccentOf(art, primary) } else primary
    val fg = MaterialTheme.colorScheme.onSurface
    val playing = state == PlaybackState.Playing

    fun tap() { if (cfg.haptic) haptics.performHapticFeedback(HapticFeedbackType.LongPress) }

    if (title == null && state == PlaybackState.Stopped) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(painterResource(R.drawable.music_note_24px), null, tint = accent)
            Text("  Nothing playing", color = fg.copy(alpha = 0.7f))
        }
        return
    }

    Column(Modifier.fillMaxWidth().padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.surfaceContainerHigh, modifier = Modifier.size((84 * cfg.artSize / 100).dp)) {
                val a = art
                if (a != null) Image(a.asImageBitmap(), null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxWidth().height(84.dp))
                else Box(contentAlignment = Alignment.Center) { Icon(painterResource(R.drawable.music_note_24px), null, tint = accent) }
            }
            Column(Modifier.padding(start = 14.dp).weight(1f)) {
                Text(title ?: "", style = MaterialTheme.typography.titleMedium, color = fg, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(artist ?: "", style = MaterialTheme.typography.bodyMedium, color = fg.copy(alpha = 0.7f), maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }

        if (cfg.progress && dur != null && dur!! > 0L) {
            val phase by rememberInfiniteTransition(label = "wave").animateFloat(
                0f, (2 * PI).toFloat(),
                infiniteRepeatable(tween(1800, easing = LinearEasing), RepeatMode.Restart), label = "phase",
            )
            val frac = ((pos ?: 0L).toFloat() / dur!!.toFloat()).coerceIn(0f, 1f)
            val track = fg.copy(alpha = 0.18f)
            val wavy = cfg.wavy
            var dragging by remember { mutableStateOf(false) }
            var dragFrac by remember { mutableFloatStateOf(0f) }
            val shown = if (dragging) dragFrac else frac
            Canvas(
                Modifier.fillMaxWidth().height(28.dp).padding(top = 6.dp)
                    .pointerInput(dur) {
                        detectTapGestures { o -> vm.seekTo((o.x / size.width * dur!!).toLong()); tap() }
                    }
                    .pointerInput(dur) {
                        detectHorizontalDragGestures(
                            onDragStart = { o -> dragging = true; dragFrac = (o.x / size.width).coerceIn(0f, 1f) },
                            onDragEnd = { vm.seekTo((dragFrac * dur!!).toLong()); dragging = false },
                            onDragCancel = { dragging = false },
                        ) { change, _ -> dragFrac = (change.position.x / size.width).coerceIn(0f, 1f) }
                    }
            ) {
                val w = size.width; val cy = size.height / 2f
                val x1 = w * shown
                drawLine(track, Offset(x1, cy), Offset(w, cy), 4.dp.toPx(), StrokeCap.Round)
                val path = Path()
                val amp = if (wavy) (if (playing) 4.dp.toPx() else 2.dp.toPx()) else 0f
                val wl = 22.dp.toPx()
                var x = 0f
                path.moveTo(0f, cy)
                while (x <= x1) {
                    path.lineTo(x, cy + amp * sin((x / wl) * 2 * PI.toFloat() - (if (playing) phase else 0f)))
                    x += 2f
                }
                drawPath(path, accent, style = Stroke(4.dp.toPx(), cap = StrokeCap.Round))
                drawCircle(accent, 7.dp.toPx(), Offset(x1, cy))
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            val ca = actions?.customActions ?: emptyList()
            if (cfg.extras) ca.firstOrNull { keyed(it, "shuffle") }?.let { a ->
                TextButton(onClick = { vm.performCustomAction(a); tap() }) { Text("Shuffle", color = fg.copy(alpha = 0.8f)) }
            }
            IconButton(onClick = { vm.skipPrevious(); tap() }) { Icon(painterResource(R.drawable.skip_previous_24px), "Previous", tint = fg) }
            IconButton(onClick = { vm.togglePause(); tap() }, modifier = Modifier.size(56.dp)) {
                Surface(shape = RoundedCornerShape(if (playing) 16.dp else 28.dp), color = accent, modifier = Modifier.size(52.dp)) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(painterResource(if (playing) R.drawable.pause_24px_filled else R.drawable.play_arrow_24px), if (playing) "Pause" else "Play", tint = MaterialTheme.colorScheme.onPrimary)
                    }
                }
            }
            IconButton(onClick = { vm.skipNext(); tap() }) { Icon(painterResource(R.drawable.skip_next_24px), "Next", tint = fg) }
            if (cfg.extras) ca.firstOrNull { keyed(it, "like", "thumbs_up", "favorite", "heart") }?.let { a ->
                TextButton(onClick = { vm.performCustomAction(a); tap() }) { Text("Like", color = fg.copy(alpha = 0.8f)) }
            }
        }
    }
}

@Composable
fun ConfigureNowPlayingWidget(widget: NowPlayingWidget, onWidgetUpdated: (NowPlayingWidget) -> Unit) {
    val c = widget.config
    fun upd(n: NowPlayingWidgetConfig) = onWidgetUpdated(widget.copy(config = n))
    OutlinedCard {
        Column {
            SwitchPreference(title = "Progress bar", value = c.progress, onValueChanged = { v -> upd(c.copy(progress = v)) })
            SwitchPreference(title = "Wavy progress", summary = "The played part ripples while music plays", value = c.wavy, onValueChanged = { v -> upd(c.copy(wavy = v)) })
            SwitchPreference(title = "Like and shuffle buttons", summary = "Shown when the player offers them", value = c.extras, onValueChanged = { v -> upd(c.copy(extras = v)) })
            SwitchPreference(title = "Colors from album art", value = c.artAccent, onValueChanged = { v -> upd(c.copy(artAccent = v)) })
            SwitchPreference(title = "Haptic taps", value = c.haptic, onValueChanged = { v -> upd(c.copy(haptic = v)) })
            SliderPreference(title = "Artwork size", value = c.artSize, min = 50, max = 130, onValueChanged = { v -> upd(c.copy(artSize = v)) }, label = { Text("$it%") })
        }
    }
}
