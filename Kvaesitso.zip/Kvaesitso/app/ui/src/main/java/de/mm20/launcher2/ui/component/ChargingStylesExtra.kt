package de.mm20.launcher2.ui.component

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sin

val chargingStyleNamesExtra = listOf(
    "Aurora", "Pulse rings", "Edge flow", "Liquid", "Sparks", "Grid pulse", "Orbit", "Tide lines",
    "Breathing glow", "Raindrops", "Equalizer", "Spiral", "Drip", "Honeycomb", "Comets",
)

private fun fr(x: Float) = x - kotlin.math.floor(x)
private fun hs(i: Int) = fr(sin(i * 12.9898f) * 43758.547f)

/** Styles 6..20. Coordinates follow the 90x160 design grid, scaled to the canvas. */
internal fun DrawScope.drawChargingExtra(style: Int, t: Float, k: Float, intensity: Int) {
    val w = size.width
    val h = size.height
    val sx = w / 90f
    val sy = h / 160f
    val d = 1.dp.toPx()
    val tt = t * k
    fun a(x: Float) = Color.White.copy(alpha = x.coerceIn(0f, 1f))
    when (style) {
        6 -> for (kk in 0..2) {
            val p = Path()
            p.moveTo(0f, h)
            var x = 0f
            while (x <= w) {
                val u = x / sx
                p.lineTo(x, h * .55f - kk * 10 * sy + sin(u / 14 + tt * 1.2f + kk * 2) * 14 * sy + sin(u / 6 - tt) * 4 * sy)
                x += 3 * sx
            }
            p.lineTo(w, h); p.close()
            drawPath(p, Brush.verticalGradient(listOf(a(0f), a(.30f)), startY = h * .3f, endY = h))
        }
        7 -> for (i in 0 until 4) {
            val p = fr(tt * .5f + i / 4f)
            drawCircle(a((1 - p) * .55f), p * h * 1.1f, Offset(w / 2, h + 8 * sy), style = Stroke(2 * d))
        }
        8 -> {
            val per = 2 * (w + h)
            fun pt(q0: Float): Offset {
                var q = ((q0 % per) + per) % per
                if (q < w) return Offset(q, 2 * d)
                q -= w
                if (q < h) return Offset(w - 2 * d, q)
                q -= h
                if (q < w) return Offset(w - q, h - 2 * d)
                q -= w
                return Offset(2 * d, h - q)
            }
            for (kk in 0 until 3) {
                val head = tt * 70 * d + kk * per / 3
                for (s in 0..14) drawCircle(a((1 - s / 15f) * .85f), (3.2f - s * .15f) * d, pt(head - s * 5 * d))
            }
        }
        9 -> {
            val lv = h * (.55f + .1f * sin(tt * .4f))
            for (layer in 0..1) {
                val p = Path()
                p.moveTo(0f, h)
                var x = 0f
                while (x <= w) {
                    val u = x / sx
                    val y = if (layer == 0) lv + sin(u / 12 + tt * 2) * 5 * sy else lv + 4 * sy + sin(u / 9 - tt * 1.6f) * 4 * sy
                    p.lineTo(x, y)
                    x += 3 * sx
                }
                p.lineTo(w, h); p.close()
                drawPath(p, a(if (layer == 0) .18f else .12f))
            }
        }
        10 -> for (i in 0 until 26) {
            val sp = .25f + hs(i) * .4f
            val p = fr(tt * sp + i * .137f)
            val x = hs(i + 50) * w + sin(tt * 2 + i) * 4 * d
            val y = h - p * h
            drawLine(a((1 - p) * .9f), Offset(x, y), Offset(x, y + (2 + p * 5) * d), 2 * d, StrokeCap.Round)
        }
        11 -> {
            var x = 6 * sx
            while (x < w) {
                var y = 6 * sx
                while (y < h) {
                    val dd = hypot(x - w / 2, y - h)
                    val v = max(0f, sin(dd / (16 * sx) - tt * 2.2f))
                    drawCircle(a(.06f + v * .6f), (1.2f + v * 1.6f) * sx, Offset(x, y))
                    y += 11 * sx
                }
                x += 11 * sx
            }
        }
        12 -> {
            for (i in 0 until 24) {
                val p = fr(tt * .25f + i / 24f)
                val ang = i * 2.4f + tt * 2 + p * 6
                val r = (1 - p) * 50 * sx
                drawCircle(a(.15f + .6f * p), (1.4f + p * 1.4f) * sx, Offset(w / 2 + cos(ang) * r, h / 2 + sin(ang) * r))
            }
            drawCircle(a(.8f), (5 + sin(tt * 4) * 1.2f) * sx, Offset(w / 2, h / 2))
        }
        13 -> for (kk in 0 until 9) {
            val y0 = h - fr((tt * 14 + kk * 20) / 170f) * 170 * sy
            val p = Path()
            var x = 0f
            var first = true
            while (x <= w) {
                val y = y0 + sin(x / sx / 16 + kk + tt) * 3 * sy
                if (first) { p.moveTo(x, y); first = false } else p.lineTo(x, y)
                x += 3 * sx
            }
            drawPath(p, a(.1f + .5f * (1 - y0 / h)), style = Stroke(d))
        }
        14 -> {
            val al = .22f + .18f * sin(tt * 1.6f)
            drawRect(Brush.radialGradient(0f to a(0f), .33f to a(0f), 1f to a(al), center = Offset(w / 2, h / 2), radius = h * .75f))
        }
        15 -> for (i in 0 until 14) {
            val p = fr(tt * .22f + i * .31f)
            val x = (hs(i + 3) * 80 + 5) * sx
            val y = h - p * h * .9f
            drawCircle(a((1 - p) * .6f), (2 + p * 7) * sx, Offset(x, y), style = Stroke(d))
        }
        16 -> for (i in 0 until 14) {
            val hh = (10 + (sin(tt * 3 + i * .9f) + sin(tt * 1.7f + i * 2.1f) + 2) * 10) * sy
            drawRect(a(.2f + hh / (60 * sy) * .4f), Offset(i * 6.4f * sx + sx, h - hh), Size(4 * sx, hh))
        }
        17 -> for (i in 0 until 70) {
            val ang = i * .35f + tt * .8f
            val r = i * .7f
            drawCircle(a((1 - i / 80f) * .8f), (1 + (1 - i / 70f)) * sx, Offset(w / 2 + cos(ang) * r * .8f * sx, h / 2 + sin(ang) * r * sy))
        }
        18 -> for (kk in 0 until 6) {
            val x = (8 + kk * 15) * sx
            val p = fr(tt * .35f + kk * .23f)
            val len = max(1f, p * h * .6f)
            drawLine(Brush.verticalGradient(listOf(a(.5f), a(0f)), startY = 0f, endY = len), Offset(x, 0f), Offset(x, len), 3 * sx)
            drawCircle(a(.8f), 2.2f * sx, Offset(x, len))
        }
        19 -> {
            val r = 9 * sx
            val rows = (h / (r * 1.5f)).toInt() + 2
            for (row in 0 until rows) for (cx in 0 until 8) {
                val x = cx * r * 1.74f + (if (row % 2 == 1) r * .87f else 0f)
                val y = row * r * 1.5f
                val v = max(0f, sin(((h - y) / h) * 6 - tt * 2 + cx * .4f))
                val p = Path()
                for (q in 0 until 6) {
                    val ang = (PI / 3 * q + PI / 6).toFloat()
                    val px = x + cos(ang) * r * .9f
                    val py = y + sin(ang) * r * .9f
                    if (q == 0) p.moveTo(px, py) else p.lineTo(px, py)
                }
                p.close()
                drawPath(p, a(.05f + v * .55f), style = Stroke(d))
            }
        }
        20 -> for (kk in 0 until 4) {
            val p = fr(tt * .3f + kk / 4f)
            val side = if (kk % 2 == 1) 1f else -1f
            for (s in 0..13) {
                val q = max(0f, p - s * .012f)
                val x = w / 2 + side * (w * .42f - sin(q * 3.14f) * w * .3f)
                val y = h - q * h
                drawCircle(a((1 - s / 14f) * (1 - p) * .9f), (2.4f - s * .12f) * sx, Offset(x, y))
            }
        }
    }
}
