package de.mm20.launcher2.ui.component

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp

/** Extra search bar looks (Kvx). Read in composition; settings changes show up immediately. */
class KvxSearchBarStyle(
    val shape: Int,
    val heightDp: Int,
    val placeholder: String,
    val showIcon: Boolean,
    val bgAlphaPct: Int,
    val borderDp: Int,
    val borderAccent: Boolean,
    val textScalePct: Int,
    val bgColor: Int = 0,
    val textColor: Int = 0,
    val iconColor: Int = 0,
    val borderColor: Int = 0,
) {
    fun shapeOr(default: Shape): Shape = when (shape) {
        1 -> CircleShape
        2 -> RoundedCornerShape(12.dp)
        3 -> RoundedCornerShape(2.dp)
        4 -> RoundedCornerShape(28.dp)
        else -> default
    }

    companion object {
        val shapeNames = listOf("Default", "Pill", "Rounded square", "Sharp", "Soft")

        private const val FILE = "kvx_searchbar"
        private var rev by mutableIntStateOf(0)
        private var listener: SharedPreferences.OnSharedPreferenceChangeListener? = null

        fun sp(c: Context): SharedPreferences = c.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

        @Composable
        fun current(): KvxSearchBarStyle {
            val c = LocalContext.current
            val sp = remember { sp(c).also { s ->
                if (listener == null) {
                    listener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> rev++ }
                    s.registerOnSharedPreferenceChangeListener(listener)
                }
            } }
            @Suppress("UNUSED_EXPRESSION") rev
            return KvxSearchBarStyle(
                shape = sp.getInt("shape", 0),
                heightDp = sp.getInt("height", 48),
                placeholder = sp.getString("placeholder", "") ?: "",
                showIcon = sp.getBoolean("icon", true),
                bgAlphaPct = sp.getInt("bgAlpha", -1),
                borderDp = sp.getInt("border", 0),
                borderAccent = sp.getBoolean("borderAccent", true),
                textScalePct = sp.getInt("textScale", 100),
                bgColor = sp.getInt("cBg", 0),
                textColor = sp.getInt("cText", 0),
                iconColor = sp.getInt("cIcon", 0),
                borderColor = sp.getInt("cBorder", 0),
            )
        }
    }
}
