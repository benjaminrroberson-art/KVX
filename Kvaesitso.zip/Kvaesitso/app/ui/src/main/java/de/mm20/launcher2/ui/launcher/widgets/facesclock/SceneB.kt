package de.mm20.launcher2.ui.launcher.widgets.facesclock

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

// ---------------------------------------------------------------- Lava lamp

internal class LavaScene(c: Context) : Scene(c) {
    override val needsAudio = true
    override val needsTilt = true

    private class Blob(var x: Float, var y: Float, val r: Float) {
        var vy = 0f
        var vx = 0f
        var temp = 0.5f
    }

    private val blobs = ArrayList<Blob>()
    private var n = -1
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fieldP = Paint(Paint.FILTER_BITMAP_FLAG)
    private var bmp: Bitmap? = null
    private var bc: Canvas? = null
    private val unit = RadialGradient(0f, 0f, 1f, intArrayOf(0xFFFFFFFF.toInt(), 0x99FFFFFF.toInt(), 0x00FFFFFF), floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP)
    private val gp = Paint(Paint.ANTI_ALIAS_FLAG).apply { shader = unit }
    private val m = Matrix()
    private val glass = Path()
    private val rf = RectF()

    private fun rebuild(e: SceneEnv) {
        blobs.clear()
        n = e.amount
        for (i in 0 until n + 3) {
            blobs.add(Blob(e.rr(0.25f, 0.75f), e.rr(0.1f, 0.95f), e.rr(0.1f, 0.19f)).also { it.temp = e.rf() })
        }
    }

    override fun draw(c: Canvas, e: SceneEnv) {
        val w = e.w
        val h = e.h
        val dp = e.dp
        if (n != e.amount) rebuild(e)
        val wax = if (e.useColor) e.custom else if (e.level > 0.02f && e.dance) e.accent else 0xFFFF5A36.toInt()
        val liquid = mixC(wax, 0xFF0A0610.toInt(), 0.82f)
        // background
        p.shader = LinearGradient(0f, 0f, 0f, h, mixC(liquid, Color.BLACK, 0.6f), mixC(liquid, Color.BLACK, 0.85f), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, p)
        p.shader = null
        val lh = h * 0.94f
        val bw = min(w * 0.9f, lh * 0.55f)
        val cx = w / 2f
        val top = h * 0.03f
        val bot = top + lh
        val gTop = top + lh * 0.08f
        val gBot = bot - lh * 0.1f
        val topW = bw * 0.38f
        val botW = bw * 0.62f
        // glow behind
        p.shader = RadialGradient(cx, (gTop + gBot) / 2f, max(w, h) * 0.8f, alC(wax, 0.28f + e.level * 0.2f), 0x00000000, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, p)
        p.shader = null
        glass.reset()
        glass.moveTo(cx - topW / 2f, gTop)
        glass.lineTo(cx + topW / 2f, gTop)
        glass.quadTo(cx + botW * 0.42f, (gTop + gBot) / 2f, cx + botW / 2f, gBot)
        glass.lineTo(cx - botW / 2f, gBot)
        glass.quadTo(cx - botW * 0.42f, (gTop + gBot) / 2f, cx - topW / 2f, gTop)
        glass.close()
        // liquid
        p.shader = LinearGradient(0f, gTop, 0f, gBot, mixC(liquid, wax, 0.12f), mixC(liquid, wax, 0.4f), Shader.TileMode.CLAMP)
        c.drawPath(glass, p)
        p.shader = null
        // physics
        val gw = botW
        val gh = gBot - gTop
        val heatBoost = 1f + (if (e.dance) e.level * 3f else 0f)
        for (b in blobs) {
            b.temp += ((if (b.y > 0.82f) 0.9f else if (b.y < 0.18f) -0.9f else -0.08f) * heatBoost) * e.dt * 0.35f
            b.temp = b.temp.coerceIn(0f, 1f)
            b.vy += ((0.5f - b.temp) * 0.28f - b.vy * 0.5f) * e.dt * 2f
            b.vx += ((0.5f - b.x) * 0.05f + e.tx * 0.03f - b.vx * 0.6f) * e.dt * 2f
            if (e.dance && e.beat > 0.5f) b.vy += (e.rf() - 0.6f) * 0.12f * e.beat
            b.x += b.vx * e.dt
            b.y += b.vy * e.dt
            b.y = b.y.coerceIn(0.05f, 1.02f)
            b.x = b.x.coerceIn(0.2f, 0.8f)
        }
        // metaball field
        val lw = max(24, (gw / 3f).toInt())
        val lhh = max(40, (gh / 3f).toInt())
        var bm = bmp
        if (bm == null || bm.width != lw || bm.height != lhh) {
            bm = Bitmap.createBitmap(lw, lhh, Bitmap.Config.ARGB_8888)
            bmp = bm
            bc = Canvas(bm)
        }
        val bcv = bc ?: return
        bm.eraseColor(0)
        for (b in blobs) {
            val R = b.r * lw * 2.4f
            m.reset(); m.setScale(R, R); m.postTranslate(b.x * lw, b.y * lhh)
            unit.setLocalMatrix(m)
            bcv.drawCircle(b.x * lw, b.y * lhh, R, gp)
        }
        // pool
        m.reset(); m.setScale(lw * 0.55f, lhh * 0.16f); m.postTranslate(lw * 0.5f, lhh * 1.03f)
        unit.setLocalMatrix(m)
        bcv.drawOval(lw * -0.05f, lhh * 0.85f, lw * 1.05f, lhh * 1.2f, gp)
        val k = 9f
        val col = mixC(wax, Color.WHITE, 0.15f)
        val cm = ColorMatrix(floatArrayOf(
            0f, 0f, 0f, 0f, Color.red(col).toFloat(),
            0f, 0f, 0f, 0f, Color.green(col).toFloat(),
            0f, 0f, 0f, 0f, Color.blue(col).toFloat(),
            0f, 0f, 0f, k, -k * 0.5f * 255f,
        ))
        fieldP.colorFilter = ColorMatrixColorFilter(cm)
        c.save()
        c.clipPath(glass)
        rf.set(cx - botW / 2f, gTop, cx + botW / 2f, gBot)
        c.drawBitmap(bm, null, rf, fieldP)
        // glass shine
        p.color = alC(Color.WHITE, 0.1f)
        c.drawRect(cx - botW * 0.38f, gTop, cx - botW * 0.30f, gBot, p)
        c.restore()
        // caps
        p.color = 0xFF2A2A30.toInt()
        c.drawRoundRect(cx - topW * 0.6f, top, cx + topW * 0.6f, gTop + 2f * dp, 6f * dp, 6f * dp, p)
        val cap = Path()
        cap.moveTo(cx - botW / 2f - 2f * dp, gBot)
        cap.lineTo(cx + botW / 2f + 2f * dp, gBot)
        cap.lineTo(cx + botW * 0.62f, bot)
        cap.lineTo(cx - botW * 0.62f, bot)
        cap.close()
        p.color = 0xFF2A2A30.toInt()
        c.drawPath(cap, p)
        p.color = alC(wax, 0.55f)
        c.drawRect(cx - botW / 2f, gBot, cx + botW / 2f, gBot + 3f * dp, p)
    }
}

// ---------------------------------------------------------------- Planetarium

internal class PlanetScene(c: Context) : Scene(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rf = RectF()
    private var offsetMs = 0.0

    // name, RA hours, Dec degrees, magnitude-ish size
    private val named = arrayOf(
        doubleArrayOf(6.752, -16.716, 3.2), doubleArrayOf(5.919, 7.407, 2.4), doubleArrayOf(5.242, -8.202, 2.6),
        doubleArrayOf(18.616, 38.784, 2.8), doubleArrayOf(14.261, 19.182, 2.8), doubleArrayOf(5.278, 45.998, 2.6),
        doubleArrayOf(2.530, 89.264, 2.2), doubleArrayOf(19.846, 8.868, 2.3), doubleArrayOf(20.690, 45.280, 2.3),
        doubleArrayOf(4.599, 16.509, 2.3), doubleArrayOf(16.490, -26.432, 2.4), doubleArrayOf(13.420, -11.161, 2.3),
        doubleArrayOf(7.655, 5.225, 2.4), doubleArrayOf(10.140, 11.967, 2.0), doubleArrayOf(22.961, -29.622, 2.2),
        doubleArrayOf(7.755, 28.026, 2.3),
    )
    private val dipper = arrayOf(
        doubleArrayOf(11.062, 61.751), doubleArrayOf(11.031, 56.382), doubleArrayOf(11.897, 53.695), doubleArrayOf(12.257, 57.033),
        doubleArrayOf(12.900, 55.960), doubleArrayOf(13.399, 54.925), doubleArrayOf(13.792, 49.313),
    )
    private val orion = arrayOf(
        doubleArrayOf(5.919, 7.407), doubleArrayOf(5.679, -1.943), doubleArrayOf(5.603, -1.202), doubleArrayOf(5.533, -0.299), doubleArrayOf(5.242, -8.202),
    )
    private val cass = arrayOf(
        doubleArrayOf(0.153, 59.150), doubleArrayOf(0.675, 56.537), doubleArrayOf(0.945, 60.717), doubleArrayOf(1.430, 60.235), doubleArrayOf(1.907, 63.670),
    )
    private val fr = java.util.Random(21)
    private val faintRa = DoubleArray(380) { fr.nextDouble() * 24.0 }
    private val faintDec = DoubleArray(380) { Math.toDegrees(asin(fr.nextDouble() * 2 - 1)) }
    private val faintMag = FloatArray(380) { 0.4f + fr.nextFloat() * 0.9f }

    private class El(val n0: Double, val n1: Double, val i0: Double, val i1: Double, val w0: Double, val w1: Double, val a: Double, val e0: Double, val e1: Double, val m0: Double, val m1: Double)

    private val sunEl = El(0.0, 0.0, 0.0, 0.0, 282.9404, 4.70935E-5, 1.0, 0.016709, -1.151E-9, 356.0470, 0.9856002585)
    private val planets = arrayOf(
        Triple("Mercury", El(48.3313, 3.24587E-5, 7.0047, 5.00E-8, 29.1241, 1.01444E-5, 0.387098, 0.205635, 5.59E-10, 168.6562, 4.0923344368), 0xFFC9B79C.toInt()),
        Triple("Venus", El(76.6799, 2.46590E-5, 3.3946, 2.75E-8, 54.8910, 1.38374E-5, 0.723330, 0.006773, -1.302E-9, 48.0052, 1.6021302244), 0xFFFFF2C4.toInt()),
        Triple("Mars", El(49.5574, 2.11081E-5, 1.8497, -1.78E-8, 286.5016, 2.92961E-5, 1.523688, 0.093405, 2.516E-9, 18.6021, 0.5240207766), 0xFFFF8A5C.toInt()),
        Triple("Jupiter", El(100.4542, 2.76854E-5, 1.3030, -1.557E-7, 273.8777, 1.64505E-5, 5.20256, 0.048498, 4.469E-9, 19.8950, 0.0830853001), 0xFFF2D9B0.toInt()),
        Triple("Saturn", El(113.6634, 2.38980E-5, 2.4886, -1.081E-7, 339.3939, 2.97661E-5, 9.55475, 0.055546, -9.499E-9, 316.9670, 0.0334442282), 0xFFE8D69A.toInt()),
    )

    private fun rad(d: Double) = d * PI / 180.0

    /** Heliocentric ecliptic x,y,z (for the sun element set this is the sun's geocentric position). */
    private fun pos(el: El, d: Double): DoubleArray {
        val N = rad(el.n0 + el.n1 * d)
        val i = rad(el.i0 + el.i1 * d)
        val w = rad(el.w0 + el.w1 * d)
        val ecc = el.e0 + el.e1 * d
        val M = rad((el.m0 + el.m1 * d) % 360.0)
        var E = M + ecc * sin(M) * (1 + ecc * cos(M))
        for (k in 0 until 6) E -= (E - ecc * sin(E) - M) / (1 - ecc * cos(E))
        val xv = el.a * (cos(E) - ecc)
        val yv = el.a * sqrt(1 - ecc * ecc) * sin(E)
        val v = atan2(yv, xv)
        val r = hypot(xv, yv)
        val xh = r * (cos(N) * cos(v + w) - sin(N) * sin(v + w) * cos(i))
        val yh = r * (sin(N) * cos(v + w) + cos(N) * sin(v + w) * cos(i))
        val zh = r * sin(v + w) * sin(i)
        return doubleArrayOf(xh, yh, zh)
    }

    private fun raDec(x: Double, y: Double, z: Double, d: Double): DoubleArray {
        val ecl = rad(23.4393 - 3.563E-7 * d)
        val yq = y * cos(ecl) - z * sin(ecl)
        val zq = y * sin(ecl) + z * cos(ecl)
        return doubleArrayOf(Math.toDegrees(atan2(yq, x)) / 15.0, Math.toDegrees(atan2(zq, hypot(x, yq))))
    }

    private var lst = 0.0
    private var latR = 0.0
    private var cx = 0f
    private var cy = 0f
    private var R = 1f

    /** Returns x,y,alt(deg) for RA hours / Dec degrees. */
    private fun project(raH: Double, decDeg: Double, out: DoubleArray) {
        val H = rad(lst - raH * 15.0)
        val dec = rad(decDeg)
        val sinAlt = sin(latR) * sin(dec) + cos(latR) * cos(dec) * cos(H)
        val alt = asin(sinAlt.coerceIn(-1.0, 1.0))
        val az = atan2(-cos(dec) * sin(H), sin(dec) * cos(latR) - cos(dec) * cos(H) * sin(latR))
        val rr = (90.0 - Math.toDegrees(alt)) / 90.0 * R
        out[0] = cx - rr * sin(az)
        out[1] = cy - rr * cos(az)
        out[2] = Math.toDegrees(alt)
    }

    override fun draw(c: Canvas, e: SceneEnv) {
        val w = e.w
        val h = e.h
        val dp = e.dp
        val lapse = if (e.amount <= 1) 1.0 else Math.pow(3.0, (e.amount - 1).toDouble())
        offsetMs += e.dt / max(0.01f, e.speed) * 1000.0 * (lapse - 1.0) * e.speed
        val nowMs = System.currentTimeMillis() + offsetMs.toLong()
        val jd = nowMs / 86400000.0 + 2440587.5
        val d = jd - 2451543.5
        val d2000 = jd - 2451545.0
        val lat = if (ClockEnv.lat.isNaN()) 36.16 else ClockEnv.lat
        val lon = if (ClockEnv.lon.isNaN()) -86.78 else ClockEnv.lon
        val gmst = (280.46061837 + 360.98564736629 * d2000) % 360.0
        lst = ((gmst + lon) % 360.0 + 360.0) % 360.0
        latR = rad(lat)
        cx = w / 2f
        cy = h / 2f
        R = min(w, h) / 2f - 14f * dp
        val tmp = DoubleArray(3)
        // sun
        val sg = pos(sunEl, d)
        val sun = raDec(sg[0], sg[1], sg[2], d)
        project(sun[0], sun[1], tmp)
        val sunAlt = tmp[2]
        val sunX = tmp[0].toFloat()
        val sunY = tmp[1].toFloat()
        val bright = smooth(-10f, 4f, sunAlt.toFloat())
        // backdrop
        p.color = 0xFF04060D.toInt()
        c.drawRect(0f, 0f, w, h, p)
        val zen = mixC(0xFF03051A.toInt(), 0xFF3F86D6.toInt(), bright)
        val hor = mixC(0xFF121B3D.toInt(), mixC(0xFFB6DDF7.toInt(), 0xFFFFB27A.toInt(), (1f - bright) * 0.5f * smooth(-14f, 0f, sunAlt.toFloat())), bright.coerceAtLeast(smooth(-14f, 0f, sunAlt.toFloat()) * 0.5f))
        p.shader = RadialGradient(cx, cy, R, zen, hor, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, R, p)
        p.shader = null
        c.save()
        path.reset(); path.addCircle(cx, cy, R, Path.Direction.CW)
        c.clipPath(path)
        val starA = (1f - bright)
        val tint = if (e.useColor) e.custom else Color.WHITE
        if (starA > 0.02f) {
            for (i in faintRa.indices) {
                project(faintRa[i], faintDec[i], tmp)
                if (tmp[2] <= 0.0) continue
                p.color = alC(tint, starA * (0.35f + 0.4f * faintMag[i] * 0.5f))
                c.drawCircle(tmp[0].toFloat(), tmp[1].toFloat(), faintMag[i] * 0.9f * dp, p)
            }
            fun line(pts: Array<DoubleArray>) {
                path.reset()
                var started = false
                for (q in pts) {
                    project(q[0], q[1], tmp)
                    if (tmp[2] < -2.0) { started = false; continue }
                    if (!started) { path.moveTo(tmp[0].toFloat(), tmp[1].toFloat()); started = true } else path.lineTo(tmp[0].toFloat(), tmp[1].toFloat())
                }
                p.style = Paint.Style.STROKE
                p.strokeWidth = 0.8f * dp
                p.color = alC(0xFF9DB7FF.toInt(), starA * 0.35f)
                c.drawPath(path, p)
                p.style = Paint.Style.FILL
            }
            line(dipper); line(orion); line(cass)
            for (s in named) {
                project(s[0], s[1], tmp)
                if (tmp[2] <= 0.0) continue
                p.color = alC(tint, starA)
                c.drawCircle(tmp[0].toFloat(), tmp[1].toFloat(), s[2].toFloat() * 0.8f * dp, p)
            }
            for (q in dipper + orion + cass) {
                project(q[0], q[1], tmp)
                if (tmp[2] <= 0.0) continue
                p.color = alC(tint, starA)
                c.drawCircle(tmp[0].toFloat(), tmp[1].toFloat(), 1.8f * dp, p)
            }
        }
        // planets
        p.textSize = 9f * dp
        for ((name, el, col) in planets) {
            val ph = pos(el, d)
            val g = raDec(ph[0] + sg[0], ph[1] + sg[1], ph[2] + sg[2], d)
            project(g[0], g[1], tmp)
            if (tmp[2] <= 0.0) continue
            val a = max(starA, 0.0f).coerceAtLeast(if (name == "Venus" || name == "Jupiter") 0.4f * (1f - bright * 0.6f) else 0f)
            if (a < 0.05f) continue
            p.shader = RadialGradient(tmp[0].toFloat(), tmp[1].toFloat(), 8f * dp, alC(col, a * 0.5f), 0x00000000, Shader.TileMode.CLAMP)
            c.drawCircle(tmp[0].toFloat(), tmp[1].toFloat(), 8f * dp, p)
            p.shader = null
            p.color = alC(col, a)
            c.drawCircle(tmp[0].toFloat(), tmp[1].toFloat(), 2.6f * dp, p)
            p.color = alC(Color.WHITE, a * 0.7f)
            c.drawText(name, tmp[0].toFloat() + 5f * dp, tmp[1].toFloat() - 4f * dp, p)
        }
        // moon
        val dm = d2000
        val mlon = rad(218.316 + 13.176396 * dm + 6.289 * sin(rad(134.963 + 13.064993 * dm)))
        val mlat = rad(5.128 * sin(rad(93.272 + 13.229350 * dm)))
        val mx = cos(mlat) * cos(mlon)
        val my = cos(mlat) * sin(mlon)
        val mz = sin(mlat)
        val md = raDec(mx, my, mz, d)
        project(md[0], md[1], tmp)
        val sunLon = atan2(sg[1], sg[0])
        val elong = mlon - sunLon
        if (tmp[2] > -3.0) {
            drawMoon(c, tmp[0].toFloat(), tmp[1].toFloat(), 8.5f * dp, elong, 1f - bright * 0.35f, dp)
        }
        // sun
        if (sunAlt > -4.0) {
            p.shader = RadialGradient(sunX, sunY, 40f * dp, alC(0xFFFFE08A.toInt(), 0.7f), 0x00000000, Shader.TileMode.CLAMP)
            c.drawCircle(sunX, sunY, 40f * dp, p)
            p.shader = null
            p.color = 0xFFFFF1B8.toInt()
            c.drawCircle(sunX, sunY, 6f * dp, p)
        }
        c.restore()
        // horizon ring and compass
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.5f * dp
        p.color = alC(Color.WHITE, 0.35f)
        c.drawCircle(cx, cy, R, p)
        p.style = Paint.Style.FILL
        p.textSize = 11f * dp
        p.color = alC(Color.WHITE, 0.8f)
        p.textAlign = Paint.Align.CENTER
        c.drawText("N", cx, cy - R - 3f * dp, p)
        c.drawText("S", cx, cy + R + 11f * dp, p)
        c.drawText("E", cx - R - 8f * dp, cy + 4f * dp, p)
        c.drawText("W", cx + R + 8f * dp, cy + 4f * dp, p)
        p.textAlign = Paint.Align.LEFT
        if (lapse > 1.0) {
            p.textSize = 10f * dp
            p.color = alC(Color.WHITE, 0.7f)
            val t = java.time.Instant.ofEpochMilli(nowMs).atZone(java.time.ZoneId.systemDefault())
            c.drawText(t.format(java.time.format.DateTimeFormatter.ofPattern("MMM d HH:mm")), 10f * dp, h - 8f * dp, p)
        }
        if (ClockEnv.lat.isNaN()) {
            p.textSize = 9f * dp
            p.color = alC(Color.WHITE, 0.55f)
            c.drawText("Set your place in Widgets settings", 10f * dp, 14f * dp, p)
        }
    }

    private fun drawMoon(c: Canvas, x: Float, y: Float, r: Float, elong: Double, a: Float, dp: Float) {
        val ce = cos(elong).toFloat()
        val waxing = sin(elong) > 0
        p.shader = RadialGradient(x, y, r * 3.2f, alC(0xFFE8EDF7.toInt(), 0.35f * a), 0x00000000, Shader.TileMode.CLAMP)
        c.drawCircle(x, y, r * 3.2f, p)
        p.shader = null
        p.color = alC(0xFF2B3140.toInt(), a)
        c.drawCircle(x, y, r, p)
        c.save()
        if (!waxing) c.scale(-1f, 1f, x, y)
        val lit = Path()
        lit.moveTo(x, y - r)
        rf.set(x - r, y - r, x + r, y + r)
        lit.arcTo(rf, -90f, 180f)
        val xr = max(0.001f, r * abs(ce))
        rf.set(x - xr, y - r, x + xr, y + r)
        lit.arcTo(rf, 90f, if (ce > 0f) -180f else 180f)
        lit.close()
        p.color = alC(0xFFF4F1E4.toInt(), a)
        c.drawPath(lit, p)
        c.restore()
    }
}

// ---------------------------------------------------------------- Koi pond

internal class KoiScene(c: Context) : Scene(c) {
    override val grabs = true
    override val needsAudio = true

    private class Koi(var x: Float, var y: Float, val pat: Int, val len: Float) {
        var ang = 0f
        var speed = 0f
        var tx = x
        var ty = y
        var wait = 0f
        val sx = FloatArray(9) { x }
        val sy = FloatArray(9) { y }
        var ph = 0f
    }

    private class Ripple(val x: Float, val y: Float) {
        var r = 0f
        var a = 0.6f
    }

    private val fish = ArrayList<Koi>()
    private val ripples = ArrayList<Ripple>()
    private var n = -1
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private var fx = -1f
    private var fy = -1f
    private var follow = 0f
    private var amb = 0f
    private var lastBeat = 0f
    private val pads = floatArrayOf(0.15f, 0.3f, 0.8f, 0.6f, 0.9f, 0.18f)

    private fun build(e: SceneEnv) {
        fish.clear()
        n = e.amount
        val cnt = (e.amount / 2 + 2).coerceIn(2, 7)
        for (i in 0 until cnt) {
            val k = Koi(e.rr(0.15f, 0.85f) * e.w, e.rr(0.2f, 0.8f) * e.h, i % 4, e.rr(11f, 15f) * e.dp)
            k.ang = e.rr(0f, 6.28f)
            for (j in 0 until 9) { k.sx[j] = k.x - cos(k.ang) * j * k.len * 0.45f; k.sy[j] = k.y - sin(k.ang) * j * k.len * 0.45f }
            fish.add(k)
        }
    }

    override fun down(x: Float, y: Float, e: SceneEnv) { fx = x; fy = y; follow = 6f; ripples.add(Ripple(x, y)) }
    override fun move(x: Float, y: Float, e: SceneEnv) { fx = x; fy = y; follow = 6f }
    override fun up(x: Float, y: Float, e: SceneEnv, tap: Boolean) { follow = 3f; if (tap) ripples.add(Ripple(x, y)) }

    override fun draw(c: Canvas, e: SceneEnv) {
        val w = e.w
        val h = e.h
        val dp = e.dp
        if (n != e.amount) build(e)
        val day = e.day
        p.shader = LinearGradient(0f, 0f, w, h, mixC(0xFF06222B.toInt(), 0xFF2E8B8F.toInt(), day), mixC(0xFF020E12.toInt(), 0xFF135A66.toInt(), day), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, p)
        p.shader = null
        // caustics
        for (i in 0 until 6) {
            val cx = w * (0.5f + 0.45f * sin(e.t * 0.2f + i * 1.7f))
            val cy = h * (0.5f + 0.42f * cos(e.t * 0.17f + i * 2.3f))
            p.shader = RadialGradient(cx, cy, 60f * dp, alC(Color.WHITE, 0.07f * (0.3f + day)), 0x00000000, Shader.TileMode.CLAMP)
            c.drawCircle(cx, cy, 60f * dp, p)
        }
        p.shader = null
        // ambient ripples
        amb -= e.dt
        val hit = e.dance && e.beat > 0.85f && lastBeat <= 0.85f
        lastBeat = e.beat
        if (amb <= 0f || hit) { amb = e.rr(2f, 6f); ripples.add(Ripple(e.rr(0.1f, 0.9f) * w, e.rr(0.1f, 0.9f) * h)) }
        follow = max(0f, follow - e.dt)
        // koi
        val boost = 1f + (if (e.dance) e.level * 1.6f else 0f)
        for (k in fish) {
            if (follow > 0f && fx >= 0f) { k.tx = fx; k.ty = fy }
            else {
                k.wait -= e.dt
                if (k.wait <= 0f || hypot(k.tx - k.x, k.ty - k.y) < 24f * dp) {
                    k.tx = e.rr(0.08f, 0.92f) * w; k.ty = e.rr(0.12f, 0.88f) * h; k.wait = e.rr(3f, 8f)
                }
            }
            val want = atan2(k.ty - k.y, k.tx - k.x)
            var da = want - k.ang
            while (da > PI) da -= (2 * PI).toFloat()
            while (da < -PI) da += (2 * PI).toFloat()
            k.ang += da.coerceIn(-1.4f, 1.4f) * min(1f, e.dt * 2.2f)
            val dist = hypot(k.tx - k.x, k.ty - k.y)
            val spd = (if (dist < 30f * dp && follow > 0f) 10f else 34f) * dp * boost
            k.speed += (spd - k.speed) * min(1f, e.dt * 1.5f)
            k.x += cos(k.ang) * k.speed * e.dt
            k.y += sin(k.ang) * k.speed * e.dt
            k.x = k.x.coerceIn(8f * dp, w - 8f * dp)
            k.y = k.y.coerceIn(8f * dp, h - 8f * dp)
            k.ph += e.dt * (2.5f + k.speed / dp * 0.08f)
            k.sx[0] = k.x; k.sy[0] = k.y
            for (j in 1 until 9) {
                val dx = k.sx[j] - k.sx[j - 1]
                val dy = k.sy[j] - k.sy[j - 1]
                val d = max(0.001f, hypot(dx, dy))
                val lenSeg = k.len * 0.45f
                val wob = sin(k.ph * 3f - j * 0.7f) * 0.18f * (j / 8f) * k.len * 0.2f
                k.sx[j] = k.sx[j - 1] + dx / d * lenSeg - dy / d * wob
                k.sy[j] = k.sy[j - 1] + dy / d * lenSeg + dx / d * wob
            }
            drawKoi(c, k, e)
        }
        // lily pads
        for (i in 0 until 3) {
            val px = pads[i * 2] * w
            val py = pads[(i * 2 + 1) % pads.size] * h
            val bob = sin(e.t * 0.8f + i) * 1.2f * dp
            p.color = mixC(0xFF0F3A22.toInt(), 0xFF3C9A52.toInt(), 0.3f + 0.7f * day)
            c.drawCircle(px, py + bob, 16f * dp, p)
            p.color = alC(0xFF03140A.toInt(), 0.45f)
            c.drawLine(px, py + bob, px + 16f * dp, py + bob - 3f * dp, p)
            if (i == 1) {
                p.color = 0xFFFF9FC0.toInt()
                for (a in 0 until 6) c.drawCircle(px + cos(a * 1.047f) * 5f * dp, py + bob + sin(a * 1.047f) * 5f * dp, 3.4f * dp, p)
                p.color = 0xFFFFE27A.toInt()
                c.drawCircle(px, py + bob, 2.4f * dp, p)
            }
        }
        // ripples
        val ri = ripples.iterator()
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.3f * dp
        while (ri.hasNext()) {
            val r = ri.next()
            r.r += e.dt * 38f * dp
            r.a -= e.dt * 0.28f
            if (r.a <= 0f) { ri.remove(); continue }
            p.color = alC(Color.WHITE, r.a * 0.6f)
            c.drawCircle(r.x, r.y, r.r, p)
            p.color = alC(Color.WHITE, r.a * 0.3f)
            c.drawCircle(r.x, r.y, r.r * 0.7f, p)
        }
        p.style = Paint.Style.FILL
        if (day < 0.99f) { p.color = alC(0xFF000814.toInt(), (1f - day) * 0.25f); c.drawRect(0f, 0f, w, h, p) }
    }

    private fun drawKoi(c: Canvas, k: Koi, e: SceneEnv) {
        val dp = e.dp
        val base = when (k.pat) { 0 -> 0xFFFF7A21.toInt(); 1 -> 0xFFF6F2E8.toInt(); 2 -> 0xFFFFC23A.toInt(); else -> 0xFFE8421E.toInt() }
        val spot = when (k.pat) { 0 -> 0xFFF6F2E8.toInt(); 1 -> 0xFFE8421E.toInt(); 2 -> 0xFFF6F2E8.toInt(); else -> 0xFF1C1C1C.toInt() }
        val b = if (e.useColor) mixC(e.custom, Color.WHITE, 0.1f) else base
        val sp = if (e.useColor) mixC(e.custom, Color.WHITE, 0.8f) else spot
        // shadow
        p.color = alC(Color.BLACK, 0.18f)
        for (j in 0 until 9) c.drawCircle(k.sx[j] + 3f * dp, k.sy[j] + 4f * dp, k.len * (0.5f - j * 0.035f), p)
        // tail
        val tx = k.sx[8]
        val ty = k.sy[8]
        val ta = atan2(k.sy[8] - k.sy[6], k.sx[8] - k.sx[6])
        path.reset()
        path.moveTo(tx, ty)
        path.lineTo(tx + cos(ta + 0.5f) * k.len * 1.1f, ty + sin(ta + 0.5f) * k.len * 1.1f)
        path.lineTo(tx + cos(ta - 0.5f) * k.len * 1.1f, ty + sin(ta - 0.5f) * k.len * 1.1f)
        path.close()
        p.color = alC(b, 0.75f)
        c.drawPath(path, p)
        // fins
        val pa = atan2(k.sy[0] - k.sy[2], k.sx[0] - k.sx[2])
        p.color = alC(b, 0.7f)
        for (sgn in intArrayOf(-1, 1)) {
            val fa = pa + sgn * 2.2f
            c.drawCircle(k.sx[2] + cos(fa) * k.len * 0.5f, k.sy[2] + sin(fa) * k.len * 0.5f, k.len * 0.28f, p)
        }
        // body
        for (j in 8 downTo 0) {
            val r = k.len * (0.52f - j * 0.04f + (if (j == 0) 0.04f else 0f))
            p.color = if ((j + k.pat) % 3 == 1) sp else b
            c.drawCircle(k.sx[j], k.sy[j], r, p)
        }
        p.color = alC(Color.BLACK, 0.8f)
        c.drawCircle(k.sx[0] + cos(pa + 0.8f) * k.len * 0.28f, k.sy[0] + sin(pa + 0.8f) * k.len * 0.28f, 1.3f * dp, p)
        c.drawCircle(k.sx[0] + cos(pa - 0.8f) * k.len * 0.28f, k.sy[0] + sin(pa - 0.8f) * k.len * 0.28f, 1.3f * dp, p)
    }
}
