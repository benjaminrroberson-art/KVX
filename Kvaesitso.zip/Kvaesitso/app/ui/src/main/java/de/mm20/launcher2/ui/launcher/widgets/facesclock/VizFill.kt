package de.mm20.launcher2.ui.launcher.widgets.facesclock

import android.content.Context
import android.graphics.Canvas
import android.os.SystemClock
import android.view.View
import android.app.Activity
import android.content.ContextWrapper
import android.content.Intent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.Dp
import de.mm20.launcher2.ui.launcher.widgets.facesclock.np.EqMenu
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import de.mm20.launcher2.ui.component.preferences.ListPreference
import de.mm20.launcher2.ui.component.preferences.SliderPreference
import de.mm20.launcher2.ui.component.preferences.SwitchPreference
import de.mm20.launcher2.ui.launcher.widgets.facesclock.np.CardRenderer
import de.mm20.launcher2.ui.launcher.widgets.facesclock.np.CardView
import de.mm20.launcher2.ui.launcher.widgets.facesclock.np.MediaState
import de.mm20.launcher2.ui.launcher.widgets.facesclock.np.Prefs
import de.mm20.launcher2.widgets.KvxVizWidgetConfig

/** Just the visualizer graphic, filling its box. Shares all drawing code with the Now Playing Card. */
class VizFillView(ctx: Context) : View(ctx) {
    private val prefs = Prefs(ctx)
    private val renderer = CardRenderer(ctx, prefs).apply {
        widgetMode = true
        vizFill = true
        layerMode = 2
        hideArt = true
        hideText = true
    }
    private var lastFrame = 0L
    private val hold = AudioHold(ctx)
    private val gate = ViewGate(this) { vis ->
        hold.set(vis && AudioHold.musicOn(context))
        if (vis) invalidate()
    }
    private val listener: () -> Unit = { invalidate(); gate.poke() }

    fun setConfig(cfg: KvxVizWidgetConfig) {
        val o = prefs.ov
        o.clear()
        if (!cfg.useGlobal) {
            for ((k, v) in cfg.opts) o[k] = if (k == "idleBreath") (v != 0) else v
        }
        o["showProgress"] = false
        o["showControls"] = false
        o["showEqChip"] = false
        o["showCapChip"] = false
        o["corner"] = 0
        invalidate()
    }

    private fun holdAudio(on: Boolean) {
        if (on) hold.set(true) else hold.release()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        MediaState.ensureStarted(context)
        MediaState.addListener(listener)
        gate.start()
        lastFrame = SystemClock.uptimeMillis()
        invalidate()
    }

    override fun onDetachedFromWindow() {
        MediaState.removeListener(listener)
        gate.stop()
        holdAudio(false)
        super.onDetachedFromWindow()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == VISIBLE) invalidate() else if (isAttachedToWindow) holdAudio(false)
    }

    override fun draw(canvas: android.graphics.Canvas) {
        val t0 = System.nanoTime()
        super.draw(canvas)
        WidgetStats.cpu("Visualizer", System.nanoTime() - t0)
    }

    override fun onDraw(canvas: Canvas) {
        val now = SystemClock.uptimeMillis()
        val dt = ((now - lastFrame) / 1000f).coerceIn(0.001f, 0.05f)
        lastFrame = now
        VizAudio.gain = 1f
        VizAudio.fall = prefs.vizFall / 100f
        VizAudio.update(prefs.idleBreath)
        renderer.draw(canvas, width.toFloat(), height.toFloat(), dt)
        if (MediaState.playing || VizAudio.active() || renderer.hasMotion() || prefs.idleBreath) postInvalidateOnAnimation()
    }
}

private fun Context.activity(): Activity? {
    var c: Context? = this
    while (c is ContextWrapper) { if (c is Activity) return c; c = c.baseContext }
    return null
}

/** Small EQ and playback-capture buttons for the corner of a visualizer widget. */
@Composable
fun VizChips(cfg: KvxVizWidgetConfig, modifier: Modifier = Modifier) {
    if (!cfg.showEq && !cfg.showCapture) return
    val view = LocalView.current
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { while (true) { kotlinx.coroutines.delay(500); tick++ } }
    @Suppress("UNUSED_EXPRESSION") tick
    val capOn = CaptureService.running
    val ink = Color.White
    Row(modifier.padding(6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        if (cfg.showEq) Box(
            Modifier.size(32.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.35f)).clickable {
                val a = ctx.activity()
                EqMenu.show(if (a != null) View(a) else view)
            },
            contentAlignment = Alignment.Center,
        ) {
            Canvas(Modifier.size(16.dp)) {
                val w = size.width; val h = size.height
                val xs = floatArrayOf(0.18f, 0.5f, 0.82f)
                val ks = floatArrayOf(0.35f, 0.65f, 0.45f)
                for (i in 0..2) {
                    drawLine(ink, Offset(w * xs[i], h * 0.06f), Offset(w * xs[i], h * 0.94f), 1.6.dp.toPx(), StrokeCap.Round)
                    drawCircle(ink, 2.2.dp.toPx(), Offset(w * xs[i], h * ks[i]))
                }
            }
        }
        if (cfg.showCapture) Box(
            Modifier.size(32.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.35f)).clickable {
                if (CaptureService.running) CaptureService.stop(ctx)
                else try { ctx.startActivity(Intent(ctx, CaptureActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_MULTIPLE_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)) } catch (e: Exception) {}
            },
            contentAlignment = Alignment.Center,
        ) {
            Canvas(Modifier.size(16.dp)) {
                drawCircle(ink, size.width * 0.42f, style = Stroke(1.8.dp.toPx()))
                if (capOn) drawCircle(ink, size.width * 0.22f, style = Fill)
            }
        }
    }
}

/** Visualizer-only widget body. */
@Composable
fun VizFillBody(cfg: KvxVizWidgetConfig) {
    val (granted, ask) = rememberAudioPermission()
    Column(Modifier.fillMaxWidth().padding(start = cfg.padStart.dp, top = cfg.padTop.dp, end = cfg.padEnd.dp, bottom = cfg.padBottom.dp)) {
        Box(Modifier.fillMaxWidth().height(cfg.height.dp)) {
            val ref = remember { arrayOfNulls<android.view.View>(1) }
            AndroidView(factory = { VizFillView(it).also { v -> ref[0] = v; VizWidgetRegistry.track(v) } }, update = { it.setConfig(cfg) }, modifier = Modifier.fillMaxSize().vizVisible(ref))
        }
        if (!granted) TextButton(onClick = ask) { Text("Allow audio access for the visualizer", color = MaterialTheme.colorScheme.primary) }
    }
}

/** The Now Playing Card (same as the bubble's panel) as a widget. Its look comes from the Visualizer settings. */
@Composable
fun CardWidgetBody(cfg: KvxVizWidgetConfig) {
    val (granted, ask) = rememberAudioPermission()
    Column(Modifier.fillMaxWidth().padding(start = cfg.padStart.dp, top = cfg.padTop.dp, end = cfg.padEnd.dp, bottom = cfg.padBottom.dp)) {
        val ref = remember { arrayOfNulls<android.view.View>(1) }
        AndroidView(
            factory = { CardView(it, Prefs(it)).also { v -> ref[0] = v; VizWidgetRegistry.track(v) } },
            update = { it.reload() },
            modifier = Modifier.fillMaxWidth().vizVisible(ref),
        )
        if (!granted) TextButton(onClick = ask) { Text("Allow audio access for the visualizer", color = MaterialTheme.colorScheme.primary) }
    }
}

private val styleItems = listOf("Bars" to 0, "Oscilloscope" to 2, "Filled wave" to 3, "Circular" to 4, "Pulse ring" to 5, "Particles" to 6, "Glow" to 7)

/**
 * The full set of visualizer options. [tp] supplies the current values, [put] stores a change
 * (keys like vizStyle, vizOpacity, vs3_bars). Used by the panel settings and the visualizer-only widget.
 */
@Composable
fun VizOptCore(tp: Prefs, showHeight: Boolean, put: (String, Int) -> Unit) {
    val st = tp.vizStyle.let { if (it == 1) 0 else it }
    fun sput(name: String, v: Int) = put("vs${st}_$name", v)
    fun g(name: String) = tp.sGet(st, name)

    ListPreference(title = "Style", items = styleItems, value = st, onValueChanged = { put("vizStyle", it) })
    ListPreference(title = "Color", items = listOf("Solid" to 0, "Gradient" to 1, "From album art" to 2, "Rainbow" to 3, "Art palette" to 4), value = g("colorMode"), onValueChanged = { sput("colorMode", it) })
    if (g("colorMode") == 0 || g("colorMode") == 1) ColorPreference("Color", g("color")) { sput("color", it) }
    if (g("colorMode") == 1) ColorPreference("Second color", g("color2")) { sput("color2", it) }
    if (st == 0 || st == 4) SliderPreference(title = "Bars", value = g("bars"), min = 8, max = 64, onValueChanged = { sput("bars", it) }, label = { Text("$it") })
    if (st == 0 || st == 2 || st == 3) ListPreference(title = "Direction", items = listOf("Up" to 0, "Down" to 1, "Mirrored" to 2), value = g("vert"), onValueChanged = { sput("vert", it) })
    if (st == 0 || st == 3) ListPreference(title = "Low end", items = listOf("Left" to 0, "Right" to 1, "Centre" to 2, "Edges" to 3), value = g("low"), onValueChanged = { sput("low", it) })
    if (st == 4 || st == 5) SliderPreference(title = "Depth", value = g("depth"), min = 6, max = 80, onValueChanged = { sput("depth", it) }, label = { Text("$it dp") })
    if (st == 0) SwitchPreference(title = "LED segments", value = g("segments") != 0, onValueChanged = { sput("segments", if (it) 1 else 0) })
    if (st == 0) SwitchPreference(title = "Reflection", value = g("reflect") != 0, onValueChanged = { sput("reflect", if (it) 1 else 0) })
    if (st == 2 || st == 3 || st == 4 || st == 5 || st == 7) SwitchPreference(title = "Glow", value = g("glow") != 0, onValueChanged = { sput("glow", if (it) 1 else 0) })
    if (st == 4) SwitchPreference(title = "Slow spin", value = g("spin") != 0, onValueChanged = { sput("spin", if (it) 1 else 0) })
    SliderPreference(title = "Sensitivity", value = g("sens"), min = 0, max = 100, onValueChanged = { sput("sens", it) }, label = { Text("$it%") })
    SliderPreference(title = "Reach", value = g("reach"), min = 10, max = 100, onValueChanged = { sput("reach", it) }, label = { Text("$it%") })
    SliderPreference(title = "Fall speed", value = g("fall"), min = 10, max = 400, onValueChanged = { sput("fall", it) }, label = { Text("$it%") })
    SliderPreference(title = "Opacity", value = tp.vizOpacity, min = 10, max = 100, onValueChanged = { put("vizOpacity", it) }, label = { Text("$it%") })
    if (showHeight && st <= 3) SliderPreference(title = "Strip height", value = tp.vizHeight, min = 24, max = 200, onValueChanged = { put("vizHeight", it) }, label = { Text("$it dp") })
    SwitchPreference(title = "Gentle motion while paused", value = tp.idleBreath, onValueChanged = { put("idleBreath", if (it) 1 else 0) })
}

/** Visualizer options stored as per-widget overrides in [cfg]. */
@Composable
fun VizOptControls(cfg: KvxVizWidgetConfig, onChange: (KvxVizWidgetConfig) -> Unit) {
    val ctx = LocalContext.current
    val tp = remember(cfg.opts, cfg.useGlobal) {
        Prefs(ctx).also { p -> if (!cfg.useGlobal) for ((k, v) in cfg.opts) p.ov[k] = if (k == "idleBreath") (v != 0) else v }
    }
    VizOptCore(tp, false) { k, v -> onChange(cfg.copy(opts = cfg.opts + (k to v))) }
}

@Composable
fun VizFillControls(cfg: KvxVizWidgetConfig, onChange: (KvxVizWidgetConfig) -> Unit) {
    SliderPreference(title = "Height", value = cfg.height, min = 30, max = 400, onValueChanged = { onChange(cfg.copy(height = it)) }, label = { Text("$it dp") })
    SwitchPreference(
        title = "Use the panel's visualizer settings",
        summary = "Follows Settings > Visualizer. Turn off to style this widget on its own.",
        value = cfg.useGlobal,
        onValueChanged = { onChange(cfg.copy(useGlobal = it)) },
    )
    if (!cfg.useGlobal) VizOptControls(cfg, onChange)
}
