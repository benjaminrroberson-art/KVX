package de.mm20.launcher2.ui.launcher.widgets.facesclock

import android.content.Context
import android.graphics.Canvas
import android.os.SystemClock
import android.view.View
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import de.mm20.launcher2.ui.component.preferences.ListPreference
import de.mm20.launcher2.ui.component.preferences.SliderPreference
import de.mm20.launcher2.ui.component.preferences.SwitchPreference
import de.mm20.launcher2.ui.launcher.widgets.facesclock.np.CardRenderer
import de.mm20.launcher2.ui.launcher.widgets.facesclock.np.CardView
import de.mm20.launcher2.ui.launcher.widgets.facesclock.np.MediaState
import de.mm20.launcher2.ui.launcher.widgets.facesclock.np.Prefs
import de.mm20.launcher2.widgets.KvxVizWidgetConfig

/** Just the visualizer graphic, filling its box. Shares all drawing code with the Now Playing Card. */
class VizFillView(ctx: Context) : View(ctx) {
    private val prefs = Prefs(ctx)
    private val renderer = CardRenderer(ctx, prefs).apply {
        widgetMode = true
        vizFill = true
        layerMode = 2
        hideArt = true
        hideText = true
    }
    private var lastFrame = 0L
    private var audioHeld = false
    private val listener: () -> Unit = { invalidate() }

    fun setConfig(cfg: KvxVizWidgetConfig) {
        val o = prefs.ov
        o.clear()
        if (!cfg.useGlobal) {
            for ((k, v) in cfg.opts) o[k] = if (k == "idleBreath") (v != 0) else v
        }
        o["showProgress"] = false
        o["showControls"] = false
        o["showEqChip"] = false
        o["showCapChip"] = false
        o["corner"] = 0
        invalidate()
    }

    private fun holdAudio(on: Boolean) {
        if (on && !audioHeld) { audioHeld = true; VizAudio.start(context) }
        else if (!on && audioHeld) { audioHeld = false; VizAudio.stop() }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        MediaState.ensureStarted(context)
        MediaState.addListener(listener)
        holdAudio(windowVisibility == VISIBLE)
        lastFrame = SystemClock.uptimeMillis()
        invalidate()
    }

    override fun onDetachedFromWindow() {
        MediaState.removeListener(listener)
        holdAudio(false)
        super.onDetachedFromWindow()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (isAttachedToWindow) holdAudio(visibility == VISIBLE)
        if (visibility == VISIBLE) invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val now = SystemClock.uptimeMillis()
        val dt = ((now - lastFrame) / 1000f).coerceIn(0.001f, 0.05f)
        lastFrame = now
        VizAudio.gain = 1f
        VizAudio.fall = prefs.vizFall / 100f
        VizAudio.update(prefs.idleBreath)
        renderer.draw(canvas, width.toFloat(), height.toFloat(), dt)
        if (MediaState.playing || VizAudio.active() || renderer.hasMotion() || prefs.idleBreath) postInvalidateOnAnimation()
    }
}

/** Visualizer-only widget body. */
@Composable
fun VizFillBody(cfg: KvxVizWidgetConfig) {
    val (granted, ask) = rememberAudioPermission()
    Column(Modifier.fillMaxWidth().padding(start = cfg.padStart.dp, top = cfg.padTop.dp, end = cfg.padEnd.dp, bottom = cfg.padBottom.dp)) {
        Box(Modifier.fillMaxWidth().height(cfg.height.dp)) {
            AndroidView(factory = { VizFillView(it) }, update = { it.setConfig(cfg) }, modifier = Modifier.fillMaxSize())
        }
        if (!granted) TextButton(onClick = ask) { Text("Allow audio access for the visualizer", color = MaterialTheme.colorScheme.primary) }
    }
}

/** The Now Playing Card (same as the bubble's panel) as a widget. Its look comes from the Visualizer settings. */
@Composable
fun CardWidgetBody(cfg: KvxVizWidgetConfig) {
    val (granted, ask) = rememberAudioPermission()
    Column(Modifier.fillMaxWidth().padding(start = cfg.padStart.dp, top = cfg.padTop.dp, end = cfg.padEnd.dp, bottom = cfg.padBottom.dp)) {
        AndroidView(
            factory = { CardView(it, Prefs(it)) },
            update = { it.reload() },
            modifier = Modifier.fillMaxWidth(),
        )
        if (!granted) TextButton(onClick = ask) { Text("Allow audio access for the visualizer", color = MaterialTheme.colorScheme.primary) }
    }
}

private val styleItems = listOf("Bars" to 0, "Oscilloscope" to 2, "Filled wave" to 3, "Circular" to 4, "Pulse ring" to 5, "Particles" to 6, "Glow" to 7)

/** The full set of visualizer options for the visualizer-only widget, stored as overrides in [cfg]. */
@Composable
fun VizOptControls(cfg: KvxVizWidgetConfig, onChange: (KvxVizWidgetConfig) -> Unit) {
    val ctx = LocalContext.current
    val tp = remember(cfg.opts, cfg.useGlobal) {
        Prefs(ctx).also { p -> if (!cfg.useGlobal) for ((k, v) in cfg.opts) p.ov[k] = if (k == "idleBreath") (v != 0) else v }
    }
    val st = tp.vizStyle.let { if (it == 1) 0 else it }
    fun put(k: String, v: Int) = onChange(cfg.copy(opts = cfg.opts + (k to v)))
    fun sput(name: String, v: Int) = put("vs${st}_$name", v)
    fun g(name: String) = tp.sGet(st, name)

    ListPreference(title = "Style", items = styleItems, value = st, onValueChanged = { put("vizStyle", it) })
    ListPreference(title = "Color", items = listOf("Solid" to 0, "Gradient" to 1, "From album art" to 2, "Rainbow" to 3, "Art palette" to 4), value = g("colorMode"), onValueChanged = { sput("colorMode", it) })
    if (g("colorMode") == 0 || g("colorMode") == 1) ColorPreference("Color", g("color")) { sput("color", it) }
    if (g("colorMode") == 1) ColorPreference("Second color", g("color2")) { sput("color2", it) }
    if (st == 0 || st == 4) SliderPreference(title = "Bars", value = g("bars"), min = 8, max = 64, onValueChanged = { sput("bars", it) }, label = { Text("$it") })
    if (st == 0 || st == 2 || st == 3) ListPreference(title = "Direction", items = listOf("Up" to 0, "Down" to 1, "Mirrored" to 2), value = g("vert"), onValueChanged = { sput("vert", it) })
    if (st == 0 || st == 3) ListPreference(title = "Low end", items = listOf("Left" to 0, "Right" to 1, "Centre" to 2, "Edges" to 3), value = g("low"), onValueChanged = { sput("low", it) })
    if (st == 4 || st == 5) SliderPreference(title = "Depth", value = g("depth"), min = 6, max = 80, onValueChanged = { sput("depth", it) }, label = { Text("$it dp") })
    if (st == 0) SwitchPreference(title = "LED segments", value = g("segments") != 0, onValueChanged = { sput("segments", if (it) 1 else 0) })
    if (st == 0) SwitchPreference(title = "Reflection", value = g("reflect") != 0, onValueChanged = { sput("reflect", if (it) 1 else 0) })
    if (st == 2 || st == 4 || st == 5) SwitchPreference(title = "Glow", value = g("glow") != 0, onValueChanged = { sput("glow", if (it) 1 else 0) })
    if (st == 4) SwitchPreference(title = "Slow spin", value = g("spin") != 0, onValueChanged = { sput("spin", if (it) 1 else 0) })
    SliderPreference(title = "Sensitivity", value = g("sens"), min = 0, max = 100, onValueChanged = { sput("sens", it) }, label = { Text("$it%") })
    SliderPreference(title = "Reach", value = g("reach"), min = 10, max = 100, onValueChanged = { sput("reach", it) }, label = { Text("$it%") })
    SliderPreference(title = "Fall speed", value = g("fall"), min = 10, max = 400, onValueChanged = { sput("fall", it) }, label = { Text("$it%") })
    SliderPreference(title = "Opacity", value = tp.vizOpacity, min = 10, max = 100, onValueChanged = { put("vizOpacity", it) }, label = { Text("$it%") })
    SwitchPreference(title = "Gentle motion while paused", value = tp.idleBreath, onValueChanged = { put("idleBreath", if (it) 1 else 0) })
}

@Composable
fun VizFillControls(cfg: KvxVizWidgetConfig, onChange: (KvxVizWidgetConfig) -> Unit) {
    SliderPreference(title = "Height", value = cfg.height, min = 30, max = 400, onValueChanged = { onChange(cfg.copy(height = it)) }, label = { Text("$it dp") })
    SwitchPreference(
        title = "Use the panel's visualizer settings",
        summary = "Follows Settings > Visualizer. Turn off to style this widget on its own.",
        value = cfg.useGlobal,
        onValueChanged = { onChange(cfg.copy(useGlobal = it)) },
    )
    if (!cfg.useGlobal) VizOptControls(cfg, onChange)
}
