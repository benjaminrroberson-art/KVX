package de.mm20.launcher2.ui.settings.services

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.padding
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.navigation3.runtime.NavKey
import de.mm20.launcher2.ui.component.preferences.Preference
import de.mm20.launcher2.ui.component.preferences.PreferenceCategory
import de.mm20.launcher2.ui.component.preferences.PreferenceScreen
import de.mm20.launcher2.ui.component.preferences.SwitchPreference
import de.mm20.launcher2.ui.edge.VolumeService
import de.mm20.launcher2.ui.launcher.widgets.facesclock.BubbleService
import de.mm20.launcher2.ui.launcher.widgets.facesclock.BubbleSettings
import de.mm20.launcher2.ui.launcher.widgets.facesclock.CaptureService
import de.mm20.launcher2.ui.launcher.widgets.facesclock.WidgetStats
import de.mm20.launcher2.ui.launcher.widgets.facesclock.np.EqService
import de.mm20.launcher2.ui.launcher.widgets.facesclock.np.Prefs
import de.mm20.launcher2.ui.panels.PanelPrefs
import de.mm20.launcher2.ui.panels.PanelService
import kotlinx.serialization.Serializable

@Serializable
data object BackgroundServicesRoute : NavKey

private fun cost(name: String): String {
    val a = WidgetStats.snapshot().firstOrNull { it.first == name }?.second ?: return ""
    val m = a.mah()
    return if (m < 0.05) "" else "\nAbout %.1f mAh since the launcher started".format(m)
}

@Composable
fun BackgroundServicesScreen() {
    val ctx = LocalContext.current
    var rev by remember { mutableIntStateOf(0) }
    @Suppress("UNUSED_EXPRESSION") rev
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val o = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) rev++ }
        owner.lifecycle.addObserver(o)
        onDispose { owner.lifecycle.removeObserver(o) }
    }
    val panelRunning = PanelService.instance != null
    val bubbleRunning = BubbleService.running
    val edgeRunning = VolumeService.instance != null
    val eqSet = Prefs(ctx).eqActive
    val capRunning = CaptureService.running
    val runningCount = listOf(panelRunning, bubbleRunning, edgeRunning, capRunning).count { it }

    PreferenceScreen(title = "Background services") {
        item {
            PreferenceCategory("Things that keep running") {
                @Suppress("UNUSED_EXPRESSION") rev
                SwitchPreference(
                    title = "Edge panel",
                    summary = (if (panelRunning) "Running" else "Not running") + ": the handle on the screen edge and its panel. Shows a notification while on." + cost("Edge panel"),
                    value = PanelPrefs.on(ctx),
                    onValueChanged = { PanelPrefs.setB(ctx, "on", it); PanelService.refresh(ctx); rev++ },
                )
                SwitchPreference(
                    title = "Floating music bubble",
                    summary = (if (bubbleRunning) "Running" else "Not running") + ": the draggable bubble that shows what's playing. Shows a notification while on.",
                    value = BubbleSettings.on(ctx),
                    onValueChanged = { BubbleSettings.setOn(ctx, it); BubbleService.refresh(ctx); rev++ },
                )
                Preference(
                    title = "Edge volume light",
                    summary = (if (edgeRunning) "Running" else "Not running") + ": an accessibility service that watches the volume keys and draws the glow. Android only lets you turn it on or off in accessibility settings." + cost("Edge volume light"),
                    onClick = { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) },
                )
                Preference(
                    title = "Equalizer",
                    summary = if (eqSet) "On: an equalizer or bass boost is set, so a small service keeps it applied. Turn the EQ and bass boost off in the Now Playing settings to stop it." else "Off: no equalizer is set, so nothing runs for it.",
                    onClick = {},
                )
                Preference(
                    title = "Audio capture for visualizers",
                    summary = (if (capRunning) "Running. Tap to stop it." else "Not running. It starts only when a visualizer is showing.") + cost("Audio capture service"),
                    onClick = { if (capRunning) { CaptureService.stop(ctx); rev++ } },
                )
            }
        }
        item {
            PreferenceCategory("All at once") {
                @Suppress("UNUSED_EXPRESSION") rev
                Preference(
                    title = "Stop everything I can",
                    summary = "$runningCount running. Turns off the panel, the bubble and audio capture. Your settings stay saved.",
                    onClick = {
                        PanelPrefs.setB(ctx, "on", false); PanelService.refresh(ctx)
                        BubbleSettings.setOn(ctx, false); BubbleService.refresh(ctx)
                        CaptureService.stop(ctx)
                        rev++
                    },
                )
            }
        }
        item {
            Text(
                "Per-service battery figures come from the same estimates as Battery use and only appear once a service has used enough to count.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
            )
        }
    }
}
