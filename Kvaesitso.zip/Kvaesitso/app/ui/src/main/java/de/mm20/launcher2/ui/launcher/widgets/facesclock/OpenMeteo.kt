package de.mm20.launcher2.ui.launcher.widgets.facesclock

import de.mm20.launcher2.weather.DailyForecast
import de.mm20.launcher2.weather.Forecast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class KvxPlace(val name: String, val detail: String, val lat: Double, val lon: Double)

class KvxWeatherData(val hourly: List<Forecast>, val daily: List<DailyForecast>)

/** Weather for a typed-in place from Open-Meteo. No key, no account, no location permission. */
internal object OpenMeteo {
    private fun http(url: String): String? = try {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 12000
        c.readTimeout = 15000
        c.setRequestProperty("User-Agent", "KvaesitsoX/1.0 (Android)")
        if (c.responseCode in 200..299) c.inputStream.bufferedReader().use { it.readText() } else null
    } catch (e: Exception) {
        null
    }

    suspend fun search(q: String): List<KvxPlace> = withContext(Dispatchers.IO) {
        val body = http("https://geocoding-api.open-meteo.com/v1/search?name=${URLEncoder.encode(q, "UTF-8")}&count=8&language=en&format=json")
            ?: return@withContext emptyList()
        try {
            val arr = JSONObject(body).optJSONArray("results") ?: return@withContext emptyList()
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                val detail = listOf(o.optString("admin1"), o.optString("country")).filter { s -> s.isNotBlank() }.joinToString(", ")
                KvxPlace(o.optString("name"), detail, o.getDouble("latitude"), o.getDouble("longitude"))
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun icon(code: Int): Int = when (code) {
        0, 1 -> Forecast.CLEAR
        2 -> Forecast.PARTLY_CLOUDY
        3 -> Forecast.OVERCAST
        45, 48 -> Forecast.FOG
        51, 53, 55, 61, 80 -> Forecast.LIGHT_RAIN
        56, 57, 66, 67 -> Forecast.SLEET
        63, 81 -> Forecast.RAIN
        65, 82 -> Forecast.HEAVY_RAIN
        71, 73, 75, 77, 85, 86 -> Forecast.SNOW
        95 -> Forecast.THUNDERSTORM
        96, 99 -> Forecast.HEAVY_THUNDERSTORM_WITH_RAIN
        else -> Forecast.UNKNOWN
    }

    private fun text(code: Int): String = when (code) {
        0 -> "Clear"; 1 -> "Mostly clear"; 2 -> "Partly cloudy"; 3 -> "Overcast"
        45, 48 -> "Fog"; 51, 53, 55 -> "Drizzle"; 56, 57, 66, 67 -> "Freezing rain"
        61, 80 -> "Light rain"; 63, 81 -> "Rain"; 65, 82 -> "Heavy rain"
        71, 73, 75, 77, 85, 86 -> "Snow"; 95 -> "Thunderstorm"; 96, 99 -> "Thunderstorm with hail"
        else -> "Unknown"
    }

    suspend fun fetch(p: KvxPlace): KvxWeatherData? = withContext(Dispatchers.IO) {
        val url = "https://api.open-meteo.com/v1/forecast?latitude=${p.lat}&longitude=${p.lon}" +
            "&hourly=temperature_2m,weather_code,is_day,relative_humidity_2m,wind_speed_10m,uv_index,precipitation_probability" +
            "&daily=weather_code,temperature_2m_max,temperature_2m_min" +
            "&wind_speed_unit=ms&timeformat=unixtime&timezone=auto&forecast_days=8"
        val body = http(url) ?: return@withContext null
        try {
            val j = JSONObject(body)
            val h = j.getJSONObject("hourly")
            val times = h.getJSONArray("time")
            val now = System.currentTimeMillis()
            val label = p.name
            val hourly = (0 until times.length()).map { i ->
                val code = h.getJSONArray("weather_code").optInt(i)
                Forecast(
                    timestamp = times.getLong(i) * 1000L,
                    temperature = h.getJSONArray("temperature_2m").getDouble(i) + 273.15,
                    humidity = h.getJSONArray("relative_humidity_2m").optDouble(i),
                    icon = icon(code),
                    condition = text(code),
                    windSpeed = h.getJSONArray("wind_speed_10m").optDouble(i),
                    uvIndex = h.getJSONArray("uv_index").optDouble(i),
                    night = h.getJSONArray("is_day").optInt(i) == 0,
                    location = label,
                    provider = "Open-Meteo",
                    providerUrl = "https://open-meteo.com",
                    precipProbability = h.getJSONArray("precipitation_probability").let { if (it.isNull(i)) null else it.getInt(i) },
                    updateTime = now,
                )
            }
            val d = j.getJSONObject("daily")
            val dt = d.getJSONArray("time")
            val daily = (0 until dt.length()).map { i ->
                val start = dt.getLong(i) * 1000L
                DailyForecast(
                    timestamp = start,
                    minTemp = d.getJSONArray("temperature_2m_min").getDouble(i) + 273.15,
                    maxTemp = d.getJSONArray("temperature_2m_max").getDouble(i) + 273.15,
                    hourlyForecasts = hourly.filter { it.timestamp in start until start + 86_400_000L },
                    icon = icon(d.getJSONArray("weather_code").optInt(i)),
                )
            }
            KvxWeatherData(hourly, daily)
        } catch (e: Exception) {
            null
        }
    }
}
