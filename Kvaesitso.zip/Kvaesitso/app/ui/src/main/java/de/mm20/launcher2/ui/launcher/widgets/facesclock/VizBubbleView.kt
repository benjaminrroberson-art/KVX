package de.mm20.launcher2.ui.launcher.widgets.facesclock

import android.content.Context
import android.graphics.Bitmap
import de.mm20.launcher2.widgets.VizConfig
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.ViewConfiguration
import android.view.View
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * The small floating bubble: mini album art with the visualizer around or on it. Tap, long-press
 * and drag are reported to the service, which owns the window.
 */
/** The bubble from the Now Playing Card app, as a plain view: art with the visualizer around or on it. */
class VizBubbleView(context: Context) : View(context) {

    var cfg: VizConfig = VizConfig()
        set(v) { field = v; invalidate() }
    var art: Bitmap? = null
        set(v) { if (field !== v) { field = v; recolor(v) }; invalidate() }
    var playing: Boolean = false
        set(v) { field = v; VizAudio.playing = v; syncAudio(); invalidate() }
    var artDp: Float = 96f
        set(v) { if (field != v) { field = v; requestLayout(); invalidate() } }

    private var accent = 0xFF00E5FF.toInt()
    private var accent2 = 0xFFFF4081.toInt()
    private var palette = intArrayOf(0xFF00E5FF.toInt(), 0xFFFF4081.toInt(), 0xFFFFD740.toInt(), 0xFF69F0AE.toInt())

    private val d = resources.displayMetrics.density
    private val sizePx get() = artDp * d

    /** Room around the artwork for rings, glow and particles. */
    val inset get() = sizePx * 0.34f
    val totalPx get() = (sizePx + 2f * inset).toInt()

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val rect2 = RectF()
    private val path = Path()
    private val artPath = Path()
    private val src = Rect()
    private val rnd = java.util.Random(11)
    private var hue = 0f
    private var rot = 0f
    private var lastFrame = 0L
    private var lastBeat = 0
    private var held = false
    private val rAge = FloatArray(4) { 9f }
    private val pn = 50
    private val px = FloatArray(pn)
    private val py = FloatArray(pn)
    private val pvx = FloatArray(pn)
    private val pvy = FloatArray(pn)
    private val plife = FloatArray(pn)
    private val pmax = FloatArray(pn) { 1f }
    private val phue = FloatArray(pn)
    private var spawnAcc = 0f

    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        setMeasuredDimension(totalPx, totalPx)
    }

    private fun syncAudio() {
        val want = isAttachedToWindow && playing
        if (want && !held) {
            held = true
            VizAudio.start(context)
        } else if (!want && held) {
            held = false
            VizAudio.stop()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        lastFrame = SystemClock.uptimeMillis()
        VizAudio.playing = playing
        syncAudio()
        invalidate()
    }

    override fun onDetachedFromWindow() {
        uiHandler.removeCallbacksAndMessages(null)
        if (held) {
            held = false
            VizAudio.stop()
        }
        super.onDetachedFromWindow()
    }

    private fun gate(v: Float): Float {
        val thr = (100 - cfg.sens).coerceIn(0, 100) / 100f * 0.5f
        return if (thr <= 0f) v else ((v - thr) / (1f - thr)).coerceAtLeast(0f)
    }

    private fun waveGate(level: Float): Float {
        val thr = (100 - cfg.sens).coerceIn(0, 100) / 100f * 0.25f
        return if (thr <= 0f) 1f else ((level - thr * 0.5f) / 0.08f).coerceIn(0f, 1f)
    }

    // ------------------------------------------------------------------ colors

    private fun lerp(a: Int, b: Int, t: Float): Int = Color.argb(
        (Color.alpha(a) + (Color.alpha(b) - Color.alpha(a)) * t).toInt(),
        (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt()
    )

    private fun palette(t: Float): Int {
        val pal = palette
        val n = pal.size
        if (n < 2) return accent
        val x = t.coerceIn(0f, 1f) * n
        val i = x.toInt()
        return lerp(pal[i % n], pal[(i + 1) % n], x - i)
    }

    private fun vizCol(t: Float): Int {
        val tt = t.coerceIn(0f, 1f)
        return when (cfg.colorMode) {
            0 -> cfg.color
            1 -> lerp(cfg.color, cfg.color2, tt)
            2 -> lerp(accent, accent2, tt)
            4 -> palette(tt)
            else -> Color.HSVToColor(floatArrayOf((hue + tt * 300f) % 360f, 0.72f, 1f))
        }
    }

    private fun hGradPaint(x0: Float, x1: Float, alpha: Float) {
        if (cfg.colorMode == 0) {
            p.shader = null
            p.color = withAlpha(cfg.color, alpha)
            return
        }
        val cols = IntArray(9) { vizCol(it / 8f) }
        p.shader = LinearGradient(x0, 0f, x1, 0f, cols, null, Shader.TileMode.CLAMP)
        p.color = Color.argb(al(alpha), 255, 255, 255)
    }

    private fun al(x: Float): Int = (255f * x).toInt().coerceIn(0, 255)

    private fun withAlpha(c: Int, a: Float): Int =
        Color.argb(al(a), Color.red(c), Color.green(c), Color.blue(c))

    // ------------------------------------------------------------------ effects state

    private fun onBeat(style: Int, cx: Float, cy: Float, r: Float) {
        if (style == 5) {
            var idx = 0
            var oldest = -1f
            for (i in rAge.indices) if (rAge[i] > oldest) { oldest = rAge[i]; idx = i }
            rAge[idx] = 0f
        } else if (style == 6) {
            for (i in 0 until 6) spawn(cx, cy, r, 2.2f)
        }
    }

    private fun spawn(cx: Float, cy: Float, r: Float, mul: Float) {
        var idx = -1
        for (i in 0 until pn) if (plife[i] <= 0f) { idx = i; break }
        if (idx < 0) return
        val ang = rnd.nextFloat() * 6.2831855f
        val ca = cos(ang)
        val sa = sin(ang)
        val speed = (14f + rnd.nextFloat() * 34f) * d * mul
        px[idx] = cx + ca * r
        py[idx] = cy + sa * r
        pvx[idx] = ca * speed
        pvy[idx] = sa * speed
        pmax[idx] = 0.6f + rnd.nextFloat() * 0.7f
        plife[idx] = pmax[idx]
        phue[idx] = rnd.nextFloat()
    }

    private fun hasMotion(): Boolean {
        for (a in rAge) if (a < 1.1f) return true
        for (l in plife) if (l > 0f) return true
        return false
    }

    // ------------------------------------------------------------------ draw

    private val smD = FloatArray(VizAudio.N)
    private val smW = FloatArray(VizAudio.W)

    private fun smoothAudio(dt: Float) {
        val fall = cfg.fall.coerceIn(10, 400) / 100f
        val up = 1f - exp(-dt / 0.03f)
        val down = 1f - exp(-dt / (0.18f / fall))
        for (i in 0 until VizAudio.N) {
            val t = VizAudio.disp[i]
            smD[i] += (t - smD[i]) * (if (t > smD[i]) up else down)
        }
        val wk = 1f - exp(-dt / (0.03f / fall.coerceAtLeast(0.2f)))
        for (j in 0 until VizAudio.W) smW[j] += (VizAudio.wave[j] - smW[j]) * wk
    }

    private fun bandS(i: Int, n: Int): Float {
        val a = i * VizAudio.N / n
        val b = max(a + 1, (i + 1) * VizAudio.N / n)
        var s = 0f
        for (k in a until min(b, VizAudio.N)) s += smD[k]
        return s / (min(b, VizAudio.N) - a)
    }

    override fun onDraw(c: Canvas) {
        val now = SystemClock.uptimeMillis()
        val dt = ((now - lastFrame) / 1000f).coerceIn(0.001f, 0.05f)
        lastFrame = now
        val style = if (cfg.style == 1) 0 else cfg.style
        val sens = cfg.reach / 100f
        VizAudio.gain = 1f
        VizAudio.fall = cfg.fall / 100f
        VizAudio.update(false)
        smoothAudio(dt)
        hue = (hue + dt * 20f) % 360f
        if (cfg.spin) rot = (rot + dt * 6f) % 360f

        val cx = totalPx / 2f
        val cy = cx
        var r = sizePx / 2f
        val playing = playing
        val a = cfg.vizOp / 100f

        if (VizAudio.beatCount != lastBeat) {
            lastBeat = VizAudio.beatCount
            onBeat(style, cx, cy, r)
        }
        for (i in rAge.indices) if (rAge[i] < 9f) rAge[i] += dt
        if (style == 6 && playing) {
            spawnAcc += dt * (4f + 40f * gate(VizAudio.level) * sens)
            while (spawnAcc >= 1f) { spawnAcc -= 1f; spawn(cx, cy, r, 1f) }
        }
        for (i in 0 until pn) {
            if (plife[i] <= 0f) continue
            plife[i] -= dt
            px[i] += pvx[i] * dt
            py[i] += pvy[i] * dt
            pvx[i] *= 1f - 0.8f * dt
            pvy[i] *= 1f - 0.8f * dt
        }

        if (style == 5) r *= 1f + 0.06f * VizAudio.beatEnv + 0.03f * VizAudio.level
        val shape = cfg.shape
        val ringR = if (shape == 0) r + 3f * d else r * 1.12f + 3f * d
        val reach = max(4f * d, inset - (ringR - sizePx / 2f) - 2f * d)

        val sig = !VizAudio.noSignal()
        if (sig) when (style) {
            7 -> drawGlow(c, cx, cy, r, a)
            6 -> drawParticles(c, a)
            4 -> drawRing(c, cx, cy, ringR, reach, a)
            5 -> drawPulse(c, cx, cy, ringR, reach, a)
        }
        drawArt(c, cx, cy, r, shape)
        if (sig && style in 0..3) drawOverlay(c, cx, cy, r, style, a)
        if (!playing) drawPaused(c, cx, cy, r)
        if (flashT > 0f) {
            drawFlash(c, cx, cy, r)
            flashT -= dt / 0.7f
        }

        if (playing || VizAudio.active() || hasMotion() || flashT > 0f) postInvalidateOnAnimation()
    }

    private fun drawArt(c: Canvas, cx: Float, cy: Float, r: Float, shape: Int) {
        rect.set(cx - r, cy - r, cx + r, cy + r)
        val rr = when (shape) {
            0 -> r
            1 -> r * 0.42f
            else -> 4f * d
        }
        p.shader = null
        p.style = Paint.Style.FILL
        for (i in 0..2) {
            p.color = Color.argb((30 * cfg.artOp / 100f).toInt(), 0, 0, 0)
            val g = (i + 1) * 1.6f * d
            rect2.set(rect.left - g, rect.top - g + 2f * d, rect.right + g, rect.bottom + g + 2f * d)
            c.drawRoundRect(rect2, rr + g, rr + g, p)
        }
        artPath.reset()
        artPath.addRoundRect(rect, rr, rr, Path.Direction.CW)
        c.save()
        c.clipPath(artPath)
        val art = art
        if (art != null) {
            val s = min(art.width, art.height)
            src.set((art.width - s) / 2, (art.height - s) / 2, (art.width + s) / 2, (art.height + s) / 2)
            p.isFilterBitmap = true
            p.alpha = (255 * cfg.artOp / 100f).toInt().coerceIn(0, 255)
            c.drawBitmap(art, src, rect, p)
            p.alpha = 255
        } else {
            p.shader = LinearGradient(
                rect.left, rect.top, rect.right, rect.bottom,
                accent, accent2, Shader.TileMode.CLAMP
            )
            p.alpha = (255 * cfg.artOp / 100f).toInt().coerceIn(0, 255)
            c.drawRect(rect, p)
            p.alpha = 255
            p.shader = null
            p.typeface = Typeface.DEFAULT
            p.textAlign = Paint.Align.CENTER
            p.textSize = r * 0.95f
            p.color = withAlpha(Color.WHITE, 0.85f * cfg.artOp / 100f)
            c.drawText("♪", cx, cy + r * 0.32f, p)
        }
        c.restore()
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.4f * d
        p.color = withAlpha(Color.WHITE, 0.30f * cfg.borderOp / 100f)
        c.drawRoundRect(rect, rr, rr, p)
        p.style = Paint.Style.FILL
    }

    private fun drawPaused(c: Canvas, cx: Float, cy: Float, r: Float) {
        c.save()
        c.clipPath(artPath)
        p.shader = null
        p.color = Color.argb(110, 0, 0, 0)
        c.drawRect(cx - r, cy - r, cx + r, cy + r, p)
        c.restore()
        p.color = withAlpha(Color.WHITE, 0.92f)
        val s = r * 0.42f
        rect.set(cx - s * 0.62f, cy - s, cx - s * 0.16f, cy + s)
        c.drawRoundRect(rect, s * 0.12f, s * 0.12f, p)
        rect.set(cx + s * 0.16f, cy - s, cx + s * 0.62f, cy + s)
        c.drawRoundRect(rect, s * 0.12f, s * 0.12f, p)
    }

    private fun drawRing(c: Canvas, cx: Float, cy: Float, ringR: Float, reach: Float, a: Float) {
        val n = (cfg.bars.coerceIn(8, 64) / 2) * 2
        val m = n / 2
        val bw = (6.2831855f * ringR / n * 0.55f).coerceIn(1.5f * d, 4f * d)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = bw
        c.save()
        c.translate(cx, cy)
        c.rotate(if (cfg.spin) rot else 0f)
        for (k in 0 until m) {
            val v = gate(bandS(m - 1 - k, m)).coerceIn(0f, 1.15f)
            val len = 2f * d + reach * v
            val ang = Math.toRadians((-90f + 180f * (k + 0.5f) / m).toDouble())
            val ca = cos(ang).toFloat()
            val sa = sin(ang).toFloat()
            p.color = withAlpha(vizCol(k / (m - 1f)), a)
            c.drawLine(ca * ringR, sa * ringR, ca * (ringR + len), sa * (ringR + len), p)
            c.drawLine(-ca * ringR, sa * ringR, -ca * (ringR + len), sa * (ringR + len), p)
        }
        c.restore()
        p.style = Paint.Style.FILL
    }

    private fun drawPulse(c: Canvas, cx: Float, cy: Float, ringR: Float, reach: Float, a: Float) {
        val be = VizAudio.beatEnv
        val lv = gate(VizAudio.level) * (cfg.reach / 100f)
        p.shader = RadialGradient(
            cx, cy, ringR + reach,
            intArrayOf(withAlpha(vizCol(0.3f), a * (0.30f + 0.35f * be)), 0x00000000),
            floatArrayOf(0.55f, 1f), Shader.TileMode.CLAMP
        )
        c.drawCircle(cx, cy, ringR + reach, p)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.8f * d
        p.color = withAlpha(vizCol(0.1f), a * (0.55f + 0.4f * be))
        c.drawCircle(cx, cy, ringR + lv * 3f * d, p)
        for (i in rAge.indices) {
            val age = rAge[i]
            if (age >= 1.0f) continue
            val t = age / 1.0f
            val e = 1f - (1f - t) * (1f - t)
            p.strokeWidth = 2f * d
            p.color = withAlpha(vizCol(0.5f + 0.5f * t), a * 0.6f * (1f - t))
            c.drawCircle(cx, cy, ringR + reach * e, p)
        }
        p.style = Paint.Style.FILL
    }

    private fun drawGlow(c: Canvas, cx: Float, cy: Float, r: Float, a: Float) {
        val be = VizAudio.beatEnv
        val lv = gate(VizAudio.level) * (cfg.reach / 100f) * 2f
        val rad = (r + inset) * (0.8f + 0.1f * be + 0.1f * lv.coerceAtMost(1f))
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(
            cx, cy, rad,
            intArrayOf(withAlpha(vizCol(0.2f), a * (0.55f + 0.4f * be)), 0x00000000),
            floatArrayOf(0.5f, 1f), Shader.TileMode.CLAMP
        )
        c.drawCircle(cx, cy, rad, p)
        p.shader = null
    }

    private fun drawParticles(c: Canvas, a: Float) {
        p.shader = null
        p.style = Paint.Style.FILL
        for (i in 0 until pn) {
            val life = plife[i]
            if (life <= 0f) continue
            val f = (life / pmax[i]).coerceIn(0f, 1f)
            p.color = withAlpha(vizCol(phue[i]), a * f)
            c.drawCircle(px[i], py[i], (1f + 1.6f * f) * d, p)
        }
    }

    private fun smoothPath(pts: Int, xAt: (Int) -> Float, yAt: (Int) -> Float) {
        path.reset()
        path.moveTo(xAt(0), yAt(0))
        for (j in 1 until pts) {
            val mx = (xAt(j - 1) + xAt(j)) / 2f
            val my = (yAt(j - 1) + yAt(j)) / 2f
            path.quadTo(xAt(j - 1), yAt(j - 1), mx, my)
        }
        path.lineTo(xAt(pts - 1), yAt(pts - 1))
    }

    /** Visualizer drawn on top of the artwork (clipped to its shape). */
    private fun drawOverlay(c: Canvas, cx: Float, cy: Float, r: Float, style: Int, a: Float) {
        c.save()
        c.clipPath(artPath)
        val x0 = cx - r
        val x1 = cx + r
        val bottom = cy + r
        val top = cy - r * 0.64f
        val hh = (bottom - top) * cfg.vizHeight / 100f
        val reachK = cfg.reach.coerceIn(10, 100) / 100f
        p.shader = null
        p.style = Paint.Style.FILL
        if (style == 0 || style == 3) {
            p.shader = LinearGradient(
                0f, cy, 0f, cy + r, 0x00000000, Color.argb((136 * cfg.artOp / 100f).toInt(), 0, 0, 0), Shader.TileMode.CLAMP
            )
            c.drawRect(cx - r, cy, cx + r, cy + r, p)
            p.shader = null
        } else {
            p.color = Color.argb((60 * cfg.artOp / 100f).toInt(), 0, 0, 0)
            c.drawRect(cx - r, cy - r, cx + r, cy + r, p)
        }
        val n = (cfg.bars / 2).coerceIn(6, 24)
        when (style) {
            0, 1 -> {
                val low = cfg.low.coerceIn(0, 3)
                val vert = cfg.vert.coerceIn(0, 2)
                val nn = if (low >= 2) (n / 2) * 2 else n
                val pitch = (x1 - x0) / nn
                val bw = max(pitch * 0.64f, 1.5f * d)
                val base = when (vert) { 0 -> bottom; 1 -> top; else -> cy }
                val full = hh * 0.62f * reachK
                fun bar(band: Int, cnt: Int, slot: Int) {
                    val v = gate(bandS(band, cnt)).coerceIn(0f, 1.1f)
                    val bh = max(bw, v * full * (if (vert == 2) 0.9f else 1f))
                    val x = x0 + pitch * slot + (pitch - bw) / 2f
                    p.color = withAlpha(vizCol(band / (cnt - 1f).coerceAtLeast(1f)), a)
                    when (vert) {
                        0 -> rect.set(x, base - bh, x + bw, base)
                        1 -> rect.set(x, base, x + bw, base + bh)
                        else -> rect.set(x, base - bh / 2f, x + bw, base + bh / 2f)
                    }
                    c.drawRoundRect(rect, bw / 2f, bw / 2f, p)
                }
                when (low) {
                    0 -> for (i in 0 until nn) bar(i, nn, i)
                    1 -> for (i in 0 until nn) bar(i, nn, nn - 1 - i)
                    else -> {
                        val m = nn / 2
                        for (i in 0 until m) {
                            if (low == 2) { bar(i, m, m + i); bar(i, m, m - 1 - i) } else { bar(i, m, i); bar(i, m, nn - 1 - i) }
                        }
                    }
                }
            }

            2 -> {
                val pts = VizAudio.W
                val vert = cfg.vert.coerceIn(0, 2)
                val flip = if (vert == 1) -1f else 1f
                val gain = (cfg.reach / 100f).coerceIn(0.1f, 1.2f) * waveGate(VizAudio.level)
                p.style = Paint.Style.STROKE
                p.strokeCap = Paint.Cap.ROUND
                p.strokeJoin = Paint.Join.ROUND
                for (pass in 0..(if (vert == 2) 1 else 0)) {
                    val sgn = if (pass == 0) flip else -1f
                    smoothPath(pts,
                        { x0 + (x1 - x0) * it / (pts - 1f) },
                        { cy - sgn * (smW[it] * gain).coerceIn(-1f, 1f) * hh * 0.42f })
                    if (cfg.glow) {
                        p.strokeWidth = 5f * d
                        hGradPaint(x0, x1, a * 0.22f)
                        c.drawPath(path, p)
                    }
                    p.strokeWidth = 1.8f * d
                    hGradPaint(x0, x1, a)
                    c.drawPath(path, p)
                }
                p.shader = null
                p.style = Paint.Style.FILL
            }

            else -> {
                val pts = 32
                val vert = cfg.vert.coerceIn(0, 2)
                val low = cfg.low.coerceIn(0, 3)
                val hf = hh * (if (vert == 2) 0.4f else 0.7f) * reachK
                val yc = if (vert == 2) cy else (top + bottom) / 2f
                fun vAt(j: Int): Float {
                    val u = j / (pts - 1f)
                    val sp = when (low) { 0 -> u; 1 -> 1f - u; 2 -> kotlin.math.abs(2f * u - 1f); else -> 1f - kotlin.math.abs(2f * u - 1f) }
                    val x = sp * (VizAudio.N - 1f)
                    val i = x.toInt().coerceIn(0, VizAudio.N - 2)
                    val f = x - i
                    return gate(smD[i] * (1f - f) + smD[i + 1] * f).coerceIn(0f, 1.1f)
                }
                val xAt = { j: Int -> x0 + (x1 - x0) * j / (pts - 1f) }
                val line = Path()
                val line2 = Path()
                val fill = Path()
                val fill2 = Path()
                when (vert) {
                    0 -> {
                        smoothPath(pts, xAt) { bottom - max(1.5f * d, vAt(it) * hf) }
                        line.set(path)
                        path.lineTo(x1, bottom); path.lineTo(x0, bottom); path.close()
                        fill.set(path)
                    }
                    1 -> {
                        smoothPath(pts, xAt) { top + max(1.5f * d, vAt(it) * hf) }
                        line.set(path)
                        path.lineTo(x1, top); path.lineTo(x0, top); path.close()
                        fill.set(path)
                    }
                    else -> {
                        smoothPath(pts, xAt) { yc - max(1.5f * d, vAt(it) * hf) }
                        line.set(path)
                        smoothPath(pts, xAt) { yc + max(1.5f * d, vAt(it) * hf) }
                        line2.set(path)
                        fill.set(line)
                        fill.lineTo(x1, yc); fill.lineTo(x0, yc); fill.close()
                        fill2.set(line2)
                        fill2.lineTo(x1, yc); fill2.lineTo(x0, yc); fill2.close()
                    }
                }
                hGradPaint(x0, x1, a * 0.35f)
                c.drawPath(fill, p)
                if (vert == 2) c.drawPath(fill2, p)
                p.style = Paint.Style.STROKE
                p.strokeCap = Paint.Cap.ROUND
                p.strokeWidth = 1.8f * d
                hGradPaint(x0, x1, a)
                c.drawPath(line, p)
                if (vert == 2) c.drawPath(line2, p)
                p.shader = null
                p.style = Paint.Style.FILL
            }
        }
        c.restore()
    }


    // ------------------------------------------------------------------ gestures (used by the floating bubble)

    var onTap: (() -> Unit)? = null
    var onLong: (() -> Unit)? = null
    var onDrag: ((dx: Float, dy: Float) -> Unit)? = null
    var onRelease: (() -> Unit)? = null
    var onFling: ((vx: Float, vy: Float) -> Boolean)? = null
    var haptic = true
    private var vt: VelocityTracker? = null
    private val slop = ViewConfiguration.get(context).scaledTouchSlop
    private val uiHandler = Handler(Looper.getMainLooper())
    private var downRawX = 0f
    private var downRawY = 0f
    private var lastRawX = 0f
    private var lastRawY = 0f
    private var moved = false
    private var longFired = false
    private var gestures = false
    fun enableGestures() { gestures = true }

    private fun buzz(type: Int) {
        if (!haptic) return
        try { performHapticFeedback(type, HapticFeedbackConstants.FLAG_IGNORE_VIEW_SETTING) } catch (e: Exception) {}
    }

    private val longRun = Runnable {
        longFired = true
        buzz(HapticFeedbackConstants.LONG_PRESS)
        onLong?.invoke()
    }

    private var flashT = 0f
    private var flashPlay = false

    fun flashAction(willPlay: Boolean) {
        flashPlay = willPlay
        flashT = 1f
        lastFrame = SystemClock.uptimeMillis()
        invalidate()
    }

    private fun drawFlash(c: Canvas, cx: Float, cy: Float, r: Float) {
        val t = flashT.coerceIn(0f, 1f)
        val a = if (t > 0.75f) 1f else t / 0.75f
        val k = 1f + 0.25f * (1f - t)
        c.save()
        c.clipPath(artPath)
        p.shader = null
        p.style = Paint.Style.FILL
        p.color = Color.argb((120 * a).toInt(), 0, 0, 0)
        c.drawRect(cx - r, cy - r, cx + r, cy + r, p)
        c.restore()
        p.color = withAlpha(Color.WHITE, 0.95f * a)
        val s = r * 0.46f * k
        if (flashPlay) {
            path.reset()
            path.moveTo(cx - s * 0.55f, cy - s)
            path.lineTo(cx + s * 0.95f, cy)
            path.lineTo(cx - s * 0.55f, cy + s)
            path.close()
            c.drawPath(path, p)
        } else {
            rect.set(cx - s * 0.62f, cy - s, cx - s * 0.16f, cy + s)
            c.drawRoundRect(rect, s * 0.12f, s * 0.12f, p)
            rect.set(cx + s * 0.16f, cy - s, cx + s * 0.62f, cy + s)
            c.drawRoundRect(rect, s * 0.12f, s * 0.12f, p)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!gestures) return super.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downRawX = e.rawX; downRawY = e.rawY
                lastRawX = e.rawX; lastRawY = e.rawY
                moved = false
                longFired = false
                vt?.recycle()
                vt = VelocityTracker.obtain()
                vt?.addMovement(e)
                uiHandler.postDelayed(longRun, 500)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                vt?.addMovement(e)
                if (!moved && (Math.abs(e.rawX - downRawX) > slop || Math.abs(e.rawY - downRawY) > slop)) {
                    moved = true
                    uiHandler.removeCallbacks(longRun)
                }
                if (moved) onDrag?.invoke(e.rawX - lastRawX, e.rawY - lastRawY)
                lastRawX = e.rawX; lastRawY = e.rawY
                return true
            }
            MotionEvent.ACTION_UP -> {
                uiHandler.removeCallbacks(longRun)
                vt?.addMovement(e)
                var used = false
                if (moved) {
                    vt?.computeCurrentVelocity(1000)
                    used = onFling?.invoke(vt?.xVelocity ?: 0f, vt?.yVelocity ?: 0f) ?: false
                }
                vt?.recycle(); vt = null
                if (moved) { if (!used) onRelease?.invoke() }
                else if (!longFired) {
                    buzz(HapticFeedbackConstants.VIRTUAL_KEY)
                    onTap?.invoke()
                }
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                uiHandler.removeCallbacks(longRun)
                return true
            }
        }
        return super.onTouchEvent(e)
    }

    private fun recolor(b: Bitmap?) {
        if (b == null) {
            accent = 0xFF00E5FF.toInt(); accent2 = 0xFFFF4081.toInt()
            palette = intArrayOf(0xFF00E5FF.toInt(), 0xFFFF4081.toInt(), 0xFFFFD740.toInt(), 0xFF69F0AE.toInt())
            return
        }
        val s = Bitmap.createScaledBitmap(b, 24, 24, true)
        val hsv = FloatArray(3)
        var bestScore = -1f
        var best = 0
        val px = IntArray(24 * 24)
        s.getPixels(px, 0, 24, 0, 0, 24, 24)
        for (p in px) {
            Color.colorToHSV(p, hsv)
            val score = hsv[1] * hsv[2] * (if (hsv[2] < 0.25f) 0.2f else 1f)
            if (score > bestScore) { bestScore = score; best = p }
        }
        Color.colorToHSV(best, hsv)
        hsv[1] = max(hsv[1], 0.55f); hsv[2] = max(hsv[2], 0.85f)
        accent = Color.HSVToColor(hsv)
        buildPalette(px, accent)
        accent2 = if (palette.size > 1) palette[1] else Color.HSVToColor(floatArrayOf((hsv[0] + 40f) % 360f, hsv[1], hsv[2]))
    }

    /** Groups the artwork's colorful pixels by hue and keeps the strongest groups as the palette. */
    private fun buildPalette(px: IntArray, first: Int) {
        val bins = 12
        val wt = FloatArray(bins)
        val sx = FloatArray(bins)
        val sy = FloatArray(bins)
        val ss = FloatArray(bins)
        val sv = FloatArray(bins)
        val hsv = FloatArray(3)
        for (p in px) {
            Color.colorToHSV(p, hsv)
            if (hsv[1] < 0.22f || hsv[2] < 0.22f) continue
            val w = hsv[1] * hsv[2]
            val bi = ((hsv[0] / 360f) * bins).toInt().coerceIn(0, bins - 1)
            val rad = Math.toRadians(hsv[0].toDouble())
            wt[bi] += w
            sx[bi] += (Math.cos(rad) * w).toFloat()
            sy[bi] += (Math.sin(rad) * w).toFloat()
            ss[bi] += hsv[1] * w
            sv[bi] += hsv[2] * w
        }
        val order = (0 until bins).filter { wt[it] > 0f }.sortedByDescending { wt[it] }
        val out = ArrayList<FloatArray>()
        if (order.isNotEmpty()) {
            val top = wt[order[0]]
            for (bi in order) {
                if (out.size >= 6) break
                if (wt[bi] < top * 0.06f) break
                var hue = Math.toDegrees(Math.atan2(sy[bi].toDouble(), sx[bi].toDouble())).toFloat()
                if (hue < 0f) hue += 360f
                // skip a hue that is almost the same as one already kept
                if (out.any { val dd = Math.abs(it[0] - hue); Math.min(dd, 360f - dd) < 24f }) continue
                out.add(floatArrayOf(hue, max(ss[bi] / wt[bi], 0.55f), max(sv[bi] / wt[bi], 0.85f)))
            }
        }
        if (out.isEmpty()) {
            Color.colorToHSV(first, hsv)
            out.add(floatArrayOf(hsv[0], hsv[1], hsv[2]))
        }
        // too few real colors (plain or black-and-white art): add tints and neighbouring hues
        var k = 0
        while (out.size < 4 && k < 8) {
            val b = out[k % out.size]
            val v = k / out.size
            out.add(
                when (v) {
                    0 -> floatArrayOf((b[0] + 28f) % 360f, max(b[1] * 0.85f, 0.45f), 1f)
                    else -> floatArrayOf((b[0] + 332f) % 360f, max(b[1] * 0.6f, 0.35f), 1f)
                }
            )
            k++
        }
        // order around the color wheel, starting at the main accent, so neighbours blend smoothly
        val h0 = out[0][0]
        out.sortBy { (it[0] - h0 + 360f) % 360f }
        palette = IntArray(out.size) { Color.HSVToColor(out[it]) }
    }
}
