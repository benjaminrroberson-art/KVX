package de.mm20.launcher2.ui.launcher.widgets.facesclock.np

import android.content.Context

/** Remembers which EQ preset to use for each music app. An app preset wins over the output device preset. */
object EqApps {
    private fun store(ctx: Context) =
        ctx.applicationContext.getSharedPreferences("kvx_np_eqapp", Context.MODE_PRIVATE)

    fun assignments(ctx: Context): Map<String, String> =
        store(ctx).all.mapValues { it.value.toString() }

    fun get(ctx: Context, pkg: String): String? = if (pkg.isEmpty()) null else store(ctx).getString(pkg, null)

    fun assign(ctx: Context, pkg: String, preset: String?) {
        val e = store(ctx).edit()
        if (preset == null) e.remove(pkg) else e.putString(pkg, preset)
        e.apply()
        EqDevices.applyForCurrent(ctx, force = true)
    }

    fun label(ctx: Context, pkg: String): String = try {
        val pm = ctx.packageManager
        pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) { pkg }
}
