package de.mm20.launcher2.ui.songshare

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager

object SongSharePrefs {
    private fun sp(c: Context) = c.applicationContext.getSharedPreferences("kvx_songshare", Context.MODE_PRIVATE)

    fun svcOn(c: Context, s: Svc) = sp(c).getBoolean("svc_" + s.name, true)
    fun setSvc(c: Context, s: Svc, on: Boolean) { sp(c).edit().putBoolean("svc_" + s.name, on).apply() }

    /** Show the "try to find the exact link" web-search helper on services that need it. */
    fun webFind(c: Context) = sp(c).getBoolean("webFind", true)
    fun setWebFind(c: Context, on: Boolean) { sp(c).edit().putBoolean("webFind", on).apply() }

    /** Tap a link row: true copies it, false opens it. */
    fun tapCopies(c: Context) = sp(c).getBoolean("tapCopies", true)
    fun setTapCopies(c: Context, on: Boolean) { sp(c).edit().putBoolean("tapCopies", on).apply() }

    private fun comp(c: Context, name: String) = ComponentName(c.packageName, name)
    const val SHARE_ALIAS = "de.mm20.launcher2.ui.songshare.SongShareTarget"
    const val TILE = "de.mm20.launcher2.ui.songshare.SongShareTile"

    fun enabled(c: Context, name: String): Boolean =
        c.packageManager.getComponentEnabledSetting(comp(c, name)) != PackageManager.COMPONENT_ENABLED_STATE_DISABLED

    fun setEnabled(c: Context, name: String, on: Boolean) {
        c.packageManager.setComponentEnabledSetting(
            comp(c, name),
            if (on) PackageManager.COMPONENT_ENABLED_STATE_ENABLED else PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
            PackageManager.DONT_KILL_APP,
        )
    }
}
