package de.mm20.launcher2.ui.launcher.widgets.facesclock

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import de.mm20.launcher2.calendar.CalendarRepository
import de.mm20.launcher2.permissions.PermissionGroup
import de.mm20.launcher2.permissions.PermissionsManager
import de.mm20.launcher2.weather.WeatherRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject
import java.time.LocalDate
import java.time.ZoneId

/** Weather and calendar data for our widgets, taken from the launcher's own services. */
class KvxDataVM : ViewModel(), KoinComponent {
    private val weather: WeatherRepository by inject()
    private val calendar: CalendarRepository by inject()
    private val permissions: PermissionsManager by inject()

    val hourly = weather.getForecasts(null)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val daily = weather.getDailyForecasts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val hasCalendarPermission = permissions.hasPermission(PermissionGroup.Calendar)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    fun events(fromDay: LocalDate, days: Int, excludeAllDay: Boolean) = run {
        val zone = ZoneId.systemDefault()
        val from = fromDay.atStartOfDay(zone).toInstant().toEpochMilli()
        val to = fromDay.plusDays(days.toLong()).atStartOfDay(zone).toInstant().toEpochMilli()
        calendar.findMany(from = from, to = to, excludeAllDayEvents = excludeAllDay).map { it.toList() }
    }

    fun requestCalendar(activity: androidx.appcompat.app.AppCompatActivity) {
        permissions.requestPermission(activity, PermissionGroup.Calendar)
    }
}
