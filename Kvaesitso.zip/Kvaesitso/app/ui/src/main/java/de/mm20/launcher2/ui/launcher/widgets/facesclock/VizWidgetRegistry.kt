package de.mm20.launcher2.ui.launcher.widgets.facesclock

import android.graphics.Rect
import android.view.View
import java.util.Collections
import java.util.WeakHashMap

/** Tracks the visualizer views that are on screen, so the floating bubble can step aside. */
object VizWidgetRegistry {
    private val views: MutableSet<View> = Collections.newSetFromMap(WeakHashMap<View, Boolean>())

    fun track(v: View) {
        v.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(x: View) { views.add(x) }
            override fun onViewDetachedFromWindow(x: View) { views.remove(x) }
        })
        if (v.isAttachedToWindow) views.add(v)
    }

    /** True when any tracked visualizer is attached, shown, and at least partly on screen. */
    fun anyVisible(): Boolean {
        val r = Rect()
        for (v in views.toList()) {
            if (v.isAttachedToWindow && v.windowVisibility == View.VISIBLE && v.isShown &&
                v.getGlobalVisibleRect(r) && r.width() > 8 && r.height() > 8) return true
        }
        return false
    }
}
