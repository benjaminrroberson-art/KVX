package de.mm20.launcher2.ui.launcher.widgets.facesclock

import android.graphics.Rect
import android.view.View
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import java.util.Collections
import java.util.WeakHashMap

/** Tracks the visualizer views that are on screen, so the floating bubble can step aside. */
object VizWidgetRegistry {
    private val views: MutableSet<View> = Collections.newSetFromMap(WeakHashMap<View, Boolean>())

    private val flags = WeakHashMap<View, Boolean>()

    /** Compose reports whether the widget's clipped bounds are really on screen (scrolled-away pages report false). */
    fun setVisible(v: View, visible: Boolean) { flags[v] = visible }

    fun track(v: View) {
        v.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(x: View) { views.add(x) }
            override fun onViewDetachedFromWindow(x: View) { views.remove(x) }
        })
        if (v.isAttachedToWindow) views.add(v)
    }

    /** True when any tracked visualizer is attached, shown, and at least partly on screen. */
    fun anyVisible(): Boolean {
        val r = Rect()
        for (v in views.toList()) {
            if (flags[v] != false && v.isAttachedToWindow && v.windowVisibility == View.VISIBLE && v.isShown &&
                v.getGlobalVisibleRect(r) && r.width() > 8 && r.height() > 8) return true
        }
        return false
    }
}

/** Attach to the Compose node that hosts a tracked view; [ref] holds the view once the factory has made it. */
fun androidx.compose.ui.Modifier.vizVisible(ref: Array<View?>): androidx.compose.ui.Modifier =
    this.onGloballyPositioned { c ->
        val v = ref[0]
        if (v != null) {
            val b = if (c.isAttached) c.boundsInWindow() else androidx.compose.ui.geometry.Rect.Zero
            VizWidgetRegistry.setVisible(v, b.width > 8f && b.height > 8f)
        }
    }
