package de.mm20.launcher2.ui.launcher.widgets.facesclock

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import de.mm20.launcher2.ui.component.colorpicker.HctColorPicker
import de.mm20.launcher2.ui.component.colorpicker.rememberHctColorPickerState
import de.mm20.launcher2.ui.component.preferences.Preference

internal val quickSwatches = listOf(
    0xFFFFFFFF.toInt(), 0xFF000000.toInt(), 0xFF9AA0A6.toInt(), 0xFFFF4D4D.toInt(), 0xFFFF9500.toInt(), 0xFFFFC107.toInt(),
    0xFFFFD60A.toInt(), 0xFF34C759.toInt(), 0xFF2BB5A0.toInt(), 0xFF32D4F0.toInt(), 0xFF4D9BFF.toInt(), 0xFF5B6CFF.toInt(),
    0xFFBF5AF2.toInt(), 0xFFFF6FA8.toInt(),
)

private fun hex(c: Int) = "#%06X".format(c and 0xFFFFFF)

/** A color row that opens a full picker: quick swatches, a free color wheel, and a hex field. */
@Composable
fun ColorPreference(title: String, value: Int, extra: List<Pair<String, Int>> = emptyList(), onChange: (Int) -> Unit) {
    var open by remember { mutableStateOf(false) }
    val label = extra.firstOrNull { it.second == value }?.first ?: hex(value)
    Preference(
        title = title,
        summary = label,
        onClick = { open = true },
        controls = {
            if (extra.none { it.second == value }) {
                Box(Modifier.size(28.dp).clip(CircleShape).background(Color(value)).border(1.dp, MaterialTheme.colorScheme.outline, CircleShape))
            }
        },
    )
    if (open) ColorPickerDialog(title, value, extra, onChange) { open = false }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ColorPickerDialog(title: String, value: Int, extra: List<Pair<String, Int>>, onChange: (Int) -> Unit, onDismiss: () -> Unit) {
    var hexText by remember { mutableStateOf(hex(value)) }
    val isExtra = extra.any { it.second == value }
    val state = rememberHctColorPickerState(Color(if (isExtra) 0xFF4D9BFF.toInt() else value)) { c ->
        hexText = hex(c.toArgb())
        onChange(c.toArgb() or (0xFF shl 24))
    }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(shape = MaterialTheme.shapes.extraLarge, color = MaterialTheme.colorScheme.surface, modifier = Modifier.fillMaxWidth(0.94f).heightIn(max = 720.dp)) {
            Column {
                Column(Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState()).padding(16.dp)) {
                    Text(title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(bottom = 12.dp))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        for ((name, v) in extra) {
                            TextButton(onClick = { onChange(v); onDismiss() }) { Text(name) }
                        }
                        for (s in quickSwatches) {
                            Box(
                                Modifier.size(34.dp).clip(CircleShape).background(Color(s))
                                    .border(1.dp, MaterialTheme.colorScheme.outline, CircleShape)
                                    .clickable { onChange(s); hexText = hex(s) }
                            )
                        }
                    }
                    HctColorPicker(state, Modifier.padding(top = 12.dp))
                    OutlinedTextField(
                        value = hexText,
                        onValueChange = { t ->
                            hexText = t
                            val clean = t.trim().removePrefix("#")
                            if (clean.length == 6) clean.toLongOrNull(16)?.let { onChange((it.toInt()) or (0xFF shl 24)) }
                        },
                        label = { Text("Hex color") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
                    )
                }
                TextButton(onClick = onDismiss, modifier = Modifier.align(Alignment.End).padding(8.dp)) { Text("Done") }
            }
        }
    }
}
