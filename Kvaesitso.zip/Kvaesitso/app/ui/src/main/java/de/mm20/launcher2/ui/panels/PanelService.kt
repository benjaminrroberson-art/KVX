package de.mm20.launcher2.ui.panels

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import de.mm20.launcher2.ui.R
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Edge panel: a handle on the screen edge that opens a panel of apps over whatever is on screen. */
class PanelService : Service() {

    companion object {
        @Volatile var instance: PanelService? = null

        /** Starts or stops the service to match the settings. Call after any change to the on switch. */
        fun refresh(ctx: Context) {
            if (PanelPrefs.on(ctx) && Settings.canDrawOverlays(ctx)) {
                try { ctx.startForegroundService(Intent(ctx, PanelService::class.java)) } catch (e: Exception) {}
            } else {
                instance?.let { ctx.stopService(Intent(ctx, PanelService::class.java)) }
            }
        }
    }

    private lateinit var wm: WindowManager
    private val d get() = resources.displayMetrics.density
    private var handle: HandleView? = null
    private var handleLp: WindowManager.LayoutParams? = null
    private var panel: PanelRoot? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var closing = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WindowManager::class.java)
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("kvx_panel", "Edge panel", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 2, Intent(this, PanelService::class.java).setAction("kvx.PANEL_STOP"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, "kvx_panel")
            .setSmallIcon(R.drawable.apps_24px)
            .setContentTitle("Edge panel is on")
            .setOngoing(true)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, R.drawable.apps_24px), "Turn off", stop).build())
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(2, n)
        instance = this
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "kvx.PANEL_STOP") {
            PanelPrefs.setB(this, "on", false)
            stopSelf()
            return START_NOT_STICKY
        }
        rebuildHandle()
        return START_STICKY
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        closeNow()
        rebuildHandle()
    }

    override fun onDestroy() {
        closeNow()
        removeHandle()
        if (instance === this) instance = null
        super.onDestroy()
    }

    /** Settings changed: redraw the handle (the panel picks changes up the next time it opens). */
    fun onPrefsChanged() { if (panel == null) rebuildHandle() }

    fun openNow() = open()

    private fun px(dp: Int) = (dp * d).toInt()
    private fun i(k: String, def: Int) = PanelPrefs.i(this, k, def)
    private fun screen(): Rect =
        if (Build.VERSION.SDK_INT >= 30) wm.currentWindowMetrics.bounds
        else resources.displayMetrics.let { Rect(0, 0, it.widthPixels, it.heightPixels) }

    // ---------------------------------------------------------------- handle

    private fun removeHandle() {
        handle?.let { try { wm.removeViewImmediate(it) } catch (e: Exception) {} }
        handle = null
        handleLp = null
    }

    private fun handleTop(sh: Int, len: Int): Int = ((sh - len) * i("handleY", 45) / 100).coerceAtLeast(0)

    private fun rebuildHandle() {
        removeHandle()
        if (!Settings.canDrawOverlays(this)) return
        val s = screen()
        val len = px(i("handleLen", 96)).coerceAtMost(s.height() / 2)
        val right = i("side", 0) == 0
        val v = HandleView(this)
        val lp = WindowManager.LayoutParams(
            px(i("zoneW", 24)), len,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or (if (right) Gravity.RIGHT else Gravity.LEFT)
            x = 0
            y = handleTop(s.height(), len)
            title = "Kvx panel handle"
        }
        try {
            wm.addView(v, lp)
            handle = v
            handleLp = lp
        } catch (e: Exception) {}
    }

    private inner class HandleView(ctx: Context) : View(ctx) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var down = false
        private var sx = 0f
        private var sy = 0f
        private var opened = false

        override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
            super.onLayout(changed, l, t, r, b)
            if (Build.VERSION.SDK_INT >= 29) systemGestureExclusionRects = listOf(Rect(0, 0, r - l, b - t))
        }

        override fun onDraw(c: Canvas) {
            val dd = resources.displayMetrics.density
            val vw = i("handleW", 5) * dd * (if (down) 1.7f else 1f)
            val right = i("side", 0) == 0
            val base = i("hColor", 0xFFE0B25A.toInt())
            paint.color = base
            paint.alpha = Color.alpha(base) * i("hAlpha", 90) / 100
            val inset = 2 * dd
            val x0 = if (right) width - vw - inset else inset
            c.drawRoundRect(x0, 0f, x0 + vw, height.toFloat(), vw / 2f, vw / 2f, paint)
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            val dd = resources.displayMetrics.density
            val right = i("side", 0) == 0
            val mode = i("openMode", 0) // 0 swipe or tap, 1 swipe only, 2 tap only
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; opened = false; down = true; invalidate()
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = if (right) sx - e.rawX else e.rawX - sx
                    if (!opened && dx > 18 * dd && mode != 2) {
                        opened = true
                        buzz()
                        open()
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    down = false; invalidate()
                    if (!opened && e.actionMasked == MotionEvent.ACTION_UP && mode != 1 &&
                        abs(e.rawX - sx) < 10 * dd && abs(e.rawY - sy) < 10 * dd
                    ) { buzz(); open() }
                }
            }
            return true
        }

        private fun buzz() {
            if (PanelPrefs.b(context, "haptic", true)) performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
        }
    }

    // ---------------------------------------------------------------- panel

    private inner class PanelRoot(ctx: Context) : FrameLayout(ctx) {
        private var hadFocus = false
        override fun dispatchKeyEvent(e: KeyEvent): Boolean {
            if (e.keyCode == KeyEvent.KEYCODE_BACK) {
                if (e.action == KeyEvent.ACTION_UP) close()
                return true
            }
            return super.dispatchKeyEvent(e)
        }
        override fun onWindowFocusChanged(hasWindowFocus: Boolean) {
            super.onWindowFocusChanged(hasWindowFocus)
            if (hasWindowFocus) hadFocus = true else if (hadFocus) close()
        }
    }

    private fun installedApps(): List<String> {
        val pm = packageManager
        return PanelPrefs.apps(this).filter { pm.getLaunchIntentForPackage(it) != null }
    }

    private fun open() {
        if (panel != null || !Settings.canDrawOverlays(this)) return
        closing = false
        val s = screen()
        val sw = s.width(); val sh = s.height()
        val right = i("side", 0) == 0
        val cols = i("cols", 2).coerceIn(1, 5)
        val iconPx = px(i("iconSize", 44))
        val labels = PanelPrefs.b(this, "labels", true)
        val labelSp = i("labelSp", 11).toFloat()
        val itemW = iconPx + px(28)
        val itemH = iconPx + (if (labels) ((labelSp * 1.5f + 6) * d).toInt() else 0) + px(16)
        val pad = px(i("pad", 10))
        val gap = px(i("edgeGap", 8))
        val corner = i("corner", 24) * d
        val apps = installedApps()
        val n = max(apps.size, 1)
        val rows = (n + cols - 1) / cols
        val contentH = rows * itemH + 2 * pad
        val maxH = (sh * i("maxH", 80) / 100 - px(48)).coerceAtLeast(px(120))
        val cardH = min(contentH, maxH)
        val cardW = if (apps.isEmpty()) px(220) else cols * itemW + 2 * pad

        val cBg = i("cBg", 0xFF1E1E1E.toInt())
        val bgA = (Color.alpha(cBg) * i("bgAlpha", 85) / 100).coerceIn(0, 255)
        val cLabel = i("cLabel", 0xFFFFFFFF.toInt())
        val cAccent = i("cAccent", 0xFFE0B25A.toInt())

        val root = PanelRoot(this)
        root.isFocusable = true
        root.isFocusableInTouchMode = true
        root.setOnClickListener { close() }

        val scrim = View(this)
        scrim.setBackgroundColor(Color.argb(255 * i("dim", 25) / 100, 0, 0, 0))
        scrim.alpha = 0f
        root.addView(scrim, FrameLayout.LayoutParams(-1, -1))

        val card = FrameLayout(this)
        card.isClickable = true
        card.background = GradientDrawable().apply {
            setColor(Color.argb(bgA, Color.red(cBg), Color.green(cBg), Color.blue(cBg)))
            cornerRadius = corner
            val bw = i("border", 0)
            if (bw > 0) setStroke(max(1, (bw * d).toInt()), cAccent)
        }
        card.elevation = 10 * d
        card.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, corner)
            }
        }
        card.clipToOutline = true

        val scroll = ScrollView(this)
        scroll.isVerticalScrollBarEnabled = false
        scroll.overScrollMode = View.OVER_SCROLL_NEVER
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(pad, pad, pad, pad)
        if (apps.isEmpty()) {
            val t = TextView(this)
            t.text = "No apps yet. Add some in Settings, Panels."
            t.setTextColor(cLabel)
            t.textSize = 13f
            t.gravity = Gravity.CENTER
            col.addView(t, LinearLayout.LayoutParams(-1, itemH))
        } else {
            var row: LinearLayout? = null
            apps.forEachIndexed { idx, pkg ->
                if (idx % cols == 0) {
                    row = LinearLayout(this).also {
                        it.orientation = LinearLayout.HORIZONTAL
                        col.addView(it, LinearLayout.LayoutParams(-2, itemH))
                    }
                }
                row!!.addView(item(pkg, itemW, itemH, iconPx, labels, labelSp, cLabel, cAccent), LinearLayout.LayoutParams(itemW, itemH))
            }
        }
        scroll.addView(col, FrameLayout.LayoutParams(-1, -2))
        card.addView(scroll, FrameLayout.LayoutParams(-1, -1))

        val handleLen = px(i("handleLen", 96)).coerceAtMost(sh / 2)
        val centerY = handleTop(sh, handleLen) + handleLen / 2
        val lo = px(24)
        val hi = (sh - cardH - px(24)).coerceAtLeast(lo)
        val top = when (i("align", 0)) {
            1 -> (sh - cardH) / 2
            2 -> lo
            else -> centerY - cardH / 2
        }.coerceIn(lo, hi)
        val clp = FrameLayout.LayoutParams(cardW, cardH, Gravity.TOP or (if (right) Gravity.RIGHT else Gravity.LEFT))
        clp.topMargin = top
        if (right) clp.rightMargin = gap else clp.leftMargin = gap
        root.addView(card, clp)

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            title = "Kvx panel"
            if (Build.VERSION.SDK_INT >= 30) layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        }
        val blurPx = px(i("blur", 20))
        val canBlur = Build.VERSION.SDK_INT >= 31 && blurPx > 0 && wm.isCrossWindowBlurEnabled
        if (canBlur) {
            lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
            lp.blurBehindRadius = 0
        }
        try { wm.addView(root, lp) } catch (e: Exception) { return }
        panel = root
        panelLp = lp
        root.requestFocus()

        val dur = i("animMs", 220).toLong()
        val kind = i("anim", 0)
        val off = (cardW + gap).toFloat() * (if (right) 1 else -1)
        card.pivotX = if (right) cardW.toFloat() else 0f
        card.pivotY = cardH / 2f
        when (kind) {
            0 -> card.translationX = off
            1 -> { card.alpha = 0f; card.scaleX = 0.9f; card.scaleY = 0.9f }
            else -> { card.alpha = 0f; card.scaleX = 0.5f; card.scaleY = 0.5f }
        }
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = dur
            interpolator = if (kind == 2) OvershootInterpolator(1.2f) else DecelerateInterpolator(1.6f)
            addUpdateListener {
                val f = it.animatedValue as Float
                when (kind) {
                    0 -> card.translationX = off * (1f - f)
                    1 -> { card.alpha = f.coerceIn(0f, 1f); card.scaleX = 0.9f + 0.1f * f; card.scaleY = 0.9f + 0.1f * f }
                    else -> { card.alpha = f.coerceIn(0f, 1f); card.scaleX = 0.5f + 0.5f * f; card.scaleY = 0.5f + 0.5f * f }
                }
                scrim.alpha = f.coerceIn(0f, 1f)
                if (canBlur && panel === root) {
                    lp.blurBehindRadius = (blurPx * f.coerceIn(0f, 1f)).toInt()
                    try { wm.updateViewLayout(root, lp) } catch (e: Exception) {}
                }
            }
            start()
        }
    }

    private fun item(pkg: String, w: Int, h: Int, iconPx: Int, labels: Boolean, labelSp: Float, cLabel: Int, cAccent: Int): View {
        val pm = packageManager
        val v = LinearLayout(this)
        v.orientation = LinearLayout.VERTICAL
        v.gravity = Gravity.CENTER
        val mask = GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = 14 * d }
        v.background = RippleDrawable(ColorStateList.valueOf(Color.argb(90, Color.red(cAccent), Color.green(cAccent), Color.blue(cAccent))), null, mask)
        val img = ImageView(this)
        try { img.setImageDrawable(pm.getApplicationIcon(pkg)) } catch (e: Exception) {}
        val shape = i("iconShape", 0)
        if (shape != 0) {
            img.outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    val r = if (shape == 1) view.width / 2f else view.width * 0.26f
                    outline.setRoundRect(0, 0, view.width, view.height, r)
                }
            }
            img.clipToOutline = true
        }
        v.addView(img, LinearLayout.LayoutParams(iconPx, iconPx))
        if (labels) {
            val t = TextView(this)
            t.text = try { pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)) } catch (e: Exception) { pkg }
            t.setTextColor(cLabel)
            t.textSize = labelSp
            t.maxLines = 1
            t.ellipsize = TextUtils.TruncateAt.END
            t.gravity = Gravity.CENTER
            t.setPadding(px(2), px(3), px(2), 0)
            v.addView(t, LinearLayout.LayoutParams(w - px(4), LinearLayout.LayoutParams.WRAP_CONTENT))
        }
        v.setOnClickListener {
            if (PanelPrefs.b(this, "haptic", true)) v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            val intent = pm.getLaunchIntentForPackage(pkg)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (PanelPrefs.b(this, "closeOnLaunch", true)) close()
            if (intent != null) try { startActivity(intent) } catch (e: Exception) {}
        }
        v.setOnLongClickListener {
            close()
            try {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Exception) {}
            true
        }
        return v
    }

    private fun closeNow() {
        val p = panel ?: return
        panel = null
        panelLp = null
        closing = false
        try { wm.removeViewImmediate(p) } catch (e: Exception) {}
    }

    private fun close() {
        val p = panel ?: return
        if (closing) return
        closing = true
        val card = p.getChildAt(1)
        val scrim = p.getChildAt(0)
        val right = i("side", 0) == 0
        val kind = i("anim", 0)
        val dur = (i("animMs", 220) * 0.8f).toLong()
        val off = ((card?.width ?: 0) + px(i("edgeGap", 8))).toFloat() * (if (right) 1 else -1)
        val lp = panelLp
        val startBlur = lp?.blurBehindRadius ?: 0
        ValueAnimator.ofFloat(1f, 0f).apply {
            duration = dur
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                val f = it.animatedValue as Float
                if (card != null) when (kind) {
                    0 -> card.translationX = off * (1f - f)
                    else -> { card.alpha = f; card.scaleX = 0.9f + 0.1f * f; card.scaleY = 0.9f + 0.1f * f }
                }
                scrim?.alpha = f
                if (lp != null && startBlur > 0 && panel === p) {
                    lp.blurBehindRadius = (startBlur * f).toInt()
                    try { wm.updateViewLayout(p, lp) } catch (e: Exception) {}
                }
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) { if (panel === p) closeNow() }
            })
            start()
        }
    }
}
