package de.mm20.launcher2.ui.panels

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.view.ViewConfiguration
import android.widget.SeekBar
import android.widget.Toast
import kotlin.math.roundToInt
import kotlin.math.sqrt
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import de.mm20.launcher2.ui.R
import de.mm20.launcher2.applications.AppRepository
import de.mm20.launcher2.icons.IconService
import de.mm20.launcher2.icons.LauncherIconRenderSettings
import de.mm20.launcher2.icons.StaticLauncherIcon
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Edge panel: a handle on the screen edge that opens a panel of apps over whatever is on screen. */
class PanelService : Service(), KoinComponent {

    companion object {
        @Volatile var instance: PanelService? = null

        /** Starts or stops the service to match the settings. Call after any change to the on switch. */
        fun refresh(ctx: Context) {
            if (PanelPrefs.on(ctx) && Settings.canDrawOverlays(ctx)) {
                try { ctx.startForegroundService(Intent(ctx, PanelService::class.java)) } catch (e: Exception) {}
            } else {
                instance?.let { ctx.stopService(Intent(ctx, PanelService::class.java)) }
            }
        }
    }

    private lateinit var wm: WindowManager
    private val d get() = resources.displayMetrics.density
    private var handle: HandleView? = null
    private var handleLp: WindowManager.LayoutParams? = null
    private var panel: PanelRoot? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var closing = false
    private val iconService: IconService by inject()
    private val appRepository: AppRepository by inject()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var torchOn = false
    private val torchCb = object : CameraManager.TorchCallback() {
        override fun onTorchModeChanged(cameraId: String, enabled: Boolean) { torchOn = enabled }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WindowManager::class.java)
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("kvx_panel", "Edge panel", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 2, Intent(this, PanelService::class.java).setAction("kvx.PANEL_STOP"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, "kvx_panel")
            .setSmallIcon(R.drawable.apps_24px)
            .setContentTitle("Edge panel is on")
            .setOngoing(true)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, R.drawable.apps_24px), "Turn off", stop).build())
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(2, n)
        instance = this
        try { getSystemService(CameraManager::class.java).registerTorchCallback(torchCb, null) } catch (e: Exception) {}
        warmIcons()
    }

    /** Renders the panel's launcher icons ahead of time so the first open is instant. */
    private fun warmIcons() {
        if (!PanelPrefs.b(this, "launcherIcons", true)) return
        val size = px(i("iconSize", 44))
        val apps = panelItems().filter { it.startsWith("app:") && !PanelPrefs.hasIcon(this, it) }
        if (apps.isEmpty()) return
        scope.launch {
            apps.forEach { k ->
                val pk = k.removePrefix("app:")
                renderLauncherIcon(pk, size)?.let { iconCache[iconKey(pk, size)] = it }
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "kvx.PANEL_STOP") {
            PanelPrefs.setB(this, "on", false)
            stopSelf()
            return START_NOT_STICKY
        }
        rebuildHandle()
        return START_STICKY
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        closeNow()
        rebuildHandle()
    }

    override fun onDestroy() {
        scope.cancel()
        closeNow()
        removeHandle()
        try { getSystemService(CameraManager::class.java).unregisterTorchCallback(torchCb) } catch (e: Exception) {}
        if (instance === this) instance = null
        super.onDestroy()
    }

    /** Settings changed: redraw the handle (the panel picks changes up the next time it opens). */
    fun onPrefsChanged() { if (panel == null) rebuildHandle() }

    fun openNow() = open()

    private fun px(dp: Int) = (dp * d).toInt()
    private fun i(k: String, def: Int) = PanelPrefs.i(this, k, def)
    private fun screen(): Rect =
        if (Build.VERSION.SDK_INT >= 30) wm.currentWindowMetrics.bounds
        else resources.displayMetrics.let { Rect(0, 0, it.widthPixels, it.heightPixels) }

    // ---------------------------------------------------------------- handle

    private fun removeHandle() {
        handle?.let { try { wm.removeViewImmediate(it) } catch (e: Exception) {} }
        handle = null
        handleLp = null
    }

    private fun handleTop(sh: Int, len: Int): Int = ((sh - len) * i("handleY", 50) / 100).coerceAtLeast(0)

    private fun rebuildHandle() {
        removeHandle()
        if (!Settings.canDrawOverlays(this)) return
        val s = screen()
        val len = px(i("handleLen", 96)).coerceAtMost(s.height() / 2)
        val right = i("side", 0) == 0
        val v = HandleView(this)
        val lp = WindowManager.LayoutParams(
            px(i("zoneW", 24)), len,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or (if (right) Gravity.RIGHT else Gravity.LEFT)
            x = 0
            y = handleTop(s.height(), len)
            title = "Kvx panel handle"
        }
        try {
            wm.addView(v, lp)
            handle = v
            handleLp = lp
        } catch (e: Exception) {}
    }

    private inner class HandleView(ctx: Context) : View(ctx) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var down = false
        private var sx = 0f
        private var sy = 0f
        private var opened = false

        override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
            super.onLayout(changed, l, t, r, b)
            if (Build.VERSION.SDK_INT >= 29) systemGestureExclusionRects = listOf(Rect(0, 0, r - l, b - t))
        }

        override fun onDraw(c: Canvas) {
            val dd = resources.displayMetrics.density
            val vw = i("handleW", 5) * dd * (if (down) 1.7f else 1f)
            val right = i("side", 0) == 0
            val base = i("hColor", 0xFFE0B25A.toInt())
            paint.color = base
            paint.alpha = Color.alpha(base) * i("hAlpha", 90) / 100
            val inset = 2 * dd
            val x0 = if (right) width - vw - inset else inset
            c.drawRoundRect(x0, 0f, x0 + vw, height.toFloat(), vw / 2f, vw / 2f, paint)
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            val dd = resources.displayMetrics.density
            val right = i("side", 0) == 0
            val mode = i("openMode", 0) // 0 swipe or tap, 1 swipe only, 2 tap only
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; opened = false; down = true; invalidate()
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = if (right) sx - e.rawX else e.rawX - sx
                    if (!opened && dx > 18 * dd && mode != 2) {
                        opened = true
                        buzz()
                        open()
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    down = false; invalidate()
                    if (!opened && e.actionMasked == MotionEvent.ACTION_UP && mode != 1 &&
                        abs(e.rawX - sx) < 10 * dd && abs(e.rawY - sy) < 10 * dd
                    ) { buzz(); open() }
                }
            }
            return true
        }

        private fun buzz() {
            if (PanelPrefs.b(context, "haptic", true)) performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
        }
    }

    // ---------------------------------------------------------------- panel

    private inner class PanelRoot(ctx: Context) : FrameLayout(ctx) {
        private var hadFocus = false
        override fun dispatchKeyEvent(e: KeyEvent): Boolean {
            if (e.keyCode == KeyEvent.KEYCODE_BACK) {
                if (e.action == KeyEvent.ACTION_UP) close()
                return true
            }
            return super.dispatchKeyEvent(e)
        }
        override fun onWindowFocusChanged(hasWindowFocus: Boolean) {
            super.onWindowFocusChanged(hasWindowFocus)
            if (hasWindowFocus) hadFocus = true else if (hadFocus) close()
        }
    }

    private inner class SwipeCard(ctx: Context) : FrameLayout(ctx) {
        private var sx = 0f
        private var sy = 0f
        private var drag = false
        private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
        private fun toward(dx: Float) = if (i("side", 0) == 0) dx else -dx

        override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; drag = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx
                    val dy = e.rawY - sy
                    if (!drag && toward(dx) > slop * 2 && abs(dx) > abs(dy) * 1.5f) { drag = true; return true }
                }
            }
            return false
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; drag = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx
                    val dy = e.rawY - sy
                    if (!drag && toward(dx) > slop * 2 && abs(dx) > abs(dy) * 1.5f) drag = true
                    if (drag) translationX = max(0f, toward(dx)) * (if (i("side", 0) == 0) 1f else -1f)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (drag) {
                        if (abs(translationX) > width * 0.25f && e.actionMasked == MotionEvent.ACTION_UP) close()
                        else animate().translationX(0f).setDuration(120).start()
                    }
                    drag = false
                }
            }
            return true
        }
    }

    private fun panelItems(): List<String> {
        val pm = packageManager
        return PanelPrefs.items(this).filter {
            if (it.startsWith("app:")) pm.getLaunchIntentForPackage(it.removePrefix("app:")) != null else PanelPrefs.tool(it) != null
        }
    }

    private val iconCache = HashMap<String, android.graphics.Bitmap>()
    private var opening = false

    private fun iconKey(pkg: String, size: Int) = "$pkg@$size@${i("cBg", 0)}@${i("cAccent", 0)}"

    private suspend fun renderLauncherIcon(pkg: String, size: Int): android.graphics.Bitmap? {
        return try {
            val app = appRepository.findOne(pkg, android.os.Process.myUserHandle()).firstOrNull() ?: return null
            val icon = iconService.getIcon(app, size).firstOrNull { it != null } as? StaticLauncherIcon ?: return null
            // The launcher caches and reuses its bitmap, so copy before keeping it.
            icon.render(
                LauncherIconRenderSettings(
                    size = size,
                    fgThemeColor = i("cBg", 0xFF1E1E1E.toInt()) or 0xFF000000.toInt(),
                    bgThemeColor = i("cAccent", 0xFFE0B25A.toInt()) or 0xFF000000.toInt(),
                    fgTone = 10,
                    bgTone = 90,
                )
            ).copy(android.graphics.Bitmap.Config.ARGB_8888, false)
        } catch (e: Exception) { null }
    }

    /** Opens the panel. Launcher icons are loaded first so nothing swaps after it appears. */
    private fun open() {
        if (panel != null || opening || !Settings.canDrawOverlays(this)) return
        val size = px(i("iconSize", 44))
        val apps = if (PanelPrefs.b(this, "launcherIcons", true))
            panelItems().filter { it.startsWith("app:") && !PanelPrefs.hasIcon(this, it) } else emptyList()
        val missing = apps.filter { iconCache[iconKey(it.removePrefix("app:"), size)] == null }
        if (missing.isEmpty()) {
            buildAndShow()
        } else {
            opening = true
            scope.launch {
                kotlinx.coroutines.withTimeoutOrNull(300) {
                    kotlinx.coroutines.coroutineScope {
                        missing.forEach { k ->
                            val pk = k.removePrefix("app:")
                            launch { renderLauncherIcon(pk, size)?.let { iconCache[iconKey(pk, size)] = it } }
                        }
                    }
                }
                opening = false
                buildAndShow()
            }
        }
        // Refresh in the background so a changed icon shows next time.
        if (apps.isNotEmpty()) scope.launch {
            apps.forEach { k ->
                renderLauncherIcon(k.removePrefix("app:"), size)?.let { iconCache[iconKey(k.removePrefix("app:"), size)] = it }
            }
        }
    }

    private fun buildAndShow() {
        if (panel != null || !Settings.canDrawOverlays(this)) return
        closing = false
        val s = screen()
        val sw = s.width(); val sh = s.height()
        val right = i("side", 0) == 0
        val cols = i("cols", 2).coerceIn(1, 5)
        val iconPx = px(i("iconSize", 44))
        val labels = PanelPrefs.b(this, "labels", true)
        val labelSp = i("labelSp", 11).toFloat()
        val itemW = iconPx + px(28)
        val itemH = iconPx + (if (labels) ((labelSp * 1.5f + 6) * d).toInt() else 0) + px(16)
        val pad = px(i("pad", 10))
        val gap = px(i("edgeGap", 8))
        val corner = i("corner", 24) * d
        val keys = panelItems()
        val sliderH = px(56)
        val gridW = cols * itemW
        val cBg = i("cBg", 0xFF1E1E1E.toInt())
        val bgA = (Color.alpha(cBg) * i("bgAlpha", 85) / 100).coerceIn(0, 255)
        val cLabel = i("cLabel", 0xFFFFFFFF.toInt())
        val cAccent = i("cAccent", 0xFFE0B25A.toInt())

        val root = PanelRoot(this)
        root.isFocusable = true
        root.isFocusableInTouchMode = true
        var rx = 0f
        var ry = 0f
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        root.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { rx = e.rawX; ry = e.rawY }
                MotionEvent.ACTION_UP -> {
                    val dx = e.rawX - rx
                    val toward = if (right) dx else -dx
                    if (abs(dx) < slop && abs(e.rawY - ry) < slop || toward > 40 * d) close()
                }
            }
            true
        }

        val scrim = View(this)
        scrim.setBackgroundColor(Color.argb(255 * i("dim", 25) / 100, 0, 0, 0))
        scrim.alpha = 0f
        root.addView(scrim, FrameLayout.LayoutParams(-1, -1))

        val card = SwipeCard(this)
        card.isClickable = true
        card.background = GradientDrawable().apply {
            setColor(Color.argb(bgA, Color.red(cBg), Color.green(cBg), Color.blue(cBg)))
            cornerRadius = corner
            val bw = i("border", 0)
            if (bw > 0) setStroke(max(1, (bw * d).toInt()), cAccent)
        }
        card.elevation = 10 * d
        card.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, corner)
            }
        }
        card.clipToOutline = true

        val scroll = ScrollView(this)
        scroll.isVerticalScrollBarEnabled = false
        scroll.overScrollMode = View.OVER_SCROLL_NEVER
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(pad, pad, pad, pad)
        var totalH = 0
        if (keys.isEmpty()) {
            val t = TextView(this)
            t.text = "Nothing here yet. Add apps and tools in Settings, Panels."
            t.setTextColor(cLabel)
            t.textSize = 13f
            t.gravity = Gravity.CENTER
            col.addView(t, LinearLayout.LayoutParams(px(200), itemH))
            totalH = itemH
        } else {
            var row: LinearLayout? = null
            var inRow = 0
            val groups: List<List<String>> = if (i("arrange", 0) == 1) {
                val apps = keys.filter { PanelPrefs.tool(it) == null }
                val small = keys.filter { PanelPrefs.tool(it)?.kind != 1 && PanelPrefs.tool(it) != null }
                val sliders = keys.filter { PanelPrefs.tool(it)?.kind == 1 }
                if (i("toolsPos", 0) == 1) listOf(small, sliders, apps) else listOf(apps, small, sliders)
            } else listOf(keys)
            for (group in groups) {
                row = null
                inRow = 0
                for (key in group) {
                    val tool = PanelPrefs.tool(key)
                    if (tool != null && tool.kind == 1) {
                        row = null
                        inRow = 0
                        col.addView(sliderRow(key, tool, gridW, iconPx, cLabel, cAccent), LinearLayout.LayoutParams(gridW, sliderH))
                        totalH += sliderH
                        continue
                    }
                    if (row == null || inRow >= cols) {
                        val nr = LinearLayout(this)
                        nr.orientation = LinearLayout.HORIZONTAL
                        col.addView(nr, LinearLayout.LayoutParams(-2, itemH))
                        row = nr
                        inRow = 0
                        totalH += itemH
                    }
                    row!!.addView(tile(key, itemW, iconPx, labels, labelSp, cLabel, cAccent), LinearLayout.LayoutParams(itemW, itemH))
                    inRow++
                }
            }
        }
        scroll.addView(col, FrameLayout.LayoutParams(-1, -2))
        card.addView(scroll, FrameLayout.LayoutParams(-1, -1))

        val contentH = totalH + 2 * pad
        val maxH = (sh * i("maxH", 80) / 100 - px(48)).coerceAtLeast(px(120))
        val cardH = min(contentH, maxH)
        val cardW = if (keys.isEmpty()) px(220) else gridW + 2 * pad

        val handleLen = px(i("handleLen", 96)).coerceAtMost(sh / 2)
        val hv = handle
        val centerY = if (hv != null && hv.isAttachedToWindow && hv.height > 0) {
            val loc = IntArray(2)
            hv.getLocationOnScreen(loc)
            loc[1] + hv.height / 2
        } else handleTop(sh, handleLen) + handleLen / 2
        val lo = px(8)
        val hi = (sh - cardH - px(8)).coerceAtLeast(lo)
        val top = when (i("align", 0)) {
            1 -> (sh - cardH) / 2
            2 -> lo
            else -> centerY - cardH / 2
        }.coerceIn(lo, hi)
        val clp = FrameLayout.LayoutParams(cardW, cardH, Gravity.TOP or (if (right) Gravity.RIGHT else Gravity.LEFT))
        clp.topMargin = top
        if (right) clp.rightMargin = gap else clp.leftMargin = gap
        root.addView(card, clp)

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            title = "Kvx panel"
            if (Build.VERSION.SDK_INT >= 30) layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        }
        val blurPx = px(i("blur", 20))
        val canBlur = Build.VERSION.SDK_INT >= 31 && blurPx > 0 && wm.isCrossWindowBlurEnabled
        if (canBlur) {
            lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
            lp.blurBehindRadius = blurPx
        }
        try { wm.addView(root, lp) } catch (e: Exception) { return }
        panel = root
        panelLp = lp
        root.requestFocus()

        val dur = i("animMs", 220).toLong()
        val kind = i("anim", 0)
        val off = (cardW + gap).toFloat() * (if (right) 1 else -1)
        card.pivotX = if (right) cardW.toFloat() else 0f
        card.pivotY = cardH / 2f
        when (kind) {
            0 -> card.translationX = off
            1 -> { card.alpha = 0f; card.scaleX = 0.9f; card.scaleY = 0.9f }
            else -> { card.alpha = 0f; card.scaleX = 0.5f; card.scaleY = 0.5f }
        }
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = dur
            interpolator = if (kind == 2) OvershootInterpolator(1.2f) else DecelerateInterpolator(1.6f)
            addUpdateListener {
                val f = it.animatedValue as Float
                when (kind) {
                    0 -> card.translationX = off * (1f - f)
                    1 -> { card.alpha = f.coerceIn(0f, 1f); card.scaleX = 0.9f + 0.1f * f; card.scaleY = 0.9f + 0.1f * f }
                    else -> { card.alpha = f.coerceIn(0f, 1f); card.scaleX = 0.5f + 0.5f * f; card.scaleY = 0.5f + 0.5f * f }
                }
                scrim.alpha = f.coerceIn(0f, 1f)
            }
            start()
        }
    }

    /** Swaps in the icon the launcher itself shows (icon pack, custom icon, shape), if it can be drawn. */
    private fun loadLauncherIcon(pkg: String, img: ImageView, size: Int, cBg: Int, cAccent: Int) {
        scope.launch {
            try {
                val app = appRepository.findOne(pkg, android.os.Process.myUserHandle()).firstOrNull() ?: return@launch
                val icon = iconService.getIcon(app, size).firstOrNull { it != null } as? StaticLauncherIcon ?: return@launch
                val bmp = icon.render(
                    LauncherIconRenderSettings(
                        size = size,
                        fgThemeColor = cBg or 0xFF000000.toInt(),
                        bgThemeColor = cAccent or 0xFF000000.toInt(),
                        fgTone = 10,
                        bgTone = 90,
                    )
                )
                img.setImageBitmap(bmp)
            } catch (e: Exception) {}
        }
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    private fun customIcon(key: String): android.graphics.Bitmap? {
        val f = PanelPrefs.iconFile(this, key)
        return if (f.exists()) BitmapFactory.decodeFile(f.path) else null
    }

    private fun toggleOn(tool: PanelPrefs.Tool): Boolean = when (tool.id) {
        "rotate" -> Settings.System.getInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION, 0) == 1
        "flash" -> torchOn
        else -> false
    }

    private fun toolColor(tool: PanelPrefs.Tool, on: Boolean, cLabel: Int, cAccent: Int): Int {
        val own = i("t_${tool.id}_color", 0)
        val onC = i("t_${tool.id}_on", 0)
        return if (on && onC != 0) onC else if (on && tool.kind == 0) cAccent else if (own != 0) own else cLabel
    }

    private fun paintTool(img: ImageView, tool: PanelPrefs.Tool, custom: Boolean, cLabel: Int, cAccent: Int) {
        val on = tool.kind != 0 || toggleOn(tool)
        val isOn = tool.kind == 0 && on
        img.alpha = if (tool.kind == 0 && !on) 0.6f else 1f
        if (custom) img.clearColorFilter() else img.setColorFilter(toolColor(tool, isOn, cLabel, cAccent))
        val bg = i("t_${tool.id}_bg", 0)
        val bgOn = i("t_${tool.id}_bgOn", 0)
        val c = if (isOn && bgOn != 0) bgOn else bg
        if (c != 0) {
            val sh = i("iconShape", 0)
            img.background = GradientDrawable().apply {
                setColor(c)
                cornerRadius = if (sh == 2 || sh == 0) 0.26f * img.layoutParams.width else img.layoutParams.width / 2f
            }
        } else img.background = null
    }

    private fun needWrite(): Boolean {
        if (Settings.System.canWrite(this)) return false
        toast("Allow \"Modify system settings\" for Kvaesitso X first")
        close()
        try {
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {}
        return true
    }

    private fun runTool(tool: PanelPrefs.Tool, img: ImageView, custom: Boolean, cLabel: Int, cAccent: Int) {
        when (tool.id) {
            "rotate" -> {
                if (needWrite()) return
                val on = toggleOn(tool)
                try { Settings.System.putInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION, if (on) 0 else 1) } catch (e: Exception) { toast("Couldn't change rotation") }
                paintTool(img, tool, custom, cLabel, cAccent)
            }
            "flash" -> {
                try {
                    val cm = getSystemService(CameraManager::class.java)
                    val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
                    if (id == null) toast("No flashlight found") else {
                        cm.setTorchMode(id, !torchOn)
                        torchOn = !torchOn
                        paintTool(img, tool, custom, cLabel, cAccent)
                    }
                } catch (e: Exception) { toast("Couldn't use the flashlight") }
            }
            "net" -> {
                close()
                val i = if (Build.VERSION.SDK_INT >= 29) Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY) else Intent(Settings.ACTION_WIRELESS_SETTINGS)
                try { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) {}
            }
            "bt" -> {
                close()
                try { startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) {}
            }
        }
    }

    private fun tile(key: String, w: Int, iconPx: Int, labels: Boolean, labelSp: Float, cLabel: Int, cAccent: Int): View {
        val pm = packageManager
        val tool = PanelPrefs.tool(key)
        val pkg = key.removePrefix("app:")
        val v = LinearLayout(this)
        v.orientation = LinearLayout.VERTICAL
        v.gravity = Gravity.CENTER
        val mask = GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = 14 * d }
        v.background = RippleDrawable(ColorStateList.valueOf(Color.argb(90, Color.red(cAccent), Color.green(cAccent), Color.blue(cAccent))), null, mask)
        val img = ImageView(this)
        img.layoutParams = LinearLayout.LayoutParams(iconPx, iconPx)
        val custom = customIcon(key)
        if (custom != null) img.setImageBitmap(custom)
        else if (tool != null) img.setImageResource(tool.icon)
        else try { img.setImageDrawable(pm.getApplicationIcon(pkg)) } catch (e: Exception) {}
        if (tool == null && custom == null && PanelPrefs.b(this, "launcherIcons", true)) {
            val cached = iconCache[iconKey(pkg, iconPx)]
            if (cached != null) img.setImageBitmap(cached)
            else loadLauncherIcon(pkg, img, iconPx, cBg = i("cBg", 0xFF1E1E1E.toInt()), cAccent = cAccent)
        }
        if (tool != null) {
            if (custom == null) { val pd = (iconPx * (100 - i("t_${tool.id}_scale", 70)) / 200f).toInt().coerceAtLeast(0); img.setPadding(pd, pd, pd, pd) }
            paintTool(img, tool, custom != null, cLabel, cAccent)
        }
        val shape = i("iconShape", 0)
        if (shape != 0) {
            img.outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    val r = if (shape == 1) view.width / 2f else view.width * 0.26f
                    outline.setRoundRect(0, 0, view.width, view.height, r)
                }
            }
            img.clipToOutline = true
        }
        v.addView(img, LinearLayout.LayoutParams(iconPx, iconPx))
        if (labels) {
            val t = TextView(this)
            t.text = tool?.label ?: try { pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)) } catch (e: Exception) { pkg }
            t.setTextColor(cLabel)
            t.textSize = labelSp
            t.maxLines = 1
            t.ellipsize = TextUtils.TruncateAt.END
            t.gravity = Gravity.CENTER
            t.setPadding(px(2), px(3), px(2), 0)
            v.addView(t, LinearLayout.LayoutParams(w - px(4), LinearLayout.LayoutParams.WRAP_CONTENT))
        }
        v.setOnClickListener {
            if (PanelPrefs.b(this, "haptic", true)) v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            if (tool != null) { runTool(tool, img, custom != null, cLabel, cAccent); return@setOnClickListener }
            val intent = pm.getLaunchIntentForPackage(pkg)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (PanelPrefs.b(this, "closeOnLaunch", true)) close()
            if (intent != null) try { startActivity(intent) } catch (e: Exception) {}
        }
        if (tool == null) {
            v.setOnLongClickListener {
                close()
                try {
                    startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (e: Exception) {}
                true
            }
        }
        return v
    }

    private fun sliderRow(key: String, tool: PanelPrefs.Tool, w: Int, iconPx: Int, cLabel: Int, cAccent: Int): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(px(6), 0, px(6), 0)
        val img = ImageView(this)
        val custom = customIcon(key)
        if (custom != null) img.setImageBitmap(custom) else { img.setImageResource(tool.icon); img.setColorFilter(cLabel) }
        val sz = min(iconPx, px(32))
        row.addView(img, LinearLayout.LayoutParams(sz, sz))
        val sb = SeekBar(this)
        sb.max = 1000
        val am = getSystemService(AudioManager::class.java)
        val vmax = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        sb.progress = if (tool.id == "bright") {
            (linearToGamma(Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128) / 255f) * 1000f).toInt()
        } else am.getStreamVolume(AudioManager.STREAM_MUSIC) * 1000 / vmax
        sb.progressTintList = ColorStateList.valueOf(cAccent)
        sb.thumbTintList = ColorStateList.valueOf(cAccent)
        sb.progressBackgroundTintList = ColorStateList.valueOf(Color.argb(90, Color.red(cLabel), Color.green(cLabel), Color.blue(cLabel)))
        sb.setOnTouchListener { v, _ -> v.parent?.requestDisallowInterceptTouchEvent(true); false }
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                if (tool.id == "bright") {
                    if (needWrite()) return
                    val b = (gammaToLinear(progress / 1000f) * 255f).roundToInt().coerceIn(1, 255)
                    try {
                        Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                        Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, b)
                    } catch (e: Exception) {}
                } else {
                    try { am.setStreamVolume(AudioManager.STREAM_MUSIC, (progress / 1000f * vmax).roundToInt(), 0) } catch (e: Exception) {}
                }
            }
            override fun onStartTrackingTouch(bar: SeekBar) {}
            override fun onStopTrackingTouch(bar: SeekBar) {}
        })
        row.addView(sb, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        return row
    }

    private fun closeNow() {
        val p = panel ?: return
        panel = null
        panelLp = null
        closing = false
        try { wm.removeViewImmediate(p) } catch (e: Exception) {}
    }

    private fun close() {
        val p = panel ?: return
        if (closing) return
        closing = true
        val card = p.getChildAt(1)
        val scrim = p.getChildAt(0)
        val right = i("side", 0) == 0
        val kind = i("anim", 0)
        val dur = (i("animMs", 220) * 0.8f).toLong()
        val off = ((card?.width ?: 0) + px(i("edgeGap", 8))).toFloat() * (if (right) 1 else -1)
        val lp = panelLp
        val startT = card?.translationX ?: 0f
        val startBlur = lp?.blurBehindRadius ?: 0
        ValueAnimator.ofFloat(1f, 0f).apply {
            duration = dur
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                val f = it.animatedValue as Float
                if (card != null) when (kind) {
                    0 -> card.translationX = startT + (off - startT) * (1f - f)
                    else -> { card.alpha = f; card.scaleX = 0.9f + 0.1f * f; card.scaleY = 0.9f + 0.1f * f }
                }
                scrim?.alpha = f
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) { if (panel === p) closeNow() }
            })
            start()
        }
    }
}

// Android's own brightness slider is not linear: it uses this curve (same maths as the system's BrightnessUtils),
// so the panel slider only lines up with the real brightness if it uses it too.
private const val BR_R = 0.5f
private const val BR_A = 0.17883277f
private const val BR_B = 0.28466892f
private const val BR_C = 0.55991073f

private fun gammaToLinear(g: Float): Float {
    val n = g.coerceIn(0f, 1f)
    val r = if (n <= BR_R) (n / BR_R) * (n / BR_R) else kotlin.math.exp((n - BR_C) / BR_A) + BR_B
    return (r / 12f).coerceIn(0f, 1f)
}

private fun linearToGamma(l: Float): Float {
    val n = l.coerceIn(0f, 1f) * 12f
    val r = if (n <= 1f) kotlin.math.sqrt(n) * BR_R else BR_A * kotlin.math.ln(n - BR_B) + BR_C
    return r.coerceIn(0f, 1f)
}
