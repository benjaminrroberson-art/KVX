package de.mm20.launcher2.ui.launcher.widgets.facesclock

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import de.mm20.launcher2.ui.component.preferences.ListPreference
import de.mm20.launcher2.ui.component.preferences.Preference
import de.mm20.launcher2.ui.component.preferences.SliderPreference
import de.mm20.launcher2.ui.component.preferences.SwitchPreference
import de.mm20.launcher2.widgets.FacesClockWidget
import de.mm20.launcher2.widgets.FacesClockWidgetConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private val swatches = listOf(
    "White" to 0xFFFFFFFF.toInt(), "Black" to 0xFF000000.toInt(), "Grey" to 0xFF9AA0A6.toInt(),
    "Red" to 0xFFFF4D4D.toInt(), "Orange" to 0xFFFF9500.toInt(), "Amber" to 0xFFFFC107.toInt(),
    "Yellow" to 0xFFFFD60A.toInt(), "Green" to 0xFF34C759.toInt(), "Teal" to 0xFF2BB5A0.toInt(),
    "Cyan" to 0xFF32D4F0.toInt(), "Blue" to 0xFF4D9BFF.toInt(), "Indigo" to 0xFF5B6CFF.toInt(),
    "Purple" to 0xFFBF5AF2.toInt(), "Pink" to 0xFFFF6FA8.toInt(),
)

@Composable
private fun ColorPref(title: String, value: Int, extra: List<Pair<String, Int>> = emptyList(), onChange: (Int) -> Unit) {
    val all = extra + swatches
    ListPreference(
        title = title,
        items = all,
        value = value,
        summary = all.firstOrNull { it.second == value }?.first ?: "Custom",
        onValueChanged = onChange,
    )
}

@Composable
private fun Group(title: String, content: @Composable () -> Unit) {
    Text(
        text = title,
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 20.dp, bottom = 8.dp, start = 4.dp),
    )
    OutlinedCard { Column { content() } }
}

@Composable
fun ConfigureFacesClockWidget(
    widget: FacesClockWidget,
    onWidgetUpdated: (FacesClockWidget) -> Unit,
) {
    val context = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val cfg = remember(widget.config.clock) { parseClockCfg(widget.config.clock) }
    val name = ClockStyles.at(cfg.style).name
    val analog = name in ClockStyles.analogFaces
    val digitalOn = analog && cfg.digital != 0
    val kind = ClockStyles.secEff(cfg)
    var showGallery by remember { mutableStateOf(false) }

    fun upd(block: ClockCfg.() -> Unit) {
        val c2 = ClockCfg.fromJson(cfg.toJson())
        c2.block()
        onWidgetUpdated(widget.copy(config = FacesClockWidgetConfig(c2.toJson().toString())))
    }

    OutlinedCard {
        Preference(
            title = "Face",
            summary = "${cfg.style + 1} of ${ClockStyles.names.size} · $name",
            onClick = { showGallery = true },
        )
    }

    val showsTime = name in ClockStyles.timeFaces || digitalOn || name in setOf("Tape", "Day arc", "Dashboard", "Nightstand")
    val showsDate = name in ClockStyles.dateFaces
    if (showsTime || showsDate || name == "Dual" || name == "World") {
        Group("Time and date") {
            if (showsTime) SwitchPreference(title = "24-hour time", value = cfg.h24, onValueChanged = { v -> upd { h24 = v } })
            if (showsTime && !cfg.h24 && (name in ClockStyles.ampmFaces || digitalOn)) SwitchPreference(title = "Show AM/PM", value = cfg.ampm, onValueChanged = { v -> upd { ampm = v } })
            if (showsTime && !cfg.h24 && name != "Tape" && (name in ClockStyles.timeFaces || digitalOn)) SwitchPreference(title = "Leading zero on the hour", value = cfg.zero, onValueChanged = { v -> upd { zero = v } })
            if (showsDate) SwitchPreference(title = "Show date", value = cfg.date, onValueChanged = { v -> upd { date = v } })
            if (showsDate && name in ClockStyles.dateStrFaces) {
                val labels = if (name == "Weather card") listOf("November 14", "14 November", "11/14") else listOf("Saturday, Nov 14", "Saturday, 14 Nov", "Saturday 11/14")
                ListPreference(title = "Date style", items = labels.mapIndexed { i, s -> s to i }, value = cfg.dateFmt, onValueChanged = { v -> upd { dateFmt = v } })
            }
            if (name == "Dual" || name == "World") {
                val zones = listOf("Europe/London", "Europe/Paris", "Europe/Berlin", "Asia/Tokyo", "Asia/Kolkata", "Asia/Dubai", "Australia/Sydney", "America/New_York", "America/Chicago", "America/Denver", "America/Los_Angeles", "UTC")
                ListPreference(title = "Second time zone", items = zones.map { it.substringAfterLast('/').replace('_', ' ') to it }, value = cfg.tz2, onValueChanged = { v -> upd { tz2 = v } })
            }
        }
    }

    val fo = ClockStyles.faceOpts[name]
    if (fo != null) {
        Group("$name details") {
            for (o in fo) {
                val key = "$name." + o.key
                val cur = cfg.opts[key] ?: o.def
                if (o.kind == 0) {
                    SwitchPreference(title = o.label, value = cur != 0, onValueChanged = { v -> upd { opts[key] = if (v) 1 else 0 } })
                } else {
                    SliderPreference(
                        title = o.label, value = cur, min = o.min, max = o.max,
                        onValueChanged = { v -> upd { opts[key] = v } },
                        label = { Text(it.toString() + o.unit) },
                    )
                }
            }
        }
    }

    if (analog) {
        Group("Digital time") {
            ListPreference(
                title = "Digital time",
                items = listOf("Off" to 0, "Below the dial" to 1, "Above the dial" to 2),
                value = cfg.digital,
                onValueChanged = { v -> upd { digital = v } },
            )
            if (cfg.digital != 0) {
                val styles = listOf("Plain", "Soft pill", "Outline pill", "Accent pill", "Bold", "Thin and spaced", "Split pills", "Dot colon", "Time and date", "Monospace", "Underline", "Two tone")
                ListPreference(title = "Style", items = styles.mapIndexed { i, s -> s to i }, value = cfg.digStyle, onValueChanged = { v -> upd { digStyle = v } })
                SliderPreference(title = "Size", value = cfg.digSize, min = 60, max = 140, onValueChanged = { v -> upd { digSize = v } }, label = { Text("$it%") })
                ColorPref("Color", cfg.digCol, listOf("Theme" to 0)) { v -> upd { digCol = v } }
            }
        }
    }

    Group("Padding") {
        PaddingControls(cfg.padT, cfg.padB, cfg.padL, cfg.padR) { t, b, l, r -> upd { padT = t; padB = b; padL = l; padR = r } }
    }

    Group("Seconds") {
        SwitchPreference(title = "Show seconds", value = cfg.sec, onValueChanged = { v -> upd { sec = v } })
        if (cfg.sec) {
            val ch = ClockStyles.secChoices(cfg.style)
            ListPreference(
                title = "Seconds style",
                items = ch.mapIndexed { i, v -> (ClockStyles.secName(v) + (if (i == 0) " (matches this face)" else "")) to (if (i == 0) 0 else v) },
                value = if (cfg.secStyle != 0 && cfg.secStyle in ch) cfg.secStyle else 0,
                onValueChanged = { v -> upd { secStyle = v } },
            )
            SwitchPreference(
                title = "Smooth motion",
                summary = "Redraws every frame so it glides. Off: it steps once a second.",
                value = cfg.smooth,
                onValueChanged = { v -> upd { smooth = v } },
            )
            ColorPref("Seconds color", cfg.secCol) { v -> upd { secCol = v } }
            SliderPreference(
                title = when (kind) { 1 -> "Hand thickness"; 7 -> "Badge ring weight"; else -> "Marker size" },
                value = cfg.secW, min = 50, max = 250,
                onValueChanged = { v -> upd { secW = v } },
                label = { Text("$it%") },
            )
            if (kind == 1) SwitchPreference(title = "Counterweight on the tail", value = cfg.secDot, onValueChanged = { v -> upd { secDot = v } })
            if (kind == 7) SwitchPreference(title = "Digits in the badge", value = cfg.secDigits, onValueChanged = { v -> upd { secDigits = v } })
        }
    }

    Group("Look") {
        SliderPreference(title = "Face size", value = cfg.scale, min = 60, max = 130, onValueChanged = { v -> upd { scale = v } }, label = { Text("$it%") })
        if (name in ClockStyles.depthFaces) SliderPreference(title = "Shadow depth", value = cfg.depth, min = 0, max = 200, onValueChanged = { v -> upd { depth = v } }, label = { Text("$it%") })
        if (name in ClockStyles.handFaces) SliderPreference(title = "Hand thickness", value = cfg.handScale, min = 50, max = 200, onValueChanged = { v -> upd { handScale = v } }, label = { Text("$it%") })
        val fonts = remember {
            val l = ArrayList<Pair<String, String>>()
            for ((key, label) in FontStore.builtin) l.add(label to key)
            for (f in FontStore.uploaded(context)) l.add(f.substringBeforeLast('.') to "file:$f")
            l.toList()
        }
        ListPreference(
            title = "Clock font",
            items = fonts,
            value = cfg.font,
            summary = fonts.firstOrNull { it.second == cfg.font }?.first ?: cfg.font,
            onValueChanged = { v -> upd { font = v } },
        )
        SwitchPreference(
            title = "Custom colors",
            summary = "Off: the faces follow the launcher's color theme.",
            value = cfg.custom,
            onValueChanged = { v ->
                upd {
                    if (v && !custom) {
                        cText = cs.onSurface.toArgb()
                        cAccent = cs.primary.toArgb()
                        cBase = cs.surface.toArgb()
                        cFace = cs.surfaceVariant.toArgb()
                        cMuted = (cs.onSurface.toArgb() and 0x00FFFFFF) or (150 shl 24)
                        cHour = cs.onSurface.toArgb()
                        cMin = cs.primary.toArgb()
                    }
                    custom = v
                }
            },
        )
        if (cfg.custom) {
            ColorPref("Text", cfg.cText) { v -> upd { cText = v } }
            ColorPref("Accent", cfg.cAccent) { v -> upd { cAccent = v } }
            ColorPref("Background", cfg.cBase) { v -> upd { cBase = v } }
            ColorPref("Face", cfg.cFace) { v -> upd { cFace = v } }
            ColorPref("Muted text", cfg.cMuted) { v -> upd { cMuted = v } }
            if (name in ClockStyles.handFaces) {
                ColorPref("Hour hand", cfg.cHour) { v -> upd { cHour = v } }
                ColorPref("Minute hand", cfg.cMin) { v -> upd { cMin = v } }
            }
        }
    }

    if (showGallery) {
        FacePickerDialog(
            current = cfg,
            onPick = { i ->
                upd { style = i }
                showGallery = false
            },
            onDismiss = { showGallery = false },
        )
    }
}

@Composable
private fun FacePickerDialog(current: ClockCfg, onPick: (Int) -> Unit, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val colors = MaterialTheme.colorScheme
    val st = remember(colors.onSurface, colors.primary, colors.surface) {
        Style().apply {
            colorMode = 1
            text = colors.onSurface.toArgb()
            accent = colors.primary.toArgb()
            bg = colors.surface.toArgb()
        }
    }
    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = MaterialTheme.shapes.extraLarge, tonalElevation = 6.dp) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Choose a face", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(bottom = 12.dp))
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    itemsIndexed(ClockStyles.names) { i, faceName ->
                        val thumb by produceState<ImageBitmap?>(null, i, st) {
                            value = withContext(Dispatchers.Default) {
                                val c2 = ClockCfg.fromJson(current.toJson())
                                c2.style = i
                                c2.sec = false
                                ClockRenderer.render(context, st, c2, 240, 240, true).asImageBitmap()
                            }
                        }
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.clickable { onPick(i) },
                        ) {
                            Box(modifier = Modifier.fillMaxWidth().aspectRatio(1f)) {
                                thumb?.let { Image(it, null, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxWidth()) }
                            }
                            Text(
                                text = "${i + 1} $faceName",
                                style = MaterialTheme.typography.labelSmall,
                                textAlign = TextAlign.Center,
                                maxLines = 1,
                            )
                        }
                    }
                }
            }
        }
    }
}
