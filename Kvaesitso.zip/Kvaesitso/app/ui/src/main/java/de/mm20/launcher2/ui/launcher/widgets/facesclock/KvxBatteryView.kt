package de.mm20.launcher2.ui.launcher.widgets.facesclock

import android.Manifest
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.BatteryManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import de.mm20.launcher2.ui.R
import de.mm20.launcher2.ui.component.preferences.ListPreference
import de.mm20.launcher2.ui.component.preferences.Preference
import de.mm20.launcher2.ui.component.preferences.SliderPreference
import de.mm20.launcher2.ui.component.preferences.SwitchPreference
import de.mm20.launcher2.widgets.KvxBatteryWidget
import de.mm20.launcher2.widgets.KvxBatteryWidgetConfig
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin
import kotlin.math.cos
import kotlin.math.ceil
import kotlin.math.roundToInt
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.sp

private class Batt(val pct: Int, val charging: Boolean, val watts: Float?, val minutes: Long?)
private class Dev(val name: String, val pct: Int, val kind: Int)

@Composable
private fun rememberBattery(): Batt {
    val context = LocalContext.current
    var b by remember { mutableStateOf(readBattery(context, null)) }
    DisposableEffect(Unit) {
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) { b = readBattery(c, i) }
        }
        val sticky = context.registerReceiver(r, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        b = readBattery(context, sticky)
        onDispose { context.unregisterReceiver(r) }
    }
    return b
}

private fun readBattery(c: Context, i: Intent?): Batt {
    val intent = i ?: c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
    val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
    val status = intent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
    val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
    val bm = c.getSystemService(BatteryManager::class.java)
    var watts: Float? = null
    var mins: Long? = null
    try {
        val ua = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
        val mv = intent?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) ?: 0
        if (charging && ua != 0L && mv > 0) watts = abs(ua) / 1_000_000f * mv / 1000f
        if (Build.VERSION.SDK_INT >= 28 && charging) {
            val ms = bm.computeChargeTimeRemaining()
            if (ms > 0) mins = ms / 60000L
        }
    } catch (e: Exception) {
    }
    return Batt((level * 100f / scale).toInt().coerceIn(0, 100), charging, watts, mins)
}

private fun deviceBatteries(c: Context): List<Dev> {
    if (Build.VERSION.SDK_INT >= 31 && c.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) return emptyList()
    return try {
        val adapter = c.getSystemService(BluetoothManager::class.java)?.adapter ?: return emptyList()
        adapter.bondedDevices.mapNotNull { d: BluetoothDevice ->
            val connected = try { BluetoothDevice::class.java.getMethod("isConnected").invoke(d) as Boolean } catch (e: Exception) { false }
            if (!connected) return@mapNotNull null
            val lvl = try { BluetoothDevice::class.java.getMethod("getBatteryLevel").invoke(d) as Int } catch (e: Exception) { -1 }
            if (lvl !in 0..100) return@mapNotNull null
            val major = d.bluetoothClass?.majorDeviceClass ?: 0
            Dev(d.name ?: "Device", lvl, if (major == 0x400) 1 else if (major == 0x700) 2 else 0)
        }
    } catch (e: Exception) {
        emptyList()
    }
}

@Composable
fun KvxBatteryView(widget: KvxBatteryWidget) = KvxBatteryBody(widget.config)

@Composable
fun KvxBatteryBody(cfg: KvxBatteryWidgetConfig) {
    val context = LocalContext.current
    val batt = rememberBattery()
    var devs by remember { mutableStateOf<List<Dev>>(emptyList()) }
    LaunchedEffect(cfg.devices) {
        while (cfg.devices) { devs = deviceBatteries(context); delay(30_000L) }
    }
    val fg = MaterialTheme.colorScheme.onSurface
    val color = when (cfg.colorMode) {
        1 -> Color(cfg.fixedColor)
        2 -> when { batt.pct <= cfg.lowAt / 2 -> Color(0xFFE24B4A); batt.pct <= cfg.lowAt -> Color(0xFFEF9F27); else -> Color(0xFF1D9E75) }
        else -> MaterialTheme.colorScheme.primary
    }
    val track = fg.copy(alpha = 0.16f)
    val t = rememberInfiniteTransition(label = "batt")
    val anim by t.animateFloat(0f, 1f, infiniteRepeatable(tween(if (cfg.charge == 2) 1600 else 1100, easing = LinearEasing), RepeatMode.Restart), label = "a")
    val pulse by t.animateFloat(0.55f, 1f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "p")
    val charging = batt.charging && cfg.charge != 0
    val fillColor = if (charging && cfg.charge == 1) color.copy(alpha = pulse) else color
    val frac = batt.pct / 100f

    Column(
        Modifier.fillMaxWidth().padding(start = 12.dp + cfg.padStart.dp, top = 12.dp + cfg.padTop.dp, end = 12.dp + cfg.padEnd.dp, bottom = 12.dp + cfg.padBottom.dp),
    ) {
        val info = buildList {
            if (cfg.showPower && batt.charging) batt.watts?.let { add("%.1f W".format(it)) }
            if (cfg.showTime && batt.charging) batt.minutes?.let { add(if (it >= 60) "${it / 60} h ${it % 60} min to full" else "$it min to full") }
        }.joinToString("  ·  ")

        val s = Sty(batt.pct, frac, fillColor, track, fg, charging, cfg.charge, anim, pulse, info, batt.charging, cfg.charge == 3 && batt.charging)
        when (cfg.style) {
            0 -> Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(96.dp), contentAlignment = Alignment.Center) {
                    Canvas(Modifier.size(96.dp)) {
                        val sw = 10.dp.toPx()
                        val d = size.minDimension - sw
                        val tl = Offset(sw / 2, sw / 2)
                        drawArc(track, 0f, 360f, false, tl, Size(d, d), style = Stroke(sw, cap = StrokeCap.Round))
                        drawArc(fillColor, -90f, 360f * frac, false, tl, Size(d, d), style = Stroke(sw, cap = StrokeCap.Round))
                        if (charging && cfg.charge == 2) {
                            val sweep = 360f * frac
                            val start = -90f + (sweep - 30f).coerceAtLeast(0f) * anim
                            drawArc(Color.White.copy(alpha = 0.55f), start, minOf(30f, sweep), false, tl, Size(d, d), style = Stroke(sw, cap = StrokeCap.Round))
                        }
                    }
                    Text("${batt.pct}%", style = MaterialTheme.typography.titleLarge, color = fg)
                }
                Column(Modifier.padding(start = 16.dp)) {
                    Text(if (batt.charging) "Charging" else "On battery", style = MaterialTheme.typography.titleMedium, color = fg)
                    if (info.isNotEmpty()) Text(info, style = MaterialTheme.typography.bodyMedium, color = fg.copy(alpha = 0.7f))
                }
            }
            1 -> Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (batt.charging && cfg.charge == 3) Icon(painterResource(R.drawable.bolt_24px), null, tint = color.copy(alpha = pulse), modifier = Modifier.padding(end = 6.dp))
                    Canvas(Modifier.weight(1f).height(24.dp)) {
                        val r = CornerRadius(size.height / 2, size.height / 2)
                        drawRoundRect(track, size = size, cornerRadius = r)
                        val w = size.width * frac
                        drawRoundRect(fillColor, size = Size(w, size.height), cornerRadius = r)
                        if (charging && cfg.charge == 2 && w > 20f) {
                            val x = (w + 60f) * anim - 60f
                            val x0 = x.coerceAtLeast(0f); val x1 = (x + 60f).coerceAtMost(w)
                            if (x1 > x0) drawRoundRect(Brush.horizontalGradient(listOf(Color.Transparent, Color.White.copy(alpha = 0.5f), Color.Transparent), startX = x, endX = x + 60f), topLeft = Offset(x0, 0f), size = Size(x1 - x0, size.height), cornerRadius = r)
                        }
                    }
                    Text("${batt.pct}%", style = MaterialTheme.typography.titleMedium, color = fg, modifier = Modifier.padding(start = 10.dp))
                }
                if (info.isNotEmpty()) Text(info, style = MaterialTheme.typography.bodyMedium, color = fg.copy(alpha = 0.7f), modifier = Modifier.padding(top = 6.dp))
            }
            2 -> Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("${batt.pct}%", style = MaterialTheme.typography.headlineMedium, color = fg)
                    if (batt.charging && cfg.charge == 3) Icon(painterResource(R.drawable.bolt_24px), null, tint = color.copy(alpha = pulse), modifier = Modifier.padding(start = 6.dp))
                }
                val phaseRaw by t.animateFloat(0f, (2 * PI).toFloat(), infiniteRepeatable(tween(if (batt.charging) 900 else 2000, easing = LinearEasing), RepeatMode.Restart), label = "w")
                Canvas(Modifier.fillMaxWidth().height(28.dp)) {
                    val w = size.width; val cy = size.height / 2f
                    val x1 = w * frac
                    drawLine(track, Offset(x1, cy), Offset(w, cy), 4.dp.toPx(), StrokeCap.Round)
                    val path = Path()
                    val amp = 4.dp.toPx(); val wl = 22.dp.toPx()
                    var x = 0f
                    path.moveTo(0f, cy)
                    while (x <= x1) { path.lineTo(x, cy + amp * sin((x / wl) * 2 * PI.toFloat() - phaseRaw)); x += 2f }
                    drawPath(path, fillColor, style = Stroke(4.dp.toPx(), cap = StrokeCap.Round))
                    drawCircle(fillColor, 7.dp.toPx(), Offset(x1, cy))
                }
                if (info.isNotEmpty()) Text(info, style = MaterialTheme.typography.bodyMedium, color = fg.copy(alpha = 0.7f))
            }
            3 -> Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("${batt.pct}%", style = MaterialTheme.typography.headlineMedium, color = fg)
                    if (batt.charging && cfg.charge == 3) Icon(painterResource(R.drawable.bolt_24px), null, tint = color.copy(alpha = pulse), modifier = Modifier.padding(start = 6.dp))
                }
                val on = ((batt.pct + 9) / 10).coerceIn(0, 10)
                Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    for (i in 0 until 10) {
                        val lit = i < on
                        val a = when {
                            lit && charging && cfg.charge == 1 -> pulse
                            charging && cfg.charge == 2 && i == on -> anim
                            else -> 1f
                        }
                        Box(Modifier.weight(1f).height(30.dp).background(if (lit) color.copy(alpha = a) else if (charging && cfg.charge == 2 && i == on) color.copy(alpha = anim * 0.8f) else track, RoundedCornerShape(6.dp)))
                    }
                }
                if (info.isNotEmpty()) Text(info, style = MaterialTheme.typography.bodyMedium, color = fg.copy(alpha = 0.7f), modifier = Modifier.padding(top = 6.dp))
            }
            4 -> BattTickRing(s)
            5 -> BattSunrise(s)
            6 -> BattSlats(s)
            7 -> BattTape(s)
            8 -> BattTickFan(s)
            9 -> BattBarber(s)
            10 -> BattVRuler(s)
            11 -> BattFillType(s)
        }

        if (cfg.devices && devs.isNotEmpty()) {
            Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.SpaceAround) {
                for (d in devs.take(4)) {
                    val dc = if (d.pct <= 15) Color(0xFFE24B4A) else if (d.pct <= cfg.lowAt && cfg.colorMode == 2) Color(0xFFEF9F27) else color
                    DevMini(cfg.style, d, dc, track, fg)
                }
            }
        }
    }
}

@Composable
private fun DevMini(style: Int, d: Dev, col: Color, track: Color, fg: Color) {
    val frac = d.pct.coerceIn(0, 100) / 100f
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(72.dp)) {
        when (style) {
            0, 4, 5, 8 -> Box(Modifier.size(52.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.size(52.dp)) {
                    if (style == 0 || style == 5) {
                        val sw = 5.dp.toPx(); val dd = size.minDimension - sw; val tl = Offset(sw / 2, sw / 2)
                        val (st, sw2) = if (style == 5) 180f to 180f else -90f to 360f
                        drawArc(track, st, sw2, false, tl, Size(dd, dd), style = Stroke(sw, cap = StrokeCap.Round))
                        drawArc(col, st, sw2 * frac, false, tl, Size(dd, dd), style = Stroke(sw, cap = StrokeCap.Round))
                    } else {
                        val n = 20; val lit = (frac * n).toInt()
                        val c = Offset(size.width / 2, size.height / 2); val ro = size.minDimension / 2; val ri = ro - 6.dp.toPx()
                        for (i in 0 until n) {
                            val a = (-90.0 + i * 360.0 / n) * PI / 180.0
                            val dx = kotlin.math.cos(a).toFloat(); val dy = sin(a).toFloat()
                            drawLine(if (i < lit) col else track, Offset(c.x + dx * ri, c.y + dy * ri), Offset(c.x + dx * ro, c.y + dy * ro), 2.dp.toPx(), StrokeCap.Round)
                        }
                    }
                }
                Text("${d.pct}", style = MaterialTheme.typography.labelLarge, color = fg)
            }
            3, 6, 10 -> {
                Text("${d.pct}%", style = MaterialTheme.typography.titleSmall, color = fg)
                val on = ((d.pct + 19) / 20).coerceIn(0, 5)
                Row(Modifier.padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.Bottom) {
                    for (i in 0 until 5) Box(Modifier.width(8.dp).height((10 + i * 4).dp).background(if (i < on) col else track, RoundedCornerShape(2.dp)))
                }
            }
            else -> {
                Text("${d.pct}%", style = MaterialTheme.typography.titleSmall, color = fg)
                Canvas(Modifier.padding(top = 8.dp).fillMaxWidth().height(8.dp)) {
                    val r = CornerRadius(size.height / 2, size.height / 2)
                    drawRoundRect(track, size = size, cornerRadius = r)
                    drawRoundRect(col, size = Size(size.width * frac, size.height), cornerRadius = r)
                }
            }
        }
        Text(d.name, style = MaterialTheme.typography.labelSmall, color = fg.copy(alpha = 0.7f), maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp))
    }
}

@Composable
fun ConfigureKvxBatteryWidget(widget: KvxBatteryWidget, onWidgetUpdated: (KvxBatteryWidget) -> Unit) {
    val c = widget.config
    val context = LocalContext.current
    fun upd(n: KvxBatteryWidgetConfig) = onWidgetUpdated(widget.copy(config = n))
    var granted by remember { mutableStateOf(Build.VERSION.SDK_INT < 31 || context.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    OutlinedCard {
        androidx.compose.foundation.layout.Column {
            ListPreference(title = "Style", items = listOf("Ring" to 0, "Pill bar" to 1, "Wavy" to 2, "Segmented cells" to 3, "Tick ring" to 4, "Sunrise" to 5, "Slats" to 6, "Tape ruler" to 7, "Tick fan" to 8, "Barber pill" to 9, "Vertical ruler" to 10, "Fill type" to 11), value = c.style, onValueChanged = { v -> upd(c.copy(style = v)) })
            ListPreference(title = "Color", items = listOf("Theme" to 0, "Fixed color" to 1, "By charge level" to 2), value = c.colorMode, onValueChanged = { v -> upd(c.copy(colorMode = v)) })
            if (c.colorMode == 1) ColorPreference("Fixed color", c.fixedColor) { v -> upd(c.copy(fixedColor = v)) }
            if (c.colorMode == 2) SliderPreference(title = "Low battery at", value = c.lowAt, min = 10, max = 40, onValueChanged = { v -> upd(c.copy(lowAt = v)) }, label = { Text("$it%") })
            ListPreference(title = "Charging animation", items = listOf("None" to 0, "Pulse" to 1, "Flow" to 2, "Bolt" to 3), value = c.charge, onValueChanged = { v -> upd(c.copy(charge = v)) })
            SwitchPreference(title = "Charging power", summary = "Watts while plugged in", value = c.showPower, onValueChanged = { v -> upd(c.copy(showPower = v)) })
            SwitchPreference(title = "Time to full", value = c.showTime, onValueChanged = { v -> upd(c.copy(showTime = v)) })
            SwitchPreference(title = "Connected devices", summary = "Earbuds, watch and others that report battery", value = c.devices, onValueChanged = { v -> upd(c.copy(devices = v)) })
            if (c.devices && !granted) Preference(title = "Allow Bluetooth access", summary = "Needed to read device batteries", onClick = { launcher.launch(Manifest.permission.BLUETOOTH_CONNECT) })
            PaddingControls(c.padTop, c.padBottom, c.padStart, c.padEnd) { t, b, s, e -> upd(c.copy(padTop = t, padBottom = b, padStart = s, padEnd = e)) }
        }
    }
}


private class Sty(
    val pct: Int, val frac: Float, val fill: Color, val track: Color, val fg: Color,
    val charging: Boolean, val mode: Int, val anim: Float, val pulse: Float,
    val info: String, val plugged: Boolean, val bolt: Boolean,
)

@Composable
private fun BattInfo(s: Sty, modifier: Modifier = Modifier, showPct: Boolean = true) {
    Column(modifier) {
        if (showPct) Row(verticalAlignment = Alignment.CenterVertically) {
            Text("${s.pct}%", style = MaterialTheme.typography.headlineMedium, color = s.fg)
            if (s.bolt) Icon(painterResource(R.drawable.bolt_24px), null, tint = s.fill.copy(alpha = s.pulse), modifier = Modifier.padding(start = 6.dp))
        }
        Text(if (s.plugged) "Charging" else "On battery", style = MaterialTheme.typography.bodyMedium, color = s.fg.copy(alpha = 0.7f))
        if (s.info.isNotEmpty()) Text(s.info, style = MaterialTheme.typography.bodyMedium, color = s.fg.copy(alpha = 0.7f))
    }
}

private fun tickColor(s: Sty, i: Int, lit: Int): Color {
    if (i >= lit) return s.track
    if (!s.charging) return s.fill
    return when (s.mode) {
        1 -> s.fill.copy(alpha = s.pulse)
        2 -> if (abs(i - (s.anim * lit).toInt()) <= 1) Color.White.copy(alpha = 0.85f) else s.fill
        else -> s.fill
    }
}

@Composable
private fun BattTickRing(s: Sty) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(96.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.size(96.dp)) {
                val n = 24
                val lit = (s.frac * n).roundToInt()
                val outer = size.minDimension / 2f - 3.dp.toPx()
                val inner = outer * 0.72f
                for (i in 0 until n) {
                    val a = ((-90f + i * 15f) * PI / 180.0).toFloat()
                    val c = cos(a); val sn = sin(a)
                    drawLine(tickColor(s, i, lit), Offset(center.x + c * inner, center.y + sn * inner), Offset(center.x + c * outer, center.y + sn * outer), 3.dp.toPx(), StrokeCap.Round)
                }
            }
            Text("${s.pct}", style = MaterialTheme.typography.titleLarge, color = s.fg)
        }
        BattInfo(s, Modifier.padding(start = 16.dp), showPct = false)
    }
}

@Composable
private fun BattSunrise(s: Sty) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Canvas(Modifier.size(width = 110.dp, height = 80.dp)) {
            val horizon = size.height * 0.82f
            val r = 30.dp.toPx()
            val bob = if (s.charging && s.mode == 2) sin(s.anim * 2f * PI.toFloat()) * 2.dp.toPx() else 0f
            val cy = horizon + r - s.frac * 2f * r + bob
            val col = if (s.charging && s.mode == 1) s.fill.copy(alpha = s.pulse) else s.fill
            clipRect(0f, 0f, size.width, horizon) {
                drawCircle(col, r, Offset(size.width / 2f, cy))
            }
            drawLine(s.fg, Offset(0f, horizon), Offset(size.width, horizon), 2.dp.toPx(), StrokeCap.Round)
        }
        BattInfo(s, Modifier.padding(start = 16.dp))
    }
}

@Composable
private fun BattSlats(s: Sty) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Canvas(Modifier.size(width = 72.dp, height = 84.dp)) {
            val cell = size.height / 10f
            val h = cell - 3.dp.toPx()
            val litCount = ceil(s.frac * 10f).toInt()
            for (i in 0 until 10) {
                val fromBottom = 9 - i
                var col = if (fromBottom < litCount) s.fill else s.track
                if (s.charging) {
                    if (s.mode == 1 && fromBottom < litCount) col = s.fill.copy(alpha = s.pulse)
                    if (s.mode == 2 && fromBottom == litCount) col = s.fill.copy(alpha = s.anim)
                }
                drawRoundRect(col, Offset(0f, i * cell), Size(size.width, h), CornerRadius(h / 2f, h / 2f))
            }
        }
        BattInfo(s, Modifier.padding(start = 16.dp))
    }
}

@Composable
private fun BattTape(s: Sty) {
    Column {
        Text("${s.pct}%", style = MaterialTheme.typography.headlineMedium, color = s.fg, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        Canvas(Modifier.fillMaxWidth().height(52.dp)) {
            val step = 8.dp.toPx()
            val cx = size.width / 2f
            val bob = if (s.charging && s.mode == 2) sin(s.anim * 2f * PI.toFloat()) * 2.dp.toPx() else 0f
            for (v in (s.pct - 40)..(s.pct + 40)) {
                if (v < 0 || v > 100) continue
                val x = cx + (v - s.pct) * step
                if (x < 0f || x > size.width) continue
                val big = v % 5 == 0
                val len = if (big) 26.dp.toPx() else 14.dp.toPx()
                var col = if (v <= s.pct) s.fill else s.track
                if (s.charging && s.mode == 1 && v <= s.pct) col = s.fill.copy(alpha = s.pulse)
                drawLine(col, Offset(x, 18.dp.toPx()), Offset(x, 18.dp.toPx() + len), 2.dp.toPx(), StrokeCap.Round)
            }
            val p = Path()
            p.moveTo(cx - 6.dp.toPx(), bob)
            p.lineTo(cx + 6.dp.toPx(), bob)
            p.lineTo(cx, 11.dp.toPx() + bob)
            p.close()
            drawPath(p, s.fg)
        }
        if (s.info.isNotEmpty()) Text(s.info, style = MaterialTheme.typography.bodyMedium, color = s.fg.copy(alpha = 0.7f), textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
    }
}

@Composable
private fun BattTickFan(s: Sty) {
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(width = 160.dp, height = 86.dp), contentAlignment = Alignment.BottomCenter) {
            Canvas(Modifier.size(width = 160.dp, height = 86.dp)) {
                val cx = size.width / 2f
                val cy = size.height - 4.dp.toPx()
                val outer = 76.dp.toPx()
                val inner = outer * 0.7f
                val lit = (s.frac * 30f).toInt() + 1
                for (i in 0..30) {
                    val a = ((180f + i * 6f) * PI / 180.0).toFloat()
                    val c = cos(a); val sn = sin(a)
                    drawLine(tickColor(s, i, lit), Offset(cx + c * inner, cy + sn * inner), Offset(cx + c * outer, cy + sn * outer), 3.dp.toPx(), StrokeCap.Round)
                }
            }
            Row(Modifier.padding(bottom = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("${s.pct}", style = MaterialTheme.typography.headlineMedium, color = s.fg)
                if (s.bolt) Icon(painterResource(R.drawable.bolt_24px), null, tint = s.fill.copy(alpha = s.pulse), modifier = Modifier.padding(start = 4.dp))
            }
        }
        if (s.info.isNotEmpty()) Text(s.info, style = MaterialTheme.typography.bodyMedium, color = s.fg.copy(alpha = 0.7f))
    }
}

@Composable
private fun BattBarber(s: Sty) {
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("${s.pct}%", style = MaterialTheme.typography.headlineMedium, color = s.fg)
            if (s.bolt) Icon(painterResource(R.drawable.bolt_24px), null, tint = s.fill.copy(alpha = s.pulse), modifier = Modifier.padding(start = 6.dp))
        }
        Canvas(Modifier.fillMaxWidth().padding(top = 8.dp).height(26.dp)) {
            val h = size.height
            val w = size.width * s.frac
            drawRoundRect(s.track, Offset.Zero, size, CornerRadius(h / 2f, h / 2f))
            if (w > 0f) {
                val path = Path()
                path.addRoundRect(RoundRect(0f, 0f, w, h, CornerRadius(h / 2f, h / 2f)))
                val base = if (s.charging && s.mode == 1) s.fill.copy(alpha = s.pulse) else s.fill
                clipPath(path) {
                    drawRect(base, Offset.Zero, Size(w, h))
                    val period = 14.dp.toPx()
                    val off = if (s.charging && s.mode == 2) s.anim * period else 0f
                    var x = -period * 2f + off
                    while (x < w + h) {
                        drawLine(Color.White.copy(alpha = 0.28f), Offset(x, h), Offset(x + h, 0f), 6.dp.toPx())
                        x += period
                    }
                }
            }
        }
        if (s.info.isNotEmpty()) Text(s.info, style = MaterialTheme.typography.bodyMedium, color = s.fg.copy(alpha = 0.7f), modifier = Modifier.padding(top = 6.dp))
    }
}

@Composable
private fun BattVRuler(s: Sty) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Canvas(Modifier.size(width = 70.dp, height = 100.dp)) {
            val pad = 4.dp.toPx()
            val span = size.height - pad * 2f
            val bob = if (s.charging && s.mode == 2) sin(s.anim * 2f * PI.toFloat()) * 2.dp.toPx() else 0f
            for (k in 0..100 step 5) {
                val y = size.height - pad - k / 100f * span
                val len = if (k % 25 == 0) 32.dp.toPx() else 18.dp.toPx()
                var col = if (k <= s.pct) s.fill else s.track
                if (s.charging && s.mode == 1 && k <= s.pct) col = s.fill.copy(alpha = s.pulse)
                drawLine(col, Offset(2.dp.toPx(), y), Offset(2.dp.toPx() + len, y), 2.5.dp.toPx(), StrokeCap.Round)
            }
            val py = size.height - pad - s.frac * span + bob
            val p = Path()
            p.moveTo(42.dp.toPx(), py)
            p.lineTo(56.dp.toPx(), py - 7.dp.toPx())
            p.lineTo(56.dp.toPx(), py + 7.dp.toPx())
            p.close()
            drawPath(p, s.fg)
        }
        BattInfo(s, Modifier.padding(start = 12.dp))
    }
}

@Composable
private fun BattFillType(s: Sty) {
    Column {
        Box {
            Text("${s.pct}%", fontSize = 72.sp, fontWeight = FontWeight.Medium, color = s.track)
            val col = if (s.charging && s.mode == 1) s.fill.copy(alpha = s.pulse) else s.fill
            Text(
                "${s.pct}%", fontSize = 72.sp, fontWeight = FontWeight.Medium, color = col,
                modifier = Modifier.drawWithContent {
                    val top = size.height * (0.85f - 0.65f * s.frac)
                    clipRect(0f, top, size.width, size.height) { this@drawWithContent.drawContent() }
                },
            )
        }
        Text(if (s.plugged) "Charging" else "On battery", style = MaterialTheme.typography.bodyMedium, color = s.fg.copy(alpha = 0.7f))
        if (s.info.isNotEmpty()) Text(s.info, style = MaterialTheme.typography.bodyMedium, color = s.fg.copy(alpha = 0.7f))
    }
}
