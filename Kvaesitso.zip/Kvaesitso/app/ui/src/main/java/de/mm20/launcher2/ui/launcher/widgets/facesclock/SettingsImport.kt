package de.mm20.launcher2.ui.launcher.widgets.facesclock

import android.content.Context
import android.net.Uri
import de.mm20.launcher2.widgets.VizConfig
import org.json.JSONObject

/** Reads the settings file exported by the Now Playing Card app. */
object SettingsImport {
    private val SNAMES = listOf("bars", "sens", "reach", "fall", "vert", "low", "colorMode", "color", "color2", "depth", "glow", "spin")
    private val LEGACY = mapOf("colorMode" to "vizColorMode", "color" to "vizColor", "color2" to "vizColor2", "bars" to "vizBars", "fall" to "vizFall", "vert" to "vizVert", "low" to "vizLow", "depth" to "vizDepth")

    class Result(val ok: Boolean, val message: String)

    private fun store(root: JSONObject, name: String): Map<String, Any> {
        val o = root.optJSONObject("stores")?.optJSONObject(name) ?: return emptyMap()
        val out = HashMap<String, Any>()
        for (k in o.keys()) {
            val e = o.optJSONObject(k) ?: continue
            when (e.optString("t")) {
                "i" -> out[k] = e.optInt("v")
                "l" -> out[k] = e.optLong("v")
                "b" -> out[k] = e.optBoolean("v")
                "f" -> out[k] = e.optDouble("v").toFloat()
                "s" -> out[k] = e.optString("v")
            }
        }
        return out
    }

    fun import(ctx: Context, uri: Uri): Result {
        val text = try {
            ctx.contentResolver.openInputStream(uri)?.use { String(it.readBytes()) } ?: return Result(false, "Couldn't read that file")
        } catch (e: Exception) { return Result(false, "Couldn't read that file") }
        val root = try { JSONObject(text) } catch (e: Exception) { return Result(false, "That isn't a settings file") }
        if (root.optString("format") != "nowplaying-settings") return Result(false, "That isn't a Now Playing settings file")

        // keep the whole file: the panel looks, saver settings and so on are read from it by later features
        try { ctx.openFileOutput("nowplaying-import.json", Context.MODE_PRIVATE).use { it.write(text.toByteArray()) } } catch (e: Exception) {}

        val np = store(root, "np")
        fun i(k: String, d: Int) = (np[k] as? Int) ?: d
        fun b(k: String, d: Boolean) = (np[k] as? Boolean) ?: d

        val sameAll = b("vizSameAll", false)
        var style = if (sameAll) i("vizAllStyle", 0) else i("bubbleStyle", 4)
        val mirrored = style == 1
        if (mirrored) style = 0
        val st = style.coerceIn(0, 7)
        fun s(name: String, def: Int): Int {
            (np["vs${st}_$name"] as? Int)?.let { return it }
            if (mirrored) (np["vs1_$name"] as? Int)?.let { return it }
            LEGACY[name]?.let { lk -> (np[lk] as? Int)?.let { return it }; (np[lk] as? Boolean)?.let { return if (it) 1 else 0 } }
            return def
        }
        val d = VizConfig()
        val viz = VizConfig(
            style = st,
            shape = i("bubbleShape", 0),
            colorMode = s("colorMode", 2),
            color = s("color", d.color),
            color2 = s("color2", d.color2),
            bars = i("bubbleBars", 28),
            sens = s("sens", 90),
            reach = s("reach", 100),
            fall = s("fall", 100),
            vert = s("vert", if (mirrored) 2 else 0),
            low = s("low", if (mirrored) 2 else 0),
            spin = s("spin", 1) != 0,
            glow = s("glow", 1) != 0,
            vizOp = i("bubbleVizOp", 100),
            artOp = i("bubbleArtOp", 100),
            borderOp = i("bubbleBorderOp", 100),
            vizHeight = i("bubbleVizHeight", 100),
        )
        BubbleSettings.setViz(ctx, viz)
        BubbleSettings.setInt(ctx, "size", i("bubbleSize", 56))
        BubbleSettings.setInt(ctx, "opacity", i("bubbleOpacity", 100))
        BubbleSettings.setBool(ctx, "snap", b("bubbleSnap", true))
        BubbleSettings.setBool(ctx, "keepPaused", b("bubbleKeepPaused", false))
        BubbleSettings.setBool(ctx, "hideInApp", b("bubbleHideInApp", true))
        BubbleSettings.setBool(ctx, "tuck", b("bubbleTuck", true))
        BubbleSettings.setBool(ctx, "dot", b("bubbleDot", true))
        BubbleSettings.setBool(ctx, "haptic", b("bubbleHaptic", true))
        BubbleSettings.setInt(ctx, "hideMin", i("bubbleHideMin", 0))

        // everything else goes into the card / EQ stores as-is
        val map = mapOf("np" to "kvx_np", "np_presets" to "kvx_np_presets", "np_eqpresets" to "kvx_np_eqpresets", "np_eqdev" to "kvx_np_eqdev")
        var presets = 0
        for ((from, to) in map) {
            val st = store(root, from)
            val e = ctx.applicationContext.getSharedPreferences(to, Context.MODE_PRIVATE).edit().clear()
            for ((k, v) in st) when (v) {
                is Int -> e.putInt(k, v); is Long -> e.putLong(k, v); is Boolean -> e.putBoolean(k, v)
                is Float -> e.putFloat(k, v); is String -> e.putString(k, v)
            }
            e.apply()
            if (from == "np_eqpresets") presets = st.size
        }
        de.mm20.launcher2.ui.launcher.widgets.facesclock.np.EqService.sync(ctx)
        BubbleService.refresh(ctx)
        return Result(true, "Imported your settings and $presets EQ preset" + (if (presets == 1) "" else "s"))
    }
}
