package de.mm20.launcher2.ui.panels

import android.content.Context

/** Settings for the edge panel. Plain SharedPreferences so the overlay service reads them directly. */
object PanelPrefs {
    private fun sp(c: Context) = c.applicationContext.getSharedPreferences("kvx_panel", Context.MODE_PRIVATE)

    fun i(c: Context, k: String, d: Int) = sp(c).getInt(k, d)
    fun b(c: Context, k: String, d: Boolean) = sp(c).getBoolean(k, d)
    fun setI(c: Context, k: String, v: Int) = sp(c).edit().putInt(k, v).apply()
    fun setB(c: Context, k: String, v: Boolean) = sp(c).edit().putBoolean(k, v).apply()

    fun on(c: Context) = b(c, "on", false)

    fun apps(c: Context): List<String> =
        (sp(c).getString("apps", "") ?: "").split('\n').filter { it.isNotBlank() }

    fun setApps(c: Context, l: List<String>) = sp(c).edit().putString("apps", l.joinToString("\n")).apply()

    val presetNames = listOf("Dark glass", "Light glass", "Amoled", "Gold", "Ocean")

    /** Colors and surface only; layout and behavior stay as they are. */
    fun applyPreset(c: Context, n: Int) {
        val e = sp(c).edit()
        when (n) {
            0 -> { e.putInt("cBg", 0xFF1E1E1E.toInt()).putInt("bgAlpha", 85).putInt("cLabel", 0xFFFFFFFF.toInt()).putInt("cAccent", 0xFFE0B25A.toInt()).putInt("hColor", 0xFFE0B25A.toInt()).putInt("border", 0).putInt("blur", 20).putInt("dim", 25) }
            1 -> { e.putInt("cBg", 0xFFF4F1EA.toInt()).putInt("bgAlpha", 88).putInt("cLabel", 0xFF1B1B1B.toInt()).putInt("cAccent", 0xFF6750A4.toInt()).putInt("hColor", 0xFF6750A4.toInt()).putInt("border", 0).putInt("blur", 24).putInt("dim", 15) }
            2 -> { e.putInt("cBg", 0xFF000000.toInt()).putInt("bgAlpha", 100).putInt("cLabel", 0xFFFFFFFF.toInt()).putInt("cAccent", 0xFFFFFFFF.toInt()).putInt("hColor", 0xFFFFFFFF.toInt()).putInt("border", 1).putInt("blur", 0).putInt("dim", 40) }
            3 -> { e.putInt("cBg", 0xFF3A2A0A.toInt()).putInt("bgAlpha", 90).putInt("cLabel", 0xFFFFE9B8.toInt()).putInt("cAccent", 0xFFFFC107.toInt()).putInt("hColor", 0xFFFFC107.toInt()).putInt("border", 1).putInt("blur", 16).putInt("dim", 25) }
            4 -> { e.putInt("cBg", 0xFF0B2A3A.toInt()).putInt("bgAlpha", 88).putInt("cLabel", 0xFFD8F3FF.toInt()).putInt("cAccent", 0xFF00B8D4.toInt()).putInt("hColor", 0xFF00B8D4.toInt()).putInt("border", 0).putInt("blur", 22).putInt("dim", 20) }
        }
        e.apply()
    }
}
