package de.mm20.launcher2.ui.panels

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import de.mm20.launcher2.ui.R
import java.io.File

/** Settings for the edge panel. Plain SharedPreferences so the overlay service reads them directly. */
object PanelPrefs {
    private fun sp(c: Context) = c.applicationContext.getSharedPreferences("kvx_panel", Context.MODE_PRIVATE)

    fun i(c: Context, k: String, d: Int) = sp(c).getInt(k, d)
    fun b(c: Context, k: String, d: Boolean) = sp(c).getBoolean(k, d)
    fun setI(c: Context, k: String, v: Int) = sp(c).edit().putInt(k, v).apply()
    fun setB(c: Context, k: String, v: Boolean) = sp(c).edit().putBoolean(k, v).apply()

    fun on(c: Context) = b(c, "on", false)

    /** Panel entries in order: "app:<package>" or "tool:<id>". Older saves hold bare package names. */
    fun items(c: Context): List<String> =
        (sp(c).getString("apps", "") ?: "").split('\n').filter { it.isNotBlank() }
            .map { if (it.contains(':')) it else "app:$it" }

    fun setItems(c: Context, l: List<String>) = sp(c).edit().putString("apps", l.joinToString("\n")).apply()

    class Tool(val id: String, val label: String, val icon: Int, val kind: Int) // kind: 0 toggle, 1 slider, 2 opens settings

    val tools = listOf(
        Tool("rotate", "Auto-rotate", R.drawable.kvx_rotate, 0),
        Tool("flash", "Flashlight", R.drawable.kvx_flash, 0),
        Tool("bright", "Brightness", R.drawable.light_mode_24px, 1),
        Tool("vol", "Media volume", R.drawable.kvx_volume, 1),
        Tool("net", "Internet", R.drawable.kvx_wifi, 2),
        Tool("bt", "Bluetooth", R.drawable.kvx_bluetooth, 2),
    )

    fun tool(key: String): Tool? = if (key.startsWith("tool:")) tools.firstOrNull { it.id == key.removePrefix("tool:") } else null

    fun iconFile(c: Context, key: String): File =
        File(File(c.filesDir, "panel_icons"), key.replace(Regex("[^A-Za-z0-9]"), "_") + ".png")

    fun hasIcon(c: Context, key: String) = iconFile(c, key).exists()

    fun clearIcon(c: Context, key: String) { iconFile(c, key).delete() }

    /** Saves a picked image as a square 192 px icon for an entry. Returns false if it couldn't be read. */
    fun saveIcon(c: Context, key: String, uri: Uri): Boolean = try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= 384 && bounds.outHeight / (sample * 2) >= 384) sample *= 2
        val src = c.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
        }
        if (src == null) false else {
            val side = minOf(src.width, src.height)
            val sq = Bitmap.createBitmap(src, (src.width - side) / 2, (src.height - side) / 2, side, side)
            val out = Bitmap.createScaledBitmap(sq, 192, 192, true)
            val f = iconFile(c, key)
            f.parentFile?.mkdirs()
            f.outputStream().use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
            true
        }
    } catch (e: Exception) { false }

    val presetNames = listOf("Dark glass", "Light glass", "Amoled", "Gold", "Ocean")

    /** Colors and surface only; layout and behavior stay as they are. */
    fun applyPreset(c: Context, n: Int) {
        val e = sp(c).edit()
        when (n) {
            0 -> { e.putInt("cBg", 0xFF1E1E1E.toInt()).putInt("bgAlpha", 85).putInt("cLabel", 0xFFFFFFFF.toInt()).putInt("cAccent", 0xFFE0B25A.toInt()).putInt("hColor", 0xFFE0B25A.toInt()).putInt("border", 0).putInt("blur", 20).putInt("dim", 25) }
            1 -> { e.putInt("cBg", 0xFFF4F1EA.toInt()).putInt("bgAlpha", 88).putInt("cLabel", 0xFF1B1B1B.toInt()).putInt("cAccent", 0xFF6750A4.toInt()).putInt("hColor", 0xFF6750A4.toInt()).putInt("border", 0).putInt("blur", 24).putInt("dim", 15) }
            2 -> { e.putInt("cBg", 0xFF000000.toInt()).putInt("bgAlpha", 100).putInt("cLabel", 0xFFFFFFFF.toInt()).putInt("cAccent", 0xFFFFFFFF.toInt()).putInt("hColor", 0xFFFFFFFF.toInt()).putInt("border", 1).putInt("blur", 0).putInt("dim", 40) }
            3 -> { e.putInt("cBg", 0xFF3A2A0A.toInt()).putInt("bgAlpha", 90).putInt("cLabel", 0xFFFFE9B8.toInt()).putInt("cAccent", 0xFFFFC107.toInt()).putInt("hColor", 0xFFFFC107.toInt()).putInt("border", 1).putInt("blur", 16).putInt("dim", 25) }
            4 -> { e.putInt("cBg", 0xFF0B2A3A.toInt()).putInt("bgAlpha", 88).putInt("cLabel", 0xFFD8F3FF.toInt()).putInt("cAccent", 0xFF00B8D4.toInt()).putInt("hColor", 0xFF00B8D4.toInt()).putInt("border", 0).putInt("blur", 22).putInt("dim", 20) }
        }
        e.apply()
    }
}
