package de.mm20.launcher2.ui.launcher.widgets.facesclock

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue

/** Settings of the launcher fork that are not part of Kvaesitso's own preferences. */
object KvxSettings {
    private const val FILE = "kvx_settings"
    private fun p(c: Context) = c.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    /** Animation frame rate cap: 0 = match the display, otherwise frames per second. */
    fun fps(c: Context): Int = p(c).getInt("fps", 0)

    fun setFps(c: Context, v: Int) {
        p(c).edit().putInt("fps", v).apply()
    }

    private var chargingStyleState by mutableIntStateOf(-1)

    /** 0 bubbles (stock), 1 edge rise, 2 ripples, 3 fireflies, 4 rising wave, 5 sweep. */
    fun chargingStyle(c: Context): Int {
        if (chargingStyleState < 0) chargingStyleState = p(c).getInt("charging_style", 0)
        return chargingStyleState
    }

    fun setChargingStyle(c: Context, v: Int) {
        p(c).edit().putInt("charging_style", v).apply()
        chargingStyleState = v
    }

    private var chargingColorModeState by mutableIntStateOf(-1)
    private var chargingColorState by mutableIntStateOf(0)

    /** 0 white, 1 custom color, 2 theme accent, 3 rainbow. */
    fun chargingColorMode(c: Context): Int {
        if (chargingColorModeState < 0) {
            chargingColorModeState = p(c).getInt("charging_color_mode", 0)
            chargingColorState = p(c).getInt("charging_color", 0xFF00E5FF.toInt())
        }
        return chargingColorModeState
    }

    fun chargingColor(c: Context): Int { chargingColorMode(c); return chargingColorState }

    fun setChargingColorMode(c: Context, v: Int) {
        p(c).edit().putInt("charging_color_mode", v).apply()
        chargingColorModeState = v
    }

    fun setChargingColor(c: Context, v: Int) {
        p(c).edit().putInt("charging_color", v).apply()
        chargingColorState = v
    }

    /** Location used for sunrise and sunset on clock faces. Empty name means unset. */
    class Place(val name: String, val lat: Double, val lon: Double)

    private var placeVersion by mutableIntStateOf(0)

    fun sunPlace(c: Context): Place? {
        placeVersion
        val sp = p(c)
        val n = sp.getString("sun_name", "") ?: ""
        if (n.isBlank()) return null
        return Place(n, java.lang.Double.longBitsToDouble(sp.getLong("sun_lat", 0)), java.lang.Double.longBitsToDouble(sp.getLong("sun_lon", 0)))
    }

    fun setSunPlace(c: Context, name: String, lat: Double, lon: Double) {
        p(c).edit().putString("sun_name", name)
            .putLong("sun_lat", java.lang.Double.doubleToRawLongBits(lat))
            .putLong("sun_lon", java.lang.Double.doubleToRawLongBits(lon)).apply()
        placeVersion++
    }
}
