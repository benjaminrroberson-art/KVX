package de.mm20.launcher2.ui.launcher.widgets.facesclock

import android.content.Context

/** Settings of the launcher fork that are not part of Kvaesitso's own preferences. */
object KvxSettings {
    private const val FILE = "kvx_settings"

    /** Animation frame rate cap: 0 = match the display, otherwise frames per second. */
    fun fps(c: Context): Int = c.getSharedPreferences(FILE, Context.MODE_PRIVATE).getInt("fps", 0)

    fun setFps(c: Context, v: Int) {
        c.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putInt("fps", v).apply()
    }
}
