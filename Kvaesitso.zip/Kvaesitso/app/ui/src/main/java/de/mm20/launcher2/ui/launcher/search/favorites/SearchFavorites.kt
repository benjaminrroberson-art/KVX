package de.mm20.launcher2.ui.launcher.search.favorites

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import de.mm20.launcher2.search.SavableSearchable
import de.mm20.launcher2.search.Tag
import de.mm20.launcher2.ui.R
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.onSizeChanged
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.max
import de.mm20.launcher2.ui.common.FavoritesTagSelector
import de.mm20.launcher2.ui.component.Banner
import de.mm20.launcher2.ui.launcher.search.common.grid.SearchResultGrid
import de.mm20.launcher2.ui.layout.BottomReversed
import de.mm20.launcher2.ui.theme.transparency.transparency

fun LazyListScope.SearchFavorites(
    favorites: List<SavableSearchable>,
    pinnedTags: List<Tag>,
    selectedTag: String?,
    compactTags: Boolean,
    tagsExpanded: Boolean,
    onExpandTags: (Boolean) -> Unit,
    onSelectTag: (String?) -> Unit,
    editButton: Boolean,
    reverse: Boolean,
) {
    item(
        key = "favorites",
    ) {
        val scope = rememberCoroutineScope()
        val off = remember { Animatable(0f) }
        var width by remember { mutableStateOf(0) }
        CompositionLocalProvider(LocalContentColor provides MaterialTheme.colorScheme.onSurface) {
            Column(
                modifier = Modifier
                    .padding(
                        top = if (reverse) 8.dp else 0.dp,
                        bottom = if (reverse) 0.dp else 8.dp,
                    )
                    .background(
                        MaterialTheme.colorScheme.surface.copy(
                            MaterialTheme.transparency.surface
                        ),
                        MaterialTheme.shapes.medium
                    )
                    .padding(vertical = 4.dp)
                    .pointerInput(pinnedTags, selectedTag) {
                        detectHorizontalDragGestures(
                            onDragStart = { scope.launch { off.stop() } },
                            onDragCancel = { scope.launch { off.animateTo(0f, spring()) } },
                            onDragEnd = {
                                val order = listOf<String?>(null) + pinnedTags.map { it.tag }
                                val cur = order.indexOf(selectedTag).coerceAtLeast(0)
                                val limit = 56.dp.toPx()
                                val total = off.value
                                val w = (if (width > 0) width else 600).toFloat() * 0.5f
                                val next = if (total < -limit && cur < order.lastIndex) 1 else if (total > limit && cur > 0) -1 else 0
                                scope.launch {
                                    if (next == 0) off.animateTo(0f, spring())
                                    else {
                                        off.animateTo(-next * w, tween(110))
                                        onSelectTag(order[cur + next])
                                        off.snapTo(next * w)
                                        off.animateTo(0f, spring(stiffness = 300f))
                                    }
                                }
                            },
                            onHorizontalDrag = { change, d ->
                                change.consume()
                                scope.launch { off.snapTo(off.value + d * 0.85f) }
                            },
                        )
                    },
                verticalArrangement = if (reverse) Arrangement.BottomReversed else Arrangement.Top
            ) {
                Box(
                    Modifier
                        .onSizeChanged { width = it.width }
                        .graphicsLayer {
                            translationX = off.value
                            alpha = (1f - abs(off.value) / (max(width, 1) * 0.5f) * 0.7f).coerceIn(0.2f, 1f)
                        }
                ) {
                if (favorites.isNotEmpty()) {
                    SearchResultGrid(favorites, transitionKey = selectedTag, reverse = reverse)
                } else {
                    Banner(
                        modifier = Modifier.padding(16.dp),
                        text = stringResource(
                            if (selectedTag == null) R.string.favorites_empty else R.string.favorites_empty_tag
                        ),
                        icon = if (selectedTag == null) R.drawable.star_24px else R.drawable.tag_24px,
                    )
                }
                }
                if (pinnedTags.isNotEmpty() || editButton) {
                    FavoritesTagSelector(
                        tags = pinnedTags,
                        selectedTag = selectedTag,
                        editButton = editButton,
                        reverse = false,
                        onSelectTag = onSelectTag,
                        scrollState = rememberScrollState(),
                        expanded = tagsExpanded,
                        compact = compactTags,
                        onExpand = onExpandTags,
                        showFavorites = true
                    )
                }
            }
        }
    }
}