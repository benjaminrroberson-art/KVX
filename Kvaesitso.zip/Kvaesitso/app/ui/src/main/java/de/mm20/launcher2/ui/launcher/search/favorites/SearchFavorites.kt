package de.mm20.launcher2.ui.launcher.search.favorites

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import de.mm20.launcher2.search.SavableSearchable
import de.mm20.launcher2.search.Tag
import de.mm20.launcher2.ui.R
import androidx.compose.animation.core.animate
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.onSizeChanged
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.max
import de.mm20.launcher2.ui.common.FavoritesTagSelector
import de.mm20.launcher2.ui.component.Banner
import de.mm20.launcher2.ui.launcher.search.common.grid.SearchResultGrid
import de.mm20.launcher2.ui.layout.BottomReversed
import de.mm20.launcher2.ui.theme.transparency.transparency

fun LazyListScope.SearchFavorites(
    favorites: List<SavableSearchable>,
    pinnedTags: List<Tag>,
    selectedTag: String?,
    compactTags: Boolean,
    tagsExpanded: Boolean,
    onExpandTags: (Boolean) -> Unit,
    onSelectTag: (String?) -> Unit,
    editButton: Boolean,
    reverse: Boolean,
) {
    item(
        key = "favorites",
    ) {
        val scope = rememberCoroutineScope()
        var off by remember { mutableFloatStateOf(0f) }
        var anim by remember { mutableStateOf<kotlinx.coroutines.Job?>(null) }
        var width by remember { mutableStateOf(0) }
        CompositionLocalProvider(LocalContentColor provides MaterialTheme.colorScheme.onSurface) {
            Column(
                modifier = Modifier
                    .padding(
                        top = if (reverse) 8.dp else 0.dp,
                        bottom = if (reverse) 0.dp else 8.dp,
                    )
                    .background(
                        MaterialTheme.colorScheme.surface.copy(
                            MaterialTheme.transparency.surface
                        ),
                        MaterialTheme.shapes.medium
                    )
                    .padding(vertical = 4.dp)
                    .pointerInput(pinnedTags, selectedTag) {
                        detectHorizontalDragGestures(
                            onDragStart = { anim?.cancel() },
                            onDragCancel = { anim = scope.launch { animate(off, 0f, animationSpec = spring()) { v, _ -> off = v } } },
                            onDragEnd = {
                                val order = listOf<String?>(null) + pinnedTags.map { it.tag }
                                val cur = order.indexOf(selectedTag).coerceAtLeast(0)
                                val limit = 48.dp.toPx()
                                val w = (if (width > 0) width else 900).toFloat()
                                val next = if (off < -limit && cur < order.lastIndex) 1 else if (off > limit && cur > 0) -1 else 0
                                anim = scope.launch {
                                    if (next == 0) animate(off, 0f, animationSpec = spring()) { v, _ -> off = v }
                                    else {
                                        // finish the swipe off screen, swap, then bring the new tag in from the other side
                                        animate(off, -next * w, animationSpec = tween(90, easing = androidx.compose.animation.core.LinearEasing)) { v, _ -> off = v }
                                        onSelectTag(order[cur + next])
                                        // let the heavy recomposition for the new tag finish off-screen before animating
                                        off = next * w
                                        androidx.compose.runtime.withFrameNanos { }
                                        androidx.compose.runtime.withFrameNanos { }
                                        androidx.compose.runtime.withFrameNanos { }
                                        animate(off, 0f, animationSpec = tween(160, easing = androidx.compose.animation.core.FastOutSlowInEasing)) { v, _ -> off = v }
                                    }
                                }
                            },
                            onHorizontalDrag = { change, d ->
                                change.consume()
                                off += d
                            },
                        )
                    },
                verticalArrangement = if (reverse) Arrangement.BottomReversed else Arrangement.Top
            ) {
                Box(
                    Modifier
                        .onSizeChanged { width = it.width }
                        .graphicsLayer {
                            translationX = off
                        }
                ) {
                if (favorites.isNotEmpty()) {
                    SearchResultGrid(favorites, transitionKey = "favorites", reverse = reverse)
                } else {
                    Banner(
                        modifier = Modifier.padding(16.dp),
                        text = stringResource(
                            if (selectedTag == null) R.string.favorites_empty else R.string.favorites_empty_tag
                        ),
                        icon = if (selectedTag == null) R.drawable.star_24px else R.drawable.tag_24px,
                    )
                }
                }
                if (pinnedTags.isNotEmpty() || editButton) {
                    FavoritesTagSelector(
                        tags = pinnedTags,
                        selectedTag = selectedTag,
                        editButton = editButton,
                        reverse = false,
                        onSelectTag = onSelectTag,
                        scrollState = rememberScrollState(),
                        expanded = tagsExpanded,
                        compact = compactTags,
                        onExpand = onExpandTags,
                        showFavorites = true
                    )
                }
            }
        }
    }
}