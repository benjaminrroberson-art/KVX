package de.mm20.launcher2.ui.launcher.widgets.facesclock

import android.text.format.DateFormat
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.foundation.clickable
import de.mm20.launcher2.ui.component.preferences.Preference
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import de.mm20.launcher2.preferences.MeasurementSystem
import de.mm20.launcher2.ui.component.preferences.ListPreference
import de.mm20.launcher2.ui.component.preferences.SliderPreference
import de.mm20.launcher2.ui.component.preferences.SwitchPreference
import de.mm20.launcher2.ui.component.weather.WeatherIcon
import de.mm20.launcher2.ui.locals.LocalMeasurementSystem
import de.mm20.launcher2.ui.utils.formatTemperature
import de.mm20.launcher2.weather.Forecast
import de.mm20.launcher2.widgets.KvxWeatherWidget
import de.mm20.launcher2.widgets.KvxWeatherWidgetConfig
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import kotlin.math.roundToInt

private fun iconOf(id: Int): WeatherIcon = when (id) {
    Forecast.CLEAR -> WeatherIcon.Clear
    Forecast.OVERCAST -> WeatherIcon.Overcast
    Forecast.EXTREME_COLD -> WeatherIcon.ExtremeHeat
    Forecast.LIGHT_RAIN -> WeatherIcon.LightRain
    Forecast.HAZE -> WeatherIcon.Haze
    Forecast.FOG -> WeatherIcon.Fog
    Forecast.HAIL -> WeatherIcon.Hail
    Forecast.EXTREME_HEAT -> WeatherIcon.ExtremeHeat
    Forecast.PARTLY_CLOUDY -> WeatherIcon.PartlyCloudy
    Forecast.RAIN -> WeatherIcon.Rain
    Forecast.HEAVY_RAIN -> WeatherIcon.HeavyRain
    Forecast.SLEET -> WeatherIcon.Sleet
    Forecast.SNOW -> WeatherIcon.Snow
    Forecast.THUNDER -> WeatherIcon.Thunder
    Forecast.THUNDERSTORM -> WeatherIcon.Thunderstorm
    Forecast.WIND -> WeatherIcon.Wind
    Forecast.MOSTLY_CLOUDY -> WeatherIcon.PartlyCloudy
    Forecast.STORM -> WeatherIcon.Wind
    Forecast.BROKEN_CLOUDS -> WeatherIcon.PartlyCloudy
    Forecast.HEAVY_THUNDERSTORM -> WeatherIcon.Thunder
    Forecast.HEAVY_THUNDERSTORM_WITH_RAIN -> WeatherIcon.Thunderstorm
    else -> WeatherIcon.Unknown
}

@Composable
fun KvxWeatherView(widget: KvxWeatherWidget) = KvxWeatherBody(widget.config)

@Composable
fun KvxWeatherBody(cfg: KvxWeatherWidgetConfig) {
    val vm: KvxDataVM = viewModel()
    val providerHourly by vm.hourly.collectAsState()
    val providerDaily by vm.daily.collectAsState()
    val typed = cfg.placeName.isNotBlank()
    var custom by remember(cfg.placeName, cfg.lat, cfg.lon) { mutableStateOf<KvxWeatherData?>(null) }
    LaunchedEffect(cfg.placeName, cfg.lat, cfg.lon) {
        while (typed) {
            OpenMeteo.fetch(KvxPlace(cfg.placeName, cfg.placeDetail, cfg.lat, cfg.lon))?.let { custom = it }
            delay(30 * 60_000L)
        }
    }
    val hourly = if (typed) custom?.hourly ?: emptyList() else providerHourly
    val daily = if (typed) custom?.daily ?: emptyList() else providerDaily
    val ms = LocalMeasurementSystem.current
    val context = LocalContext.current
    val zone = ZoneId.systemDefault()
    val now = System.currentTimeMillis()
    val upcoming = hourly.filter { it.timestamp >= now - 3_600_000L }
    val cur = upcoming.firstOrNull() ?: hourly.lastOrNull()
    val pad = Modifier.padding(start = 12.dp + cfg.padStart.dp, top = 12.dp + cfg.padTop.dp, end = 12.dp + cfg.padEnd.dp, bottom = 12.dp + cfg.padBottom.dp)

    if (cur == null) {
        Text(if (typed) "Loading weather for ${cfg.placeName}..." else "No weather yet. Choose a weather provider in Settings > Weather.", modifier = pad.fillMaxWidth(), style = MaterialTheme.typography.bodyMedium)
        return
    }
    val fg = MaterialTheme.colorScheme.onSurface
    val hourFmt = DateTimeFormatter.ofPattern(if (DateFormat.is24HourFormat(context)) "HH" else "ha")
    val dayFmt = DateTimeFormatter.ofPattern("EEE")
    fun t(k: Double) = formatTemperature(context, k.toFloat(), ms)

    @Composable
    fun Chip(top: String, icon: Int, night: Boolean, label: String, sub: String? = null) {
        val shape = if (cfg.chip == 1) RoundedCornerShape(50) else RoundedCornerShape(16.dp)
        Column(
            Modifier.then(if (cfg.chip == 2) Modifier else Modifier.clip(shape).background(MaterialTheme.colorScheme.surfaceContainerHigh))
                .padding(horizontal = 10.dp, vertical = 8.dp).width(54.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(top, style = MaterialTheme.typography.labelSmall, color = fg.copy(alpha = 0.7f), maxLines = 1)
            WeatherIcon(icon = iconOf(icon), night = night, modifier = Modifier.padding(vertical = 4.dp))
            Text(label, style = MaterialTheme.typography.labelMedium, color = fg, maxLines = 1)
            if (sub != null) Text(sub, style = MaterialTheme.typography.labelSmall, color = fg.copy(alpha = 0.6f), maxLines = 1)
        }
    }

    Column(pad.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            WeatherIcon(icon = iconOf(cur.icon), night = cur.night, modifier = Modifier.size(56.dp))
            Column(Modifier.padding(start = 12.dp)) {
                Text(t(cur.temperature), style = MaterialTheme.typography.displaySmall, color = fg)
                Text(cur.condition, style = MaterialTheme.typography.bodyMedium, color = fg.copy(alpha = 0.8f))
                Text(cur.location, style = MaterialTheme.typography.labelSmall, color = fg.copy(alpha = 0.6f))
            }
        }
        if (cfg.details) {
            val bits = buildList {
                if (cfg.humidity) cur.humidity?.takeIf { it >= 0 }?.let { add("Humidity ${it.roundToInt()}%") }
                if (cfg.wind) cur.windSpeed?.takeIf { it >= 0 }?.let {
                    add(if (ms == MeasurementSystem.UnitedStates) "Wind ${(it * 2.23694).roundToInt()} mph" else "Wind ${(it * 3.6).roundToInt()} km/h")
                }
                if (cfg.uv) cur.uvIndex?.takeIf { it >= 0 }?.let { add("UV ${it.roundToInt()}") }
                if (cfg.rain) cur.precipProbability?.takeIf { it >= 0 }?.let { add("Rain $it%") }
            }
            if (bits.isNotEmpty()) Text(bits.joinToString("  ·  "), style = MaterialTheme.typography.labelMedium, color = fg.copy(alpha = 0.75f), modifier = Modifier.padding(top = 8.dp))
        }
        if (cfg.hourly && upcoming.isNotEmpty()) {
            Row(Modifier.padding(top = 12.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (f in upcoming.take(cfg.hourlyCount)) {
                    Chip(Instant.ofEpochMilli(f.timestamp).atZone(zone).format(hourFmt), f.icon, f.night, t(f.temperature))
                }
            }
        }
        if (cfg.daily && daily.isNotEmpty()) {
            Row(Modifier.padding(top = 8.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (d in daily.take(cfg.dailyCount)) {
                    Chip(Instant.ofEpochMilli(d.timestamp).atZone(zone).format(dayFmt), d.icon, false, t(d.maxTemp), t(d.minTemp))
                }
            }
        }
    }
}

@Composable
fun ConfigureKvxWeatherWidget(widget: KvxWeatherWidget, onWidgetUpdated: (KvxWeatherWidget) -> Unit) {
    val c = widget.config
    fun upd(n: KvxWeatherWidgetConfig) = onWidgetUpdated(widget.copy(config = n))
    OutlinedCard {
        Column {
            WeatherPlacePicker(c.placeName, c.placeDetail) { n, d, la, lo -> upd(c.copy(placeName = n, placeDetail = d, lat = la, lon = lo)) }
            SwitchPreference(title = "Details line", value = c.details, onValueChanged = { v -> upd(c.copy(details = v)) })
            if (c.details) {
                SwitchPreference(title = "Humidity", value = c.humidity, onValueChanged = { v -> upd(c.copy(humidity = v)) })
                SwitchPreference(title = "Wind", value = c.wind, onValueChanged = { v -> upd(c.copy(wind = v)) })
                SwitchPreference(title = "UV index", value = c.uv, onValueChanged = { v -> upd(c.copy(uv = v)) })
                SwitchPreference(title = "Chance of rain", value = c.rain, onValueChanged = { v -> upd(c.copy(rain = v)) })
            }
            SwitchPreference(title = "Hourly chips", value = c.hourly, onValueChanged = { v -> upd(c.copy(hourly = v)) })
            if (c.hourly) SliderPreference(title = "Hours shown", value = c.hourlyCount, min = 3, max = 24, onValueChanged = { v -> upd(c.copy(hourlyCount = v)) }, label = { Text("$it") })
            SwitchPreference(title = "Daily chips", value = c.daily, onValueChanged = { v -> upd(c.copy(daily = v)) })
            if (c.daily) SliderPreference(title = "Days shown", value = c.dailyCount, min = 2, max = 8, onValueChanged = { v -> upd(c.copy(dailyCount = v)) }, label = { Text("$it") })
            ListPreference(title = "Chip style", items = listOf("Rounded" to 0, "Pill" to 1, "No background" to 2), value = c.chip, onValueChanged = { v -> upd(c.copy(chip = v)) })
            PaddingControls(c.padTop, c.padBottom, c.padStart, c.padEnd) { t, b, s, e -> upd(c.copy(padTop = t, padBottom = b, padStart = s, padEnd = e)) }
        }
    }
}

@Composable
internal fun WeatherPlacePicker(name: String, detail: String, onPick: (String, String, Double, Double) -> Unit, title: String = "Location", unset: String = "Launcher weather provider") {
    var open by remember { mutableStateOf(false) }
    Preference(
        title = title,
        summary = if (name.isBlank()) unset else listOf(name, detail).filter { it.isNotBlank() }.joinToString(", "),
        onClick = { open = true },
    )
    if (!open) return
    var q by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<KvxPlace>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var searched by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    fun go() {
        if (q.isBlank()) return
        busy = true
        scope.launch { results = OpenMeteo.search(q.trim()); busy = false; searched = true }
    }
    androidx.compose.material3.AlertDialog(
        onDismissRequest = { open = false },
        title = { Text("Weather location") },
        text = {
            Column {
                androidx.compose.material3.OutlinedTextField(
                    value = q, onValueChange = { q = it }, singleLine = true, label = { Text("City or place") },
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(imeAction = androidx.compose.ui.text.input.ImeAction.Search),
                    keyboardActions = androidx.compose.foundation.text.KeyboardActions(onSearch = { go() }),
                    modifier = Modifier.fillMaxWidth(),
                )
                if (busy) Text("Searching...", modifier = Modifier.padding(top = 8.dp))
                else if (searched && results.isEmpty()) Text("No matches", modifier = Modifier.padding(top = 8.dp))
                for (p in results) {
                    Column(Modifier.fillMaxWidth().clickable { onPick(p.name, p.detail, p.lat, p.lon); open = false }.padding(vertical = 8.dp)) {
                        Text(p.name, style = MaterialTheme.typography.bodyLarge)
                        if (p.detail.isNotBlank()) Text(p.detail, style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        },
        confirmButton = { androidx.compose.material3.TextButton(onClick = { go() }) { Text("Search") } },
        dismissButton = {
            Row {
                if (name.isNotBlank()) androidx.compose.material3.TextButton(onClick = { onPick("", "", 0.0, 0.0); open = false }) { Text("Use provider") }
                androidx.compose.material3.TextButton(onClick = { open = false }) { Text("Close") }
            }
        },
    )
}
