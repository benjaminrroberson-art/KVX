package de.mm20.launcher2.ui.songshare

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import androidx.navigation3.runtime.rememberNavBackStack
import de.mm20.launcher2.ui.R
import de.mm20.launcher2.ui.base.BaseActivity
import de.mm20.launcher2.ui.base.ProvideSettings
import de.mm20.launcher2.ui.component.preferences.PreferenceScreen
import de.mm20.launcher2.ui.launcher.widgets.facesclock.np.MediaState
import de.mm20.launcher2.ui.locals.LocalBackStack
import de.mm20.launcher2.ui.overlays.OverlayHost
import de.mm20.launcher2.ui.settings.SettingsActivity
import de.mm20.launcher2.ui.settings.main.MainRoute
import de.mm20.launcher2.ui.theme.LauncherTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Share a song from any music app, or the one that is playing, and get a link for every service. */
class SongShareActivity : BaseActivity() {

    companion object {
        const val ACTION_NOW_PLAYING = "de.mm20.launcher2.songshare.NOW_PLAYING"

        fun nowPlayingIntent(c: Context): Intent =
            Intent(c, SongShareActivity::class.java).setAction(ACTION_NOW_PLAYING)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    enum class Phase { EMPTY, LOADING, RESULT }

    private var phase by mutableStateOf(Phase.EMPTY)
    private var item by mutableStateOf<Item?>(null)
    private var source: Svc? = null
    private var origUrl: String? = null
    private var caption by mutableStateOf("")
    private var art by mutableStateOf<Bitmap?>(null)
    private var rows by mutableStateOf<List<LinkRow>>(emptyList())
    private var rowsBusy by mutableStateOf(false)
    private var copied by mutableStateOf<Svc?>(null)
    private var finding by mutableStateOf<Set<Svc>>(emptySet())
    private var findFailed by mutableStateOf<Set<Svc>>(emptySet())

    private var fixOpen by mutableStateOf(false)
    private var fixKind by mutableStateOf(Kind.SONG)
    private var fixQuery by mutableStateOf("")
    private var fixResults by mutableStateOf<List<Item>>(emptyList())
    private var fixBusy by mutableStateOf(false)
    private var fixSearched by mutableStateOf(false)

    private var flow: Job? = null
    private var rowsJob: Job? = null
    private var artJob: Job? = null
    private var fixJob: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            LauncherTheme {
                ProvideSettings {
                    OverlayHost {
                        androidx.compose.runtime.CompositionLocalProvider(LocalBackStack provides rememberNavBackStack(MainRoute)) {
                            Screen()
                        }
                    }
                }
            }
        }
        if (savedInstanceState == null) handle(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handle(intent)
    }

    private fun handle(i: Intent?) {
        if (i == null) return
        if (i.action == ACTION_NOW_PLAYING) { startNowPlaying(); return }
        if (i.action == Intent.ACTION_SEND && i.type?.startsWith("text/") == true) {
            val text = i.getStringExtra(Intent.EXTRA_TEXT) ?: ""
            val subj = i.getStringExtra(Intent.EXTRA_SUBJECT) ?: i.getStringExtra(Intent.EXTRA_TITLE)
            if (text.isNotBlank()) start(text, subj)
        }
    }

    // ---------- flow ----------

    private fun reset() {
        flow?.cancel(); rowsJob?.cancel(); artJob?.cancel(); fixJob?.cancel()
        phase = Phase.LOADING
        item = null
        rows = emptyList()
        rowsBusy = false
        art = null
        fixOpen = false
        fixResults = emptyList()
        fixSearched = false
        finding = emptySet()
        findFailed = emptySet()
    }

    private fun start(text: String, subj: String?) {
        reset()
        flow = lifecycleScope.launch {
            val res = withContext(Dispatchers.IO) {
                try { Resolver.identify(text, subj) } catch (e: Exception) { Resolver.Result(null, null, null, "") }
            }
            source = res.source
            origUrl = res.origUrl
            phase = Phase.RESULT
            val found = res.item
            item = found
            if (found == null) {
                caption = "Couldn’t work out the song from that share. Search for it below."
                fixOpen = true
                fixKind = Kind.SONG
                fixQuery = ""
            } else {
                caption = res.note
                loadArt(found)
                computeRows()
            }
        }
    }

    private fun message(msg: String) {
        reset()
        phase = Phase.RESULT
        caption = msg
    }

    private fun startNowPlaying() {
        reset()
        flow = lifecycleScope.launch {
            MediaState.ensureStarted(applicationContext)
            var n = 0
            while (MediaState.title.isBlank() && n < 15) { delay(100); n++ }
            val title = MediaState.title
            if (title.isBlank()) {
                message("Nothing is playing right now. Start a song, then tap again.")
                return@launch
            }
            val artist = MediaState.artist
            val album = MediaState.album
            val src = Resolver.svcForPackage(MediaState.pkg)
            val res = withContext(Dispatchers.IO) {
                try { Resolver.identifyMeta(title, artist, album, src) } catch (e: Exception) { Resolver.Result(null, src, null, "") }
            }
            source = res.source
            origUrl = null
            phase = Phase.RESULT
            item = res.item
            caption = res.note
            res.item?.let { loadArt(it); computeRows() }
        }
    }

    private fun loadArt(i: Item) {
        art = null
        val u = i.art ?: return
        artJob?.cancel()
        artJob = lifecycleScope.launch {
            val b = withContext(Dispatchers.IO) { Resolver.bitmap(u) }
            if (b != null) art = b
        }
    }

    private fun computeRows() {
        val i = item ?: return
        val s = source
        val o = origUrl
        rowsJob?.cancel()
        rowsBusy = true
        rows = emptyList()
        rowsJob = lifecycleScope.launch {
            val r = withContext(Dispatchers.IO) {
                try { Resolver.rows(i, s, o) } catch (e: Exception) { emptyList() }
            }
            rows = r.filter { SongSharePrefs.svcOn(this@SongShareActivity, it.svc) }
            rowsBusy = false
        }
    }

    private fun findExact(r: LinkRow) {
        val i = item ?: return
        finding = finding + r.svc
        findFailed = findFailed - r.svc
        lifecycleScope.launch {
            val u = withContext(Dispatchers.IO) { try { Resolver.findExact(i, r.svc) } catch (e: Exception) { null } }
            finding = finding - r.svc
            if (u != null) {
                rows = rows.map { if (it.svc == r.svc) LinkRow(it.svc, u, true, "Direct link · found by web search, title checked") else it }
            } else {
                findFailed = findFailed + r.svc
            }
        }
    }

    private fun pick(i: Item) {
        item = i
        phase = Phase.RESULT
        caption = "Picked by you."
        fixOpen = false
        fixResults = emptyList()
        fixSearched = false
        loadArt(i)
        computeRows()
    }

    private fun openFix() {
        val i = item
        fixOpen = true
        fixSearched = false
        fixResults = emptyList()
        if (i != null) {
            fixKind = i.kind
            fixQuery = Resolver.query(i)
            runFix()
        }
    }

    private fun runFix() {
        val q = fixQuery.trim()
        if (q.isEmpty()) return
        fixBusy = true
        fixSearched = false
        fixResults = emptyList()
        val k = fixKind
        fixJob?.cancel()
        fixJob = lifecycleScope.launch {
            val r = withContext(Dispatchers.IO) { try { Resolver.search(q, k) } catch (e: Exception) { emptyList() } }
            fixResults = r
            fixBusy = false
            fixSearched = true
        }
    }

    private fun copy(r: LinkRow) {
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("Song link", r.url))
        copied = r.svc
        lifecycleScope.launch { delay(1600); if (copied == r.svc) copied = null }
    }

    private fun open(r: LinkRow) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(r.url))) } catch (e: Exception) { }
    }

    // ---------- UI ----------

    @Composable
    private fun Screen() {
        val ctx = LocalContext.current
        PreferenceScreen(
            title = "Song Share",
            topBarActions = {
                IconButton(onClick = {
                    startActivity(Intent(ctx, SettingsActivity::class.java).putExtra(SettingsActivity.EXTRA_ROUTE, SettingsActivity.ROUTE_SONGSHARE))
                }) { Icon(painterResource(R.drawable.settings_24px), "Song Share settings") }
            },
        ) {
            when (phase) {
                Phase.LOADING -> item { LoadingCard() }
                Phase.EMPTY -> {
                    item { EmptyCard() }
                    item { FixCard() }
                }
                Phase.RESULT -> {
                    val i = item
                    if (i == null) {
                        item { Card { Text(caption, style = MaterialTheme.typography.bodyLarge) } }
                        item { FixCard() }
                    } else {
                        item { MatchCard(i) }
                        if (fixOpen) item { FixCard() }
                        item { LinksHeader() }
                        if (rowsBusy) item { Text("Finding links…", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(horizontal = 16.dp)) }
                        else items(rows.size) { n -> LinkRowItem(rows[n]) }
                    }
                }
            }
        }
    }

    @Composable
    private fun Card(content: @Composable () -> Unit) {
        Surface(
            shape = MaterialTheme.shapes.large,
            color = MaterialTheme.colorScheme.surfaceBright,
            modifier = Modifier.fillMaxWidth(),
        ) { Column(Modifier.padding(16.dp)) { content() } }
    }

    @Composable
    private fun LoadingCard() {
        Card {
            Row(Modifier.fillMaxWidth().padding(vertical = 16.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(Modifier.size(28.dp))
                Text("  Finding your song…", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }

    @Composable
    private fun EmptyCard() {
        Card {
            Text("Share a song here", style = MaterialTheme.typography.titleLarge)
            Text(
                "In Apple Music, Spotify or any music app, tap Share on a song, album or artist and pick Song Share. You’ll get a link for every service to copy.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 8.dp),
            )
            Button(onClick = { startNowPlaying() }, modifier = Modifier.fillMaxWidth().padding(top = 14.dp)) { Text("Use what’s playing now") }
        }
    }

    @Composable
    private fun MatchCard(i: Item) {
        Card {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(92.dp).clip(MaterialTheme.shapes.large).background(MaterialTheme.colorScheme.surfaceContainerHighest),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(i.title.take(1).uppercase(), style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    art?.let {
                        androidx.compose.foundation.Image(
                            it.asImageBitmap(), null,
                            contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                            modifier = Modifier.matchParentSize(),
                        )
                    }
                }
                Column(Modifier.weight(1f).padding(start = 16.dp)) {
                    Text(i.kind.label.uppercase(), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    Text(i.title, style = MaterialTheme.typography.titleLarge, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    if (i.artist.isNotBlank()) Text(i.artist, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (i.album.isNotBlank()) Text(i.album, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            if (caption.isNotBlank()) Text(caption, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 12.dp))
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Is this the right ${i.kind.label.lowercase()}?", style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                FilledTonalButton(onClick = { if (fixOpen) fixOpen = false else openFix() }) { Text(if (fixOpen) "Close" else "Not it") }
            }
        }
    }

    @Composable
    private fun FixCard() {
        Card {
            Text(if (item != null) "Find the right one" else "Search by hand", style = MaterialTheme.typography.titleMedium)
            Row(Modifier.padding(vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (k in Kind.values()) {
                    FilterChip(
                        selected = k == fixKind,
                        onClick = { fixKind = k; fixResults = emptyList(); fixSearched = false; if (fixQuery.isNotBlank()) runFix() },
                        label = { Text(k.label) },
                    )
                }
            }
            OutlinedTextField(
                value = fixQuery,
                onValueChange = { fixQuery = it },
                singleLine = true,
                placeholder = { Text("Song, album or artist") },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { runFix() }),
                modifier = Modifier.fillMaxWidth(),
            )
            Button(onClick = { runFix() }, modifier = Modifier.fillMaxWidth().padding(top = 10.dp)) { Text("Search") }
            if (fixBusy) Text("Searching…", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 12.dp))
            else if (fixSearched && fixResults.isEmpty()) Text("No matches. Try different words.", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 12.dp))
            for (r in fixResults) {
                Surface(
                    shape = MaterialTheme.shapes.medium,
                    color = MaterialTheme.colorScheme.surfaceContainerHighest,
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp).clickable { pick(r) },
                ) {
                    Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                        Text(r.title, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        val sub = listOf(r.artist, r.album).filter { it.isNotBlank() }.joinToString("  ·  ")
                        if (sub.isNotEmpty()) Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
    }

    @Composable
    private fun LinksHeader() {
        val ctx = LocalContext.current
        val tap = SongSharePrefs.tapCopies(ctx)
        Column(Modifier.padding(horizontal = 4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Copy a link", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                TextButton(onClick = { if (!rowsBusy) computeRows() }) { Text(if (rowsBusy) "Searching…" else "Search again") }
            }
            Text(
                "Direct links go straight to the song. Search links only open that app’s search for it, so whoever you send one to needs an extra tap. " +
                    (if (tap) "Tap a row to copy, hold to open." else "Tap a row to open, hold to copy."),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }

    @OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
    @Composable
    private fun LinkRowItem(r: LinkRow) {
        val ctx = LocalContext.current
        val tap = SongSharePrefs.tapCopies(ctx)
        Surface(
            shape = MaterialTheme.shapes.large,
            color = MaterialTheme.colorScheme.surfaceBright,
            modifier = Modifier.fillMaxWidth().clip(MaterialTheme.shapes.large).combinedClickable(
                onClick = { if (tap) copy(r) else open(r) },
                onLongClick = { if (tap) open(r) else copy(r) },
            ),
        ) {
            Row(Modifier.padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(36.dp).clip(CircleShape).background(Color(r.svc.color)), contentAlignment = Alignment.Center) {
                    Text(r.svc.label.take(1), color = Color.White, fontWeight = FontWeight.Bold)
                }
                Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
                    Text(r.svc.label, style = MaterialTheme.typography.titleMedium)
                    Text(
                        if (r.svc in findFailed) "Couldn’t find an exact link · tap below to retry" else r.note,
                        style = MaterialTheme.typography.bodySmall,
                        color = if (r.exact) Color(0xFF2EAD5A) else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    if (!r.exact && r.svc.canFind && item != null && SongSharePrefs.webFind(ctx)) {
                        Text(
                            if (r.svc in finding) "Searching…" else "Try to find the exact link ›",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(top = 6.dp).clickable { if (r.svc !in finding) findExact(r) },
                        )
                    }
                }
                Text(
                    if (copied == r.svc) "Copied ✓" else if (tap) "Copy" else "Open",
                    style = MaterialTheme.typography.labelLarge,
                    color = if (copied == r.svc) Color(0xFF2EAD5A) else MaterialTheme.colorScheme.primary,
                )
            }
        }
    }
}
