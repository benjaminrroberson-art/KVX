package de.mm20.launcher2.ui.edge

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import de.mm20.launcher2.ui.settings.SettingsActivity

/**
 * The accessibility service points here as its settings page. The settings themselves are now
 * regular launcher settings pages, so this just forwards to them.
 */
class EdgeSettingsActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        startActivity(
            Intent(this, SettingsActivity::class.java)
                .putExtra(SettingsActivity.EXTRA_ROUTE, SettingsActivity.ROUTE_EDGE)
        )
        finish()
    }
}
