package de.mm20.launcher2.ui.launcher.widgets.facesclock

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

// ---------------------------------------------------------------- Fish tank

internal class FishScene(c: Context) : Scene(c) {
    override val needsAudio = true

    private class Fish(var x: Float, var y: Float, val sz: Float, val hue: Float, val kind: Int) {
        var vx = 0f
        var vy = 0f
        var ph = 0f
        var tx = x
        var ty = y
        var wait = 0f
    }

    private class Food(var x: Float, var y: Float)

    private val fish = ArrayList<Fish>()
    private val food = ArrayList<Food>()
    private val bub = ArrayList<FloatArray>()
    private var count = -1
    private var bubT = 0f
    private var lastBeat = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rect = RectF()
    private val rnd = java.util.Random(7)
    private val pebX = FloatArray(14) { rnd.nextFloat() }
    private val pebS = FloatArray(14) { 0.5f + rnd.nextFloat() }

    private fun rebuild(e: SceneEnv, n: Int) {
        fish.clear()
        for (i in 0 until n) {
            val sz = e.rr(8f, 17f) * e.dp
            val f = Fish(e.rr(0.1f, 0.9f) * e.w, e.rr(0.15f, 0.7f) * e.h, sz, e.rf(), (e.rf() * 3).toInt())
            f.vx = e.rr(-1f, 1f) * 20f * e.dp
            fish.add(f)
        }
        count = n
    }

    override fun down(x: Float, y: Float, e: SceneEnv) {}

    override fun up(x: Float, y: Float, e: SceneEnv, tap: Boolean) {
        if (!tap) return
        for (i in 0 until 5) food.add(Food(x + e.rr(-14f, 14f) * e.dp, max(0f, y * 0.5f) + e.rr(-6f, 6f) * e.dp))
    }

    override fun draw(c: Canvas, e: SceneEnv) {
        val w = e.w
        val h = e.h
        val dp = e.dp
        val want = e.amount + 2
        if (count != want) rebuild(e, want)
        val day = e.day
        val top = mixC(0xFF071A33.toInt(), 0xFF5CC8F2.toInt(), day)
        val bot = mixC(0xFF02060F.toInt(), 0xFF0B4A74.toInt(), day)
        p.shader = LinearGradient(0f, 0f, 0f, h, top, bot, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, p)
        p.shader = null
        // light shafts
        if (day > 0.05f) {
            for (i in 0 until 4) {
                val x0 = w * (0.12f + i * 0.25f) + sin(e.t * 0.3f + i) * 14f * dp
                path.reset()
                path.moveTo(x0 - 16f * dp, 0f); path.lineTo(x0 + 16f * dp, 0f)
                path.lineTo(x0 + 60f * dp, h); path.lineTo(x0 - 30f * dp, h); path.close()
                p.color = alC(Color.WHITE, 0.07f * day)
                c.drawPath(path, p)
            }
        }
        val floorY = h * 0.88f
        // plants
        val sway = 1f + e.bass * 2f
        for (i in 0 until 6) {
            val bx = w * (0.08f + i * 0.17f)
            val th = h * (0.18f + 0.08f * ((i * 7) % 3))
            path.reset()
            path.moveTo(bx, floorY)
            val steps = 6
            for (s in 1..steps) {
                val f = s / steps.toFloat()
                val off = sin(e.t * 1.2f + i + f * 3f) * 7f * dp * f * sway
                path.lineTo(bx + off, floorY - th * f)
            }
            p.style = Paint.Style.STROKE
            p.strokeWidth = 4f * dp
            p.strokeCap = Paint.Cap.ROUND
            p.color = mixC(0xFF0A2B1A.toInt(), mixC(0xFF1F7A3A.toInt(), 0xFF49B96A.toInt(), (i % 3) / 2f), 0.35f + 0.65f * day)
            c.drawPath(path, p)
            p.style = Paint.Style.FILL
        }
        // sand
        path.reset()
        path.moveTo(0f, h)
        path.lineTo(0f, floorY)
        var x = 0f
        while (x <= w + 8f) {
            path.lineTo(x, floorY + sin(x / (30f * dp)) * 3f * dp)
            x += 8f
        }
        path.lineTo(w, h); path.close()
        p.color = mixC(0xFF2A2418.toInt(), 0xFFD8C08A.toInt(), 0.3f + 0.7f * day)
        c.drawPath(path, p)
        for (i in pebX.indices) {
            p.color = mixC(0xFF3B352A.toInt(), 0xFF8C7B5B.toInt(), 0.3f + 0.7f * day)
            c.drawCircle(pebX[i] * w, floorY + (h - floorY) * (0.35f + 0.5f * pebS[i] % 1f), 2.5f * dp * pebS[i], p)
        }
        // bubbles
        bubT -= e.dt
        val beatHit = e.beat > 0.8f && lastBeat <= 0.8f
        lastBeat = e.beat
        if (bubT <= 0f || beatHit) {
            bubT = e.rr(0.3f, 0.9f)
            val n = if (beatHit) 3 else 1
            for (k in 0 until n) bub.add(floatArrayOf(w * 0.86f + e.rr(-6f, 6f) * dp, floorY, e.rr(1.5f, 4f) * dp, e.rr(25f, 50f) * dp))
        }
        val bi = bub.iterator()
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1f * dp
        while (bi.hasNext()) {
            val b = bi.next()
            b[1] -= b[3] * e.dt
            b[0] += sin(e.t * 3f + b[1] * 0.05f) * 6f * dp * e.dt
            if (b[1] < -10f) { bi.remove(); continue }
            p.color = alC(Color.WHITE, 0.55f)
            c.drawCircle(b[0], b[1], b[2], p)
        }
        p.style = Paint.Style.FILL
        // food
        val fi = food.iterator()
        while (fi.hasNext()) {
            val f = fi.next()
            f.y = min(floorY - 2f * dp, f.y + 24f * dp * e.dt)
            p.color = 0xFFE8A64A.toInt()
            c.drawCircle(f.x, f.y, 2f * dp, p)
        }
        // fish
        val boost = if (e.dance) 1f + e.level * 2.5f + e.beat * 1.2f else 1f
        for ((idx, f) in fish.withIndex()) {
            var target: Food? = null
            var bd = 1e9f
            for (fd in food) {
                val d = hypot(fd.x - f.x, fd.y - f.y)
                if (d < bd) { bd = d; target = fd }
            }
            if (target != null) { f.tx = target.x; f.ty = target.y }
            else {
                f.wait -= e.dt
                if (f.wait <= 0f || hypot(f.tx - f.x, f.ty - f.y) < 12f * dp) {
                    f.tx = e.rr(0.06f, 0.94f) * w
                    f.ty = e.rr(0.1f, 0.78f) * h
                    f.wait = e.rr(2f, 6f)
                }
            }
            val dx = f.tx - f.x
            val dy = f.ty - f.y
            val d = max(1f, hypot(dx, dy))
            val spd = (22f + f.sz / dp * 1.2f) * dp * boost * (if (target != null) 1.5f else 1f)
            f.vx += (dx / d * spd - f.vx) * min(1f, e.dt * 1.8f)
            f.vy += (dy / d * spd - f.vy) * min(1f, e.dt * 1.8f)
            if (e.dance) {
                f.vy += sin(e.t * 9f + idx) * e.level * 260f * dp * e.dt
                f.vx += sin(e.t * 6f + idx * 1.7f) * e.level * 200f * dp * e.dt
                if (beatHit) { f.vy -= e.rr(50f, 110f) * dp; f.vx += (if (f.vx >= 0f) 1f else -1f) * e.rr(20f, 60f) * dp }
            }
            f.x += f.vx * e.dt
            f.y += f.vy * e.dt
            f.x = f.x.coerceIn(f.sz, w - f.sz)
            f.y = f.y.coerceIn(h * 0.06f, floorY - f.sz)
            f.ph += e.dt * (6f + hypot(f.vx, f.vy) / dp * 0.12f + e.level * 14f)
            val dir = if (f.vx >= 0f) 1f else -1f
            if (target != null && bd < f.sz * 0.9f) food.remove(target)
            drawFish(c, f.x, f.y, f.sz, dir, f.hue, f.kind, sin(f.ph), e)
        }
        // night shade
        if (day < 0.99f) {
            p.color = alC(0xFF000814.toInt(), (1f - day) * 0.3f)
            c.drawRect(0f, 0f, w, h, p)
        }
    }

    private fun drawFish(c: Canvas, x: Float, y: Float, s: Float, dir: Float, hue: Float, kind: Int, wag: Float, e: SceneEnv) {
        c.save()
        c.translate(x, y)
        c.scale(dir, 1f)
        val body = if (e.useColor) mixC(e.custom, Color.WHITE, hue * 0.4f) else Color.HSVToColor(floatArrayOf(((hue * 60f) + (if (kind == 1) 190f else 5f)) % 360f, 0.75f, 1f))
        val dark = mixC(body, Color.BLACK, 0.35f)
        // tail
        path.reset()
        path.moveTo(-s * 0.8f, 0f)
        path.lineTo(-s * 1.7f, -s * 0.6f + wag * s * 0.35f)
        path.lineTo(-s * 1.7f, s * 0.6f + wag * s * 0.35f)
        path.close()
        p.color = dark
        c.drawPath(path, p)
        // dorsal
        path.reset()
        path.moveTo(-s * 0.4f, -s * 0.4f)
        path.quadTo(0f, -s * 1.0f, s * 0.5f, -s * 0.4f)
        path.close()
        c.drawPath(path, p)
        // body
        rect.set(-s, -s * 0.55f, s, s * 0.55f)
        p.color = body
        c.drawOval(rect, p)
        if (kind == 0) {
            p.color = alC(Color.WHITE, 0.7f)
            c.drawRect(-s * 0.1f, -s * 0.52f, s * 0.12f, s * 0.52f, p)
        } else if (kind == 2) {
            p.color = dark
            c.drawCircle(-s * 0.2f, 0f, s * 0.18f, p)
            c.drawCircle(s * 0.25f, s * 0.12f, s * 0.14f, p)
        }
        p.color = Color.WHITE
        c.drawCircle(s * 0.58f, -s * 0.12f, s * 0.17f, p)
        p.color = Color.BLACK
        c.drawCircle(s * 0.62f, -s * 0.12f, s * 0.08f, p)
        c.restore()
    }
}

// ---------------------------------------------------------------- Ant farm

internal class AntScene(c: Context) : Scene(c) {
    private val GW = 56
    private val GH = 28
    private val SKY = 2
    private val open = BooleanArray(GW * GH)
    private val pile = IntArray(GW)
    private val sp = c.getSharedPreferences("kvx_scene", Context.MODE_PRIVATE)
    private var dugToday = 0
    private var dirty = false
    private var saveAt = 0f
    private val shaft = GW / 2
    private val homeIdx = 9 * GW + shaft
    private var dSurf = IntArray(GW * GH)
    private var dHome = IntArray(GW * GH)
    private var dCrumb = IntArray(GW * GH)
    private var crumb = -1
    private val specks = FloatArray(260) { java.util.Random(5).let { r -> 0f } }
    private val srnd = java.util.Random(11)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    private class Ant(var cx: Int, var cy: Int) {
        var nx = cx
        var ny = cy
        var f = 1f
        var carry = 0
        var px = cx
        var py = cy
        var speed = 1f
        var ang = 0f
    }

    private val ants = ArrayList<Ant>()
    private var nAnts = -1

    init {
        val saved = sp.getString("ants", null)
        if (saved != null && saved.length == GW * GH) {
            for (i in saved.indices) open[i] = saved[i] == '1'
            dugToday = if (sp.getInt("ants_day", -1) == java.time.LocalDate.now().dayOfYear) sp.getInt("ants_dug", 0) else 0
        } else {
            for (y in SKY..8) open[y * GW + shaft] = true
            for (y in 8..10) for (x in shaft - 4..shaft + 4) open[y * GW + x] = true
        }
        for (x in 0 until GW) open[SKY * GW + x] = true
        for (i in specks.indices) specks[i] = srnd.nextFloat()
        recompute()
    }

    private fun bfs(src: Int): IntArray {
        val d = IntArray(GW * GH) { -1 }
        if (src < 0 || !open[src]) return d
        val q = IntArray(GW * GH)
        var h = 0
        var t = 0
        q[t++] = src; d[src] = 0
        while (h < t) {
            val i = q[h++]
            val x = i % GW
            val y = i / GW
            for (k in 0 until 4) {
                val nx = x + (if (k == 0) 1 else if (k == 1) -1 else 0)
                val ny = y + (if (k == 2) 1 else if (k == 3) -1 else 0)
                if (nx < 0 || ny < 0 || nx >= GW || ny >= GH) continue
                val j = ny * GW + nx
                if (open[j] && d[j] < 0) { d[j] = d[i] + 1; q[t++] = j }
            }
        }
        return d
    }

    private fun recompute() {
        dSurf = bfs(SKY * GW + shaft)
        dHome = bfs(homeIdx)
        dCrumb = bfs(crumb)
    }

    private fun save() {
        val sb = StringBuilder(GW * GH)
        for (b in open) sb.append(if (b) '1' else '0')
        sp.edit().putString("ants", sb.toString()).putInt("ants_day", java.time.LocalDate.now().dayOfYear).putInt("ants_dug", dugToday).apply()
        dirty = false
    }

    override fun detach() { if (dirty) save() }

    override fun up(x: Float, y: Float, e: SceneEnv, tap: Boolean) {
        if (!tap) return
        val cx = (x / e.w * GW).toInt().coerceIn(1, GW - 2)
        crumb = SKY * GW + cx
        recompute()
    }

    private fun neighbours(i: Int, openOnly: Boolean): IntArray {
        val x = i % GW
        val y = i / GW
        val out = ArrayList<Int>(4)
        for (k in 0 until 4) {
            val nx = x + (if (k == 0) 1 else if (k == 1) -1 else 0)
            val ny = y + (if (k == 2) 1 else if (k == 3) -1 else 0)
            if (nx < 0 || ny < 0 || nx >= GW || ny >= GH) continue
            val j = ny * GW + nx
            if (!openOnly || open[j]) out.add(j)
        }
        return out.toIntArray()
    }

    private fun tryDig(a: Ant, e: SceneEnv): Boolean {
        if (dugToday >= 34 || a.cy < 6) return false
        val here = a.cy * GW + a.cx
        val ns = neighbours(here, false)
        ns.shuffle()
        for (j in ns) {
            if (open[j]) continue
            val x = j % GW
            val y = j / GW
            if (x < 2 || x > GW - 3 || y < 6 || y > GH - 2) continue
            var o = 0
            for (k in neighbours(j, true)) o++
            if (o > 1) continue
            open[j] = true
            dugToday++
            dirty = true
            a.carry = 1
            recompute()
            return true
        }
        return false
    }

    private fun step(a: Ant, e: SceneEnv) {
        val here = a.cy * GW + a.cx
        if (a.carry == 1) {
            if (a.cy == SKY) {
                a.carry = 0
                pile[a.cx.coerceIn(0, GW - 1)]++
                for (i in 0 until GW) if (pile[i] > 5) pile[i] = 5
                return
            }
        } else if (a.carry == 2) {
            if (here == homeIdx) { a.carry = 0 }
        } else if (crumb >= 0 && here == crumb) {
            a.carry = 2
            crumb = -1
            recompute()
        }
        val ns = neighbours(here, true)
        if (ns.isEmpty()) return
        var pick = -1
        if (a.carry == 1) {
            var best = Int.MAX_VALUE
            for (j in ns) { val d = dSurf[j]; if (d in 0 until best) { best = d; pick = j } }
        } else if (a.carry == 2) {
            var best = Int.MAX_VALUE
            for (j in ns) { val d = dHome[j]; if (d in 0 until best) { best = d; pick = j } }
        } else if (crumb >= 0 && dCrumb[here] >= 0 && e.rf() < 0.85f) {
            var best = Int.MAX_VALUE
            for (j in ns) { val d = dCrumb[j]; if (d in 0 until best) { best = d; pick = j } }
        } else {
            if (e.rf() < 0.02f && tryDig(a, e)) return
            val prev = a.py * GW + a.px
            val cand = ns.filter { it != prev }
            val list = if (cand.isEmpty() || e.rf() < 0.08f) ns.toList() else cand
            // on the surface ants prefer to wander only near the shaft
            pick = list[e.rnd.nextInt(list.size)]
            if (a.cy == SKY && abs((pick % GW) - shaft) > 10) pick = ns.minByOrNull { abs((it % GW) - shaft) } ?: pick
        }
        if (pick < 0) pick = ns[e.rnd.nextInt(ns.size)]
        a.px = a.cx; a.py = a.cy
        a.nx = pick % GW; a.ny = pick / GW
        a.f = 0f
        a.speed = e.rr(0.8f, 1.4f)
    }

    override fun draw(c: Canvas, e: SceneEnv) {
        val w = e.w
        val h = e.h
        val dp = e.dp
        if (nAnts != e.amount * 2 + 2) {
            nAnts = e.amount * 2 + 2
            ants.clear()
            for (i in 0 until nAnts) {
                val a = Ant(shaft + (i % 5) - 2, 9)
                if (!open[a.cy * GW + a.cx]) { a.cx = shaft; a.cy = 9 }
                a.nx = a.cx; a.ny = a.cy; a.px = a.cx; a.py = a.cy
                ants.add(a)
            }
        }
        val cw = w / GW
        val ch = h / GH
        // sky
        p.shader = LinearGradient(0f, 0f, 0f, ch * 3f, mixC(0xFF0A1030.toInt(), 0xFF8FD3FF.toInt(), e.day), mixC(0xFF1B2547.toInt(), 0xFFD9F1FF.toInt(), e.day), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, ch * 3f, p)
        p.shader = null
        // dirt
        p.shader = LinearGradient(0f, ch * 3f, 0f, h, mixC(0xFF3B2A1C.toInt(), 0xFF8A6240.toInt(), 0.4f + 0.6f * e.day), mixC(0xFF1D140C.toInt(), 0xFF4B3321.toInt(), 0.4f + 0.6f * e.day), Shader.TileMode.CLAMP)
        c.drawRect(0f, ch * 3f, w, h, p)
        p.shader = null
        for (i in specks.indices step 2) {
            p.color = alC(Color.BLACK, 0.18f)
            c.drawCircle(specks[i] * w, ch * 3f + specks[(i + 1) % specks.size] * (h - ch * 3f), 1.4f * dp, p)
        }
        // tunnels
        val tun = mixC(0xFF140C06.toInt(), 0xFF2A1C10.toInt(), e.day * 0.5f)
        p.color = tun
        for (y in SKY + 1 until GH) for (x in 0 until GW) {
            if (open[y * GW + x]) c.drawRoundRect(x * cw - 0.6f, y * ch - 0.6f, (x + 1) * cw + 0.6f, (y + 1) * ch + 0.6f, cw * 0.4f, ch * 0.4f, p)
        }
        // dirt piles
        p.color = mixC(0xFF5A3F28.toInt(), 0xFF9A7048.toInt(), e.day)
        for (x in 0 until GW) if (pile[x] > 0) {
            c.drawOval((x - 1.2f) * cw, ch * 2f - pile[x] * ch * 0.35f, (x + 2.2f) * cw, ch * 2.6f, p)
        }
        // crumb
        if (crumb >= 0) {
            p.color = 0xFFE8A64A.toInt()
            c.drawCircle((crumb % GW + 0.5f) * cw, (crumb / GW + 0.5f) * ch, 2.4f * dp, p)
        }
        // ants
        for (a in ants) {
            if (a.f >= 1f) { a.cx = a.nx; a.cy = a.ny; step(a, e); if (a.f >= 1f) a.f = 1f }
            a.f = min(1f, a.f + e.dt * 4.2f * a.speed * (if (a.carry != 0) 0.8f else 1f))
            val fx = lerpF(a.cx + 0.5f, a.nx + 0.5f, a.f) * cw
            val fy = lerpF(a.cy + 0.5f, a.ny + 0.5f, a.f) * ch
            if (a.nx != a.cx || a.ny != a.cy) a.ang = kotlin.math.atan2((a.ny - a.cy) * ch, (a.nx - a.cx) * cw)
            drawAnt(c, fx, fy, a.ang, a.carry, e)
        }
        // depth shade
        p.shader = LinearGradient(0f, 0f, 0f, h, 0x00000000, alC(Color.BLACK, 0.25f + (1f - e.day) * 0.2f), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, p)
        p.shader = null
    }

    private fun drawAnt(c: Canvas, x: Float, y: Float, ang: Float, carry: Int, e: SceneEnv) {
        val dp = e.dp
        val s = 2.1f * dp
        c.save()
        c.translate(x, y)
        c.rotate(ang * 180f / PI.toFloat())
        p.color = if (e.useColor) e.custom else 0xFF0E0E0E.toInt()
        c.drawCircle(-s * 1.1f, 0f, s * 0.8f, p)
        c.drawCircle(0f, 0f, s * 0.6f, p)
        c.drawCircle(s * 1.0f, 0f, s * 0.55f, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 0.7f * dp
        val wig = sin(e.t * 22f + x * 0.3f) * 0.6f * dp
        c.drawLine(-0.3f * s, 0f, -0.9f * s, -s * 1.1f + wig, p)
        c.drawLine(0.3f * s, 0f, 0.1f * s, s * 1.1f - wig, p)
        c.drawLine(0.3f * s, 0f, 0.9f * s, -s * 1.1f - wig, p)
        c.drawLine(-0.3f * s, 0f, -0.9f * s, s * 1.1f + wig, p)
        p.style = Paint.Style.FILL
        if (carry == 1) { p.color = 0xFF7A5230.toInt(); c.drawCircle(s * 1.7f, 0f, s * 0.6f, p) }
        if (carry == 2) { p.color = 0xFFE8A64A.toInt(); c.drawCircle(s * 1.7f, 0f, s * 0.6f, p) }
        c.restore()
    }
}

// ---------------------------------------------------------------- Window on the weather

internal class WindowScene(c: Context) : Scene(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val srnd = java.util.Random(3)
    private val starX = FloatArray(70) { srnd.nextFloat() }
    private val starY = FloatArray(70) { srnd.nextFloat() * 0.6f }
    private val bW = FloatArray(14) { 0.05f + srnd.nextFloat() * 0.07f }
    private val bH = FloatArray(14) { 0.12f + srnd.nextFloat() * 0.3f }
    private val bLit = BooleanArray(14 * 12) { srnd.nextFloat() < 0.4f }
    private var drops = FloatArray(0)
    private var dropN = 0
    private val flakes = FloatArray(160 * 3)
    private val glass = ArrayList<FloatArray>()
    private var fw = 0
    private var fh = 0
    private var clear = FloatArray(0)
    private var fogBmp: Bitmap? = null
    private var pix = IntArray(0)
    private var flash = 0f
    private var flashAt = 4f
    private var lastX = -1f
    private var lastY = -1f
    private val cloudX = FloatArray(6) { srnd.nextFloat() }
    private val cloudY = FloatArray(6) { 0.1f + srnd.nextFloat() * 0.3f }
    private val rain = FloatArray(220 * 3) { srnd.nextFloat() }

    private fun wipe(x: Float, y: Float, e: SceneEnv) {
        if (fw == 0) return
        val cx = x / e.w * fw
        val cy = y / e.h * fh
        val r = 22f * e.dp / e.w * fw
        for (iy in max(0, (cy - r).toInt())..min(fh - 1, (cy + r).toInt())) for (ix in max(0, (cx - r).toInt())..min(fw - 1, (cx + r).toInt())) {
            val d = hypot(ix - cx, iy - cy)
            if (d < r) clear[iy * fw + ix] = max(clear[iy * fw + ix], 1f - d / r * 0.3f)
        }
    }

    override fun down(x: Float, y: Float, e: SceneEnv) { lastX = x; lastY = y; wipe(x, y, e) }

    override fun move(x: Float, y: Float, e: SceneEnv) {
        if (lastX >= 0f) {
            val n = max(1, (hypot(x - lastX, y - lastY) / (6f * e.dp)).toInt())
            for (i in 1..n) wipe(lerpF(lastX, x, i / n.toFloat()), lerpF(lastY, y, i / n.toFloat()), e)
        }
        lastX = x; lastY = y
    }

    override fun up(x: Float, y: Float, e: SceneEnv, tap: Boolean) { lastX = -1f }

    override fun draw(c: Canvas, e: SceneEnv) {
        val w = e.w
        val h = e.h
        val dp = e.dp
        val code = e.wx
        val isRain = code in 51..67 || code in 80..82 || code >= 95
        val isSnow = code in 71..77 || code == 85 || code == 86
        val isFog = code == 45 || code == 48
        val thunder = code >= 95
        val cloudy = code >= 2
        val heavy = code == 65 || code == 67 || code == 82 || thunder
        val day = e.day
        // sky
        var top = mixC(0xFF070C28.toInt(), 0xFF4E9FE0.toInt(), day)
        var bot = mixC(0xFF1B2A55.toInt(), 0xFFBFE6FF.toInt(), day)
        val dusk = 4f * day * (1f - day)
        top = mixC(top, 0xFF6A4C93.toInt(), dusk * 0.5f)
        bot = mixC(bot, 0xFFFFA45C.toInt(), dusk * 0.7f)
        if (cloudy) {
            val gray = if (isRain || thunder || isSnow) 0.7f else 0.4f
            top = mixC(top, mixC(0xFF1D2330.toInt(), 0xFF7C8794.toInt(), day), gray)
            bot = mixC(bot, mixC(0xFF2A3140.toInt(), 0xFFA9B2BD.toInt(), day), gray)
        }
        p.shader = LinearGradient(0f, 0f, 0f, h, top, bot, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, p)
        p.shader = null
        // stars
        if (day < 0.6f && !cloudy) {
            for (i in starX.indices) {
                p.color = alC(Color.WHITE, (0.4f + 0.4f * sin(e.t * 2f + i)) * (1f - day))
                c.drawCircle(starX[i] * w, starY[i] * h, 1.1f * dp, p)
            }
        }
        // sun or moon
        val (rise, set) = SceneSun.times()
        val now = java.time.LocalTime.now()
        val m = now.hour * 60f + now.minute
        val sunUp = m in rise.toFloat()..set.toFloat()
        val frac = if (sunUp) (m - rise) / (set - rise).toFloat() else {
            val nightLen = 1440f - (set - rise)
            val mm = if (m >= set) m - set else m + 1440f - set
            mm / nightLen
        }
        val bx = w * (0.12f + 0.76f * frac)
        val by = h * (0.62f - 0.5f * sin(frac * PI.toFloat()))
        if (!(cloudy && (isRain || thunder || isSnow))) {
            val col = if (sunUp) 0xFFFFE08A.toInt() else 0xFFE8EDF7.toInt()
            p.shader = RadialGradient(bx, by, 60f * dp, alC(col, if (cloudy) 0.35f else 0.8f), alC(col, 0f), Shader.TileMode.CLAMP)
            c.drawCircle(bx, by, 60f * dp, p)
            p.shader = null
            p.color = alC(col, if (cloudy) 0.5f else 1f)
            c.drawCircle(bx, by, 11f * dp, p)
        }
        // clouds
        if (cloudy) {
            for (i in cloudX.indices) {
                cloudX[i] = (cloudX[i] + e.dt * 0.012f * (1f + i * 0.2f)) % 1.3f
                val cx = (cloudX[i] - 0.15f) * w
                val cy = cloudY[i] * h
                p.color = mixC(0xFF2B3342.toInt(), 0xFFE9EEF4.toInt(), day * (if (isRain || thunder) 0.55f else 0.9f))
                p.alpha = 190
                for (k in 0 until 4) c.drawCircle(cx + k * 22f * dp, cy + (if (k % 2 == 0) 0f else -8f * dp), 20f * dp, p)
            }
        }
        // skyline
        var x = 0f
        var bi = 0
        val gy = h * 0.88f
        val building = mixC(0xFF0B0F1A.toInt(), 0xFF5A6575.toInt(), day * 0.8f)
        while (x < w) {
            val i = bi % 14
            val bw = bW[i] * w
            val bh = bH[i] * h
            p.color = building
            c.drawRect(x, gy - bh, x + bw, h, p)
            if (day < 0.7f) {
                for (r in 0 until 6) for (q in 0 until 2) {
                    if (bLit[(i * 12 + r * 2 + q) % bLit.size]) {
                        p.color = alC(0xFFFFD27A.toInt(), (1f - day) * 0.9f)
                        c.drawRect(x + bw * (0.2f + q * 0.4f), gy - bh + 6f * dp + r * 11f * dp, x + bw * (0.2f + q * 0.4f) + 4f * dp, gy - bh + 6f * dp + r * 11f * dp + 5f * dp, p)
                    }
                }
            }
            x += bw + 2f * dp
            bi++
        }
        p.color = mixC(0xFF05070D.toInt(), 0xFF39424F.toInt(), day * 0.8f)
        c.drawRect(0f, gy, w, h, p)
        // precipitation behind glass
        if (isRain) {
            val n = if (heavy) 220 else if (code == 63 || code == 81) 130 else 70
            p.strokeWidth = 1.1f * dp
            p.style = Paint.Style.STROKE
            p.color = alC(Color.WHITE, 0.4f)
            for (i in 0 until n) {
                val ix = i * 3
                rain[ix + 1] += e.dt * (0.9f + rain[ix + 2] * 0.7f) * (if (heavy) 1.6f else 1f)
                if (rain[ix + 1] > 1f) { rain[ix + 1] = 0f; rain[ix] = e.rf() }
                val rx = rain[ix] * w
                val ry = rain[ix + 1] * h
                c.drawLine(rx, ry, rx - 3f * dp, ry + 12f * dp, p)
            }
            p.style = Paint.Style.FILL
        }
        if (isSnow) {
            p.color = alC(Color.WHITE, 0.9f)
            val n = if (code == 75 || code == 86) 150 else 80
            for (i in 0 until n) {
                val ix = i * 3
                flakes[ix + 1] += e.dt * (0.1f + flakes[ix + 2] * 0.12f)
                flakes[ix] += sin(e.t + i) * e.dt * 0.02f
                if (flakes[ix + 1] > 1f) { flakes[ix + 1] = 0f; flakes[ix] = e.rf(); flakes[ix + 2] = e.rf() }
                c.drawCircle(((flakes[ix] % 1f + 1f) % 1f) * w, flakes[ix + 1] * h, (1.2f + flakes[ix + 2] * 1.8f) * dp, p)
            }
        }
        if (thunder) {
            flashAt -= e.dt
            if (flashAt <= 0f) { flash = 1f; flashAt = e.rr(4f, 12f) }
            if (flash > 0f) {
                p.color = alC(Color.WHITE, flash * 0.6f)
                c.drawRect(0f, 0f, w, h, p)
                flash = max(0f, flash - e.dt * 2.5f)
            }
        }
        if (isFog) { p.color = alC(Color.WHITE, 0.18f); c.drawRect(0f, 0f, w, h, p) }
        // fogged glass
        frost(c, e)
        // drops on the glass
        if (isRain) {
            if (glass.size < (if (heavy) 26 else 12) && e.rf() < 0.12f) glass.add(floatArrayOf(e.rf() * w, e.rf() * h * 0.5f, e.rr(1.5f, 3.2f) * dp, e.rr(8f, 40f) * dp, 0f))
        }
        val gi = glass.iterator()
        p.color = alC(Color.WHITE, 0.45f)
        while (gi.hasNext()) {
            val d = gi.next()
            d[4] += e.dt
            if (d[4] > 0.5f) d[1] += d[3] * e.dt
            if (d[1] > h || d[4] > 18f) { gi.remove(); continue }
            c.drawCircle(d[0], d[1], d[2], p)
        }
        if (!isRain && glass.isNotEmpty()) glass.clear()
        // frame
        val fr = 7f * dp
        p.color = mixC(0xFF1A1410.toInt(), 0xFF6B4E34.toInt(), 0.5f + 0.5f * day)
        c.drawRect(0f, 0f, w, fr, p)
        c.drawRect(0f, h - fr, w, h, p)
        c.drawRect(0f, 0f, fr, h, p)
        c.drawRect(w - fr, 0f, w, h, p)
        c.drawRect(w / 2f - fr * 0.4f, 0f, w / 2f + fr * 0.4f, h, p)
        c.drawRect(0f, h * 0.46f - fr * 0.4f, w, h * 0.46f + fr * 0.4f, p)
        // sill
        p.color = mixC(0xFF120D09.toInt(), 0xFF8A6A48.toInt(), 0.5f + 0.5f * day)
        c.drawRect(0f, h - fr * 1.6f, w, h, p)
        if (!e.wxReal) {
            p.color = alC(Color.WHITE, 0.7f)
            p.textSize = 10f * dp
            c.drawText("No weather yet, showing rain.", fr * 2f, h - fr * 2.2f, p)
        }
    }

    // ---- cold weather: frost creeping in from the window frame
    private val seg = ArrayList<FloatArray>()
    private var segW = 0f
    private var segH = 0f

    private fun grow(x: Float, y: Float, ang: Float, len: Float, depth: Int, th: Float, r: java.util.Random) {
        val ex = x + cos(ang) * len
        val ey = y + sin(ang) * len
        seg.add(floatArrayOf(x, y, ex, ey, th, depth.toFloat()))
        if (depth < 3) {
            for (f in floatArrayOf(0.4f, 0.72f)) {
                val bx = x + (ex - x) * f
                val by = y + (ey - y) * f
                grow(bx, by, ang + 1.0f, len * 0.42f, depth + 1, th + 0.1f, r)
                grow(bx, by, ang - 1.0f, len * 0.42f, depth + 1, th + 0.1f, r)
            }
            grow(ex, ey, ang + (r.nextFloat() - 0.5f) * 0.5f, len * 0.55f, depth + 1, th + 0.07f, r)
        }
    }

    private fun buildFrost(w: Float, h: Float, dp: Float) {
        seg.clear()
        val r = java.util.Random(11)
        val fr = 7f * dp
        val gap = 30f * dp
        var x = fr + gap / 2
        while (x < w - fr) { grow(x, fr, (PI / 2).toFloat() + (r.nextFloat() - 0.5f) * 0.5f, (26f + r.nextFloat() * 22f) * dp, 0, r.nextFloat() * 0.45f, r); grow(x + gap / 3, h - fr * 1.6f, (-PI / 2).toFloat() + (r.nextFloat() - 0.5f) * 0.5f, (24f + r.nextFloat() * 20f) * dp, 0, r.nextFloat() * 0.45f, r); x += gap }
        var y = fr + gap / 2
        while (y < h - fr * 1.6f) { grow(fr, y, 0f + (r.nextFloat() - 0.5f) * 0.5f, (26f + r.nextFloat() * 22f) * dp, 0, r.nextFloat() * 0.45f, r); grow(w - fr, y + gap / 3, PI.toFloat() + (r.nextFloat() - 0.5f) * 0.5f, (26f + r.nextFloat() * 22f) * dp, 0, r.nextFloat() * 0.45f, r); y += gap }
        segW = w; segH = h
    }

    private fun frost(c: Canvas, e: SceneEnv) {
        // 0 at 4 C and above, full at -6 C and below
        val f = smooth(4f, -6f, e.temp)
        if (f < 0.02f) return
        val w = e.w; val h = e.h; val dp = e.dp
        if (segW != w || segH != h) buildFrost(w, h, dp)
        // milky frost along the edges
        val depth = (0.10f + 0.10f * f) * min(w, h)
        val a0 = alC(0xFFEAF6FF.toInt(), 0.55f * f)
        val z = 0x00EAF6FF
        p.shader = LinearGradient(0f, 0f, 0f, depth, a0, z, Shader.TileMode.CLAMP); c.drawRect(0f, 0f, w, depth, p)
        p.shader = LinearGradient(0f, h, 0f, h - depth, a0, z, Shader.TileMode.CLAMP); c.drawRect(0f, h - depth, w, h, p)
        p.shader = LinearGradient(0f, 0f, depth, 0f, a0, z, Shader.TileMode.CLAMP); c.drawRect(0f, 0f, depth, h, p)
        p.shader = LinearGradient(w, 0f, w - depth, 0f, a0, z, Shader.TileMode.CLAMP); c.drawRect(w - depth, 0f, w, h, p)
        p.shader = null
        // crystals
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        for (sgm in seg) {
            val th = sgm[4]
            val vis = ((f - th * 0.9f) / 0.2f).coerceIn(0f, 1f)
            if (vis <= 0f) continue
            val d = sgm[5]
            p.strokeWidth = (1.7f - d * 0.35f) * dp
            p.color = alC(0xFFF4FBFF.toInt(), (0.75f - d * 0.12f) * vis)
            c.drawLine(sgm[0], sgm[1], sgm[0] + (sgm[2] - sgm[0]) * vis, sgm[1] + (sgm[3] - sgm[1]) * vis, p)
        }
        p.style = Paint.Style.FILL
        // glints
        var i = 0
        for (sgm in seg) {
            if (sgm[5] >= 2f && (i++ % 5 == 0) && f > sgm[4]) {
                val tw = 0.5f + 0.5f * sin(e.t * 1.6f + sgm[0] * 0.05f + sgm[1] * 0.03f)
                p.color = alC(Color.WHITE, 0.85f * tw * f)
                c.drawCircle(sgm[2], sgm[3], (1.1f + tw * 1.3f) * dp, p)
            }
        }
    }

    private fun fogLayer(c: Canvas, e: SceneEnv, foggy: Boolean) {
        val nw = max(30, (e.w / (5f * e.dp) * 1.6f).toInt())
        val nh = max(20, (e.h / e.w * nw).toInt())
        if (fw != nw || fh != nh) {
            fw = nw; fh = nh
            clear = FloatArray(fw * fh)
            pix = IntArray(fw * fh)
            fogBmp = Bitmap.createBitmap(fw, fh, Bitmap.Config.ARGB_8888)
        }
        val base = if (foggy) 150 else 40
        val tint = mixC(0xFFCFD8E3.toInt(), 0xFFFFFFFF.toInt(), e.day)
        val tr = Color.red(tint)
        val tg = Color.green(tint)
        val tb = Color.blue(tint)
        for (i in clear.indices) {
            clear[i] = max(0f, clear[i] - e.dt * 0.018f)
            val a = (base * (1f - clear[i])).toInt()
            pix[i] = (a shl 24) or (tr shl 16) or (tg shl 8) or tb
        }
        val b = fogBmp ?: return
        b.setPixels(pix, 0, fw, 0, 0, fw, fh)
        val dst = RectF(0f, 0f, e.w, e.h)
        p.isFilterBitmap = true
        c.drawBitmap(b, null, dst, p)
    }
}
