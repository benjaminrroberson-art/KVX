package de.mm20.launcher2.ui.launcher.widgets.facesclock

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import de.mm20.launcher2.ui.component.preferences.SliderPreference

/** Four padding sliders in dp. Used by every widget and clock we add. */
@Composable
fun PaddingControls(top: Int, bottom: Int, start: Int, end: Int, onChange: (top: Int, bottom: Int, start: Int, end: Int) -> Unit) {
    SliderPreference(title = "Top padding", value = top, min = 0, max = 80, onValueChanged = { v -> onChange(v, bottom, start, end) }, label = { Text("$it dp") })
    SliderPreference(title = "Bottom padding", value = bottom, min = 0, max = 80, onValueChanged = { v -> onChange(top, v, start, end) }, label = { Text("$it dp") })
    SliderPreference(title = "Left padding", value = start, min = 0, max = 80, onValueChanged = { v -> onChange(top, bottom, v, end) }, label = { Text("$it dp") })
    SliderPreference(title = "Right padding", value = end, min = 0, max = 80, onValueChanged = { v -> onChange(top, bottom, start, v) }, label = { Text("$it dp") })
}
