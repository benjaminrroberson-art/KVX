package de.mm20.launcher2.ui.settings.visualizer

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.navigation3.runtime.NavKey
import de.mm20.launcher2.ui.component.preferences.PreferenceCategory
import de.mm20.launcher2.ui.component.preferences.PreferenceScreen
import de.mm20.launcher2.ui.launcher.widgets.facesclock.BubbleSettings
import de.mm20.launcher2.ui.launcher.widgets.facesclock.VizBubble
import de.mm20.launcher2.ui.launcher.widgets.facesclock.VizFillBody
import de.mm20.launcher2.ui.launcher.widgets.facesclock.np.CardView
import de.mm20.launcher2.ui.launcher.widgets.facesclock.np.MediaState
import de.mm20.launcher2.ui.launcher.widgets.facesclock.np.Prefs
import de.mm20.launcher2.ui.settings.widgets.BubbleCategory
import de.mm20.launcher2.ui.settings.widgets.EqCategory
import de.mm20.launcher2.ui.settings.widgets.PanelCategory
import de.mm20.launcher2.widgets.KvxVizWidgetConfig
import kotlinx.coroutines.delay
import kotlinx.serialization.Serializable

@Serializable
data object VisualizerSettingsRoute : NavKey

@Composable
private fun PreviewLabel(t: String) {
    Text(t, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
}

/** Live previews that follow the settings below them. Play something to see them move. */
@Composable
private fun PreviewCategory() {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { while (true) { delay(500); tick++ } }
    PreferenceCategory(title = "Preview") {
        Text(
            "Play something to see these move. They follow the settings below.",
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
        )
        PreviewLabel("Bubble")
        Box(Modifier.fillMaxWidth().padding(vertical = 4.dp), contentAlignment = Alignment.Center) {
            @Suppress("UNUSED_EXPRESSION") tick
            VizBubble(BubbleSettings.size(ctx).toFloat().coerceIn(48f, 110f), BubbleSettings.viz(ctx), MediaState.art, MediaState.playing, true)
        }
        PreviewLabel("Panel")
        AndroidView(
            factory = { CardView(it, Prefs(it)) },
            update = { @Suppress("UNUSED_EXPRESSION") tick; it.reload() },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
        )
        PreviewLabel("Visualizer only (widget)")
        VizFillBody(KvxVizWidgetConfig(layout = 1, height = 80))
    }
}

@Composable
fun VisualizerSettingsScreen() {
    PreferenceScreen(title = "Visualizer") {
        item { PreviewCategory() }
        item { BubbleCategory() }
        item { PanelCategory() }
        item { EqCategory() }
    }
}
