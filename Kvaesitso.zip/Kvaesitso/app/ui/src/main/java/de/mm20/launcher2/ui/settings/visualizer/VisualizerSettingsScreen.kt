package de.mm20.launcher2.ui.settings.visualizer

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.navigation3.runtime.NavKey
import de.mm20.launcher2.ui.component.preferences.Preference
import de.mm20.launcher2.ui.component.preferences.PreferenceCategory
import de.mm20.launcher2.ui.component.preferences.PreferenceScreen
import de.mm20.launcher2.ui.launcher.widgets.facesclock.BubbleSettings
import de.mm20.launcher2.ui.launcher.widgets.facesclock.VizBubble
import de.mm20.launcher2.ui.launcher.widgets.facesclock.np.CardView
import de.mm20.launcher2.ui.launcher.widgets.facesclock.np.MediaState
import de.mm20.launcher2.ui.launcher.widgets.facesclock.np.Prefs
import de.mm20.launcher2.ui.locals.LocalBackStack
import de.mm20.launcher2.ui.settings.widgets.BubbleCategory
import de.mm20.launcher2.ui.settings.widgets.EqCategory
import de.mm20.launcher2.ui.settings.widgets.EqGraph
import de.mm20.launcher2.ui.settings.widgets.PanelCategory
import kotlinx.coroutines.delay
import kotlinx.serialization.Serializable

@Serializable
data object VisualizerSettingsRoute : NavKey

/** One page of the Visualizer settings, picked by name. */
@Serializable
data class VizPageRoute(val page: String) : NavKey

private enum class Pv { None, Bubble, Panel, Eq }

@Composable
private fun BubblePreview() {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { while (true) { delay(500); tick++ } }
    @Suppress("UNUSED_EXPRESSION") tick
    Box(Modifier.fillMaxWidth().padding(vertical = 4.dp), contentAlignment = Alignment.Center) {
        VizBubble(BubbleSettings.size(ctx).toFloat().coerceIn(48f, 100f), BubbleSettings.viz(ctx), MediaState.art, MediaState.playing, true)
    }
}

@Composable
private fun PanelPreview() {
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { while (true) { delay(500); tick++ } }
    AndroidView(
        factory = { CardView(it, Prefs(it)) },
        update = { @Suppress("UNUSED_EXPRESSION") tick; it.reload() },
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
    )
}

/** A settings page whose preview stays pinned at the top while the controls scroll underneath. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun PinnedPage(title: String, pv: Pv, content: LazyListScope.() -> Unit) {
    PreferenceScreen(title = title) {
        if (pv != Pv.None) {
            stickyHeader {
                Column(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceContainer)) {
                    when (pv) {
                        Pv.Bubble -> BubblePreview()
                        Pv.Panel -> PanelPreview()
                        Pv.Eq -> EqGraph()
                        Pv.None -> {}
                    }
                    Text(
                        "Play something to see it move. It stays here while you scroll.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 2.dp),
                    )
                }
            }
        }
        content()
    }
}

@Composable
private fun Row(title: String, summary: String, page: String) {
    val back = LocalBackStack.current
    Preference(title = title, summary = summary, onClick = { back.add(VizPageRoute(page)) })
}

@Composable
fun VisualizerSettingsScreen() {
    PreferenceScreen(title = "Visualizer") {
        item {
            PreferenceCategory(title = "Customize") {
                Row("Music bubble", "Floating bubble: behavior and look", "bubble")
                Row("Bubble panel", "The card that opens from the bubble", "panel")
                Row("Equalizer", "System-wide EQ, presets and per-device presets", "eq")
            }
        }
        item { BubbleCategory("import") }
        item { CrashReport() }
    }
}

/** Shows the last crash the app saved, and copies it, so a crash that kills capture or the launcher can be reported. */
@Composable
private fun CrashReport() {
    val ctx = LocalContext.current
    val f = java.io.File(ctx.filesDir, "kvx_crash.txt")
    val txt = remember { if (f.exists()) f.readText() else "" }
    PreferenceCategory(title = "Troubleshooting") {
        Preference(
            title = "Last crash report",
            summary = if (txt.isBlank()) "No crash recorded" else txt.lines().take(3).joinToString("\n") + "\nTap to copy",
            onClick = {
                if (txt.isNotBlank()) {
                    val cm = ctx.getSystemService(android.content.ClipboardManager::class.java)
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("crash", txt))
                    android.widget.Toast.makeText(ctx, "Copied", android.widget.Toast.LENGTH_SHORT).show()
                }
            },
        )
    }
}

@Composable
fun VizPageScreen(page: String) {
    when (page) {
        "bubble" -> PinnedPage("Music bubble", Pv.Bubble) {
            item { PreferenceCategory(title = "Pages") {
                Row("Behavior", "On/off, size, taps, hiding", "bubble_main")
                Row("Look", "Visualizer style, colors and shape", "bubble_look")
            } }
        }
        "bubble_main" -> PinnedPage("Bubble behavior", Pv.Bubble) { item { BubbleCategory("main") } }
        "bubble_look" -> PinnedPage("Bubble look", Pv.Bubble) { item { BubbleCategory("look") } }
        "panel" -> PinnedPage("Bubble panel", Pv.Panel) {
            item { PreferenceCategory(title = "Pages") {
                Row("Visualizer", "Style, colors, bars, height and more", "panel_viz")
                Row("Album art", "Shape, size, side", "panel_art")
                Row("Background", "Blur, tint, corners", "panel_bg")
                Row("Text", "Font, size, color", "panel_text")
                Row("Controls and behavior", "Buttons, progress, width, auto-close", "panel_controls")
            } }
        }
        "panel_viz" -> PinnedPage("Panel visualizer", Pv.Panel) { item { PanelCategory("viz") } }
        "panel_art" -> PinnedPage("Panel album art", Pv.Panel) { item { PanelCategory("art") } }
        "panel_bg" -> PinnedPage("Panel background", Pv.Panel) { item { PanelCategory("bg") } }
        "panel_text" -> PinnedPage("Panel text", Pv.Panel) { item { PanelCategory("text") } }
        "panel_controls" -> PinnedPage("Panel controls", Pv.Panel) { item { PanelCategory("controls") } }
        "eq" -> PinnedPage("Equalizer", Pv.Eq) {
            item { PreferenceCategory(title = "More") { Row("Presets and devices", "Import, save, load, per-output presets", "eq_presets") } }
            item { EqCategory("main") }
        }
        "eq_presets" -> PinnedPage("EQ presets", Pv.Eq) { item { EqCategory("presets") } }
        else -> PinnedPage("Visualizer", Pv.None) {}
    }
}
