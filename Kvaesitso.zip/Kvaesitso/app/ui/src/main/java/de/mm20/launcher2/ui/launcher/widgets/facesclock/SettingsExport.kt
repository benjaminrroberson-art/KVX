package de.mm20.launcher2.ui.launcher.widgets.facesclock

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Writes every visualizer, bubble, panel and EQ setting to one JSON file that Import can read back. */
object SettingsExport {
    val STORES = listOf("kvx_np", "kvx_np_presets", "kvx_np_eqpresets", "kvx_np_eqdev", "kvx_bubble", "kvx_np_eqapp", "kvx_edge", "kvx_edge_presets")
    const val FORMAT = "kvx-visualizer-settings"

    fun build(ctx: Context): String {
        val root = JSONObject()
        root.put("format", FORMAT)
        root.put("version", 1)
        val stores = JSONObject()
        for (name in STORES) {
            val sp = ctx.applicationContext.getSharedPreferences(name, Context.MODE_PRIVATE)
            val o = JSONObject()
            for ((k, v) in sp.all) {
                val e = JSONObject()
                when (v) {
                    is Int -> { e.put("t", "i"); e.put("v", v) }
                    is Long -> { e.put("t", "l"); e.put("v", v) }
                    is Float -> { e.put("t", "f"); e.put("v", v.toDouble()) }
                    is Boolean -> { e.put("t", "b"); e.put("v", v) }
                    is String -> { e.put("t", "s"); e.put("v", v) }
                    is Set<*> -> { e.put("t", "ss"); e.put("v", JSONArray(v.map { it.toString() })) }
                    else -> continue
                }
                o.put(k, e)
            }
            stores.put(name, o)
        }
        root.put("stores", stores)
        return root.toString(1)
    }
}
