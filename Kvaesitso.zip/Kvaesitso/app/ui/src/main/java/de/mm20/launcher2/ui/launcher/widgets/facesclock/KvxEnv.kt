package de.mm20.launcher2.ui.launcher.widgets.facesclock

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.lifecycle.viewmodel.compose.viewModel
import de.mm20.launcher2.preferences.MeasurementSystem
import de.mm20.launcher2.ui.locals.LocalMeasurementSystem
import de.mm20.launcher2.weather.Forecast
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter

/** Bumped whenever new weather or calendar data reaches the faces, so they redraw. */
internal val envTick = mutableIntStateOf(0)

private fun wmo(icon: Int): Int = when (icon) {
    Forecast.CLEAR -> 0
    Forecast.PARTLY_CLOUDY, Forecast.MOSTLY_CLOUDY, Forecast.BROKEN_CLOUDS -> 2
    Forecast.OVERCAST, Forecast.WIND, Forecast.STORM -> 3
    Forecast.FOG, Forecast.HAZE -> 45
    Forecast.LIGHT_RAIN -> 61
    Forecast.RAIN -> 63
    Forecast.HEAVY_RAIN -> 65
    Forecast.SLEET -> 67
    Forecast.SNOW -> 73
    Forecast.HAIL -> 96
    Forecast.THUNDER, Forecast.THUNDERSTORM, Forecast.HEAVY_THUNDERSTORM, Forecast.HEAVY_THUNDERSTORM_WITH_RAIN -> 95
    else -> 3
}

/** Gives the clock faces the launcher's real weather and next calendar event. */
@Composable
internal fun FeedClockEnv() {
    val vm: KvxDataVM = viewModel()
    val providerHourly by vm.hourly.collectAsState()
    val providerDaily by vm.daily.collectAsState()
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val place = KvxSettings.sunPlace(ctx)
    var typed by remember(place?.name, place?.lat, place?.lon) { androidx.compose.runtime.mutableStateOf<KvxWeatherData?>(null) }
    LaunchedEffect(place?.name, place?.lat, place?.lon) {
        ClockEnv.lat = place?.lat ?: Double.NaN
        ClockEnv.lon = place?.lon ?: Double.NaN
        envTick.intValue++
        while (place != null) {
            OpenMeteo.fetch(KvxPlace(place.name, "", place.lat, place.lon))?.let { typed = it }
            kotlinx.coroutines.delay(30 * 60_000L)
        }
    }
    val hourly = typed?.hourly ?: providerHourly
    val daily = typed?.daily ?: providerDaily
    val ms = LocalMeasurementSystem.current
    val has by vm.hasCalendarPermission.collectAsState()
    val flow = remember(has) { vm.events(LocalDate.now(), 7, false) }
    val events by flow.collectAsState(emptyList())

    LaunchedEffect(hourly, daily, ms) {
        ClockEnv.metric = ms != MeasurementSystem.UnitedStates
        val now = System.currentTimeMillis()
        val hrs = hourly.filter { it.timestamp >= now - 3_600_000L }.take(48)
        if (hrs.size < 6 || daily.size < 3) {
            ClockEnv.weather = null
        } else {
            val zone = ZoneId.systemDefault()
            val f = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm")
            fun c(k: Double) = k - 273.15
            val ht = JSONArray(); val hT = JSONArray(); val hC = JSONArray(); val hD = JSONArray(); val hP = JSONArray()
            for (h in hrs) {
                ht.put(Instant.ofEpochMilli(h.timestamp).atZone(zone).toLocalDateTime().format(f))
                hT.put(c(h.temperature)); hC.put(wmo(h.icon)); hD.put(if (h.night) 0 else 1)
                hP.put((h.precipProbability ?: 0).coerceAtLeast(0))
            }
            val dt = JSONArray(); val dC = JSONArray(); val dH = JSONArray(); val dL = JSONArray(); val dP = JSONArray(); val dU = JSONArray()
            for (d in daily.take(8)) {
                dt.put(Instant.ofEpochMilli(d.timestamp).atZone(zone).toLocalDate().toString())
                dC.put(wmo(d.icon)); dH.put(c(d.maxTemp)); dL.put(c(d.minTemp))
                dP.put(d.hourlyForecasts.maxOfOrNull { (it.precipProbability ?: 0).coerceAtLeast(0) } ?: 0)
                dU.put(d.hourlyForecasts.maxOfOrNull { (it.uvIndex ?: 0.0).coerceAtLeast(0.0) } ?: 0.0)
            }
            val cur0 = hrs.first()
            val cur = JSONObject().put("time", ht.getString(0)).put("temperature_2m", c(cur0.temperature))
                .put("apparent_temperature", c(cur0.temperature))
                .put("relative_humidity_2m", (cur0.humidity ?: 0.0).coerceAtLeast(0.0))
                .put("weather_code", wmo(cur0.icon)).put("is_day", if (cur0.night) 0 else 1)
                .put("wind_speed_10m", (cur0.windSpeed ?: 0.0).coerceAtLeast(0.0) * 3.6)
                .put("uv_index", (cur0.uvIndex ?: 0.0).coerceAtLeast(0.0))
            val json = JSONObject().put("current", cur)
                .put("hourly", JSONObject().put("time", ht).put("temperature_2m", hT).put("weather_code", hC).put("is_day", hD).put("precipitation_probability", hP))
                .put("daily", JSONObject().put("time", dt).put("weather_code", dC).put("temperature_2m_max", dH).put("temperature_2m_min", dL).put("precipitation_probability_max", dP).put("uv_index_max", dU))
            ClockEnv.weather = try { parseWx(json) } catch (e: Exception) { null }
        }
        envTick.intValue++
    }

    LaunchedEffect(events) {
        val now = System.currentTimeMillis()
        val e = events.filter { it.endTime >= now && !it.isTask }.minByOrNull { it.startTime ?: it.endTime }
        ClockEnv.event = e?.let {
            Ev(it.key.hashCode().toLong(), it.label, it.startTime ?: it.endTime, it.endTime, it.allDay, (it.color ?: 0xFF4CAF7D.toInt()) or (0xFF shl 24), it.location ?: "")
        }
        envTick.intValue++
    }
}
