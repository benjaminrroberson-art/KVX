package de.mm20.launcher2.ui.launcher.widgets.facesclock

import android.text.format.DateFormat
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import de.mm20.launcher2.search.CalendarEvent
import de.mm20.launcher2.ui.component.preferences.ListPreference
import de.mm20.launcher2.ui.component.preferences.SliderPreference
import de.mm20.launcher2.ui.component.preferences.SwitchPreference
import de.mm20.launcher2.widgets.KvxCalendarWidget
import de.mm20.launcher2.widgets.KvxCalendarWidgetConfig
import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Date
import java.util.Locale

private fun CalendarEvent.day(zone: ZoneId): LocalDate =
    Instant.ofEpochMilli(startTime ?: endTime).atZone(zone).toLocalDate()

@Composable
fun KvxCalendarView(widget: KvxCalendarWidget) = KvxCalendarBody(widget.config)

@Composable
fun KvxCalendarBody(cfg: KvxCalendarWidgetConfig) {
    val vm: KvxDataVM = viewModel()
    val context = LocalContext.current
    val has by vm.hasCalendarPermission.collectAsState()
    val fg = MaterialTheme.colorScheme.onSurface
    val pad = Modifier.padding(start = 12.dp + cfg.padStart.dp, top = 12.dp + cfg.padTop.dp, end = 12.dp + cfg.padEnd.dp, bottom = 12.dp + cfg.padBottom.dp)
    val zone = ZoneId.systemDefault()
    val timeFmt = remember { DateFormat.getTimeFormat(context) }
    fun time(ms: Long) = timeFmt.format(Date(ms))

    if (has == false) {
        Column(pad.fillMaxWidth()) {
            Text("Calendar access is needed to show your events.", color = fg)
            TextButton(onClick = { (context as? AppCompatActivity)?.let { vm.requestCalendar(it) } }) { Text("Allow calendar access") }
        }
        return
    }

    val today = LocalDate.now()
    var month by remember { mutableStateOf(YearMonth.now()) }
    var picked by remember { mutableStateOf(today) }

    val rangeStart = if (cfg.style == 2) month.atDay(1).minusDays(7) else today
    val rangeDays = if (cfg.style == 2) 50 else cfg.days
    val flow = remember(rangeStart, rangeDays, cfg.allDay) { vm.events(rangeStart, rangeDays, !cfg.allDay) }
    val events by flow.collectAsState(emptyList())
    val now = System.currentTimeMillis()

    @Composable
    fun EventRow(e: CalendarEvent) {
        Row(
            Modifier.fillMaxWidth().clickable { e.launch(context, null) }.padding(vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(Modifier.width(4.dp).height(34.dp).clip(RoundedCornerShape(2.dp)).background(Color((e.color ?: 0xFF6750A4.toInt()) or (0xFF shl 24))))
            Column(Modifier.padding(start = 10.dp)) {
                Text(e.label, style = MaterialTheme.typography.bodyLarge, color = fg, maxLines = 1, overflow = TextOverflow.Ellipsis)
                val whenText = if (e.allDay) "All day" else (e.startTime?.let { time(it) + " – " } ?: "") + time(e.endTime)
                val loc = if (cfg.location && !e.location.isNullOrBlank()) "  ·  ${e.location}" else ""
                Text(whenText + loc, style = MaterialTheme.typography.labelMedium, color = fg.copy(alpha = 0.7f), maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }

    when (cfg.style) {
        1 -> {
            val next = events.filter { it.endTime >= now }.minByOrNull { it.startTime ?: it.endTime }
            Column(pad.fillMaxWidth()) {
                if (next == null) {
                    Text("Nothing coming up", style = MaterialTheme.typography.titleMedium, color = fg)
                } else {
                    val start = next.startTime ?: next.endTime
                    val mins = (start - now) / 60000L
                    val whenWord = when {
                        next.allDay -> "All day, ${next.day(zone).dayOfWeek.getDisplayName(TextStyle.FULL, Locale.getDefault())}"
                        mins <= 0 -> "Now"
                        mins < 60 -> "In $mins min"
                        mins < 24 * 60 -> "In ${mins / 60} h ${mins % 60} min"
                        else -> next.day(zone).format(DateTimeFormatter.ofPattern("EEEE, MMM d")) + ", " + time(start)
                    }
                    Text(whenWord, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                    Text(next.label, style = MaterialTheme.typography.headlineSmall, color = fg, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.clickable { next.launch(context, null) })
                    if (cfg.location && !next.location.isNullOrBlank()) Text(next.location ?: "", style = MaterialTheme.typography.bodyMedium, color = fg.copy(alpha = 0.7f))
                }
            }
        }
        2 -> {
            val byDay = events.groupBy { it.day(zone) }
            val first = DayOfWeek.of(if (cfg.weekStart == 1) 1 else 7)
            Column(pad.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { month = month.minusMonths(1) }) { Text("‹") }
                    Text(month.format(DateTimeFormatter.ofPattern("MMMM yyyy")), Modifier.weight(1f), textAlign = TextAlign.Center, style = MaterialTheme.typography.titleMedium, color = fg)
                    TextButton(onClick = { month = month.plusMonths(1) }) { Text("›") }
                }
                Row(Modifier.fillMaxWidth()) {
                    for (i in 0..6) Text(first.plus(i.toLong()).getDisplayName(TextStyle.NARROW, Locale.getDefault()), Modifier.weight(1f), textAlign = TextAlign.Center, style = MaterialTheme.typography.labelSmall, color = fg.copy(alpha = 0.6f))
                }
                val lead = ((month.atDay(1).dayOfWeek.value - first.value) + 7) % 7
                val cells = lead + month.lengthOfMonth()
                val rows = (cells + 6) / 7
                for (r in 0 until rows) {
                    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                        for (c in 0..6) {
                            val n = r * 7 + c - lead + 1
                            Box(Modifier.weight(1f).height(38.dp), contentAlignment = Alignment.Center) {
                                if (n in 1..month.lengthOfMonth()) {
                                    val d = month.atDay(n)
                                    val sel = d == picked
                                    Column(
                                        Modifier.clip(CircleShape).then(if (sel) Modifier.background(MaterialTheme.colorScheme.primary) else if (d == today) Modifier.background(MaterialTheme.colorScheme.primaryContainer) else Modifier)
                                            .clickable { picked = d }.size(36.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center,
                                    ) {
                                        Text("$n", style = MaterialTheme.typography.labelLarge, color = if (sel) MaterialTheme.colorScheme.onPrimary else fg)
                                        if (byDay[d]?.isNotEmpty() == true) Box(Modifier.size(4.dp).clip(CircleShape).background(if (sel) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.primary))
                                    }
                                }
                            }
                        }
                    }
                }
                val list = byDay[picked].orEmpty().sortedBy { it.startTime ?: it.endTime }
                Text(picked.format(DateTimeFormatter.ofPattern("EEEE, MMM d")), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 8.dp))
                if (list.isEmpty()) Text("No events", style = MaterialTheme.typography.bodyMedium, color = fg.copy(alpha = 0.7f))
                list.take(cfg.maxEvents).forEach { EventRow(it) }
            }
        }
        else -> {
            val shown = events.filter { it.allDay || it.endTime >= now }.sortedBy { it.startTime ?: it.endTime }.take(cfg.maxEvents)
            Column(pad.fillMaxWidth()) {
                if (shown.isEmpty()) Text("No upcoming events", style = MaterialTheme.typography.bodyMedium, color = fg.copy(alpha = 0.8f))
                var lastDay: LocalDate? = null
                for (e in shown) {
                    val d = e.day(zone)
                    if (d != lastDay) {
                        lastDay = d
                        val head = when (d) {
                            today -> "Today"
                            today.plusDays(1) -> "Tomorrow"
                            else -> d.format(DateTimeFormatter.ofPattern("EEEE, MMM d"))
                        }
                        Text(head, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 6.dp))
                    }
                    EventRow(e)
                }
            }
        }
    }
}

@Composable
fun ConfigureKvxCalendarWidget(widget: KvxCalendarWidget, onWidgetUpdated: (KvxCalendarWidget) -> Unit) {
    val c = widget.config
    fun upd(n: KvxCalendarWidgetConfig) = onWidgetUpdated(widget.copy(config = n))
    OutlinedCard {
        Column {
            ListPreference(title = "Style", items = listOf("Agenda" to 0, "Next up" to 1, "Month" to 2), value = c.style, onValueChanged = { v -> upd(c.copy(style = v)) })
            if (c.style != 2) SliderPreference(title = "Look ahead", value = c.days, min = 1, max = 60, onValueChanged = { v -> upd(c.copy(days = v)) }, label = { Text("$it days") })
            if (c.style != 1) SliderPreference(title = "Events shown", value = c.maxEvents, min = 1, max = 20, onValueChanged = { v -> upd(c.copy(maxEvents = v)) }, label = { Text("$it") })
            if (c.style == 2) ListPreference(title = "Week starts on", items = listOf("Sunday" to 0, "Monday" to 1), value = c.weekStart, onValueChanged = { v -> upd(c.copy(weekStart = v)) })
            SwitchPreference(title = "Show locations", value = c.location, onValueChanged = { v -> upd(c.copy(location = v)) })
            SwitchPreference(title = "Include all-day events", value = c.allDay, onValueChanged = { v -> upd(c.copy(allDay = v)) })
            PaddingControls(c.padTop, c.padBottom, c.padStart, c.padEnd) { t, b, s, e -> upd(c.copy(padTop = t, padBottom = b, padStart = s, padEnd = e)) }
        }
    }
}
