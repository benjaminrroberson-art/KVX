package de.mm20.launcher2.ui.launcher.widgets.facesclock

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Rect
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.PowerManager
import android.os.SystemClock
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.ui.platform.LocalLifecycleOwner
import de.mm20.launcher2.widgets.KvxToolWidgetConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

// ---------------------------------------------------------------- shared "is this really on screen" gate

/**
 * True only while the widget is on screen, the app is resumed and the phone is awake and unlocked.
 * Meters use this so nothing keeps listening in the background.
 */
@Composable
private fun rememberOnScreen(): Pair<Boolean, Modifier> {
    val ctx = LocalContext.current
    val view = LocalView.current
    val owner = LocalLifecycleOwner.current
    var resumed by remember { mutableStateOf(owner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) }
    var awake by remember { mutableStateOf(true) }
    var inView by remember { mutableStateOf(false) }
    DisposableEffect(owner) {
        val ob = LifecycleEventObserver { _, _ -> resumed = owner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED) }
        owner.lifecycle.addObserver(ob)
        val rc = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) { awake = i.action != Intent.ACTION_SCREEN_OFF }
        }
        ctx.registerReceiver(rc, IntentFilter().apply { addAction(Intent.ACTION_SCREEN_OFF); addAction(Intent.ACTION_SCREEN_ON); addAction(Intent.ACTION_USER_PRESENT) })
        awake = ctx.getSystemService(PowerManager::class.java).isInteractive
        onDispose { owner.lifecycle.removeObserver(ob); try { ctx.unregisterReceiver(rc) } catch (_: Exception) {} }
    }
    val mod = Modifier.onGloballyPositioned { c ->
        val b = c.boundsInWindow()
        val win = Rect(); view.getWindowVisibleDisplayFrame(win)
        val vis = min(b.bottom, win.bottom.toFloat()) - max(b.top, 0f)
        inView = c.isAttached && b.height > 0f && vis > b.height * 0.5f && view.windowVisibility == android.view.View.VISIBLE
    }
    return (resumed && awake && inView) to mod
}

// ---------------------------------------------------------------- mix / loudness meter

private const val FFT_N = 2048
private const val RATE = 44100
private const val BANDS = 24

private fun fft(re: FloatArray, im: FloatArray) {
    val n = re.size
    var j = 0
    for (i in 1 until n) {
        var bit = n shr 1
        while (j and bit != 0) { j = j xor bit; bit = bit shr 1 }
        j = j xor bit
        if (i < j) { val tr = re[i]; re[i] = re[j]; re[j] = tr; val ti = im[i]; im[i] = im[j]; im[j] = ti }
    }
    var len = 2
    while (len <= n) {
        val ang = -2.0 * PI / len
        val wr = cos(ang).toFloat(); val wi = sin(ang).toFloat()
        var i = 0
        while (i < n) {
            var cr = 1f; var ci = 0f
            for (k in 0 until len / 2) {
                val a = i + k; val b = i + k + len / 2
                val xr = re[b] * cr - im[b] * ci
                val xi = re[b] * ci + im[b] * cr
                re[b] = re[a] - xr; im[b] = im[a] - xi
                re[a] += xr; im[a] += xi
                val t = cr * wr - ci * wi; ci = cr * wi + ci * wr; cr = t
            }
            i += len
        }
        len = len shl 1
    }
}

private fun aWeightDb(f: Double): Double {
    val f2 = f * f
    val r = (12194.0.pow(2) * f2 * f2) / ((f2 + 20.6.pow(2)) * sqrt((f2 + 107.7.pow(2)) * (f2 + 737.9.pow(2))) * (f2 + 12194.0.pow(2)))
    return 20 * log10(max(r, 1e-9)) + 2.0
}

private fun bandEdge(i: Int) = 31.5 * (16000.0 / 31.5).pow(i.toDouble() / BANDS)

@Composable
fun MeterTool(cfg: KvxToolWidgetConfig) {
    val ctx = LocalContext.current
    val (visible, posMod) = rememberOnScreen()
    var on by remember { mutableStateOf(false) }
    val running = on && visible
    var denied by remember { mutableStateOf(false) }
    val askMic = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) on = true else denied = true }
    // wiping the "on" flag when hidden means coming back never restarts it on its own
    LaunchedEffect(visible) { if (!visible) on = false }

    // live values
    var dba by remember { mutableFloatStateOf(0f) }
    var peak by remember { mutableFloatStateOf(0f) }
    var leq by remember { mutableFloatStateOf(0f) }
    val bands = remember { FloatArray(BANDS) }
    val holds = remember { FloatArray(BANDS) }
    var frame by remember { mutableIntStateOf(0) }
    var secs by remember { mutableIntStateOf(0) }
    var low by remember { mutableFloatStateOf(0f) }
    var mid by remember { mutableFloatStateOf(0f) }
    var high by remember { mutableFloatStateOf(0f) }
    var lvl by remember { mutableFloatStateOf(0f) }

    // microphone mode
    LaunchedEffect(running, cfg.mode, cfg.calib) {
        if (!running || cfg.mode != 0) return@LaunchedEffect
        withContext(Dispatchers.Default) {
            val minBuf = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val rec = try {
                val src = if (android.os.Build.VERSION.SDK_INT >= 24) MediaRecorder.AudioSource.UNPROCESSED else MediaRecorder.AudioSource.MIC
                AudioRecord(src, RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, max(minBuf, FFT_N * 4)).also {
                    if (it.state != AudioRecord.STATE_INITIALIZED) { it.release(); throw IllegalStateException() }
                }
            } catch (e: Exception) {
                try { AudioRecord(MediaRecorder.AudioSource.MIC, RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, max(minBuf, FFT_N * 4)) } catch (e2: Exception) { null }
            } ?: return@withContext
            try {
                rec.startRecording()
                val sh = ShortArray(FFT_N)
                val re = FloatArray(FFT_N); val im = FloatArray(FFT_N)
                val win = FloatArray(FFT_N) { (0.5 - 0.5 * cos(2 * PI * it / (FFT_N - 1))).toFloat() }
                val sw2 = win.sumOf { (it * it).toDouble() }
                val aw = DoubleArray(FFT_N / 2) { if (it == 0) -100.0 else aWeightDb(it * RATE.toDouble() / FFT_N) }
                var energy = 0.0; var n = 0L
                val t0 = SystemClock.elapsedRealtime()
                while (isActive) {
                    var got = 0
                    while (got < FFT_N && isActive) { val r = rec.read(sh, got, FFT_N - got); if (r <= 0) break; got += r }
                    if (got < FFT_N) break
                    var pk = 0
                    for (i in 0 until FFT_N) { re[i] = sh[i] / 32768f * win[i]; im[i] = 0f; pk = max(pk, abs(sh[i].toInt())) }
                    fft(re, im)
                    var msA = 0.0
                    val bp = DoubleArray(BANDS)
                    for (k in 1 until FFT_N / 2) {
                        val p = (re[k] * re[k] + im[k] * im[k]).toDouble() * 2.0 / (FFT_N * sw2)
                        msA += p * 10.0.pow(aw[k] / 10.0)
                        val f = k * RATE.toDouble() / FFT_N
                        var b = ((ln(f / 31.5) / ln(16000.0 / 31.5)) * BANDS).toInt()
                        if (f >= 31.5 && b in 0 until BANDS) bp[b] += p
                    }
                    val calib = cfg.calib.toDouble()
                    val a = (10 * log10(max(msA, 1e-12)) + calib).toFloat()
                    energy += msA; n++
                    val lq = (10 * log10(max(energy / n, 1e-12)) + calib).toFloat()
                    val pkDb = (20 * log10(max(pk / 32768.0, 1e-6)) + calib).toFloat()
                    for (b in 0 until BANDS) {
                        val db = (10 * log10(max(bp[b], 1e-12)) + calib).toFloat()
                        bands[b] = bands[b] * 0.5f + db * 0.5f
                        holds[b] = max(holds[b] - 0.6f, bands[b])
                    }
                    dba = dba * 0.6f + a * 0.4f
                    peak = max(peak * 0.97f, pkDb)
                    leq = lq
                    secs = ((SystemClock.elapsedRealtime() - t0) / 1000).toInt()
                    frame++
                }
            } finally { try { rec.stop() } catch (_: Exception) {}; rec.release() }
        }
    }

    // music mode: reuse the visualizer capture
    if (cfg.mode == 1) {
        DisposableEffect(running) {
            if (running) VizAudio.start(ctx)
            onDispose { if (running) VizAudio.stop() }
        }
        LaunchedEffect(running) {
            while (running) {
                val d = VizAudio.disp
                fun avg(a: Int, b: Int): Float { var s = 0f; for (i in a until b) s += d[i]; return s / (b - a) }
                low = low * 0.8f + avg(0, 10) * 0.2f
                mid = mid * 0.8f + avg(10, 36) * 0.2f
                high = high * 0.8f + avg(36, 64) * 0.2f
                lvl = lvl * 0.8f + VizAudio.level * 0.2f
                frame++
                kotlinx.coroutines.delay(33)
            }
        }
    }

    fun toggle() {
        if (on) { on = false; return }
        if (cfg.mode == 0 && ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) askMic.launch(Manifest.permission.RECORD_AUDIO)
        else { on = true; bands.fill(0f); holds.fill(0f); dba = 0f; peak = 0f; leq = 0f; secs = 0 }
    }

    ToolCard {
        Column(Modifier.then(posMod)) {
            if (cfg.mode == 0) MicMeter(cfg, running, dba, peak, leq, bands, holds, frame, secs)
            else MusicMeter(running, low, mid, high, lvl, frame, cfg)
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = { toggle() }) { Text(if (running) "Stop" else "Start listening") }
                if (denied && !running) Text("  Microphone permission is needed", style = MaterialTheme.typography.bodySmall)
                else Text(if (running) "  Stops when you leave or lock" else "  Off until you tap", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

private fun ln(x: Double) = kotlin.math.ln(x)

@Composable
private fun MicMeter(cfg: KvxToolWidgetConfig, running: Boolean, dba: Float, peak: Float, leq: Float, bands: FloatArray, holds: FloatArray, frame: Int, secs: Int) {
    @Suppress("UNUSED_EXPRESSION") frame
    val zone = when { dba < 85f -> Color(0xFF4CAF50); dba < 100f -> Color(0xFFFFB300); else -> Color(0xFFE53935) }
    val shown = if (running || dba > 0f) dba else 0f
    Row(verticalAlignment = Alignment.Bottom) {
        Text(if (shown > 0f) "%.0f".format(shown) else "--", style = MaterialTheme.typography.displayMedium, color = if (shown > 0f) zone else MaterialTheme.colorScheme.onSurfaceVariant)
        Text(" dBA", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(bottom = 8.dp))
        Column(Modifier.weight(1f).padding(start = 16.dp, bottom = 4.dp), horizontalAlignment = Alignment.End) {
            Text("Peak %.0f dB".format(peak), style = MaterialTheme.typography.labelMedium)
            Text("Avg (Leq) %.0f dBA  ·  %d:%02d".format(leq, secs / 60, secs % 60), style = MaterialTheme.typography.labelMedium)
        }
    }
    // spectrum
    val base = (cfg.calib - 90).toFloat()
    val surfaceVar = MaterialTheme.colorScheme.surfaceVariant
    Canvas(Modifier.fillMaxWidth().height((cfg.height - 120).coerceAtLeast(60).dp).padding(vertical = 6.dp)) {
        val w = size.width / BANDS
        for (b in 0 until BANDS) {
            val v = ((bands[b] - base) / 100f).coerceIn(0f, 1f)
            val h = ((holds[b] - base) / 100f).coerceIn(0f, 1f)
            val col = when { bands[b] < 85f -> Color(0xFF4CAF50); bands[b] < 100f -> Color(0xFFFFB300); else -> Color(0xFFE53935) }
            drawRect(surfaceVar, Offset(b * w + 1f, 0f), Size(w - 2f, size.height))
            drawRect(col, Offset(b * w + 1f, size.height * (1 - v)), Size(w - 2f, size.height * v))
            drawRect(Color.White, Offset(b * w + 1f, size.height * (1 - h)), Size(w - 2f, 3f))
        }
    }
    val allowed = 8.0 * 2.0.pow(-((leq - 85.0) / 3.0))
    val safe = when {
        leq <= 0f -> "Hearing guide: starts when you do"
        leq < 85f -> "Hearing guide: safe for a full 8 hours"
        allowed >= 1 -> "Hearing guide: about %.1f h at this level".format(allowed)
        else -> "Hearing guide: about %.0f min at this level, earplugs".format(allowed * 60)
    }
    Text(safe, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

@Composable
private fun MusicMeter(running: Boolean, low: Float, mid: Float, high: Float, lvl: Float, frame: Int, cfg: KvxToolWidgetConfig) {
    @Suppress("UNUSED_EXPRESSION") frame
    val tot = max(low + mid + high, 0.001f)
    // reference: music normally carries more energy in the lows than the highs
    val lo = low / tot; val mi = mid / tot; val hi = high / tot
    val verdict = when {
        !running || lvl < 0.02f -> "Play something to see its balance"
        lo > 0.52f -> "Bass-heavy"
        hi > 0.30f -> "Bright"
        mi < 0.22f -> "Scooped mids"
        lo < 0.30f -> "Thin low end"
        else -> "Well balanced"
    }
    Text(verdict, style = MaterialTheme.typography.titleLarge)
    Text("Relative balance of what this phone is playing. No absolute loudness, since volume is set by you.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    val primary = MaterialTheme.colorScheme.primary
    val track = MaterialTheme.colorScheme.surfaceVariant
    Canvas(Modifier.fillMaxWidth().height((cfg.height - 120).coerceAtLeast(60).dp).padding(vertical = 8.dp)) {
        val vals = floatArrayOf(lo, mi, hi, lvl.coerceIn(0f, 1f))
        val ref = floatArrayOf(0.42f, 0.36f, 0.22f, 0f)
        val bw = size.width / 4
        for (i in 0 until 4) {
            val v = if (i < 3) (vals[i] / 0.7f).coerceIn(0f, 1f) else vals[i]
            drawRect(track, Offset(i * bw + 8f, 0f), Size(bw - 16f, size.height))
            drawRect(primary, Offset(i * bw + 8f, size.height * (1 - v)), Size(bw - 16f, size.height * v))
            if (i < 3) { val r = size.height * (1 - ref[i] / 0.7f); drawRect(Color.White, Offset(i * bw + 4f, r), Size(bw - 8f, 3f)) }
        }
    }
    Row(Modifier.fillMaxWidth()) {
        for (t in listOf("Low", "Mid", "High", "Level")) Text(t, Modifier.weight(1f), style = MaterialTheme.typography.labelSmall, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
    }
}

// ---------------------------------------------------------------- metronome and tap tempo

private fun clickTrack(freq: Double, ms: Int, amp: Double): AudioTrack {
    val n = RATE * ms / 1000
    val buf = ShortArray(n) { i -> (sin(2 * PI * freq * i / RATE) * exp(-i.toDouble() / n * 6.0) * amp * 32767).toInt().toShort() }
    val t = AudioTrack.Builder()
        .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
        .setAudioFormat(AudioFormat.Builder().setSampleRate(RATE).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
        .setBufferSizeInBytes(n * 2).setTransferMode(AudioTrack.MODE_STATIC).build()
    t.write(buf, 0, n)
    return t
}

private fun exp(x: Double) = kotlin.math.exp(x)

@Composable
fun MetronomeTool() {
    val ctx = LocalContext.current
    var bpm by remember { mutableIntStateOf(ToolStore.getLong(ctx, "bpm", 120).toInt()) }
    var beats by remember { mutableIntStateOf(ToolStore.getLong(ctx, "beats", 4).toInt()) }
    var on by remember { mutableStateOf(false) }
    var beat by remember { mutableIntStateOf(-1) }
    val taps = remember { ArrayList<Long>() }
    fun setBpm(v: Int) { bpm = v.coerceIn(30, 300); ToolStore.putLong(ctx, "bpm", bpm.toLong()) }

    val (visible, posMod) = rememberOnScreen()
    LaunchedEffect(visible) { if (!visible) on = false }

    LaunchedEffect(on) {
        if (!on) { beat = -1; return@LaunchedEffect }
        withContext(Dispatchers.Default) {
            val hi = clickTrack(1600.0, 40, 0.9); val lo = clickTrack(1000.0, 40, 0.6)
            try {
                var i = 0
                var next = System.nanoTime()
                while (isActive) {
                    val t = if (i % beats == 0) hi else lo
                    try { t.stop(); t.setPlaybackHeadPosition(0); t.play() } catch (_: Exception) {}
                    beat = i % beats
                    i++
                    next += (60_000_000_000L / bpm)   // drift-free: schedule from the original start, not from "now"
                    val wait = (next - System.nanoTime()) / 1_000_000
                    if (wait > 0) kotlinx.coroutines.delay(wait)
                }
            } finally { hi.release(); lo.release() }
        }
    }

    ToolCard {
        Column(Modifier.then(posMod)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { setBpm(bpm - 1) }) { Text("−") }
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("$bpm", style = MaterialTheme.typography.displayMedium)
                    Text("BPM", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                TextButton(onClick = { setBpm(bpm + 1) }) { Text("+") }
            }
            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.Center) {
                for (i in 0 until beats) {
                    Canvas(Modifier.padding(horizontal = 5.dp).height(14.dp).then(Modifier.padding(0.dp))) {
                        drawCircle(if (i == beat) (if (i == 0) Color(0xFFFFB300) else Color(0xFF4CAF50)) else Color.Gray.copy(alpha = 0.4f), radius = 7.dp.toPx(), center = Offset(7.dp.toPx(), 7.dp.toPx()))
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = { on = !on }) { Text(if (on) "Stop" else "Start") }
                FilledTonalButton(onClick = {
                    val now = SystemClock.elapsedRealtime()
                    if (taps.isNotEmpty() && now - taps.last() > 2000) taps.clear()
                    taps.add(now)
                    while (taps.size > 7) taps.removeAt(0)
                    if (taps.size >= 2) setBpm((60_000.0 / ((taps.last() - taps.first()).toDouble() / (taps.size - 1))).toInt())
                }) { Text("Tap tempo") }
                for (b in listOf(3, 4, 6)) FilterChip(selected = beats == b, onClick = { beats = b; ToolStore.putLong(ctx, "beats", b.toLong()) }, label = { Text("$b") })
            }
            Text("Stops when you leave this page", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp))
        }
    }
}
