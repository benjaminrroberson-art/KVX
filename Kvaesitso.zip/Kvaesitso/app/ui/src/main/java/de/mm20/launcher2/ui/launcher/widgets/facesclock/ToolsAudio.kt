package de.mm20.launcher2.ui.launcher.widgets.facesclock

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Rect
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.PowerManager
import android.os.SystemClock
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.background
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.ui.platform.LocalLifecycleOwner
import de.mm20.launcher2.widgets.KvxToolWidgetConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

// ---------------------------------------------------------------- shared "is this really on screen" gate

/**
 * True only while the widget is on screen, the app is resumed and the phone is awake and unlocked.
 * Meters use this so nothing keeps listening in the background.
 */
@Composable
internal fun rememberOnScreen(): Pair<Boolean, Modifier> {
    val ctx = LocalContext.current
    val view = LocalView.current
    val owner = LocalLifecycleOwner.current
    var resumed by remember { mutableStateOf(owner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) }
    var awake by remember { mutableStateOf(true) }
    var inView by remember { mutableStateOf(false) }
    DisposableEffect(owner) {
        val ob = LifecycleEventObserver { _, _ -> resumed = owner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED) }
        owner.lifecycle.addObserver(ob)
        val rc = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) { awake = i.action != Intent.ACTION_SCREEN_OFF }
        }
        ctx.registerReceiver(rc, IntentFilter().apply { addAction(Intent.ACTION_SCREEN_OFF); addAction(Intent.ACTION_SCREEN_ON); addAction(Intent.ACTION_USER_PRESENT) })
        awake = ctx.getSystemService(PowerManager::class.java).isInteractive
        onDispose { owner.lifecycle.removeObserver(ob); try { ctx.unregisterReceiver(rc) } catch (_: Exception) {} }
    }
    val mod = Modifier.onGloballyPositioned { c ->
        val b = c.boundsInWindow()
        val win = Rect(); view.getWindowVisibleDisplayFrame(win)
        val vis = min(b.bottom, win.bottom.toFloat()) - max(b.top, 0f)
        inView = c.isAttached && b.height > 0f && vis > b.height * 0.5f && view.windowVisibility == android.view.View.VISIBLE
    }
    return (resumed && awake && inView) to mod
}

// ---------------------------------------------------------------- mix / loudness meter

private const val FFT_N = 2048
internal const val RATE = 44100
private const val BANDS = 24

private fun fft(re: FloatArray, im: FloatArray) {
    val n = re.size
    var j = 0
    for (i in 1 until n) {
        var bit = n shr 1
        while (j and bit != 0) { j = j xor bit; bit = bit shr 1 }
        j = j xor bit
        if (i < j) { val tr = re[i]; re[i] = re[j]; re[j] = tr; val ti = im[i]; im[i] = im[j]; im[j] = ti }
    }
    var len = 2
    while (len <= n) {
        val ang = -2.0 * PI / len
        val wr = cos(ang).toFloat(); val wi = sin(ang).toFloat()
        var i = 0
        while (i < n) {
            var cr = 1f; var ci = 0f
            for (k in 0 until len / 2) {
                val a = i + k; val b = i + k + len / 2
                val xr = re[b] * cr - im[b] * ci
                val xi = re[b] * ci + im[b] * cr
                re[b] = re[a] - xr; im[b] = im[a] - xi
                re[a] += xr; im[a] += xi
                val t = cr * wr - ci * wi; ci = cr * wi + ci * wr; cr = t
            }
            i += len
        }
        len = len shl 1
    }
}

private fun aWeightDb(f: Double): Double {
    val f2 = f * f
    val r = (12194.0.pow(2) * f2 * f2) / ((f2 + 20.6.pow(2)) * sqrt((f2 + 107.7.pow(2)) * (f2 + 737.9.pow(2))) * (f2 + 12194.0.pow(2)))
    return 20 * log10(max(r, 1e-9)) + 2.0
}

private fun bandEdge(i: Int) = 31.5 * (16000.0 / 31.5).pow(i.toDouble() / BANDS)

private fun zoneColor(db: Float) = when { db < 85f -> Color(0xFF4CAF50); db < 100f -> Color(0xFFFFB300); else -> Color(0xFFE53935) }

@Composable
fun MeterTool(cfg: KvxToolWidgetConfig) {
    val ctx = LocalContext.current
    val (visible, posMod) = rememberOnScreen()
    val live = cfg.mode == 0
    // live (microphone) always needs a tap; media only if the widget is set that way
    val needTap = live || cfg.tap
    var on by remember { mutableStateOf(false) }
    val running = visible && (if (needTap) on else true)
    var denied by remember { mutableStateOf(false) }
    val askMic = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) on = true else denied = true }
    // leaving the page, locking or switching apps turns it off for good; coming back needs a new tap
    LaunchedEffect(visible) { if (!visible) on = false }

    var dba by remember { mutableFloatStateOf(0f) }
    var peak by remember { mutableFloatStateOf(0f) }
    var leq by remember { mutableFloatStateOf(0f) }
    val bands = remember { FloatArray(BANDS) }
    val holds = remember { FloatArray(BANDS) }
    var frame by remember { mutableIntStateOf(0) }
    var secs by remember { mutableIntStateOf(0) }

    LaunchedEffect(running, live) {
        while (running) { kotlinx.coroutines.delay(1000L); WidgetStats.res(toolTitle(5), mic = if (live) 1.0 else 0.0, audio = if (live) 0.0 else 1.0) }
    }

    // ---- microphone
    LaunchedEffect(running, cfg.mode, cfg.calib) {
        if (!running || !live) return@LaunchedEffect
        withContext(Dispatchers.Default) {
            val minBuf = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val rec = try {
                val src = if (android.os.Build.VERSION.SDK_INT >= 24) MediaRecorder.AudioSource.UNPROCESSED else MediaRecorder.AudioSource.MIC
                AudioRecord(src, RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, max(minBuf, FFT_N * 4)).also {
                    if (it.state != AudioRecord.STATE_INITIALIZED) { it.release(); throw IllegalStateException() }
                }
            } catch (e: Exception) {
                try { AudioRecord(MediaRecorder.AudioSource.MIC, RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, max(minBuf, FFT_N * 4)) } catch (e2: Exception) { null }
            } ?: return@withContext
            try {
                rec.startRecording()
                val sh = ShortArray(FFT_N)
                val re = FloatArray(FFT_N); val im = FloatArray(FFT_N)
                val win = FloatArray(FFT_N) { (0.5 - 0.5 * cos(2 * PI * it / (FFT_N - 1))).toFloat() }
                val sw2 = win.sumOf { (it * it).toDouble() }
                val aw = DoubleArray(FFT_N / 2) { if (it == 0) -100.0 else aWeightDb(it * RATE.toDouble() / FFT_N) }
                var energy = 0.0; var n = 0L
                val t0 = SystemClock.elapsedRealtime()
                while (isActive) {
                    var got = 0
                    while (got < FFT_N && isActive) { val r = rec.read(sh, got, FFT_N - got); if (r <= 0) break; got += r }
                    if (got < FFT_N) break
                    var pk = 0
                    for (i in 0 until FFT_N) { re[i] = sh[i] / 32768f * win[i]; im[i] = 0f; pk = max(pk, abs(sh[i].toInt())) }
                    fft(re, im)
                    var msA = 0.0
                    val bp = DoubleArray(BANDS)
                    for (k in 1 until FFT_N / 2) {
                        val p = (re[k] * re[k] + im[k] * im[k]).toDouble() * 2.0 / (FFT_N * sw2)
                        msA += p * 10.0.pow(aw[k] / 10.0)
                        val f = k * RATE.toDouble() / FFT_N
                        val b = ((ln(f / 31.5) / ln(16000.0 / 31.5)) * BANDS).toInt()
                        if (f >= 31.5 && b in 0 until BANDS) bp[b] += p
                    }
                    val calib = cfg.calib.toDouble()
                    val a = (10 * log10(max(msA, 1e-12)) + calib).toFloat()
                    energy += msA; n++
                    val lq = (10 * log10(max(energy / n, 1e-12)) + calib).toFloat()
                    val pkDb = (20 * log10(max(pk / 32768.0, 1e-6)) + calib).toFloat()
                    for (b in 0 until BANDS) {
                        val db = (10 * log10(max(bp[b], 1e-12)) + calib).toFloat()
                        bands[b] = bands[b] * 0.5f + db * 0.5f
                        holds[b] = max(holds[b] - 0.6f, bands[b])
                    }
                    dba = dba * 0.6f + a * 0.4f
                    peak = max(peak - 0.4f, pkDb)
                    leq = lq
                    secs = ((SystemClock.elapsedRealtime() - t0) / 1000).toInt()
                    frame++
                }
            } finally { try { rec.stop() } catch (_: Exception) {}; rec.release() }
        }
    }

    // ---- media: reuse the visualizer capture
    val mm = remember { MediaMeters() }
    if (!live) {
        DisposableEffect(running) {
            if (running) VizAudio.start(ctx)
            onDispose { if (running) VizAudio.stop() }
        }
        LaunchedEffect(running) {
            while (running) {
                VizAudio.playing = de.mm20.launcher2.ui.launcher.widgets.facesclock.np.MediaState.playing
                VizAudio.gain = 1f; VizAudio.fall = 1f
                VizAudio.update(false)
                mm.step()
                frame++
                kotlinx.coroutines.delay(33)
            }
        }
    }

    fun toggle() {
        if (on) { on = false; return }
        if (live && ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) askMic.launch(Manifest.permission.RECORD_AUDIO)
        else { on = true; bands.fill(0f); holds.fill(0f); dba = 0f; peak = 0f; leq = 0f; secs = 0 }
    }

    ToolCard {
        Column(Modifier.then(posMod)) {
            if (live) MicMeter(cfg, dba, peak, leq, bands, holds, frame, secs)
            else MediaMeterStack(cfg, mm, running, frame)
            if (needTap) Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = { toggle() }) { Text(if (running) "Stop" else "Start listening") }
                if (denied && !running) Text("  Microphone permission is needed", style = MaterialTheme.typography.bodySmall)
                else Text(if (running) "  Stops when you leave or lock" else "  Off until you tap", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

private fun ln(x: Double) = kotlin.math.ln(x)

// ---- live: loudness + EQ only

@Composable
private fun MicMeter(cfg: KvxToolWidgetConfig, dba: Float, peak: Float, leq: Float, bands: FloatArray, holds: FloatArray, frame: Int, secs: Int) {
    @Suppress("UNUSED_EXPRESSION") frame
    val track = MaterialTheme.colorScheme.surfaceVariant
    Row(verticalAlignment = Alignment.Bottom) {
        Text(if (dba > 0f) "%.0f".format(dba) else "--", style = MaterialTheme.typography.displayMedium, color = if (dba > 0f) zoneColor(dba) else MaterialTheme.colorScheme.onSurfaceVariant)
        Text(" dBA", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(bottom = 8.dp))
        Column(Modifier.weight(1f).padding(start = 16.dp, bottom = 4.dp), horizontalAlignment = Alignment.End) {
            Text("Peak %.0f dB".format(peak), style = MaterialTheme.typography.labelMedium)
            Text("Avg %.0f dBA  ·  %d:%02d".format(leq, secs / 60, secs % 60), style = MaterialTheme.typography.labelMedium)
        }
    }
    // loudness bar 50..120 dB with zone colours, peak and average markers
    Canvas(Modifier.fillMaxWidth().height(22.dp).padding(vertical = 4.dp)) {
                if (frame < 0) return@Canvas
        val lo = 50f; val hi = 120f
        fun x(v: Float) = size.width * ((v - lo) / (hi - lo)).coerceIn(0f, 1f)
        drawRect(track, Offset(0f, 0f), size)
        val segs = 35
        for (i in 0 until segs) {
            val v0 = lo + (hi - lo) * i / segs
            if (v0 + 1f <= dba) drawRect(zoneColor(v0), Offset(x(v0) + 1f, 0f), Size(size.width / segs - 2f, size.height))
        }
        drawRect(Color.White, Offset(x(peak) - 1.5f, 0f), Size(3f, size.height))
        drawRect(Color(0xFF80D8FF), Offset(x(leq) - 1.5f, 0f), Size(3f, size.height))
    }
    // EQ spectrum
    val base = (cfg.calib - 90).toFloat()
    Canvas(Modifier.fillMaxWidth().height((cfg.height - 130).coerceAtLeast(60).dp).padding(vertical = 6.dp)) {
                if (frame < 0) return@Canvas
        val w = size.width / BANDS
        for (b in 0 until BANDS) {
            val v = ((bands[b] - base) / 100f).coerceIn(0f, 1f)
            val h = ((holds[b] - base) / 100f).coerceIn(0f, 1f)
            drawRect(track, Offset(b * w + 1f, 0f), Size(w - 2f, size.height))
            drawRect(zoneColor(bands[b]), Offset(b * w + 1f, size.height * (1 - v)), Size(w - 2f, size.height * v))
            drawRect(Color.White, Offset(b * w + 1f, size.height * (1 - h)), Size(w - 2f, 3f))
        }
    }
    Row(Modifier.fillMaxWidth()) {
        for (t in listOf("32", "125", "500", "2k", "8k", "16k")) Text(t, Modifier.weight(1f), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
    }
    val allowed = 8.0 * 2.0.pow(-((leq - 85.0) / 3.0))
    val safe = when {
        leq <= 0f -> "Hearing guide: starts when you do"
        leq < 85f -> "Hearing guide: safe for a full 8 hours"
        allowed >= 1 -> "Hearing guide: about %.1f h at this level".format(allowed)
        else -> "Hearing guide: about %.0f min at this level, earplugs".format(allowed * 60)
    }
    Text(safe, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp))
}

// ---- media: a stack of meters, each switchable

internal val meterNames = listOf("Needle (VU)", "Level bar", "Spectrum (EQ)", "Stereo field", "Waveform", "Low / mid / high", "Beat", "Phase correlation", "L/R balance and width")

private const val HB = 32

internal class MediaMeters {
    var vuL = 0f
    var vuR = 0f
    var dbL = -90f
    var dbR = -90f
    var pkDb = -90f
    var stereo = false
    var level = 0f
    var peak = 0f
    var low = 0f; var mid = 0f; var high = 0f
    var beat = 0f
    var gonioGain = 1f
    val spec = FloatArray(HB)
    val specHold = FloatArray(HB)

    fun step() {
        val d = VizAudio.disp
        val l = (VizAudio.level * 3f).coerceIn(0f, 1.2f)
        stereo = VizAudio.stereoLive()
        val inL = if (stereo) VizAudio.lRms else VizAudio.monoRms
        val inR = if (stereo) VizAudio.rRms else VizAudio.monoRms
        fun db(x: Float) = 20f * kotlin.math.log10(max(x, 1e-5f))
        dbL += (db(inL) - dbL) * 0.3f
        dbR += (db(inR) - dbR) * 0.3f
        pkDb = max(pkDb - 0.25f, max(dbL, dbR))
        // VU ballistics, 0 VU at -14 dBFS, scale -20 .. +3 VU
        val tL = (((dbL + 14f) + 20f) / 23f).coerceIn(0f, 1.1f)
        val tR = (((dbR + 14f) + 20f) / 23f).coerceIn(0f, 1.1f)
        vuL += (tL - vuL) * (if (tL > vuL) 0.3f else 0.08f)
        vuR += (tR - vuR) * (if (tR > vuR) 0.3f else 0.08f)
        level = l
        peak = max(peak - 0.008f, l)
        for (i in 0 until HB) {
            val a = d[i * 2]; val b = d[i * 2 + 1]
            spec[i] = (a + b) / 2f
            specHold[i] = max(specHold[i] - 0.012f, spec[i])
        }
        fun avg(a: Int, b: Int): Float { var s = 0f; for (i in a until b) s += d[i]; return s / (b - a) }
        low += (avg(0, 10) - low) * 0.25f
        mid += (avg(10, 36) - mid) * 0.25f
        high += (avg(36, 64) - high) * 0.25f
        beat = VizAudio.beatEnv
    }

}

@Composable
private fun MediaMeterStack(cfg: KvxToolWidgetConfig, m: MediaMeters, running: Boolean, frame: Int) {
    @Suppress("UNUSED_EXPRESSION") frame
    val primary = MaterialTheme.colorScheme.primary
    val tertiary = MaterialTheme.colorScheme.tertiary
    val track = MaterialTheme.colorScheme.surfaceVariant
    val on = MaterialTheme.colorScheme.onSurface
    var shown = 0
    for (i in meterNames.indices) {
        if ((cfg.mmask shr i) and 1 == 0) continue
        shown++
        if (cfg.labels) Text(meterNames[i], style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = if (shown > 1) 10.dp else 0.dp, bottom = 2.dp))
        else if (shown > 1) androidx.compose.foundation.layout.Spacer(Modifier.height(10.dp))
        when (i) {
            0 -> {
                Canvas(Modifier.fillMaxWidth().height(96.dp)) {
                    if (frame < 0) return@Canvas
                    for (side in 0..1) {
                        val x0 = size.width / 2f * side
                        val cw = size.width / 2f
                        val cx = x0 + cw / 2f; val cy = size.height * 1.05f
                        val r = min(cw * 0.46f, size.height * 0.95f)
                        val arcTl = Offset(cx - r, cy - r)
                        drawArc(track, 200f, 140f, false, topLeft = arcTl, size = Size(r * 2, r * 2), style = Stroke(7.dp.toPx()))
                        drawArc(Color(0xFFE53935), 320f, 20f, false, topLeft = arcTl, size = Size(r * 2, r * 2), style = Stroke(7.dp.toPx()))
                        for (k in 0..10) {
                            val a = Math.toRadians((200.0 + 140.0 * k / 10)); val r0 = r - 12.dp.toPx(); val r1 = r - 4.dp.toPx()
                            drawLine(on.copy(alpha = 0.6f), Offset(cx + (cos(a) * r0).toFloat(), cy + (sin(a) * r0).toFloat()), Offset(cx + (cos(a) * r1).toFloat(), cy + (sin(a) * r1).toFloat()), strokeWidth = 1.5.dp.toPx())
                        }
                        val v = if (side == 0) m.vuL else m.vuR
                        val ang = Math.toRadians(200.0 + 140.0 * (v / 1.1f).coerceIn(0f, 1f))
                        drawLine(if (side == 0) primary else tertiary, Offset(cx, cy), Offset(cx + (cos(ang) * (r - 16.dp.toPx())).toFloat(), cy + (sin(ang) * (r - 16.dp.toPx())).toFloat()), strokeWidth = 3.dp.toPx(), cap = StrokeCap.Round)
                    }
                }
                Text("L %.1f dB   ·   R %.1f dB   (0 VU = -14 dBFS)%s".format(m.dbL.coerceAtLeast(-90f), m.dbR.coerceAtLeast(-90f), if (m.stereo) "" else "   mono"), style = MaterialTheme.typography.labelMedium)
            }
            1 -> {
                Canvas(Modifier.fillMaxWidth().height(if (m.stereo) 30.dp else 18.dp)) {
                    if (frame < 0) return@Canvas
                    val rows = if (m.stereo) 2 else 1
                    val rh = (size.height - 4.dp.toPx() * (rows - 1)) / rows
                    for (rw in 0 until rows) {
                        val y = rw * (rh + 4.dp.toPx())
                        val dbv = if (rw == 0) m.dbL else m.dbR
                        val cr = androidx.compose.ui.geometry.CornerRadius(4.dp.toPx())
                        drawRoundRect(track, Offset(0f, y), Size(size.width, rh), cr)
                        val wv = size.width * ((dbv + 60f) / 60f).coerceIn(0f, 1f)
                        drawRoundRect(Brush.horizontalGradient(listOf(Color(0xFF4CAF50), Color(0xFFFFB300), Color(0xFFE53935)), 0f, size.width), Offset(0f, y), Size(wv, rh), cr)
                    }
                    drawRect(Color.White, Offset(size.width * ((m.pkDb + 60f) / 60f).coerceIn(0f, 1f) - 2f, 0f), Size(3f, size.height))
                }
                Text(
                    if (m.stereo) "L %.1f   R %.1f dBFS   ·   peak %.1f".format(m.dbL.coerceAtLeast(-90f), m.dbR.coerceAtLeast(-90f), m.pkDb.coerceAtLeast(-90f))
                    else "%.1f dBFS   ·   peak %.1f   (mono)".format(m.dbL.coerceAtLeast(-90f), m.pkDb.coerceAtLeast(-90f)),
                    style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(top = 2.dp),
                )
            }
            2 -> Canvas(Modifier.fillMaxWidth().height(80.dp)) {
                if (frame < 0) return@Canvas
                val w = size.width / HB
                for (b in 0 until HB) {
                    val v = m.spec[b].coerceIn(0f, 1f); val h = m.specHold[b].coerceIn(0f, 1f)
                    drawRect(track, Offset(b * w + 1f, 0f), Size(w - 2f, size.height))
                    drawRect(primary, Offset(b * w + 1f, size.height * (1 - v)), Size(w - 2f, size.height * v))
                    drawRect(on, Offset(b * w + 1f, size.height * (1 - h)), Size(w - 2f, 3f))
                }
            }
            3 -> if (!VizAudio.stereoLive()) StereoHint() else Canvas(Modifier.fillMaxWidth().height(150.dp)) {
                if (frame < 0) return@Canvas
                val cx = size.width / 2f; val cy = size.height / 2f
                val r = size.height * 0.46f
                drawCircle(track, r, Offset(cx, cy), style = Stroke(1.5.dp.toPx()))
                drawLine(track, Offset(cx, cy - r), Offset(cx, cy + r), 1.dp.toPx())
                drawLine(track, Offset(cx - r, cy), Offset(cx + r, cy), 1.dp.toPx())
                drawLine(track.copy(alpha = 0.5f), Offset(cx - r * 0.7f, cy + r * 0.7f), Offset(cx + r * 0.7f, cy - r * 0.7f), 1.dp.toPx())
                drawLine(track.copy(alpha = 0.5f), Offset(cx - r * 0.7f, cy - r * 0.7f), Offset(cx + r * 0.7f, cy + r * 0.7f), 1.dp.toPx())
                var pk = 0.15f
                for (i in 0 until VizAudio.G) pk = max(pk, max(abs(VizAudio.gonioL[i]), abs(VizAudio.gonioR[i])))
                m.gonioGain += (1f / pk - m.gonioGain) * 0.1f
                val g = m.gonioGain.coerceIn(0.8f, 6f) * r * 0.9f
                for (i in 0 until VizAudio.G) {
                    val l = VizAudio.gonioL[i]; val rr2 = VizAudio.gonioR[i]
                    val x = cx + (l - rr2) * 0.7071f * g
                    val y = cy - (l + rr2) * 0.7071f * g
                    drawCircle(primary.copy(alpha = 0.55f), 1.6.dp.toPx(), Offset(x.coerceIn(cx - r, cx + r), y.coerceIn(cy - r, cy + r)))
                }
            }
            4 -> Canvas(Modifier.fillMaxWidth().height(64.dp)) {
                if (frame < 0) return@Canvas
                val path = Path()
                val n = VizAudio.W
                for (k in 0 until n) {
                    val x = size.width * k / (n - 1); val y = size.height / 2f - VizAudio.wave[k].coerceIn(-1f, 1f) * size.height * 0.45f
                    if (k == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                drawPath(path, tertiary, style = Stroke(2.dp.toPx(), cap = StrokeCap.Round, join = androidx.compose.ui.graphics.StrokeJoin.Round))
            }
            5 -> {
                val tot = max(m.low + m.mid + m.high, 0.001f)
                Canvas(Modifier.fillMaxWidth().height(70.dp)) {
                if (frame < 0) return@Canvas
                    val bw = size.width / 3f
                    val vs = floatArrayOf(m.low, m.mid, m.high)
                    for (k in 0 until 3) {
                        val v = (vs[k] / max(max(m.low, max(m.mid, m.high)), 0.25f)).coerceIn(0f, 1f)
                        drawRoundRect(track, Offset(k * bw + 6f, 0f), Size(bw - 12f, size.height), androidx.compose.ui.geometry.CornerRadius(8.dp.toPx()))
                        drawRoundRect(listOf(Color(0xFFFF7043), Color(0xFF66BB6A), Color(0xFF42A5F5))[k], Offset(k * bw + 6f, size.height * (1 - v)), Size(bw - 12f, size.height * v), androidx.compose.ui.geometry.CornerRadius(8.dp.toPx()))
                    }
                }
                if (cfg.labels) Row(Modifier.fillMaxWidth()) { for (t in listOf("Low", "Mid", "High")) Text(t, Modifier.weight(1f), style = MaterialTheme.typography.labelSmall, textAlign = androidx.compose.ui.text.style.TextAlign.Center) }
            }
            6 -> Canvas(Modifier.fillMaxWidth().height(56.dp)) {
                if (frame < 0) return@Canvas
                val r = size.height / 2f * (0.45f + 0.55f * m.beat.coerceIn(0f, 1f))
                drawCircle(primary.copy(alpha = 0.25f + 0.6f * m.beat.coerceIn(0f, 1f)), r, Offset(size.width / 2f, size.height / 2f))
                drawCircle(primary, size.height * 0.18f, Offset(size.width / 2f, size.height / 2f))
            }
            7 -> if (!VizAudio.stereoLive()) StereoHint() else {
                Canvas(Modifier.fillMaxWidth().height(34.dp)) {
                    if (frame < 0) return@Canvas
                    drawRoundRect(track, Offset(0f, 8.dp.toPx()), Size(size.width, 14.dp.toPx()), androidx.compose.ui.geometry.CornerRadius(7.dp.toPx()))
                    val c = VizAudio.corr.coerceIn(-1f, 1f)
                    val x = size.width * (c + 1f) / 2f
                    drawRect(Color(0xFFE53935).copy(alpha = 0.35f), Offset(0f, 8.dp.toPx()), Size(size.width * 0.5f, 14.dp.toPx()))
                    drawRect(Color(0xFF4CAF50).copy(alpha = 0.35f), Offset(size.width * 0.5f, 8.dp.toPx()), Size(size.width * 0.5f, 14.dp.toPx()))
                    drawRect(on, Offset(x - 2.dp.toPx(), 2.dp.toPx()), Size(4.dp.toPx(), 26.dp.toPx()))
                }
                if (cfg.labels) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("-1 out of phase", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("%+.2f".format(VizAudio.corr), style = MaterialTheme.typography.labelMedium)
                    Text("+1 mono", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            8 -> if (!VizAudio.stereoLive()) StereoHint() else {
                Canvas(Modifier.fillMaxWidth().height(46.dp)) {
                    if (frame < 0) return@Canvas
                    val h = size.height / 2f - 3.dp.toPx()
                    val l = (VizAudio.lRms * 3f).coerceIn(0f, 1f); val r = (VizAudio.rRms * 3f).coerceIn(0f, 1f)
                    drawRoundRect(track, Offset.Zero, Size(size.width, h), androidx.compose.ui.geometry.CornerRadius(4.dp.toPx()))
                    drawRoundRect(primary, Offset.Zero, Size(size.width * l, h), androidx.compose.ui.geometry.CornerRadius(4.dp.toPx()))
                    drawRoundRect(track, Offset(0f, h + 6.dp.toPx()), Size(size.width, h), androidx.compose.ui.geometry.CornerRadius(4.dp.toPx()))
                    drawRoundRect(tertiary, Offset(0f, h + 6.dp.toPx()), Size(size.width * r, h), androidx.compose.ui.geometry.CornerRadius(4.dp.toPx()))
                }
                val bal = if (VizAudio.lRms + VizAudio.rRms > 0.001f) (VizAudio.rRms - VizAudio.lRms) / (VizAudio.rRms + VizAudio.lRms) else 0f
                if (cfg.labels) Text("L / R   ·   balance %s   ·   width %.0f%%".format(if (abs(bal) < 0.03f) "centred" else if (bal > 0) "%.0f%% right".format(bal * 100) else "%.0f%% left".format(-bal * 100), VizAudio.width * 200f), style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(top = 2.dp))
            }
        }
    }
    if (shown == 0) Text("Turn meters on in the widget's settings", color = MaterialTheme.colorScheme.onSurfaceVariant)
    else if (!running) Text("Waiting. Play something, or tap Start.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 6.dp))
}

// ---------------------------------------------------------------- metronome and tap tempo

private fun clickTrack(freq: Double, ms: Int, amp: Double): AudioTrack {
    val n = RATE * ms / 1000
    val buf = ShortArray(n) { i -> (sin(2 * PI * freq * i / RATE) * exp(-i.toDouble() / n * 6.0) * amp * 32767).toInt().toShort() }
    val t = AudioTrack.Builder()
        .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
        .setAudioFormat(AudioFormat.Builder().setSampleRate(RATE).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
        .setBufferSizeInBytes(n * 2).setTransferMode(AudioTrack.MODE_STATIC).build()
    t.write(buf, 0, n)
    return t
}

private fun exp(x: Double) = kotlin.math.exp(x)

@Composable
fun MetronomeTool() {
    val ctx = LocalContext.current
    var bpm by remember { mutableIntStateOf(ToolStore.getLong(ctx, "bpm", 120).toInt()) }
    var beats by remember { mutableIntStateOf(ToolStore.getLong(ctx, "beats", 4).toInt()) }
    var on by remember { mutableStateOf(false) }
    var beat by remember { mutableIntStateOf(-1) }
    val taps = remember { ArrayList<Long>() }
    fun setBpm(v: Int) { bpm = v.coerceIn(30, 300); ToolStore.putLong(ctx, "bpm", bpm.toLong()) }

    val (visible, posMod) = rememberOnScreen()
    LaunchedEffect(visible) { if (!visible) on = false }

    LaunchedEffect(on) {
        while (on) { kotlinx.coroutines.delay(1000L); WidgetStats.res(toolTitle(6), audio = 1.0) }
    }
    LaunchedEffect(on) {
        if (!on) { beat = -1; return@LaunchedEffect }
        withContext(Dispatchers.Default) {
            val hi = clickTrack(1600.0, 40, 0.9); val lo = clickTrack(1000.0, 40, 0.6)
            try {
                var i = 0
                var next = System.nanoTime()
                while (isActive) {
                    val t = if (i % beats == 0) hi else lo
                    try { t.stop(); t.setPlaybackHeadPosition(0); t.play() } catch (_: Exception) {}
                    beat = i % beats
                    i++
                    next += (60_000_000_000L / bpm)   // drift-free: schedule from the original start, not from "now"
                    val wait = (next - System.nanoTime()) / 1_000_000
                    if (wait > 0) kotlinx.coroutines.delay(wait)
                }
            } finally { hi.release(); lo.release() }
        }
    }

    ToolCard {
        Column(Modifier.then(posMod)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { setBpm(bpm - 1) }) { Text("−") }
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("$bpm", style = MaterialTheme.typography.displayMedium)
                    Text("BPM", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                TextButton(onClick = { setBpm(bpm + 1) }) { Text("+") }
            }
            Row(Modifier.fillMaxWidth().height(40.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                for (i in 0 until beats) {
                    androidx.compose.foundation.layout.Box(
                        Modifier.padding(horizontal = 6.dp).size(if (i == beat) 18.dp else 14.dp).clip(androidx.compose.foundation.shape.CircleShape)
                            .background(if (i == beat) (if (i == 0) Color(0xFFFFB300) else Color(0xFF4CAF50)) else Color.Gray.copy(alpha = 0.4f))
                    )
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = { on = !on }) { Text(if (on) "Stop" else "Start") }
                FilledTonalButton(onClick = {
                    val now = SystemClock.elapsedRealtime()
                    if (taps.isNotEmpty() && now - taps.last() > 2000) taps.clear()
                    taps.add(now)
                    while (taps.size > 7) taps.removeAt(0)
                    if (taps.size >= 2) setBpm((60_000.0 / ((taps.last() - taps.first()).toDouble() / (taps.size - 1))).toInt())
                }) { Text("Tap tempo") }
                for (b in listOf(3, 4, 6)) FilterChip(selected = beats == b, onClick = { beats = b; ToolStore.putLong(ctx, "beats", b.toLong()) }, label = { Text("$b") })
            }
            Text("Stops when you leave this page", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp))
        }
    }
}

@Composable
private fun StereoHint() {
    val ctx = LocalContext.current
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("Stereo meters need audio capture to hear both channels.", Modifier.weight(1f), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        TextButton(onClick = {
            try { ctx.startActivity(Intent(ctx, CaptureActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_MULTIPLE_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)) } catch (e: Exception) {}
        }) { Text("Start capture") }
    }
}
