package de.mm20.launcher2.ui.theme

import android.content.Context
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.material3.ColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import de.mm20.launcher2.ui.launcher.widgets.facesclock.np.MediaState

/** Optional theme accent taken from the album art. Only active while music is playing. */
object KvxDynTheme {
    var on by mutableStateOf(false)
    private var loaded = false

    private fun sp(ctx: Context) = ctx.applicationContext.getSharedPreferences("kvx_dyn_theme", Context.MODE_PRIVATE)

    fun load(ctx: Context) {
        if (loaded) return
        loaded = true
        on = sp(ctx).getBoolean("on", false)
    }

    fun set(ctx: Context, v: Boolean) {
        load(ctx)
        on = v
        sp(ctx).edit().putBoolean("on", v).apply()
    }

    private fun tone(argb: Int, dark: Boolean, container: Boolean): Color {
        val hsv = FloatArray(3)
        android.graphics.Color.colorToHSV(argb, hsv)
        if (dark) {
            hsv[1] = minOf(hsv[1], if (container) 0.60f else 0.45f)
            hsv[2] = if (container) 0.32f else 0.92f
        } else {
            hsv[1] = minOf(hsv[1], if (container) 0.28f else 0.75f)
            hsv[2] = if (container) 0.95f else 0.42f
        }
        return Color(android.graphics.Color.HSVToColor(hsv))
    }

    private fun onOf(c: Color): Color = if (c.luminance01() > 0.5f) Color(0xFF111111) else Color.White
    private fun Color.luminance01(): Float = 0.2126f * red + 0.7152f * green + 0.0722f * blue

    /** Returns [base] recoloured from the artwork while playing, fading back to [base] when paused. */
    @Composable
    fun apply(base: ColorScheme, dark: Boolean): ColorScheme {
        val ctx = LocalContext.current
        load(ctx)
        if (!on) return base
        var sig by remember { mutableIntStateOf(0) }
        DisposableEffect(Unit) {
            MediaState.ensureStarted(ctx)
            val l: () -> Unit = { sig++ }
            MediaState.addListener(l)
            onDispose { MediaState.removeListener(l) }
        }
        @Suppress("UNUSED_EXPRESSION") sig
        val active = MediaState.playing && MediaState.art != null
        val spec = tween<Color>(700)
        val pr = animateColorAsState(if (active) tone(MediaState.accent, dark, false) else base.primary, spec, label = "dp").value
        val prc = animateColorAsState(if (active) tone(MediaState.accent, dark, true) else base.primaryContainer, spec, label = "dpc").value
        val se = animateColorAsState(if (active) tone(MediaState.accent2, dark, false) else base.secondary, spec, label = "ds").value
        val sec = animateColorAsState(if (active) tone(MediaState.accent2, dark, true) else base.secondaryContainer, spec, label = "dsc").value
        val tc = MediaState.palette.getOrElse(2) { MediaState.accent2 }
        val te = animateColorAsState(if (active) tone(tc, dark, false) else base.tertiary, spec, label = "dt").value
        val tec = animateColorAsState(if (active) tone(tc, dark, true) else base.tertiaryContainer, spec, label = "dtc").value
        return base.copy(
            primary = pr, onPrimary = onOf(pr), primaryContainer = prc, onPrimaryContainer = onOf(prc),
            secondary = se, onSecondary = onOf(se), secondaryContainer = sec, onSecondaryContainer = onOf(sec),
            tertiary = te, onTertiary = onOf(te), tertiaryContainer = tec, onTertiaryContainer = onOf(tec),
            surfaceTint = pr, inversePrimary = pr,
        )
    }
}
