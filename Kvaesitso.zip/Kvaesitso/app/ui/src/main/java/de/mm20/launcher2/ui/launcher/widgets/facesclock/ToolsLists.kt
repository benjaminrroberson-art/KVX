package de.mm20.launcher2.ui.launcher.widgets.facesclock

import android.app.Activity
import androidx.compose.ui.res.painterResource
import de.mm20.launcher2.ui.R
import android.app.NotificationManager
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.location.LocationManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.PowerManager
import android.provider.ContactsContract
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.layout.height
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import de.mm20.launcher2.widgets.KvxToolWidgetConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.net.HttpURLConnection
import java.net.URL

// ---------------------------------------------------------------- to-do

@Composable
fun TodoTool() {
    val ctx = LocalContext.current
    var rev by remember { mutableStateOf(0) }
    var text by remember { mutableStateOf("") }
    @Suppress("UNUSED_EXPRESSION") rev
    val arr = try { JSONArray(ToolStore.get(ctx, "todo", "[]")) } catch (e: Exception) { JSONArray() }
    fun save() { ToolStore.put(ctx, "todo", arr.toString()); rev++ }
    fun add() {
        val t = text.trim(); if (t.isEmpty()) return
        arr.put(JSONObject().put("t", t).put("d", false)); text = ""; save()
    }
    ToolCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = text, onValueChange = { text = it }, singleLine = true, placeholder = { Text("Add a task") },
                modifier = Modifier.weight(1f),
                keyboardActions = androidx.compose.foundation.text.KeyboardActions(onDone = { add() }),
                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(imeAction = androidx.compose.ui.text.input.ImeAction.Done),
            )
            TextButton(onClick = { add() }) { Text("Add") }
        }
        if (arr.length() == 0) Text("Nothing to do", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 8.dp))
        // open tasks first, then done
        val order = (0 until arr.length()).sortedBy { if (arr.getJSONObject(it).getBoolean("d")) 1 else 0 }
        for (i in order.take(8)) {
            val o = arr.getJSONObject(i)
            val done = o.getBoolean("d")
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = done, onCheckedChange = { o.put("d", it); save() })
                Text(
                    o.getString("t"), modifier = Modifier.weight(1f), maxLines = 2, overflow = TextOverflow.Ellipsis,
                    color = if (done) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface,
                    textDecoration = if (done) androidx.compose.ui.text.style.TextDecoration.LineThrough else null,
                )
                TextButton(onClick = {
                    val rest = JSONArray(); for (j in 0 until arr.length()) if (j != i) rest.put(arr.getJSONObject(j))
                    ToolStore.put(ctx, "todo", rest.toString()); rev++
                }) { Text("✕") }
            }
        }
        if (arr.length() > 8) Text("+${arr.length() - 8} more", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        var anyDone = false
        for (i in 0 until arr.length()) if (arr.getJSONObject(i).getBoolean("d")) anyDone = true
        if (anyDone) TextButton(onClick = {
            val rest = JSONArray(); for (j in 0 until arr.length()) if (!arr.getJSONObject(j).getBoolean("d")) rest.put(arr.getJSONObject(j))
            ToolStore.put(ctx, "todo", rest.toString()); rev++
        }) { Text("Clear done") }
    }
}

// ---------------------------------------------------------------- toggles

private val toggleLabels = listOf("Flashlight", "Wi-Fi", "Bluetooth", "Internet", "Airplane mode", "Do not disturb", "Auto-rotate", "Location", "Battery saver", "Hotspot", "Volume", "Battery share")
private val toggleIcons = listOf(R.drawable.kvx_flash, R.drawable.kvx_wifi, R.drawable.kvx_bluetooth, R.drawable.public_24px, R.drawable.kvx_airplane, R.drawable.do_not_disturb_on_24px,
    R.drawable.kvx_rotate, R.drawable.location_on_24px, R.drawable.kvx_saver, R.drawable.kvx_hotspot, R.drawable.kvx_volume, R.drawable.battery_charging_full_24px)

private fun start(ctx: Context, i: Intent) {
    try { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) {
        try { ctx.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
    }
}

@Composable
fun TogglesTool(cfg: KvxToolWidgetConfig) {
    val ctx = LocalContext.current
    var torch by remember { mutableStateOf(false) }
    var tick by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) { while (true) { delay(2000); tick++ } }
    val cm = remember { ctx.getSystemService(CameraManager::class.java) }
    androidx.compose.runtime.DisposableEffect(Unit) {
        val cb = object : CameraManager.TorchCallback() { override fun onTorchModeChanged(id: String, on: Boolean) { torch = on } }
        try { cm.registerTorchCallback(cb, null) } catch (_: Exception) {}
        onDispose { try { cm.unregisterTorchCallback(cb) } catch (_: Exception) {} }
    }
    @Suppress("UNUSED_EXPRESSION") tick
    fun state(i: Int): Boolean? = try {
        when (i) {
            0 -> torch
            1 -> ctx.applicationContext.getSystemService(WifiManager::class.java).isWifiEnabled
            2 -> ctx.getSystemService(BluetoothManager::class.java).adapter?.isEnabled
            4 -> Settings.Global.getInt(ctx.contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1
            5 -> ctx.getSystemService(NotificationManager::class.java).currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL
            6 -> Settings.System.getInt(ctx.contentResolver, Settings.System.ACCELEROMETER_ROTATION, 0) == 1
            7 -> ctx.getSystemService(LocationManager::class.java).isLocationEnabled
            8 -> ctx.getSystemService(PowerManager::class.java).isPowerSaveMode
            else -> null
        }
    } catch (e: Exception) { null }
    fun act(i: Int) {
        when (i) {
            0 -> try { val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }; if (id != null) cm.setTorchMode(id, !torch) } catch (_: Exception) {}
            1 -> start(ctx, Intent(Settings.Panel.ACTION_WIFI))
            2 -> start(ctx, Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
            3 -> start(ctx, Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY))
            4 -> start(ctx, Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS))
            5 -> {
                val nm = ctx.getSystemService(NotificationManager::class.java)
                if (nm.isNotificationPolicyAccessGranted) {
                    nm.setInterruptionFilter(if (nm.currentInterruptionFilter == NotificationManager.INTERRUPTION_FILTER_ALL) NotificationManager.INTERRUPTION_FILTER_PRIORITY else NotificationManager.INTERRUPTION_FILTER_ALL)
                } else start(ctx, Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            }
            6 -> if (Settings.System.canWrite(ctx)) {
                Settings.System.putInt(ctx.contentResolver, Settings.System.ACCELEROMETER_ROTATION, if (state(6) == true) 0 else 1)
            } else start(ctx, Intent(Settings.ACTION_DISPLAY_SETTINGS))
            7 -> start(ctx, Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
            8 -> start(ctx, Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS))
            9 -> start(ctx, Intent("android.settings.TETHER_SETTINGS"))
            10 -> start(ctx, Intent(Settings.Panel.ACTION_VOLUME))
            11 -> {
                // Pixel "Battery Share" lives in battery settings; try the direct page, fall back to battery settings
                val direct = Intent().setClassName("com.android.settings", "com.android.settings.Settings\$BatterySharingActivity")
                try { ctx.startActivity(direct.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { start(ctx, Intent(Intent.ACTION_POWER_USAGE_SUMMARY)) }
            }
        }
        tick++
    }
    val shown = (0..11).filter { (cfg.mask shr it) and 1 == 1 }
    ToolCard {
        if (shown.isEmpty()) Text("Pick toggles in the widget's settings", color = MaterialTheme.colorScheme.onSurfaceVariant)
        for (row in shown.chunked(4)) {
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (i in row) {
                    val on = state(i)
                    val bg = if (on == true) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceContainerHighest
                    val fg = if (on == true) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                    Box(
                        Modifier.weight(1f).clip(MaterialTheme.shapes.large).background(bg).clickable { act(i) }.padding(vertical = 14.dp, horizontal = 4.dp),
                        contentAlignment = Alignment.Center,
                    ) { androidx.compose.material3.Icon(painterResource(toggleIcons[i]), contentDescription = toggleLabels[i], tint = fg, modifier = Modifier.size(24.dp)) }
                }
                repeat(4 - row.size) { Box(Modifier.weight(1f)) }
            }
        }
    }
}

// ---------------------------------------------------------------- contacts

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ContactsTool(cfg: KvxToolWidgetConfig) {
    val ctx = LocalContext.current
    var rev by remember { mutableStateOf(0) }
    @Suppress("UNUSED_EXPRESSION") rev
    val arr = try { JSONArray(ToolStore.get(ctx, "contacts", "[]")) } catch (e: Exception) { JSONArray() }
    var picking by remember { mutableStateOf(false) }
    val askPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) picking = true }
    fun openPicker() {
        if (ctx.checkSelfPermission(android.Manifest.permission.READ_CONTACTS) == android.content.pm.PackageManager.PERMISSION_GRANTED) picking = true
        else askPerm.launch(android.Manifest.permission.READ_CONTACTS)
    }
    if (picking) ContactPickerDialog(onDismiss = { picking = false }) { n, p, u, ph ->
        arr.put(JSONObject().put("n", n).put("p", p).put("u", u).put("ph", ph))
        ToolStore.put(ctx, "contacts", arr.toString()); rev++; picking = false
    }
    ToolCard {
        if (arr.length() == 0) Text("Add the people you call most", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(bottom = 8.dp))
        val list = (0 until arr.length()).toList()
        for (row in list.chunked(4)) {
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (i in row) {
                    val o = arr.getJSONObject(i)
                    val name = o.getString("n")
                    Column(
                        Modifier.weight(1f).combinedClickable(
                            onClick = {
                                val p = o.getString("p")
                                start(ctx, when (cfg.mode) {
                                    1 -> Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$p"))
                                    2 -> Intent(Intent.ACTION_VIEW, Uri.parse(o.getString("u")))
                                    else -> Intent(Intent.ACTION_DIAL, Uri.parse("tel:$p"))
                                })
                            },
                            onLongClick = {
                                val rest = JSONArray(); for (j in 0 until arr.length()) if (j != i) rest.put(arr.getJSONObject(j))
                                ToolStore.put(ctx, "contacts", rest.toString()); rev++
                            },
                        ),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        val hue = (name.hashCode().toLong().and(0xFFFF) % 360).toFloat()
                        val photo = remember(o.optString("ph")) { loadPhoto(ctx, o.optString("ph")) }
                        Box(Modifier.size(48.dp).clip(CircleShape).background(Color.hsv(hue, 0.45f, 0.75f)), contentAlignment = Alignment.Center) {
                            if (photo != null) androidx.compose.foundation.Image(photo, null, Modifier.size(48.dp), contentScale = androidx.compose.ui.layout.ContentScale.Crop)
                            else Text(name.trim().take(1).uppercase(), color = Color.White, style = MaterialTheme.typography.titleMedium)
                        }
                        Text(name.substringBefore(' '), style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp))
                    }
                }
                repeat(4 - row.size) { Box(Modifier.weight(1f)) }
            }
        }
        TextButton(onClick = { openPicker() }) { Text("Add contact") }
        if (arr.length() > 0) Text("Long-press a contact to remove it", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

// ---------------------------------------------------------------- headlines

private class Headline(val title: String, val link: String, val source: String)

private fun fetchFeed(url: String): List<Headline> {
    val out = ArrayList<Headline>()
    val conn = URL(url).openConnection() as HttpURLConnection
    conn.connectTimeout = 8000; conn.readTimeout = 8000
    conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) KvaesitsoX")
    try {
        val p = XmlPullParserFactory.newInstance().newPullParser()
        p.setInput(conn.inputStream, null)
        var source = ""
        var inItem = false
        var title = ""; var link = ""
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            when (ev) {
                XmlPullParser.START_TAG -> when (p.name) {
                    "item", "entry" -> { inItem = true; title = ""; link = "" }
                    "title" -> { val t = p.nextText().trim(); if (inItem) title = t else if (source.isEmpty()) source = t }
                    "link" -> if (inItem) {
                        val h = p.getAttributeValue(null, "href")
                        val t = if (h != null) { p.nextTag(); h } else p.nextText().trim()
                        if (link.isEmpty() && t.isNotEmpty()) link = t
                    }
                }
                XmlPullParser.END_TAG -> if ((p.name == "item" || p.name == "entry") && inItem) {
                    inItem = false
                    if (title.isNotEmpty() && link.isNotEmpty()) out.add(Headline(title, link, source))
                }
            }
            ev = p.next()
        }
    } finally { conn.disconnect() }
    return out
}

@Composable
fun HeadlinesTool(cfg: KvxToolWidgetConfig) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var items by remember { mutableStateOf(emptyList<Headline>()) }
    var status by remember { mutableStateOf("") }
    fun cacheLoad(): List<Headline> = try {
        val a = JSONArray(ToolStore.get(ctx, "headlines", "[]"))
        (0 until a.length()).map { a.getJSONObject(it).let { o -> Headline(o.getString("t"), o.getString("l"), o.getString("s")) } }
    } catch (e: Exception) { emptyList() }
    fun refresh() {
        scope.launch {
            status = "Updating…"
            val urls = cfg.feeds.lines().map { it.trim() }.filter { it.startsWith("http") }
            WidgetStats.res(toolTitle(4), net = kotlin.math.max(1, cfg.feeds.lines().count { it.trim().startsWith("http") }).toDouble())
            val lists = withContext(Dispatchers.IO) { urls.map { try { fetchFeed(it) } catch (e: Exception) { emptyList() } } }
            val merged = ArrayList<Headline>()
            var k = 0
            while (merged.size < 40 && lists.any { k < it.size }) { for (l in lists) if (k < l.size) merged.add(l[k]); k++ }
            if (merged.isNotEmpty()) {
                items = merged
                val a = JSONArray(); merged.forEach { a.put(JSONObject().put("t", it.title).put("l", it.link).put("s", it.source)) }
                ToolStore.put(ctx, "headlines", a.toString()); ToolStore.putLong(ctx, "headlines_at", System.currentTimeMillis())
                status = ""
            } else status = if (urls.isEmpty()) "No feeds set" else "Could not load. Showing saved headlines."
        }
    }
    LaunchedEffect(cfg.feeds) {
        items = cacheLoad()
        while (true) {
            if (System.currentTimeMillis() - ToolStore.getLong(ctx, "headlines_at") > 30 * 60_000L || items.isEmpty()) refresh()
            delay(10 * 60_000L)
        }
    }
    ToolCard {
        for (h in items.take(cfg.count)) {
            Column(Modifier.fillMaxWidth().clickable { start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(h.link))) }.padding(vertical = 6.dp)) {
                Text(h.title, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
                Text(h.source, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
            }
        }
        if (items.isEmpty() && status.isEmpty()) Text("No headlines yet", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { refresh() }) { Text("Refresh") }
            Text(status, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun FeedsEditor(value: String, onChange: (String) -> Unit) {
    var text by remember(value) { mutableStateOf(value) }
    Column(Modifier.padding(16.dp)) {
        Text("Feeds (one web address per line)", style = MaterialTheme.typography.titleSmall)
        OutlinedTextField(value = text, onValueChange = { text = it; onChange(it) }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp), minLines = 3)
    }
}

private fun loadPhoto(ctx: Context, uri: String): androidx.compose.ui.graphics.ImageBitmap? {
    if (uri.isEmpty()) return null
    return try { ctx.contentResolver.openInputStream(Uri.parse(uri))?.use { android.graphics.BitmapFactory.decodeStream(it)?.asImageBitmap() } } catch (e: Exception) { null }
}

private class PhoneRow(val name: String, val number: String, val uri: String, val photo: String)

@Composable
private fun ContactPickerDialog(onDismiss: () -> Unit, onPick: (String, String, String, String) -> Unit) {
    val ctx = LocalContext.current
    var q by remember { mutableStateOf("") }
    val all by produceState(emptyList<PhoneRow>()) {
        value = withContext(Dispatchers.IO) {
            val out = ArrayList<PhoneRow>()
            try {
                val C = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
                ctx.contentResolver.query(C, arrayOf("_id", "display_name", "data1", "photo_thumb_uri"), null, null, "display_name COLLATE NOCASE ASC")?.use { c ->
                    while (c.moveToNext()) out.add(PhoneRow(c.getString(1) ?: "", c.getString(2) ?: "", Uri.withAppendedPath(C, c.getLong(0).toString()).toString(), c.getString(3) ?: ""))
                }
            } catch (_: Exception) {}
            out.distinctBy { it.name + it.number.filter { ch -> ch.isDigit() } }
        }
    }
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add a contact") },
        text = {
            Column {
                OutlinedTextField(value = q, onValueChange = { q = it }, singleLine = true, placeholder = { Text("Search") }, modifier = Modifier.fillMaxWidth())
                androidx.compose.foundation.lazy.LazyColumn(Modifier.padding(top = 8.dp).height(320.dp)) {
                    items(all.filter { q.isBlank() || it.name.contains(q, true) || it.number.contains(q) }.take(100)) { r ->
                        Column(Modifier.fillMaxWidth().clickable { onPick(r.name, r.number, r.uri, r.photo) }.padding(vertical = 8.dp)) {
                            Text(r.name, style = MaterialTheme.typography.bodyLarge, maxLines = 1)
                            Text(r.number, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
