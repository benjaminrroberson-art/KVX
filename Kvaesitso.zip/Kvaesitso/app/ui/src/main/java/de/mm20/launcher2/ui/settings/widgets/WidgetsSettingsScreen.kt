package de.mm20.launcher2.ui.settings.widgets

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation3.runtime.NavKey
import de.mm20.launcher2.preferences.ClockWidgetStyle
import de.mm20.launcher2.preferences.ui.ClockWidgetSettings
import de.mm20.launcher2.services.widgets.WidgetsService
import de.mm20.launcher2.ui.R
import de.mm20.launcher2.ui.component.preferences.Preference
import de.mm20.launcher2.ui.component.preferences.PreferenceCategory
import de.mm20.launcher2.ui.component.preferences.PreferenceScreen
import de.mm20.launcher2.ui.launcher.widgets.facesclock.ConfigureRingerWidget
import de.mm20.launcher2.ui.launcher.widgets.facesclock.FacesClockEditor
import de.mm20.launcher2.ui.launcher.widgets.facesclock.RingerBody
import de.mm20.launcher2.widgets.FacesClockWidget
import de.mm20.launcher2.widgets.FacesClockWidgetConfig
import de.mm20.launcher2.widgets.RingerWidget
import de.mm20.launcher2.widgets.NowPlayingWidget
import de.mm20.launcher2.ui.launcher.widgets.facesclock.ConfigureNowPlayingWidget
import de.mm20.launcher2.ui.launcher.widgets.facesclock.NowPlayingBody
import de.mm20.launcher2.widgets.Widget
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import androidx.lifecycle.viewModelScope
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject
import kotlinx.serialization.Serializable

@Serializable
data object WidgetsSettingsRoute : NavKey

class WidgetsSettingsScreenVM : ViewModel(), KoinComponent {
    private val widgets: WidgetsService by inject()
    private val clock: ClockWidgetSettings by inject()

    val all = widgets.getWidgets().stateIn(viewModelScope, SharingStarted.WhileSubscribed(), emptyList<Widget>())
    val clockStyle = clock.clockStyle.stateIn(viewModelScope, SharingStarted.WhileSubscribed(), null)

    fun update(w: Widget) = widgets.updateWidget(w)
    fun setClockStyle(s: ClockWidgetStyle) = clock.setClockStyle(s)
}

@Composable
private fun WidgetCard(title: String, preview: @Composable () -> Unit, content: @Composable () -> Unit) {
    var open by remember { mutableStateOf(false) }
    OutlinedCard(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)) {
        Column {
            Preference(
                title = title,
                summary = if (open) "Tap to close" else "Tap to customize",
                onClick = { open = !open },
            )
            Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) { preview() }
            if (open) Column(Modifier.padding(8.dp)) { content() }
        }
    }
}

@Composable
fun WidgetsSettingsScreen() {
    val vm: WidgetsSettingsScreenVM = viewModel()
    val widgets by vm.all.collectAsState()
    val clockStyle by vm.clockStyle.collectAsState()

    PreferenceScreen(title = "Widgets") {
        item {
            PreferenceCategory(title = "Home screen clock") {
                val cs = clockStyle
                if (cs is ClockWidgetStyle.Faces) {
                    Column(Modifier.padding(16.dp)) {
                        FacesClockEditor(cs.clock, onChange = { vm.setClockStyle(cs.copy(clock = it)) })
                    }
                } else {
                    Preference(
                        title = "Use the face clock",
                        summary = "Switch the home screen clock to our 59 faces and customize it here",
                        onClick = { vm.setClockStyle(ClockWidgetStyle.Faces()) },
                    )
                }
            }
        }
        item {
            PreferenceCategory(title = "Added widgets") {
                val mine = widgets.filter { it is FacesClockWidget || it is RingerWidget || it is NowPlayingWidget }
                if (mine.isEmpty()) {
                    Text(
                        "No face clocks or ringer widgets added yet. Add them from a widget page with Edit widgets > Add widget.",
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(16.dp),
                    )
                }
                for (w in mine) {
                    when (w) {
                        is FacesClockWidget -> WidgetCard(
                            title = "Face clock",
                            preview = {},
                            content = {
                                FacesClockEditor(w.config.clock, onChange = { vm.update(w.copy(config = FacesClockWidgetConfig(it))) })
                            },
                        )
                        is RingerWidget -> WidgetCard(
                            title = "Ringer mode",
                            preview = { RingerBody(w.config) },
                            content = { ConfigureRingerWidget(w) { vm.update(it) } },
                        )
                        is NowPlayingWidget -> WidgetCard(
                            title = "Now playing",
                            preview = { NowPlayingBody(w.config) },
                            content = { ConfigureNowPlayingWidget(w) { vm.update(it) } },
                        )
                        else -> {}
                    }
                }
            }
        }
    }
}
