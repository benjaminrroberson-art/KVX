package de.mm20.launcher2.ui.launcher.widgets.facesclock

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.ui.layout.layout
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.foundation.layout.Column
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import de.mm20.launcher2.music.PlaybackState
import de.mm20.launcher2.ui.component.preferences.ListPreference
import de.mm20.launcher2.ui.component.preferences.SliderPreference
import de.mm20.launcher2.ui.component.preferences.SwitchPreference
import de.mm20.launcher2.ui.launcher.widgets.music.MusicWidgetVM
import de.mm20.launcher2.widgets.KvxVizWidget
import de.mm20.launcher2.widgets.KvxVizWidgetConfig
import de.mm20.launcher2.widgets.VizConfig

/** Artwork with the visualizer around or on it. When [reserve] is false the visualizer overflows the layout box so the artwork keeps exactly [artDp]. */
@Composable
fun VizBubble(artDp: Float, cfg: VizConfig, art: Bitmap?, playing: Boolean, reserve: Boolean, modifier: Modifier = Modifier) {
    val total = artDp * 1.68f
    var m = modifier
    m = if (reserve) m.size(total.dp) else m.size(artDp.dp).layout { measurable, c ->
        val big = (total * density).toInt()
        val p = measurable.measure(Constraints.fixed(big, big))
        val side = (artDp * density).toInt()
        layout(side, side) { p.place(-(big - side) / 2, -(big - side) / 2) }
    }
    val ref = remember { arrayOfNulls<android.view.View>(1) }
    AndroidView(
        factory = { VizBubbleView(it).also { v -> ref[0] = v; VizWidgetRegistry.track(v) } },
        update = { v ->
            v.artDp = artDp
            v.cfg = cfg
            v.art = art
            v.playing = playing
        },
        modifier = m.vizVisible(ref),
    )
}

@Composable
internal fun rememberAudioPermission(): Pair<Boolean, () -> Unit> {
    val context = LocalContext.current
    var granted by remember { mutableStateOf(context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        granted = ok
        if (ok) VizAudio.retry(context)
    }
    return granted to { launcher.launch(Manifest.permission.RECORD_AUDIO) }
}

@Composable
fun KvxVizView(widget: KvxVizWidget) = KvxVizBody(widget.config)

@Composable
fun KvxVizBody(cfg: KvxVizWidgetConfig) {
    if (cfg.layout == 1) { VizFillBody(cfg); return }
    if (cfg.layout == 2) { CardWidgetBody(cfg); return }
    val vm: MusicWidgetVM = viewModel()
    val art by vm.albumArt.collectAsState(null)
    val state by vm.playbackState.collectAsState(PlaybackState.Stopped)
    val (granted, ask) = rememberAudioPermission()
    Column(Modifier.fillMaxWidth().padding(start = 12.dp + cfg.padStart.dp, top = 12.dp + cfg.padTop.dp, end = 12.dp + cfg.padEnd.dp, bottom = 12.dp + cfg.padBottom.dp)) {
        Box(Modifier.fillMaxWidth(), contentAlignment = when (cfg.align) { 0 -> Alignment.CenterStart; 2 -> Alignment.CenterEnd; else -> Alignment.Center }) {
            val ctx = androidx.compose.ui.platform.LocalContext.current
            val look = if (cfg.followBubble) BubbleSettings.viz(ctx) else cfg.viz
            VizBubble(cfg.size.toFloat(), look, art, state == PlaybackState.Playing, true)
        }
        if (!granted) TextButton(onClick = ask) { Text("Allow audio access for the visualizer", color = MaterialTheme.colorScheme.primary) }
    }
}

private val vizStyles = listOf("Bars" to 0, "Wave" to 2, "Filled wave" to 3, "Ring" to 4, "Pulse ring" to 5, "Particles" to 6, "Glow" to 7)

/** Visualizer settings, shared by the Visualizer widget and Now Playing. */
@Composable
fun VizControls(c: VizConfig, shape: Boolean, onChange: (VizConfig) -> Unit) {
    val (granted, ask) = rememberAudioPermission()
    if (!granted) de.mm20.launcher2.ui.component.preferences.Preference(title = "Allow audio access", summary = "Needed to analyse the music", onClick = ask)
    val st = if (c.style == 1) 0 else c.style
    ListPreference(title = "Visualizer style", items = vizStyles, value = st, onValueChanged = { v -> onChange(c.copy(style = v)) })
    if (shape) ListPreference(title = "Artwork shape", items = listOf("Circle" to 0, "Rounded square" to 1, "Square" to 2), value = c.shape, onValueChanged = { v -> onChange(c.copy(shape = v)) })
    ListPreference(title = "Color", items = listOf("Solid" to 0, "Gradient" to 1, "From album art" to 2, "Rainbow" to 3, "Art palette" to 4), value = c.colorMode, onValueChanged = { v -> onChange(c.copy(colorMode = v)) })
    if (c.colorMode == 0 || c.colorMode == 1) ColorPreference("Color", c.color) { v -> onChange(c.copy(color = v)) }
    if (c.colorMode == 1) ColorPreference("Second color", c.color2) { v -> onChange(c.copy(color2 = v)) }
    if (st == 0 || st == 4) SliderPreference(title = "Bars", value = c.bars, min = 8, max = 64, onValueChanged = { v -> onChange(c.copy(bars = v)) }, label = { Text("$it") })
    if (st == 0 || st == 2 || st == 3) ListPreference(title = "Direction", items = listOf("Up" to 0, "Down" to 1, "Mirrored" to 2), value = c.vert, onValueChanged = { v -> onChange(c.copy(vert = v)) })
    if (st == 0 || st == 3) ListPreference(title = "Low end", items = listOf("Left" to 0, "Right" to 1, "Centre" to 2, "Edges" to 3), value = c.low, onValueChanged = { v -> onChange(c.copy(low = v)) })
    if (st == 4) SwitchPreference(title = "Slow spin", value = c.spin, onValueChanged = { v -> onChange(c.copy(spin = v)) })
    if (st == 2) SwitchPreference(title = "Glow", value = c.glow, onValueChanged = { v -> onChange(c.copy(glow = v)) })
    SliderPreference(title = "Sensitivity", value = c.sens, min = 0, max = 100, onValueChanged = { v -> onChange(c.copy(sens = v)) }, label = { Text("$it%") })
    SliderPreference(title = "Reach", value = c.reach, min = 10, max = 100, onValueChanged = { v -> onChange(c.copy(reach = v)) }, label = { Text("$it%") })
    SliderPreference(title = "Fall speed", value = c.fall, min = 10, max = 400, onValueChanged = { v -> onChange(c.copy(fall = v)) }, label = { Text("$it%") })
    SliderPreference(title = "Visualizer opacity", value = c.vizOp, min = 10, max = 100, onValueChanged = { v -> onChange(c.copy(vizOp = v)) }, label = { Text("$it%") })
    if (st <= 3) SliderPreference(title = "Visualizer height", value = c.vizHeight, min = 30, max = 130, onValueChanged = { v -> onChange(c.copy(vizHeight = v)) }, label = { Text("$it%") })
    SliderPreference(title = "Artwork opacity", value = c.artOp, min = 20, max = 100, onValueChanged = { v -> onChange(c.copy(artOp = v)) }, label = { Text("$it%") })
    SliderPreference(title = "Border opacity", value = c.borderOp, min = 0, max = 100, onValueChanged = { v -> onChange(c.copy(borderOp = v)) }, label = { Text("$it%") })
}

@Composable
fun ConfigureKvxVizWidget(widget: KvxVizWidget, onWidgetUpdated: (KvxVizWidget) -> Unit) {
    val c = widget.config
    fun upd(n: KvxVizWidgetConfig) = onWidgetUpdated(widget.copy(config = n))
    OutlinedCard {
        Column {
            ListPreference(title = "Layout", items = listOf("Artwork with visualizer" to 0, "Visualizer only (fills the width)" to 1, "Now playing card" to 2), value = c.layout, onValueChanged = { v -> upd(c.copy(layout = v)) })
            if (c.layout == 1) VizFillControls(c) { upd(it) }
            if (c.layout == 2) Text("The card's look is set in Settings > Visualizer > Bubble panel.", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(16.dp))
            if (c.layout == 0) {
            SwitchPreference(title = "Match the bubble's look", summary = "Uses your bubble and imported visualizer settings", value = c.followBubble, onValueChanged = { v -> upd(c.copy(followBubble = v)) })
            if (!c.followBubble) VizControls(c.viz, true) { v -> upd(c.copy(viz = v)) }
            SliderPreference(title = "Artwork size", value = c.size, min = 48, max = 220, onValueChanged = { v -> upd(c.copy(size = v)) }, label = { Text("$it dp") })
            ListPreference(title = "Position", items = listOf("Left" to 0, "Centre" to 1, "Right" to 2), value = c.align, onValueChanged = { v -> upd(c.copy(align = v)) })
            }
            PaddingControls(c.padTop, c.padBottom, c.padStart, c.padEnd) { t, b, s, e -> upd(c.copy(padTop = t, padBottom = b, padStart = s, padEnd = e)) }
        }
    }
}
