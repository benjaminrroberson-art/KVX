package de.mm20.launcher2.ui.theme

import android.content.Context
import android.view.View
import androidx.core.app.ActivityOptionsCompat
import de.mm20.launcher2.ui.R

/** How apps open from the launcher. */
object KvxLaunchAnim {
    val names = listOf("Default (grow from icon)", "Zoom in", "Fade", "Slide up", "None")

    private fun sp(ctx: Context) = ctx.applicationContext.getSharedPreferences("kvx_launch_anim", Context.MODE_PRIVATE)
    fun mode(ctx: Context): Int = sp(ctx).getInt("mode", 0)
    fun setMode(ctx: Context, v: Int) { sp(ctx).edit().putInt("mode", v).apply() }

    /** Moves the launcher's own window out of the way while the app opens (the system animation sits on top). */
    fun play(activity: android.app.Activity) {
        val v = activity.window?.decorView ?: return
        val m = mode(activity)
        if (m == 0 || m == 4) return
        v.animate().cancel()
        val a = v.animate().setDuration(240).setInterpolator(android.view.animation.AccelerateInterpolator())
        when (m) {
            1 -> a.scaleX(1.12f).scaleY(1.12f).alpha(0f)
            2 -> a.alpha(0f)
            3 -> a.translationY(-v.height * 0.05f).alpha(0f)
        }
        a.start()
    }

    /** Brings the launcher back in when you return to it. */
    fun restore(activity: android.app.Activity) {
        val v = activity.window?.decorView ?: return
        if (v.alpha == 1f && v.scaleX == 1f && v.translationY == 0f) return
        v.animate().cancel()
        v.pivotX = v.width / 2f; v.pivotY = v.height / 2f
        v.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f).setDuration(220)
            .setInterpolator(android.view.animation.DecelerateInterpolator()).start()
    }

    /** Null means "use the stock behaviour". */
    fun options(ctx: Context, view: View?, left: Int, top: Int, w: Int, h: Int): ActivityOptionsCompat? {
        return when (mode(ctx)) {
            1 -> ActivityOptionsCompat.makeCustomAnimation(ctx, R.anim.kvx_zoom_in, R.anim.kvx_zoom_out)
            2 -> ActivityOptionsCompat.makeCustomAnimation(ctx, R.anim.kvx_fade_in, R.anim.kvx_fade_out)
            3 -> ActivityOptionsCompat.makeCustomAnimation(ctx, R.anim.kvx_slide_up_in, R.anim.kvx_slide_up_out)
            4 -> ActivityOptionsCompat.makeCustomAnimation(ctx, R.anim.kvx_none, R.anim.kvx_none)
            else -> null
        }
    }
}
