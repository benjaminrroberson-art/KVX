package de.mm20.launcher2.ui.theme

import android.content.Context
import android.view.View
import androidx.core.app.ActivityOptionsCompat
import de.mm20.launcher2.ui.R

/** How apps open from the launcher. */
object KvxLaunchAnim {
    val names = listOf("Default (grow from icon)", "Zoom in", "Fade", "Slide up", "None")

    private fun sp(ctx: Context) = ctx.applicationContext.getSharedPreferences("kvx_launch_anim", Context.MODE_PRIVATE)
    fun mode(ctx: Context): Int = sp(ctx).getInt("mode", 0)
    fun setMode(ctx: Context, v: Int) { sp(ctx).edit().putInt("mode", v).apply() }

    /** Null means "use the stock behaviour". */
    fun options(ctx: Context, view: View?, left: Int, top: Int, w: Int, h: Int): ActivityOptionsCompat? {
        return when (mode(ctx)) {
            1 -> ActivityOptionsCompat.makeCustomAnimation(ctx, R.anim.kvx_zoom_in, R.anim.kvx_zoom_out)
            2 -> ActivityOptionsCompat.makeCustomAnimation(ctx, R.anim.kvx_fade_in, R.anim.kvx_fade_out)
            3 -> ActivityOptionsCompat.makeCustomAnimation(ctx, R.anim.kvx_slide_up_in, R.anim.kvx_slide_up_out)
            4 -> ActivityOptionsCompat.makeCustomAnimation(ctx, R.anim.kvx_none, R.anim.kvx_none)
            else -> null
        }
    }
}
