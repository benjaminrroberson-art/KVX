package de.mm20.launcher2.ui.songshare

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.text.Html
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

enum class Kind(val label: String, val entity: String) {
    SONG("Song", "song"),
    ALBUM("Album", "album"),
    ARTIST("Artist", "musicArtist")
}

enum class Svc(val label: String, val color: Int, val hosts: List<String>, val base: String) {
    APPLE("Apple Music", 0xFFFA243C.toInt(), listOf("music.apple.com", "itunes.apple.com"), "https://music.apple.com/us/search?term="),
    SPOTIFY("Spotify", 0xFF1DB954.toInt(), listOf("spotify.com", "spotify.link"), "https://open.spotify.com/search/"),
    YTM("YouTube Music", 0xFFE62117.toInt(), listOf("youtube.com", "youtu.be"), "https://music.youtube.com/search?q="),
    AMAZON("Amazon Music", 0xFF1BA8B3.toInt(), listOf("music.amazon", "amazon."), "https://music.amazon.com/search/"),
    TIDAL("Tidal", 0xFF3A4048.toInt(), listOf("tidal.com"), "https://tidal.com/search?q="),
    DEEZER("Deezer", 0xFFA238FF.toInt(), listOf("deezer.com", "deezer.page.link", "dzr.page.link"), "https://www.deezer.com/search/"),
    SOUNDCLOUD("SoundCloud", 0xFFFF5500.toInt(), listOf("soundcloud.com", "on.soundcloud"), "https://soundcloud.com/search?q=");

    fun search(q: String): String = base + Uri.encode(q)

    val canFind: Boolean get() = this != APPLE && this != DEEZER
}

data class Item(
    val kind: Kind,
    val title: String,
    val artist: String,
    val album: String,
    val art: String?,
    val appleUrl: String?
)

class LinkRow(val svc: Svc, val url: String, val exact: Boolean, val note: String)

object Resolver {
    class Result(val item: Item?, val source: Svc?, val origUrl: String?, val note: String)

    private const val UA =
        "Mozilla/5.0 (Linux; Android 14; Pixel) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"

    // ---------- network ----------

    fun get(url: String, ua: String = UA, timeout: Int = 8000): String? {
        return try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = timeout
            c.readTimeout = timeout
            c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", ua)
            c.setRequestProperty("Accept-Language", "en-US,en;q=0.9")
            if (c.responseCode !in 200..299) null
            else c.inputStream.bufferedReader().use { it.readText() }
        } catch (e: Exception) {
            null
        }
    }

    private fun getJson(url: String, ua: String = UA, timeout: Int = 8000): JSONObject? {
        val s = get(url, ua, timeout) ?: return null
        return try {
            JSONObject(s)
        } catch (e: Exception) {
            null
        }
    }

    fun bitmap(url: String): Bitmap? {
        return try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 8000
            c.readTimeout = 8000
            c.setRequestProperty("User-Agent", UA)
            c.inputStream.use { BitmapFactory.decodeStream(it) }
        } catch (e: Exception) {
            null
        }
    }

    // ---------- names ----------

    private fun norm(s: String): String = s.lowercase()
        .replace(Regex("\\s-\\s(single|ep)$"), "")
        .replace(Regex("\\(.*?\\)|\\[.*?\\]"), "")
        .replace("&", "and")
        .replace(Regex("[^\\p{L}\\p{N} ]"), "")
        .replace(Regex("\\s+"), " ")
        .trim()

    fun sameName(a: String, b: String): Boolean {
        val x = norm(a)
        val y = norm(b)
        return if (x.isEmpty() || y.isEmpty()) a.trim().equals(b.trim(), true) else x == y
    }

    private fun looseName(a: String, b: String): Boolean {
        if (sameName(a, b)) return true
        val x = norm(a)
        val y = norm(b)
        return x.isNotEmpty() && y.isNotEmpty() && (x.contains(y) || y.contains(x))
    }

    private fun unescape(s: String): String =
        Html.fromHtml(s, Html.FROM_HTML_MODE_LEGACY).toString().trim()

    fun query(i: Item): String =
        if (i.kind == Kind.ARTIST) i.title else listOf(i.title, i.artist).filter { it.isNotBlank() }.joinToString(" ")

    // ---------- identify what was shared ----------

    fun identify(text: String, subject: String?): Result {
        val url = Regex("https?://\\S+").find(text)?.value?.trimEnd('.', ',', ')', '"', '\'')
        var rest = text
        if (url != null) rest = rest.replace(url, " ")
        rest = rest.replace(Regex("\\s+"), " ").trim().trim('"', '“', '”')
        if (rest.isEmpty() && !subject.isNullOrBlank()) rest = subject.trim()

        val host = url?.let { Uri.parse(it).host?.lowercase() } ?: ""
        val src = Svc.values().firstOrNull { s -> s.hosts.any { host.contains(it) } }

        var guess: Item? = null
        var exact = false
        if (url != null) {
            guess = when (src) {
                Svc.APPLE -> apple(url).also { exact = it != null }
                Svc.SPOTIFY -> spotify(url)
                Svc.YTM -> youtube(url)
                else -> page(url)
            }
        }
        if (guess == null && rest.isNotEmpty()) guess = fromText(rest)
        if (guess == null) return Result(null, src, url, "")

        val from = src?.label ?: "shared text"
        if (exact) {
            return Result(guess, src, url, "Read straight from your Apple Music link.")
        }

        val term = query(guess)
        val found = try {
            search(term, guess.kind)
        } catch (e: Exception) {
            emptyList()
        }
        val g = guess
        val best = found.firstOrNull { sameName(it.title, g.title) && (g.artist.isBlank() || looseName(it.artist, g.artist)) }
            ?: found.firstOrNull { sameName(it.title, g.title) }
            ?: found.firstOrNull()

        val read = "From your $from link: “${g.title}”" + (if (g.artist.isNotBlank()) " by ${g.artist}" else "")
        return if (best == null) {
            Result(g, src, url, "$read. Couldn’t confirm it on Apple Music — check the details.")
        } else {
            Result(best, src, url, "$read. Matched on Apple Music.")
        }
    }

    private fun fromText(rest: String): Item {
        val m = Regex("^(.+?) by (.+)$", RegexOption.IGNORE_CASE).find(rest)
        return if (m != null) Item(Kind.SONG, m.groupValues[1].trim(), m.groupValues[2].trim(), "", null, null)
        else Item(Kind.SONG, rest, "", "", null, null)
    }

    private fun apple(url: String): Item? {
        val u = Uri.parse(url)
        val segs = u.pathSegments
        val cc = segs.firstOrNull()?.takeIf { it.length == 2 } ?: "us"
        val id = u.getQueryParameter("i")
            ?: segs.lastOrNull { it.isNotEmpty() && it.all { ch -> ch.isDigit() } }
            ?: return null
        val j = getJson("https://itunes.apple.com/lookup?id=$id&country=${cc.uppercase()}") ?: return null
        val arr = j.optJSONArray("results") ?: return null
        val r = arr.optJSONObject(0) ?: return null
        return fromItunes(r)
    }

    private fun spotify(url: String): Item? {
        val html = get(url)
        if (html != null) {
            val raw = Regex("<title>(.*?)</title>", RegexOption.DOT_MATCHES_ALL).find(html)?.groupValues?.get(1)
            if (raw != null) {
                val t = unescape(raw).removeSuffix("| Spotify").trim()
                Regex("^(.+) - song (?:and lyrics )?by (.+)$").find(t)?.let {
                    return Item(Kind.SONG, it.groupValues[1].trim(), it.groupValues[2].trim(), "", null, null)
                }
                Regex("^(.+) - (?:Album|Single|EP|Compilation) by (.+)$").find(t)?.let {
                    return Item(Kind.ALBUM, it.groupValues[1].trim(), it.groupValues[2].trim(), "", null, null)
                }
                if (Uri.parse(url).path?.contains("/artist/") == true && t.isNotBlank()) {
                    return Item(Kind.ARTIST, t, "", "", null, null)
                }
            }
        }
        val j = getJson("https://open.spotify.com/oembed?url=" + Uri.encode(url)) ?: return null
        val title = j.optString("title").trim()
        return if (title.isBlank()) null else Item(Kind.SONG, title, "", "", null, null)
    }

    private fun youtube(url: String): Item? {
        val u = Uri.parse(url)
        val v = u.getQueryParameter("v") ?: if ((u.host ?: "").contains("youtu.be")) u.lastPathSegment else null
        if (v == null) return null
        val j = getJson(
            "https://www.youtube.com/oembed?format=json&url=" + Uri.encode("https://www.youtube.com/watch?v=$v")
        ) ?: return null
        var title = j.optString("title").trim()
        var artist = j.optString("author_name").removeSuffix(" - Topic").replace(Regex("(?i)vevo$"), "").trim()
        title = title.replace(
            Regex("\\s*[\\(\\[](official|lyric|lyrics|audio|video|music video|visualizer|hd|4k)[^\\)\\]]*[\\)\\]]", RegexOption.IGNORE_CASE),
            ""
        ).trim()
        val p = title.split(" - ", limit = 2)
        if (p.size == 2) {
            val left = p[0].trim()
            if (artist.isBlank() || left.equals(artist, true) || artist.contains(left, true)) {
                title = p[1].trim()
            } else {
                artist = left
                title = p[1].trim()
            }
        }
        return if (title.isBlank()) null else Item(Kind.SONG, title, artist, "", null, null)
    }

    private fun page(url: String): Item? {
        val html = get(url) ?: return null
        val og = Regex("<meta[^>]+property=[\"']og:title[\"'][^>]+content=[\"']([^\"']*)[\"']", RegexOption.IGNORE_CASE)
            .find(html)?.groupValues?.get(1)
        val raw = og ?: Regex("<title>(.*?)</title>", RegexOption.DOT_MATCHES_ALL).find(html)?.groupValues?.get(1)
        ?: return null
        var t = unescape(raw)
        t = t.replace(
            Regex("\\s*[|\\u2013-]\\s*(Spotify|TIDAL|Tidal|Deezer|SoundCloud|Amazon Music|YouTube Music).*$"), ""
        ).replace(Regex("(?i)\\s+on\\s+(tidal|deezer|soundcloud)$"), "").trim()
        if (t.isBlank()) return null
        return fromText(t)
    }

    // ---------- iTunes ----------

    private fun fromItunes(r: JSONObject): Item? {
        fun art(): String? {
            val a = r.optString("artworkUrl100")
            return if (a.isBlank()) null else a.replace("100x100bb", "400x400bb")
        }
        return when (r.optString("wrapperType")) {
            "track" -> Item(
                Kind.SONG, r.optString("trackName"), r.optString("artistName"),
                r.optString("collectionName"), art(), r.optString("trackViewUrl").ifBlank { null }
            )
            "collection" -> Item(
                Kind.ALBUM, r.optString("collectionName"), r.optString("artistName"),
                "", art(), r.optString("collectionViewUrl").ifBlank { null }
            )
            "artist" -> Item(
                Kind.ARTIST, r.optString("artistName"), "", "", null,
                r.optString("artistLinkUrl").ifBlank { null }
            )
            else -> null
        }
    }

    fun search(term: String, kind: Kind): List<Item> {
        val j = getJson(
            "https://itunes.apple.com/search?media=music&limit=8&entity=${kind.entity}&term=" + Uri.encode(term)
        ) ?: return emptyList()
        val arr = j.optJSONArray("results") ?: return emptyList()
        val out = ArrayList<Item>()
        for (n in 0 until arr.length()) {
            val o = arr.optJSONObject(n) ?: continue
            val it = fromItunes(o) ?: continue
            if (it.kind == kind && it.title.isNotBlank()) out.add(it)
        }
        return out
    }

    // ---------- links for every service ----------

    class Dz(val link: String, val code: String?)

    private fun deezer(item: Item): Dz? {
        val t = item.title.replace("\"", " ")
        val a = item.artist.replace("\"", " ")
        val path: String
        val q: String
        when (item.kind) {
            Kind.SONG -> { path = "track"; q = if (a.isBlank()) t else "artist:\"$a\" track:\"$t\"" }
            Kind.ALBUM -> { path = "album"; q = if (a.isBlank()) t else "artist:\"$a\" album:\"$t\"" }
            Kind.ARTIST -> { path = "artist"; q = t }
        }
        val j = getJson("https://api.deezer.com/search/$path?limit=4&q=" + Uri.encode(q)) ?: return null
        val arr = j.optJSONArray("data") ?: return null
        for (n in 0 until arr.length()) {
            val o = arr.optJSONObject(n) ?: continue
            val name = if (item.kind == Kind.ARTIST) o.optString("name") else o.optString("title")
            if (!sameName(name, item.title)) continue
            if (item.kind != Kind.ARTIST && item.artist.isNotBlank()) {
                val an = o.optJSONObject("artist")?.optString("name") ?: ""
                if (!looseName(an, item.artist)) continue
            }
            val link = o.optString("link").substringBefore("?")
            if (link.isBlank()) continue
            val id = o.optLong("id")
            var code: String? = null
            try {
                if (item.kind == Kind.SONG) {
                    code = getJson("https://api.deezer.com/track/$id")?.optString("isrc")?.takeIf { it.isNotBlank() }
                } else if (item.kind == Kind.ALBUM) {
                    code = getJson("https://api.deezer.com/album/$id")?.optString("upc")?.takeIf { it.isNotBlank() }
                }
            } catch (e: Exception) {
            }
            return Dz(link, code)
        }
        return null
    }

    // ---- MusicBrainz: ISRC/UPC -> streaming links other services' IDs ----

    private const val MB = "https://musicbrainz.org/ws/2/"
    private const val MB_UA = "SongShare/1.0 (personal Android app)"
    private var mbLast = 0L

    private fun mb(path: String): JSONObject? {
        synchronized(this) {
            val wait = 1100 - (System.currentTimeMillis() - mbLast)
            if (wait > 0) Thread.sleep(wait)
            mbLast = System.currentTimeMillis()
        }
        val sep = if (path.contains("?")) "&" else "?"
        return getJson(MB + path + sep + "fmt=json", MB_UA, 10000)
    }

    private fun relUrls(o: JSONObject?): List<String> {
        val arr = o?.optJSONArray("relations") ?: return emptyList()
        val out = ArrayList<String>()
        for (n in 0 until arr.length()) {
            val r = arr.optJSONObject(n) ?: continue
            val u = r.optJSONObject("url")?.optString("resource") ?: continue
            if (u.isNotBlank()) out.add(u)
        }
        return out
    }

    private fun classify(u: String): Pair<Svc, Kind>? {
        val x = Uri.parse(u)
        val host = (x.host ?: "").lowercase()
        val path = x.path ?: ""
        val svc = when {
            host.endsWith("open.spotify.com") -> Svc.SPOTIFY
            host.endsWith("tidal.com") -> Svc.TIDAL
            host.contains("music.amazon") -> Svc.AMAZON
            host.endsWith("soundcloud.com") -> Svc.SOUNDCLOUD
            host == "music.youtube.com" -> Svc.YTM
            else -> return null
        }
        val lvl: Kind = when {
            path.contains("/track/") || path.contains("/tracks/") || path.startsWith("/watch") -> Kind.SONG
            path.contains("/album/") || path.contains("/albums/") || path.contains("/playlist") || path.contains("/sets/") -> Kind.ALBUM
            path.contains("/artist/") || path.contains("/artists/") || path.contains("/channel/") -> Kind.ARTIST
            svc == Svc.SOUNDCLOUD -> if (x.pathSegments.size >= 2) Kind.SONG else Kind.ARTIST
            else -> return null
        }
        return Pair(svc, lvl)
    }

    // Pair = (url, isExactForWhatWasShared)
    private fun mbLinks(item: Item, code: String?): Map<Svc, Pair<String, Boolean>> {
        val found = HashMap<Svc, Pair<String, Boolean>>()
        fun collect(urls: List<String>) {
            for (u in urls) {
                val c = classify(u) ?: continue
                val svc = c.first
                if (c.second == item.kind) {
                    found[svc] = Pair(u.substringBefore("?"), true)
                } else if (item.kind == Kind.SONG && c.second == Kind.ALBUM && !found.containsKey(svc)) {
                    found[svc] = Pair(u.substringBefore("?"), false)
                }
            }
        }
        val t = item.title.replace("\"", " ")
        val a = item.artist.replace("\"", " ")
        when (item.kind) {
            Kind.SONG -> {
                var recId: String? = null
                if (code != null) {
                    val arr = mb("isrc/$code")?.optJSONArray("recordings")
                    if (arr != null) {
                        for (n in 0 until arr.length()) {
                            val o = arr.optJSONObject(n) ?: continue
                            if (recId == null || sameName(o.optString("title"), item.title)) recId = o.optString("id")
                            if (sameName(o.optString("title"), item.title)) break
                        }
                    }
                }
                if (recId == null) {
                    val qq = if (a.isBlank()) "recording:\"$t\"" else "recording:\"$t\" AND artist:\"$a\""
                    val arr = mb("recording?limit=3&query=" + Uri.encode(qq))?.optJSONArray("recordings")
                    if (arr != null) {
                        for (n in 0 until arr.length()) {
                            val o = arr.optJSONObject(n) ?: continue
                            if (sameName(o.optString("title"), item.title)) { recId = o.optString("id"); break }
                        }
                    }
                }
                if (recId == null) return found
                val rec = mb("recording/$recId?inc=url-rels+releases")
                collect(relUrls(rec))
                val rels = rec?.optJSONArray("releases")
                var relId: String? = null
                if (rels != null) {
                    for (n in 0 until rels.length()) {
                        val o = rels.optJSONObject(n) ?: continue
                        if (item.album.isNotBlank() && sameName(o.optString("title"), item.album)) { relId = o.optString("id"); break }
                        if (relId == null) relId = o.optString("id")
                    }
                }
                if (relId != null) collect(relUrls(mb("release/$relId?inc=url-rels")))
            }
            Kind.ALBUM -> {
                val qq = if (code != null) "barcode:$code"
                else if (a.isBlank()) "release:\"$t\"" else "release:\"$t\" AND artist:\"$a\""
                val arr = mb("release?limit=5&query=" + Uri.encode(qq))?.optJSONArray("releases")
                if (arr != null) {
                    for (n in 0 until arr.length()) {
                        val o = arr.optJSONObject(n) ?: continue
                        if (sameName(o.optString("title"), item.title)) {
                            collect(relUrls(mb("release/" + o.optString("id") + "?inc=url-rels")))
                            break
                        }
                    }
                }
            }
            Kind.ARTIST -> {
                val arr = mb("artist?limit=3&query=" + Uri.encode("artist:\"$t\""))?.optJSONArray("artists")
                if (arr != null) {
                    for (n in 0 until arr.length()) {
                        val o = arr.optJSONObject(n) ?: continue
                        if (sameName(o.optString("name"), item.title)) {
                            collect(relUrls(mb("artist/" + o.optString("id") + "?inc=url-rels")))
                            break
                        }
                    }
                }
            }
        }
        return found
    }

    // ---- YouTube Music via keyless Piped / Invidious instances ----

    private val pipedHosts = listOf(
        "https://pipedapi.kavin.rocks",
        "https://pipedapi.adminforge.de",
        "https://api.piped.private.coffee"
    )
    private val invHosts = listOf(
        "https://inv.nadeko.net",
        "https://yewtu.be",
        "https://invidious.nerdvpn.de"
    )

    // ---- YouTube Music: its own search endpoint (no account, no key of ours) ----

    private fun post(url: String, body: String, timeout: Int = 8000): String? {
        return try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.doOutput = true
            c.connectTimeout = timeout
            c.readTimeout = timeout
            c.setRequestProperty("User-Agent", UA)
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("Origin", "https://music.youtube.com")
            c.setRequestProperty("Referer", "https://music.youtube.com/")
            c.outputStream.use { it.write(body.toByteArray()) }
            if (c.responseCode !in 200..299) null
            else c.inputStream.bufferedReader().use { it.readText() }
        } catch (e: Exception) {
            null
        }
    }

    private fun collectKey(o: Any?, key: String, out: MutableList<JSONObject>) {
        when (o) {
            is JSONObject -> {
                val ks = o.keys()
                while (ks.hasNext()) {
                    val k = ks.next()
                    val v = o.opt(k)
                    if (k == key && v is JSONObject) out.add(v) else collectKey(v, key, out)
                }
            }
            is org.json.JSONArray -> for (n in 0 until o.length()) collectKey(o.opt(n), key, out)
        }
    }

    private fun findFirst(o: Any?, key: String): String? {
        when (o) {
            is JSONObject -> {
                val ks = o.keys()
                while (ks.hasNext()) {
                    val k = ks.next()
                    val v = o.opt(k)
                    if (k == key && v is String && v.isNotBlank()) return v
                    val r = findFirst(v, key)
                    if (r != null) return r
                }
            }
            is org.json.JSONArray -> for (n in 0 until o.length()) {
                val r = findFirst(o.opt(n), key)
                if (r != null) return r
            }
        }
        return null
    }

    private fun runsText(col: JSONObject?): String {
        val runs = col?.optJSONObject("musicResponsiveListItemFlexColumnRenderer")
            ?.optJSONObject("text")?.optJSONArray("runs") ?: return ""
        val sb = StringBuilder()
        for (n in 0 until runs.length()) sb.append(runs.optJSONObject(n)?.optString("text") ?: "")
        return sb.toString()
    }

    private class Yt(val ok: Boolean, val link: String?)

    private fun innertube(item: Item): Yt {
        val params = when (item.kind) {
            Kind.SONG -> "EgWKAQIIAWoMEA4QChADEAQQCRAF"
            Kind.ALBUM -> "EgWKAQIYAWoMEA4QChADEAQQCRAF"
            Kind.ARTIST -> "EgWKAQIgAWoMEA4QChADEAQQCRAF"
        }
        val client = JSONObject().put("clientName", "WEB_REMIX").put("clientVersion", "1.20250310.01.00")
            .put("hl", "en").put("gl", "US")
        val body = JSONObject().put("context", JSONObject().put("client", client))
            .put("query", query(item)).put("params", params).toString()
        val txt = post(
            "https://music.youtube.com/youtubei/v1/search?prettyPrint=false&key=AIzaSyC9XL3ZjWddXya6X74dJoCTL-WEYFDNX30",
            body
        ) ?: return Yt(false, null)
        val root = try { JSONObject(txt) } catch (e: Exception) { return Yt(false, null) }
        val items = ArrayList<JSONObject>()
        collectKey(root, "musicResponsiveListItemRenderer", items)
        if (items.isEmpty()) return Yt(false, null)
        for (r in items) {
            val fc = r.optJSONArray("flexColumns") ?: continue
            val title = runsText(fc.optJSONObject(0))
            val sub = runsText(fc.optJSONObject(1))
            if (title.isBlank() || !looseName(title, item.title)) continue
            val artistOk = item.artist.isBlank() || norm(sub).contains(norm(firstArtist(item.artist)))
            val bid = r.optJSONObject("navigationEndpoint")?.optJSONObject("browseEndpoint")?.optString("browseId") ?: ""
            when (item.kind) {
                Kind.SONG -> {
                    val vid = findFirst(r, "videoId") ?: continue
                    if (artistOk) return Yt(true, "https://music.youtube.com/watch?v=$vid")
                }
                Kind.ALBUM -> if (bid.startsWith("MPRE") && artistOk) return Yt(true, "https://music.youtube.com/browse/$bid")
                Kind.ARTIST -> if (bid.startsWith("UC")) return Yt(true, "https://music.youtube.com/channel/$bid")
            }
        }
        return Yt(true, null)
    }

    private fun ytmLink(item: Item): String? {
        val r = try { innertube(item) } catch (e: Exception) { Yt(false, null) }
        if (r.ok) return r.link
        return ytmFallback(item)
    }

    private fun ytmFallback(item: Item): String? {
        val q = query(item)
        val filter = when (item.kind) {
            Kind.SONG -> "music_songs"
            Kind.ALBUM -> "music_albums"
            Kind.ARTIST -> "music_artists"
        }
        for (h in pipedHosts) {
            val j = getJson("$h/search?filter=$filter&q=" + Uri.encode(q), UA, 6000) ?: continue
            val arr = j.optJSONArray("items") ?: continue
            for (n in 0 until arr.length()) {
                val o = arr.optJSONObject(n) ?: continue
                val u = o.optString("url")
                if (u.isBlank()) continue
                val title = if (item.kind == Kind.ARTIST) o.optString("name").ifBlank { o.optString("title") } else o.optString("title")
                if (!looseName(title, item.title)) continue
                if (item.kind == Kind.SONG && item.artist.isNotBlank()) {
                    val up = o.optString("uploaderName")
                    if (up.isNotBlank() && !looseName(up, item.artist)) continue
                }
                return "https://music.youtube.com$u"
            }
            return null
        }
        if (item.kind == Kind.SONG) {
            for (h in invHosts) {
                val s = get("$h/api/v1/search?type=video&q=" + Uri.encode(q), UA, 6000) ?: continue
                val arr = try { org.json.JSONArray(s) } catch (e: Exception) { continue }
                for (n in 0 until arr.length()) {
                    val o = arr.optJSONObject(n) ?: continue
                    val id = o.optString("videoId")
                    if (id.isBlank() || !looseName(o.optString("title"), item.title)) continue
                    val au = o.optString("author")
                    if (item.artist.isNotBlank() && au.isNotBlank() && !looseName(au, item.artist)) continue
                    return "https://music.youtube.com/watch?v=$id"
                }
                return null
            }
        }
        return null
    }

    private fun clean(s: Svc, url: String): String =
        if (s == Svc.SPOTIFY) url.substringBefore('?') else url

    fun rows(item: Item, src: Svc?, orig: String?): List<LinkRow> {
        val q = query(item)
        var ytm: String? = null
        val skipYt = src == Svc.YTM && orig != null
        val yt = Thread {
            ytm = try { ytmLink(item) } catch (e: Exception) { null }
        }
        if (!skipYt) yt.start()
        val dz = try { deezer(item) } catch (e: Exception) { null }
        val mbMap = try { mbLinks(item, dz?.code) } catch (e: Exception) { emptyMap() }
        if (!skipYt) yt.join(15000)
        val ytmL = ytm
        val ap = item.appleUrl?.takeIf { it.isNotBlank() }
        return Svc.values().map { s ->
            when {
                s == src && orig != null -> LinkRow(s, clean(s, orig), true, "Original link (as shared)")
                s == Svc.APPLE && ap != null -> LinkRow(s, ap, true, "Direct link")
                s == Svc.DEEZER && dz != null -> LinkRow(s, dz.link, true, "Direct link")
                s == Svc.YTM && ytmL != null -> LinkRow(s, ytmL, true, "Direct link")
                else -> {
                    val m = mbMap[s]
                    if (m != null) {
                        LinkRow(s, m.first, m.second, if (m.second) "Direct link" else "Album link \u00B7 track not found")
                    } else {
                        LinkRow(s, s.search(q), false, "Search link \u00B7 opens a search, not the song")
                    }
                }
            }
        }
    }

    // ---------- what's playing -> match ----------

    fun svcForPackage(p: String): Svc? = when {
        p.contains("apple.android.music") -> Svc.APPLE
        p.contains("spotify") -> Svc.SPOTIFY
        p.contains("apps.youtube.music") -> Svc.YTM
        p.contains("amazon") -> Svc.AMAZON
        p.contains("tidal") -> Svc.TIDAL
        p.contains("deezer") -> Svc.DEEZER
        p.contains("soundcloud") -> Svc.SOUNDCLOUD
        else -> null
    }

    fun identifyMeta(title: String, artist: String, album: String, src: Svc?): Result {
        val g = Item(Kind.SONG, title, artist, album, null, null)
        val found = try { search(query(g), Kind.SONG) } catch (e: Exception) { emptyList() }
        val best = found.firstOrNull { sameName(it.title, title) && (artist.isBlank() || looseName(it.artist, artist)) }
            ?: found.firstOrNull { sameName(it.title, title) }
            ?: found.firstOrNull()
        val from = src?.label ?: "your player"
        val read = "From $from: \u201C$title\u201D" + (if (artist.isNotBlank()) " by $artist" else "")
        return if (best == null) Result(g, src, null, "$read. Couldn\u2019t confirm it on Apple Music \u2014 check the details.")
        else Result(best, src, null, "$read. Matched on Apple Music.")
    }

    // ---------- try harder: web search restricted to one service ----------

    private fun firstArtist(a: String): String =
        a.split(Regex("\\s*(,|&|feat\\.?|ft\\.?|\\bx\\b)\\s*"), limit = 2)[0].trim()

    fun findExact(item: Item, svc: Svc): String? {
        if (svc == Svc.YTM) return ytmLink(item)
        val site = when (svc) {
            Svc.SPOTIFY -> "open.spotify.com"
            Svc.YTM -> "music.youtube.com"
            Svc.TIDAL -> "tidal.com"
            Svc.AMAZON -> "music.amazon.com"
            Svc.SOUNDCLOUD -> "soundcloud.com"
            Svc.DEEZER -> "deezer.com"
            Svc.APPLE -> "music.apple.com"
        }
        val t = item.title.replace("\"", " ")
        val a = item.artist.replace("\"", " ")
        val q = "site:$site \"$t\"" + (if (a.isNotBlank() && item.kind != Kind.ARTIST) " \"$a\"" else "")
        val html = get("https://html.duckduckgo.com/html/?q=" + Uri.encode(q), UA, 10000) ?: return null
        val re = Regex("<a\\s[^>]*class=\"result__a\"[^>]*>(.*?)</a>", RegexOption.DOT_MATCHES_ALL)
        for (m in re.findAll(html)) {
            var href = Regex("href=\"([^\"]+)\"").find(m.value)?.groupValues?.get(1) ?: continue
            href = unescape(href)
            if (href.startsWith("//")) href = "https:$href"
            val real = Uri.parse(href).getQueryParameter("uddg") ?: href
            val rtitle = unescape(m.groupValues[1].replace(Regex("<[^>]+>"), ""))
            val c = classify(real) ?: continue
            if (c.first != svc || c.second != item.kind) continue
            val nt = norm(rtitle)
            if (!nt.contains(norm(item.title))) continue
            if (item.kind != Kind.ARTIST && item.artist.isNotBlank() && !nt.contains(norm(firstArtist(item.artist)))) continue
            return real.substringBefore("?")
        }
        return null
    }
}
