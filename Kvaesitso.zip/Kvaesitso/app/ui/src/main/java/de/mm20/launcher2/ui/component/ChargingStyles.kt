package de.mm20.launcher2.ui.component

import androidx.compose.animation.core.withInfiniteAnimationFrameMillis
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.isActive
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

val chargingStyleNames = listOf("Bubbles", "Edge rise", "Ripples", "Fireflies", "Rising wave", "Sweep") + chargingStyleNamesExtra

private fun frac(x: Float) = x - kotlin.math.floor(x)
private fun hash(i: Int) = frac(sin(i * 12.9898f) * 43758.547f)

/** Charging effects other than the stock bubbles. intensity is roughly the charge current in 100 mA steps. */
@Composable
fun ChargingStyleCanvas(style: Int, intensity: Int, modifier: Modifier = Modifier) {
    var t by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(intensity > 0) {
        if (intensity <= 0) return@LaunchedEffect
        while (isActive) {
            withInfiniteAnimationFrameMillis { t = it / 1000f }
        }
    }
    if (intensity <= 0) return
    val k = (intensity / 10f).coerceIn(0.4f, 2f)
    val context = androidx.compose.ui.platform.LocalContext.current
    val mode = de.mm20.launcher2.ui.launcher.widgets.facesclock.KvxSettings.chargingColorMode(context)
    val custom = Color(de.mm20.launcher2.ui.launcher.widgets.facesclock.KvxSettings.chargingColor(context))
    val accent = androidx.compose.material3.MaterialTheme.colorScheme.primary
    Canvas(modifier) {
        val tint = when (mode) {
            1 -> custom
            2 -> accent
            3 -> Color.hsv((t * 40f) % 360f, 0.6f, 1f)
            else -> Color.White
        }
        val w = size.width
        val h = size.height
        val d = 1.dp.toPx()
        when (style) {
            1 -> {
                val n = (intensity.coerceIn(3, 12))
                for (side in 0..1) {
                    val x = if (side == 0) 2 * d else w - 2 * d
                    for (i in 0 until n) {
                        val pos = frac(t * 0.25f * k + i / n.toFloat() + side * 0.37f)
                        val y = h - pos * h
                        drawLine(tint.copy(alpha = (1f - pos) * 0.8f), Offset(x, y), Offset(x, y - 44 * d), 3 * d, StrokeCap.Round)
                    }
                }
            }
            2 -> {
                val n = (2 + intensity / 5).coerceIn(2, 5)
                for (i in 0 until n) {
                    val ph = frac(t * 0.35f * k + i / n.toFloat())
                    drawCircle(tint.copy(alpha = (1f - ph) * 0.5f), ph * w * 0.7f, Offset(w / 2f, h), style = Stroke(2 * d))
                }
            }
            3 -> {
                val n = (intensity * 3).coerceIn(6, 36)
                for (i in 0 until n) {
                    val life = frac(t * (0.12f + hash(i) * 0.12f) * k + hash(i + 100))
                    val x = w * hash(i + 50) + sin((t + i) * 1.3f) * 14 * d
                    val y = h - life * h * 0.55f
                    drawCircle(tint.copy(alpha = (1f - life) * 0.9f), (1.5f + hash(i + 7) * 2f) * d, Offset(x, y))
                }
            }
            4 -> {
                val amp = (3 + intensity / 3f).coerceAtMost(10f) * d
                val base = h - 6 * d
                val p = Path()
                p.moveTo(0f, h)
                var x = 0f
                while (x <= w) {
                    p.lineTo(x, base - amp * sin(x / (36 * d) + t * 2.5f * k))
                    x += 6 * d
                }
                val line = Path().apply { addPath(p) }
                p.lineTo(w, h); p.close()
                drawPath(p, tint.copy(alpha = 0.12f))
                drawPath(line, tint.copy(alpha = 0.6f), style = Stroke(2 * d, cap = StrokeCap.Round))
            }
            5 -> {
                val ph = frac(t * 0.3f * k)
                val pp = if (ph < 0.5f) ph * 2f else (1f - ph) * 2f
                val cx = pp * w
                for (i in 0 until 6) {
                    val dir = if (ph < 0.5f) -1 else 1
                    val x = cx + dir * i * 14 * d
                    drawLine(tint.copy(alpha = (1f - i / 6f) * 0.8f), Offset(x, h - 3 * d), Offset(x + dir * -12 * d, h - 3 * d), 3 * d, StrokeCap.Round)
                }
            }
            else -> if (style >= 6) drawChargingExtra(style, t, k, intensity, tint)
        }
    }
}
