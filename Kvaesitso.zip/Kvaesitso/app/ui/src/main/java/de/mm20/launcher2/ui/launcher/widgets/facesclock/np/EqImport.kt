package de.mm20.launcher2.ui.launcher.widgets.facesclock.np

import kotlin.math.abs

/** Best-effort import of EQ presets from text: Equalizer APO lines, "freq gain Q" lines, or XML. */
object EqImport {
    class Result(val bands: List<EqEngine.Band>, val preampDb: Float?)

    private fun typeOf(s: String): Int {
        val t = s.lowercase().replace(Regex("[^a-z]"), "")
        return when {
            t == "ls" || t == "lsc" || t.contains("lowshelf") || t.contains("lshelf") -> 1
            t == "hs" || t == "hsc" || t.contains("highshelf") || t.contains("hshelf") -> 2
            t == "hp" || t == "hpq" || t.contains("highpass") || t.contains("lowcut") -> 3
            t == "lp" || t == "lpq" || t.contains("lowpass") || t.contains("highcut") -> 4
            else -> 0
        }
    }

    fun parse(text: String): Result? {
        val oz = parseOzone(text)
        if (oz != null && oz.bands.isNotEmpty()) return oz
        val a = parseApo(text)
        if (a != null && a.bands.isNotEmpty()) return a
        val b = parseNumbers(text)
        if (b != null && b.bands.isNotEmpty()) return b
        val c = parseXml(text)
        if (c != null && c.bands.isNotEmpty()) return c
        return null
    }

    /**
     * iZotope Ozone preset XML: <Param ElementID="Equalizer" ParamID="Band 3 Gain" Value="3.5" />.
     * Ozone leaves out settings that are at their default, so: a band is only on if "Enable" is 1;
     * a missing shape means the band's default (band 1 low shelf, band 8 high shelf, others bell).
     * Shape 0 and 16 are treated as bell.
     */
    private fun parseOzone(text: String): Result? {
        if (!text.contains("<OzoneMS")) return null
        val block = Regex("(?s)<EQ\\b[^>]*>(.*?)</EQ>").find(text)?.groupValues?.get(1) ?: return null
        class Acc { var f: Float? = null; var g: Float? = null; var q: Float? = null; var shape: Int? = null; var on = false }
        val map = java.util.TreeMap<Int, Acc>()
        val re = Regex("""ParamID\s*=\s*"Band\s+(\d+)\s+([A-Za-z ]+?)"\s+Value\s*=\s*"([^"]*)"\s*/?>""")
        for (m in re.findAll(block)) {
            val idx = m.groupValues[1].toIntOrNull() ?: continue
            val v = m.groupValues[3].trim().toFloatOrNull() ?: continue
            val a = map.getOrPut(idx) { Acc() }
            when (m.groupValues[2].trim().lowercase()) {
                "frequency" -> a.f = v
                "gain" -> a.g = v
                "q" -> a.q = v
                "shape" -> a.shape = v.toInt()
                "enable" -> a.on = v >= 0.5f
            }
        }
        val out = ArrayList<EqEngine.Band>()
        for ((idx, a) in map) {
            if (!a.on) continue
            val f = a.f ?: continue
            val g = a.g ?: continue
            val q = a.q ?: 0.71f
            val t = if (a.shape != null) 0 else when (idx) { 1 -> 1; 8 -> 2; else -> 0 }
            out.add(EqEngine.Band(t, f, g, q))
        }
        return Result(out, null)
    }

    // Filter 1: ON PK Fc 1000 Hz Gain -3.0 dB Q 1.41
    private fun parseApo(text: String): Result? {
        val re = Regex("""(?i)Filter\s*\d*\s*:\s*ON\s+(\w+)\s+Fc\s+([\d.]+)\s*Hz(?:\s+Gain\s+(-?[\d.]+)\s*dB)?(?:\s+Q\s+([\d.]+))?""")
        val out = ArrayList<EqEngine.Band>()
        for (m in re.findAll(text)) {
            val t = typeOf(m.groupValues[1])
            val f = m.groupValues[2].toFloatOrNull() ?: continue
            val g = m.groupValues[3].toFloatOrNull() ?: 0f
            val q = m.groupValues[4].toFloatOrNull() ?: 0.707f
            out.add(EqEngine.Band(t, f, g, q))
        }
        val pre = Regex("""(?i)Preamp\s*:\s*(-?[\d.]+)\s*dB""").find(text)?.groupValues?.get(1)?.toFloatOrNull()
        return Result(out, pre)
    }

    // "freq gain q" per line (comma, tab or space separated)
    private fun parseNumbers(text: String): Result? {
        val out = ArrayList<EqEngine.Band>()
        for (line in text.lines()) {
            if (line.contains("<") || line.contains("=")) continue
            val nums = Regex("""-?\d+(?:\.\d+)?""").findAll(line).map { it.value.toFloat() }.toList()
            if (nums.size < 2 || nums.size > 4) continue
            val f = nums[0]
            if (f < 10f || f > 24000f) continue
            val g = nums[1]
            if (abs(g) > 30f) continue
            val q = if (nums.size >= 3) nums[2] else 1.41f
            val t = typeOf(line.replace(Regex("""[-\d.,\s]+"""), " "))
            out.add(EqEngine.Band(t, f, g, if (q > 0f) q else 1.41f))
        }
        return Result(out, null)
    }

    // XML: collect name/value pairs, then group them by the number in the name (band index).
    private fun parseXml(text: String): Result? {
        if (!text.contains("<")) return null
        val pairs = ArrayList<Pair<String, String>>()
        // <PARAM id="Band1Frequency" value="1000"/>  /  <Parameter name=".." value=".."/>
        for (m in Regex("""<[^>]*?(?:id|name|ID|Name)\s*=\s*"([^"]+)"[^>]*?(?:value|Value)\s*=\s*"([^"]*)"[^>]*>""").findAll(text)) {
            pairs.add(m.groupValues[1] to m.groupValues[2])
        }
        // attributes like Band1Frequency="1000"
        for (m in Regex("""([A-Za-z_][\w.\-]*\d[\w.\-]*)\s*=\s*"([^"]*)"(?=[\s/>])""").findAll(text)) {
            pairs.add(m.groupValues[1] to m.groupValues[2])
        }
        // <Band1Frequency>1000</Band1Frequency>
        for (m in Regex("""<([A-Za-z_][\w.\-]*)>\s*([^<\s][^<]*?)\s*</\1>""").findAll(text)) {
            pairs.add(m.groupValues[1] to m.groupValues[2])
        }
        class Acc { var f: Float? = null; var g: Float? = null; var q: Float? = null; var t = 0; var off = false }
        val map = LinkedHashMap<String, Acc>()
        for ((k0, v) in pairs) {
            val k = k0.lowercase()
            val idx = Regex("""\d+""").findAll(k).lastOrNull()?.value ?: continue
            val field = when {
                k.contains("freq") -> "f"
                k.contains("gain") -> "g"
                k.contains("qfactor") || k.contains("quality") || k.endsWith("q") || k.contains("_q") || k.contains("width") -> "q"
                k.contains("type") || k.contains("shape") || k.contains("mode") -> "t"
                k.contains("bypass") || k.contains("enable") || k.contains("active") -> "e"
                else -> continue
            }
            val acc = map.getOrPut(idx) { Acc() }
            val num = v.trim().toFloatOrNull()
            when (field) {
                "f" -> acc.f = num
                "g" -> acc.g = num
                "q" -> acc.q = num
                "t" -> acc.t = if (num != null) 0 else typeOf(v)
                "e" -> {
                    val on = v.trim().lowercase()
                    val isBypass = k.contains("bypass")
                    val truthy = on == "1" || on == "true" || on == "on"
                    acc.off = if (isBypass) truthy else !truthy
                }
            }
        }
        val out = ArrayList<EqEngine.Band>()
        for ((_, a) in map) {
            val f = a.f ?: continue
            if (f < 10f || f > 24000f) continue
            val g = a.g ?: continue
            if (abs(g) > 30f || a.off) continue
            out.add(EqEngine.Band(a.t, f, g, a.q?.takeIf { it > 0f } ?: 1.41f))
        }
        return Result(out, null)
    }
}
